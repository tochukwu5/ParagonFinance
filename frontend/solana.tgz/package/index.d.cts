/**
 * Copyright (c) 2026, Circle Internet Group, Inc. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { TransactionInstruction, Signer, AddressLookupTableAccount, Connection } from '@solana/web3.js';
import { Abi } from 'abitype';
import { AnchorProvider } from '@coral-xyz/anchor';

/**
 * @packageDocumentation
 * @module ChainDefinitions
 *
 * This module provides a complete type system for blockchain chain definitions.
 * It supports both EVM and non‑EVM chains, token configurations, and multiple
 * versions of the Cross-Chain Transfer Protocol (CCTP). Additionally, utility types
 * are provided to extract subsets of chains (e.g. chains supporting USDC, EURC, or specific
 * CCTP versions) from a provided collection.
 *
 * All types are fully documented with TSDoc to maximize developer experience.
 */
/**
 * Represents basic information about a currency or token.
 * @category Types
 * @description Provides the essential properties of a cryptocurrency or token.
 * @example
 * ```typescript
 * const ethCurrency: Currency = {
 *   name: "Ether",
 *   symbol: "ETH",
 *   decimals: 18
 * };
 * ```
 */
interface Currency {
    /**
     * The full name of the currency.
     * @example "Ether", "USDC"
     */
    name: string;
    /**
     * The symbol or ticker of the currency.
     * @example "ETH", "USDC"
     */
    symbol: string;
    /**
     * The number of decimal places for the currency.
     * @description Defines the divisibility of the currency (e.g., 1 ETH = 10^18 wei).
     * @example 18 for ETH, 6 for USDC
     */
    decimals: number;
}
/**
 * Base information that all chain definitions must include.
 * @category Types
 * @description Provides the common properties shared by all blockchain definitions.
 * @example
 * ```typescript
 * const baseChain: BaseChainDefinition = {
 *   chain: Blockchain.Ethereum,
 *   name: "Ethereum",
 *   nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
 *   isTestnet: false
 * };
 * ```
 */
interface BaseChainDefinition {
    /**
     * The blockchain identifier from the {@link Blockchain} enum.
     */
    chain: Blockchain;
    /**
     * The display name of the blockchain.
     * @example "Ethereum", "Solana", "Avalanche"
     */
    name: string;
    /**
     * Optional title or alternative name for the blockchain.
     * @example "Ethereum Mainnet", "Solana Mainnet"
     */
    title?: string;
    /**
     * Information about the native currency of the blockchain.
     */
    nativeCurrency: Currency;
    /**
     * Indicates whether this is a testnet or mainnet.
     * @description Used to differentiate between production and testing environments.
     */
    isTestnet: boolean;
    /**
     * Template URL for the blockchain explorer to view transactions.
     * @description URL template with a `\{hash\}` placeholder for transaction hash.
     * @example "https://etherscan.io/tx/\{hash\}", "https://sepolia.etherscan.io/tx/\{hash\}"
     */
    explorerUrl: string;
    /**
     * Default RPC endpoints for connecting to the blockchain network.
     * @description Array of reliable public RPC endpoints that can be used for read and write operations.
     * The first endpoint in the array is considered the primary endpoint.
     * @example ["https://cloudflare-eth.com", "https://ethereum.publicnode.com"]
     */
    rpcEndpoints: readonly string[];
    /**
     * The contract address for EURC.
     * @description Its presence indicates that EURC is supported.
     */
    eurcAddress: string | null;
    /**
     * The contract address for USDC.
     * @description Its presence indicates that USDC is supported.
     */
    usdcAddress: string | null;
    /**
     * The contract address for USDT.
     * @description Its presence indicates that USDT is supported.
     */
    usdtAddress: string | null;
    /**
     * Optional CCTP configuration.
     * @description If provided, the chain supports CCTP.
     */
    cctp: CCTPConfig | null;
    /**
     * Optional kit-specific contract addresses for enhanced chain functionality.
     *
     * @description When provided, the chain supports additional kit-specific logic in addition
     * to standard CCTP. This enables hybrid flows where both standard approve/burn/mint
     * and enhanced custom features are available. When undefined, the chain uses only
     * the standard CCTP flow.
     *
     * The address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     * - Other chains: Platform-specific address formats
     *
     * @example
     * ```typescript
     * // EVM chain with bridge contract
     * const evmChain: ChainDefinition = {
     *   // ... other properties
     *   kitContracts: {
     *     bridge: "0x1234567890abcdef1234567890abcdef12345678"
     *   }
     * }
     *
     * // Solana chain with bridge contract
     * const solanaChain: ChainDefinition = {
     *   // ... other properties
     *   kitContracts: {
     *     bridge: "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"
     *   }
     * }
     * ```
     */
    kitContracts?: KitContracts;
    /**
     * Optional Gateway contract configuration for Gateway protocol support.
     *
     * @description When provided, the chain supports the Gateway protocol for
     * cross-chain transfers. Gateway provides an alternative bridging mechanism
     * with its own set of smart contracts (GatewayWallet and GatewayMinter).
     *
     * Use the {@link isGatewayV1Supported} type guard to check if a chain
     * supports Gateway v1 before accessing these properties.
     *
     * @example
     * ```typescript
     * // Chain with Gateway v1 support
     * const chainWithGateway: ChainDefinition = {
     *   // ... other properties
     *   gateway: {
     *     domain: 6,
     *     forwarderSupported: { source: true, destination: true },
     *     contracts: {
     *       v1: {
     *         wallet: '0x1234567890abcdef1234567890abcdef12345678',
     *         minter: '0xabcdef1234567890abcdef1234567890abcdef12'
     *       }
     *     }
     *   }
     * }
     *
     * // Check Gateway support
     * if (isGatewayV1Supported(chainWithGateway)) {
     *   console.log('Gateway wallet:', chainWithGateway.gateway.contracts.v1.wallet)
     * }
     * ```
     *
     * @see {@link GatewayConfig} for the structure of Gateway configuration.
     * @see {@link isGatewayV1Supported} for checking Gateway v1 support.
     */
    gateway?: GatewayConfig;
}
/**
 * Represents chain definitions for Ethereum Virtual Machine (EVM) compatible blockchains.
 * @extends BaseChainDefinition
 * @category Types
 * @description Adds properties specific to EVM chains.
 * @example
 * ```typescript
 * const ethereum: EVMChainDefinition = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   title: 'Ethereum Mainnet',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false
 * };
 * ```
 */
interface EVMChainDefinition extends BaseChainDefinition {
    /**
     * Discriminator for EVM chains.
     * @description Used for type narrowing when handling different chain types.
     */
    type: 'evm';
    /**
     * The unique identifier for the blockchain.
     * @description Standard EVM chain ID as defined in EIP-155.
     * @example 1 for Ethereum Mainnet, 137 for Polygon.
     */
    chainId: number;
}
/**
 * Represents chain definitions for non-EVM blockchains.
 * @extends BaseChainDefinition
 * @category Types
 * @description Contains properties for blockchains that do not use the EVM.
 * @example
 * ```typescript
 * const solana: NonEVMChainDefinition = {
 *   type: 'solana',
 *   chain: Blockchain.Solana,
 *   name: 'Solana',
 *   nativeCurrency: { name: 'Solana', symbol: 'SOL', decimals: 9 },
 *   isTestnet: false
 * };
 * ```
 */
interface NonEVMChainDefinition extends BaseChainDefinition {
    /**
     * Discriminator for non-EVM chains.
     * @description Identifies the specific blockchain platform.
     */
    type: 'algorand' | 'avalanche' | 'solana' | 'aptos' | 'near' | 'stellar' | 'sui' | 'hedera' | 'noble' | 'polkadot';
}
/**
 * The type of chain.
 * @alias ChainType
 * @category Types
 * @description Represents the type of chain.
 * @example
 * ```typescript
 * const chainType: ChainType = 'evm'
 * ```
 */
type ChainType = EVMChainDefinition['type'] | NonEVMChainDefinition['type'];
/**
 * Public chain definition type.
 * @alias ChainDefinition
 * @category Types
 * @description Represents either an EVM-based or non-EVM-based blockchain definition.
 * This type is used by developers to define chain configurations.
 * @example
 * ```typescript
 * // Standard chain with CCTP support only
 * const ethereumChain: ChainDefinition = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   explorerUrl: 'https://etherscan.io/tx/{hash}',
 *   rpcEndpoints: ['https://eth.example.com'],
 *   eurcAddress: null,
 *   usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
 *   usdtAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       v2: {
 *         type: 'split',
 *         tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
 *         messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
 *         confirmations: 65,
 *         fastConfirmations: 2
 *       }
 *     }
 *   },
 *   kitContracts: undefined
 * };
 *
 * // Chain with custom contract support (hybrid flow)
 * const customChain: ChainDefinition = {
 *   ...ethereumChain,
 *   kitContracts: {
 *     bridge: '0x1234567890abcdef1234567890abcdef12345678'
 *   }
 * };
 * ```
 */
type ChainDefinition = EVMChainDefinition | NonEVMChainDefinition;
/**
 * Chain definition with CCTPv2 configuration.
 * @alias ChainDefinitionWithCCTPv2
 * @extends ChainDefinition
 * @category Types
 * @description Represents a chain definition that includes CCTPv2 configuration. This is useful for typescript consumers to narrow down the type of chain definition to a chain that supports CCTPv2.
 * @example
 * ```typescript
 * const ethereumWithCCTPv2: ChainDefinitionWithCCTPv2 = {
 *   ...ethereum,
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       v2: {
 *         type: 'merged',
 *         contract: '0x123...'
 *       }
 *     }
 *   }
 * };
 * ```
 */
type ChainDefinitionWithCCTPv2 = ChainDefinition & {
    cctp: CCTPConfig & {
        contracts: {
            v2: VersionConfig;
        };
    };
    usdcAddress: string;
};
/**
 * Chain identifier that can be used in transfer parameters and factory functions.
 * This can be either:
 * - A ChainDefinition object
 * - A Blockchain enum value (e.g., Blockchain.Ethereum)
 * - A string literal of the blockchain value (e.g., "Ethereum")
 */
type ChainIdentifier = ChainDefinition | Blockchain | `${Blockchain}`;
/**
 * Split CCTP contract configuration.
 *
 * Used by chains that deploy separate TokenMessenger and MessageTransmitter contracts.
 * This is the traditional CCTP architecture used by most EVM chains.
 *
 * @example
 * ```typescript
 * const splitConfig: CCTPSplitConfig = {
 *   type: 'split',
 *   tokenMessenger: '0x1234567890abcdef1234567890abcdef12345678',
 *   messageTransmitter: '0xabcdef1234567890abcdef1234567890abcdef12',
 *   confirmations: 12
 * }
 * ```
 */
interface CCTPSplitConfig {
    type: 'split';
    tokenMessenger: string;
    messageTransmitter: string;
    /**
     * Address of the `TokenMessengerWithFees` wrapper, when deployed on this chain.
     *
     * Optional. Present only on chains that support the prepaid FORWARD path
     * (source-chain fee collection via `depositForBurnWithHookAndFees`). Resolve
     * it with `resolveCCTPV2ContractAddress(chain, 'tokenMessengerWithFees')`.
     */
    tokenMessengerWithFees?: string;
    confirmations: number;
}
/**
 * Merged CCTP contract configuration.
 *
 * Used by chains that deploy a single unified CCTP contract.
 * This simplified architecture is used by newer chain integrations.
 *
 * @example
 * ```typescript
 * const mergedConfig: CCTPMergedConfig = {
 *   type: 'merged',
 *   contract: '0x9876543210fedcba9876543210fedcba98765432',
 *   confirmations: 1
 * }
 * ```
 */
interface CCTPMergedConfig {
    type: 'merged';
    contract: string;
    /**
     * Address of the `TokenMessengerWithFees` wrapper, when deployed on this chain.
     *
     * Optional. Present only on chains that support the prepaid FORWARD path
     * (source-chain fee collection via `depositForBurnWithHookAndFees`). Resolve
     * it with `resolveCCTPV2ContractAddress(chain, 'tokenMessengerWithFees')`.
     */
    tokenMessengerWithFees?: string;
    confirmations: number;
}
/**
 * Version configuration for CCTP contracts.
 *
 * Defines whether the chain uses split or merged CCTP contract architecture.
 * Split configuration uses separate TokenMessenger and MessageTransmitter contracts,
 * while merged configuration uses a single unified contract.
 *
 * @example Split configuration (most EVM chains)
 * ```typescript
 * const splitConfig: VersionConfig = {
 *   type: 'split',
 *   tokenMessenger: '0x1234567890abcdef1234567890abcdef12345678',
 *   messageTransmitter: '0xabcdef1234567890abcdef1234567890abcdef12',
 *   confirmations: 12
 * }
 * ```
 *
 * @example Merged configuration (newer chains)
 * ```typescript
 * const mergedConfig: VersionConfig = {
 *   type: 'merged',
 *   contract: '0x9876543210fedcba9876543210fedcba98765432',
 *   confirmations: 1
 * }
 * ```
 */
type VersionConfig = CCTPSplitConfig | CCTPMergedConfig;
type CCTPContracts = Partial<{
    v1: VersionConfig;
    v2: VersionConfig & {
        fastConfirmations: number;
    };
}>;
/**
 * Configuration for the Cross-Chain Transfer Protocol (CCTP).
 * @category Types
 * @description Contains the domain and required contract addresses for CCTP support.
 * @example
 * ```
 * const cctpConfig: CCTPConfig = {
 *   domain: 0,
 *   contracts: {
 *     TokenMessenger: '0xabc',
 *     MessageReceiver: '0xdef'
 *   }
 * };
 * ```
 */
interface CCTPConfig {
    /**
     * The CCTP domain identifier.
     */
    domain: number;
    /**
     * The contracts required for CCTP.
     */
    contracts: CCTPContracts;
    /**
     * Indicates whether the chain supports forwarder for source and destination.
     * @example
     * ```typescript
     * const chainWithForwarderSupported: ChainDefinition = {
     *   forwarderSupported: {
     *     source: true,
     *     destination: true,
     *   },
     * }
     * ```
     */
    forwarderSupported: {
        source: boolean;
        destination: boolean;
    };
}
/**
 * Available kit contract types for enhanced chain functionality.
 *
 * @description Defines the valid contract types that can be deployed on chains
 * to provide additional features beyond standard CCTP functionality.
 *
 * @example
 * ```typescript
 * import type { KitContractType } from '@core/chains'
 *
 * const contractType: KitContractType = 'bridge' // Valid
 * const invalidType: KitContractType = 'invalid' // TypeScript error
 * ```
 */
type KitContractType = 'bridge' | 'adapter';
/**
 * Configuration for Gateway v1 contracts.
 *
 * @description Contains the addresses for the GatewayWallet and GatewayMinter
 * smart contracts that enable Gateway functionality on a chain.
 *
 * @example
 * ```typescript
 * import type { GatewayV1Contracts } from '@core/chains'
 *
 * const v1Contracts: GatewayV1Contracts = {
 *   wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *   minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 * }
 * ```
 */
interface GatewayV1Contracts {
    /**
     * The address of the GatewayWallet smart contract.
     *
     * @description The GatewayWallet contract manages wallet operations
     * for Gateway transactions.
     *
     * Address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     *
     * @example "0x1234567890abcdef1234567890abcdef12345678"
     */
    wallet: string;
    /**
     * The address of the GatewayMinter smart contract.
     *
     * @description The GatewayMinter contract handles minting operations
     * for Gateway transactions.
     *
     * Address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     *
     * @example "0xabcdef1234567890abcdef1234567890abcdef12"
     */
    minter: string;
    /**
     * The address of the `DepositForHandler` contract.
     *
     * @description Optional. The handler the GenericExecutor calls on this chain
     * to run a fast cross-chain deposit into the {@link GatewayV1Contracts.wallet}.
     * Present only on chains that are fast-deposit destinations; other Gateway
     * chains omit it.
     *
     * Address format varies by blockchain:
     * - EVM chains: 40-character hexadecimal with 0x prefix (e.g., "0x1234...")
     * - Solana: Base58-encoded 32-byte address (e.g., "9WzDX...")
     *
     * @example "0xD05E7D2E7d30b92c5F17d7d0fC575fce231F1A48"
     */
    depositForHandler?: string;
}
/**
 * Versioned map of Gateway contract configurations.
 *
 * @description Maps protocol versions to their contract addresses, following
 * the same pattern as {@link CCTPContracts}. Each version is optional so that
 * chains can support any combination of Gateway protocol versions.
 *
 * @example
 * ```typescript
 * import type { GatewayContracts } from '@core/chains'
 *
 * const contracts: GatewayContracts = {
 *   v1: {
 *     wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *     minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *   }
 * }
 * ```
 */
type GatewayContracts = Partial<{
    v1: GatewayV1Contracts;
}>;
/**
 * Configuration for the Gateway protocol on a blockchain.
 *
 * @description Contains the Gateway domain identifier and version-specific
 * contract configurations. Follows the same structure as {@link CCTPConfig}:
 * a domain number plus a versioned contracts map.
 *
 * @example
 * ```typescript
 * import type { GatewayConfig } from '@core/chains'
 *
 * const gatewayConfig: GatewayConfig = {
 *   domain: 0,
 *   forwarderSupported: { source: true, destination: true },
 *   contracts: {
 *     v1: {
 *       wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *       minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *     }
 *   }
 * }
 * ```
 */
interface GatewayConfig {
    /**
     * The Gateway domain identifier for this chain.
     *
     * @description Similar to CCTP domains, this number uniquely identifies
     * the chain within the Gateway protocol.
     *
     * @example 0 for Ethereum, 6 for Base
     */
    domain: number;
    /**
     * Version-specific Gateway contract addresses.
     *
     * @description Contains the addresses for each supported Gateway protocol
     * version, following the same pattern as {@link CCTPContracts}.
     */
    contracts: GatewayContracts;
    /**
     * Indicate whether the chain supports the Forwarding Service as a source
     * and/or destination within the Gateway protocol.
     *
     * @example
     * ```typescript
     * forwarderSupported: { source: true, destination: true }
     * ```
     */
    forwarderSupported: {
        /** Whether this chain can be used as a source in forwarded transfers. */
        source: boolean;
        /** Whether this chain can be used as a destination in forwarded transfers. */
        destination: boolean;
    };
}
/**
 * Kit-specific contract addresses for enhanced chain functionality.
 *
 * @description Maps contract types to their addresses on a specific chain.
 * All contract types are optional, allowing chains to selectively support
 * specific kit features.
 *
 * @example
 * ```typescript
 * import type { KitContracts } from '@core/chains'
 *
 * const contracts: KitContracts = {
 *   bridge: "0x1234567890abcdef1234567890abcdef12345678"
 * }
 *
 * // Future example with multiple contract types:
 * const futureContracts: KitContracts = {
 *   bridge: "0x1234567890abcdef1234567890abcdef12345678",
 *   // Note: other contract types would be added to KitContractType union
 *   // customType: "0xabcdef1234567890abcdef1234567890abcdef12"
 * }
 * ```
 */
type KitContracts = Partial<Record<KitContractType, string>>;
/**
 * Enumeration of all blockchains known to this library.
 *
 * This enum contains every blockchain that has a chain definition, regardless
 * of whether bridging is currently supported. For chains that support bridging
 * via CCTPv2, see {@link BridgeChain}.
 *
 * @enum
 * @category Enums
 * @description Provides string identifiers for each blockchain with a definition.
 * @see {@link BridgeChain} for the subset of chains that support CCTPv2 bridging.
 */
declare enum Blockchain {
    Algorand = "Algorand",
    Algorand_Testnet = "Algorand_Testnet",
    Aptos = "Aptos",
    Aptos_Testnet = "Aptos_Testnet",
    Arc_Testnet = "Arc_Testnet",
    Arbitrum = "Arbitrum",
    Arbitrum_Sepolia = "Arbitrum_Sepolia",
    Avalanche = "Avalanche",
    Avalanche_Fuji = "Avalanche_Fuji",
    Base = "Base",
    Base_Sepolia = "Base_Sepolia",
    Celo = "Celo",
    Celo_Alfajores_Testnet = "Celo_Alfajores_Testnet",
    Codex = "Codex",
    Codex_Testnet = "Codex_Testnet",
    Cronos = "Cronos",
    Cronos_Testnet = "Cronos_Testnet",
    Edge = "Edge",
    Edge_Testnet = "Edge_Testnet",
    Ethereum = "Ethereum",
    Ethereum_Sepolia = "Ethereum_Sepolia",
    Hedera = "Hedera",
    Hedera_Testnet = "Hedera_Testnet",
    HyperEVM = "HyperEVM",
    HyperEVM_Testnet = "HyperEVM_Testnet",
    Injective = "Injective",
    Injective_Testnet = "Injective_Testnet",
    Ink = "Ink",
    Ink_Testnet = "Ink_Testnet",
    Linea = "Linea",
    Linea_Sepolia = "Linea_Sepolia",
    Monad = "Monad",
    Monad_Testnet = "Monad_Testnet",
    Morph = "Morph",
    Morph_Testnet = "Morph_Testnet",
    NEAR = "NEAR",
    NEAR_Testnet = "NEAR_Testnet",
    Noble = "Noble",
    Noble_Testnet = "Noble_Testnet",
    Optimism = "Optimism",
    Optimism_Sepolia = "Optimism_Sepolia",
    Pharos = "Pharos",
    Pharos_Testnet = "Pharos_Testnet",
    Plasma = "Plasma",
    Plasma_Testnet = "Plasma_Testnet",
    Polkadot_Asset_Hub = "Polkadot_Asset_Hub",
    Polkadot_Westmint = "Polkadot_Westmint",
    Plume = "Plume",
    Plume_Testnet = "Plume_Testnet",
    Polygon = "Polygon",
    Polygon_Amoy_Testnet = "Polygon_Amoy_Testnet",
    Sei = "Sei",
    Sei_Testnet = "Sei_Testnet",
    Solana = "Solana",
    Solana_Devnet = "Solana_Devnet",
    Sonic = "Sonic",
    Sonic_Testnet = "Sonic_Testnet",
    Stellar = "Stellar",
    Stellar_Testnet = "Stellar_Testnet",
    Sui = "Sui",
    Sui_Testnet = "Sui_Testnet",
    Unichain = "Unichain",
    Unichain_Sepolia = "Unichain_Sepolia",
    World_Chain = "World_Chain",
    World_Chain_Sepolia = "World_Chain_Sepolia",
    XDC = "XDC",
    XDC_Apothem = "XDC_Apothem",
    X_Layer = "X_Layer",
    X_Layer_Testnet = "X_Layer_Testnet",
    ZKSync_Era = "ZKSync_Era",
    ZKSync_Sepolia = "ZKSync_Sepolia"
}

/**
 * Core type definitions for blockchain transaction execution and gas estimation.
 *
 * This module provides TypeScript interfaces and types for handling blockchain
 * transactions across different networks, with a focus on EVM-compatible chains
 * and gas estimation.
 *
 * @module types
 */

/**
 * Estimated gas information for a blockchain transaction.
 *
 * This interface provides a unified way to represent gas costs across different
 * blockchain networks, supporting both EVM-style gas calculations and other
 * fee models.
 *
 * @interface EstimatedGas
 * @category Types
 * @example
 * ```typescript
 * // EVM chain example
 * const evmGas: EstimatedGas = {
 *   gas: 21000n,
 *   gasPrice: 1000000000n, // 1 Gwei
 *   fee: (21000n * 1000000000n).toString() // Total fee in wei
 * };
 *
 * // Solana example
 * const solanaGas: EstimatedGas = {
 *   gas: 5000n, // Lamports for compute units
 *   fee: '5000' // Total fee in Lamports
 * };
 * ```
 */
interface EstimatedGas {
    /**
     * The amount of gas estimated for the transaction.
     * For EVM chains, this represents the gas units.
     * For other chains, this might represent compute units or similar metrics.
     *
     * @example 21000n, 5000n
     */
    gas: bigint;
    /**
     * The estimated price per unit of gas.
     * This is primarily used in EVM chains where gas price is a separate metric.
     *
     * @example 1000000000n
     */
    gasPrice: bigint;
    /**
     * The total estimated fee as a string.
     * This field is useful for chains where gas/gasPrice isn't the whole story
     * or when the total fee needs to be represented in a different format.
     * For EVM chains, this is the total fee in wei (gas * gasPrice).
     *
     * @example "21000000000000", "5000"
     */
    fee: string;
}
/**
 * Override parameters for EVM gas estimation.
 *
 * These parameters allow customization of gas estimation behavior
 * for EVM-compatible chains.
 *
 * @interface EvmEstimateOverrides
 */
interface EvmEstimateOverrides {
    /**
     * The sender's address for the transaction.
     * @example "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"
     */
    from?: string;
    /**
     * The value to be sent with the transaction in wei.
     * @example 1000000000000000000n // 1 ETH
     */
    value?: bigint;
    /**
     * The block tag to use for estimation.
     * @example "latest", "safe", "finalized"
     */
    blockTag?: 'latest' | 'earliest' | 'pending' | 'safe' | 'finalized';
    /**
     * The maximum gas limit for the transaction.
     * @example 3000000
     */
    gasLimit?: number;
    /**
     * The maximum fee per gas unit (EIP-1559).
     * @example 20000000000n // 20 Gwei
     */
    maxFeePerGas?: bigint;
    /**
     * The maximum priority fee per gas unit (EIP-1559).
     * @example 1500000000n // 1.5 Gwei
     */
    maxPriorityFeePerGas?: bigint;
}
/**
 * Extended override parameters for EVM transaction execution.
 *
 * Includes all estimation overrides plus additional parameters
 * specific to transaction execution.
 *
 * @interface EvmExecuteOverrides
 * @extends EvmEstimateOverrides
 */
interface EvmExecuteOverrides extends EvmEstimateOverrides {
    /**
     * The nonce to use for the transaction.
     * If not provided, the current nonce of the sender will be used.
     * @example 42
     */
    nonce?: number;
}
/**
 * Raw EVM call data tuple for a single contract interaction.
 *
 * Represents the minimal data needed to submit an EVM transaction:
 * the target contract address, the ABI-encoded calldata, and an
 * optional native token value. Used by EIP-5792 batched execution
 * to compose multiple calls into a single `wallet_sendCalls` request.
 *
 * @interface EvmCallData
 *
 * @example
 * ```typescript
 * const callData: EvmCallData = {
 *   to: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   data: '0x095ea7b3000000000000000000000000...',
 * }
 * ```
 */
interface EvmCallData {
    /** The target contract address. */
    to: `0x${string}`;
    /** The ABI-encoded function calldata. */
    data: `0x${string}`;
    /** Optional native token value to send with the call. */
    value?: bigint | undefined;
}
/**
 * Prepared contract execution for EVM chains.
 *
 * Represents a prepared contract execution that can be estimated
 * and executed on EVM-compatible chains.
 *
 * @interface EvmPreparedChainRequest
 */
interface EvmPreparedChainRequest {
    /** The type of the prepared execution. */
    type: 'evm';
    /**
     * Estimate the gas cost for the contract execution.
     *
     * @param overrides - Optional parameters to override the default estimation behavior
     * @param fallback - Optional fallback gas information to use if the estimation fails
     * @returns A promise that resolves to the estimated gas information
     * @throws If the estimation fails
     */
    estimate(overrides?: EvmEstimateOverrides, fallback?: EstimatedGas): Promise<EstimatedGas>;
    /**
     * Execute the prepared contract call.
     *
     * @param overrides - Optional parameters to override the default execution behavior
     * @returns A promise that resolves to the transaction hash
     * @throws If the execution fails
     */
    execute(overrides?: EvmExecuteOverrides): Promise<string>;
    /**
     * Return the raw call tuple without executing or estimating.
     *
     * Expose the `{ to, data, value }` triple that would be sent on-chain so
     * callers can feed it into EIP-5792 `wallet_sendCalls` or other batching
     * mechanisms. This method is optional -- adapters that do not support
     * calldata extraction (e.g. Ethers v6) may omit it.
     *
     * @returns The raw EVM call data for this prepared request.
     * @throws Never — synchronous accessor with no failure path.
     * @since 2.0.0
     *
     * @example
     * ```typescript
     * const prepared = await adapter.prepare(params, ctx)
     * if (prepared.getCallData) {
     *   const { to, data, value } = prepared.getCallData()
     *   console.log('Target:', to, 'Data:', data)
     * }
     * ```
     */
    getCallData?(): EvmCallData;
}
/**
 * Union type for all supported prepared contract executions.
 * Currently only supports EVM chains, but can be extended for other chains.
 */
type PreparedChainRequest = EvmPreparedChainRequest | SolanaPreparedChainRequest | NoopPreparedChainRequest;
/**
 * Parameters for preparing an EVM contract execution.
 */
type EvmPreparedChainRequestParams = {
    /** The type of the prepared execution. */
    type: 'evm';
    /** The ABI of the contract. */
    abi: Abi | string[];
    /** The address of the contract. */
    address: `0x${string}`;
    /** The name of the function to call. */
    functionName: string;
    /** The arguments to pass to the function. */
    args: unknown[];
    /**
     * Specific block number to read contract state at (read-only calls only).
     * Used for historical reads, e.g. checking delegate status at Gateway's
     * processed height rather than the latest block. Ignored for write
     * operations (transactions).
     */
    blockNumber?: bigint;
} & Partial<EvmEstimateOverrides>;
/**
 * Parameters for preparing an EIP-712 typed data signing request (EVM).
 * When executed, returns the signature hex string.
 */
interface EvmSignTypedDataPreparedChainRequestParams {
    type: 'evm-sign-typed-data';
    typedData: {
        types: Record<string, unknown[]>;
        domain: Record<string, unknown>;
        primaryType: string;
        message: Record<string, unknown>;
    };
}
/**
 * Solana-specific parameters for preparing a transaction.
 *
 * @example
 * ```typescript
 * import type { SolanaPreparedChainRequestParams } from '@core/adapter'
 *
 * const params: SolanaPreparedChainRequestParams = {
 *   instructions: [transferInstruction],
 *   addressLookupTables: [],
 * }
 * ```
 */
interface SolanaPreparedChainRequestParams {
    /**
     * The array of instructions to include in the transaction.
     *
     * @remarks
     * Used for instruction-based transaction building. Mutually exclusive with
     * `serializedTransaction`.
     */
    instructions?: TransactionInstruction[];
    /**
     * A pre-serialized transaction as a Uint8Array (e.g., from a service like Jupiter).
     *
     * @remarks
     * Used for executing pre-built transactions from external services.
     * The transaction may be partially signed. Mutually exclusive with `instructions`.
     */
    serializedTransaction?: Uint8Array;
    /**
     * Additional signers besides the Adapter's wallet (e.g. program-derived authorities).
     */
    signers?: Signer[];
    /**
     * Optional override for how many compute units this transaction may consume.
     * If omitted, the network's default compute budget applies.
     */
    computeUnitLimit?: number;
    /**
     * Optional Address Lookup Table accounts for transaction compression.
     * Used to reduce transaction size by compressing frequently-used addresses.
     * This is used by @solana/web3.js adapters that have already fetched the ALT data.
     */
    addressLookupTableAccounts?: AddressLookupTableAccount[];
    /**
     * Optional Address Lookup Table addresses for transaction compression.
     * Used by adapters that need to fetch ALT data themselves (e.g., @solana/kit adapters).
     * These are base58-encoded addresses of ALT accounts to use for compression.
     */
    addressLookupTableAddresses?: string[];
}
/**
 * Parameters for preparing a message signing request (Solana).
 * When executed, returns the signature.
 *
 * @example
 * ```typescript
 * import type { SolanaSignMessagePreparedChainRequestParams } from '@core/adapter'
 *
 * const params: SolanaSignMessagePreparedChainRequestParams = {
 *   type: 'solana-sign-message',
 *   message: new TextEncoder().encode('Sign this message'),
 * }
 * ```
 */
interface SolanaSignMessagePreparedChainRequestParams {
    type: 'solana-sign-message';
    message: Uint8Array;
}
/**
 * Solana-specific configuration for transaction estimation.
 * @interface SolanaEstimateOverrides
 */
interface SolanaEstimateOverrides {
    /** Optional compute unit limit for the transaction. */
    computeUnitLimit?: number;
}
/**
 * Solana-specific configuration for transaction execution.
 * @interface SolanaExecuteOverrides
 * @extends SolanaEstimateOverrides
 */
interface SolanaExecuteOverrides extends SolanaEstimateOverrides {
    /** The commitment level for the transaction. */
    preflightCommitment?: 'processed' | 'confirmed' | 'finalized';
    /** The maximum number of retries for the transaction. */
    maxRetries?: number;
    /** Whether to skip the preflight check. */
    skipPreflight?: boolean;
}
/**
 * Solana-specific prepared chain request.
 * @interface SolanaPreparedChainRequest
 */
interface SolanaPreparedChainRequest {
    /** The type of the chain request. */
    type: 'solana';
    /** Estimate the compute units and fee for the transaction. */
    estimate(overrides?: SolanaEstimateOverrides, fallback?: EstimatedGas): Promise<EstimatedGas>;
    /** Execute the prepared transaction. */
    execute(overrides?: SolanaExecuteOverrides): Promise<string>;
}
/**
 * No-op prepared chain request for unsupported operations.
 *
 * This interface represents a prepared chain request that performs no operation.
 * It is returned when an action is not supported by the target chain or when
 * no actual blockchain interaction is required.
 *
 * @remarks
 * The estimate and execute methods return placeholder values since no actual
 * transaction is performed. This allows the calling code to handle unsupported
 * operations gracefully without breaking the expected interface contract.
 *
 * @example
 * ```typescript
 * const noopRequest: NoopPreparedChainRequest = {
 *   type: 'noop',
 *   estimate: async () => ({ gasLimit: 0n, gasPrice: 0n, totalFee: 0n }),
 *   execute: async () => '0x0000000000000000000000000000000000000000000000000000000000000000'
 * }
 * ```
 */
interface NoopPreparedChainRequest {
    /** The type of the prepared request. */
    type: 'noop';
    /**
     * Placeholder for the estimate method.
     * @returns The estimated gas cost.
     */
    estimate: (overrides?: EvmEstimateOverrides | SolanaEstimateOverrides, fallback?: EstimatedGas) => Promise<EstimatedGas>;
    /**
     * Placeholder for the execute method.
     * @returns The transaction hash.
     */
    execute: () => Promise<string>;
}
/**
 * Union type for all supported contract execution parameters.
 * Currently only supports EVM chains, but can be extended for other chains.
 */
type PreparedChainRequestParams = EvmPreparedChainRequestParams | EvmSignTypedDataPreparedChainRequestParams | SolanaPreparedChainRequestParams | SolanaSignMessagePreparedChainRequestParams;
/**
 * Response from waiting for a transaction to be mined and confirmed on the blockchain.
 *
 * @interface WaitForTransactionResponse
 */
interface WaitForTransactionResponse {
    /**
     * The transaction hash identifier.
     * @example "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
     */
    txHash: string;
    /**
     * The final status of the transaction execution.
     * Indicates whether the transaction was successfully executed or reverted.
     * @example "success", "reverted"
     */
    status: 'success' | 'reverted';
    /**
     * The total amount of gas used by all transactions in the block up to and including this transaction.
     * Represents the cumulative gas consumption within the block.
     * @example 2100000n
     */
    cumulativeGasUsed?: bigint;
    /**
     * The amount of gas actually consumed by this specific transaction.
     * This value is always less than or equal to the gas limit set for the transaction.
     * @example 21000n
     */
    gasUsed?: bigint;
    /**
     * The block number where the transaction was mined.
     * Represents the sequential position of the block in the blockchain.
     * @example 18500000n
     */
    blockNumber?: bigint;
    /**
     * The hash of the block containing this transaction.
     * Provides a unique identifier for the block where the transaction was included.
     * @example "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
     */
    blockHash?: string;
    /**
     * The zero-based index position of the transaction within the block.
     * Indicates the order in which this transaction appears in the block.
     * @example 5
     */
    transactionIndex?: number;
    /**
     * The actual gas price paid per unit of gas for this transaction.
     * For EIP-1559 transactions, this reflects the base fee plus priority fee.
     * @example 15000000000n // 15 Gwei
     */
    effectiveGasPrice?: bigint;
}
interface WaitForTransactionConfig {
    /**
     * The timeout for the transaction to be mined and confirmed on the blockchain.
     * @example 10000
     */
    timeout?: number | undefined;
    /**
     * The number of confirmations to wait for the transaction to be mined and confirmed on the blockchain.
     * @example 1
     */
    confirmations?: number;
    /**
     * The maximum supported transaction version for getTransaction.
     * Defaults to 0 if not provided.
     * @example 0
     */
    maxSupportedTransactionVersion?: number;
}
/**
 * Type utility to extract the address context from adapter capabilities.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type
 * @returns The address context type or never if capabilities are undefined
 */
type ExtractAddressContext<TAdapterCapabilities extends AdapterCapabilities> = TAdapterCapabilities extends {
    addressContext: infer TContext;
} ? TContext : never;
type AddressField<TAddressContext> = TAddressContext extends 'user-controlled' ? {
    /**
     * ℹ️ Address is forbidden for user-controlled adapters.
     *
     * User-controlled adapters (like browser wallets or private key adapters)
     * automatically resolve the address from the connected wallet or signer.
     * Providing an explicit address would conflict with this behavior.
     *
     * @example
     * ```typescript
     * // ℹ️ This will cause a TypeScript error:
     * const context: AdapterContext<{ addressContext: 'user-controlled' }> = {
     *   adapter: userAdapter,
     *   chain: 'Ethereum',
     *   address: '0x123...' // Error: Address is forbidden for user-controlled adapters
     * }
     * ```
     */
    address?: never;
} : TAddressContext extends 'developer-controlled' ? {
    /**
     * ℹ️ Address is required for developer-controlled adapters.
     *
     * Developer-controlled adapters (like enterprise providers or server-side adapters)
     * require an explicit address for each operation since they don't have a single
     * connected wallet. The address must be provided for every operation.
     *
     * @example
     * ```typescript
     * // ℹ️ This is required:
     * const context: AdapterContext<{ addressContext: 'developer-controlled' }> = {
     *   adapter: devAdapter,
     *   chain: 'Ethereum',
     *   address: '0x123...' // Required for developer-controlled adapters
     * }
     *
     * // ℹ️ This will cause a TypeScript error:
     * const context: AdapterContext<{ addressContext: 'developer-controlled' }> = {
     *   adapter: devAdapter,
     *   chain: 'Ethereum'
     *   // Error: Address is required for developer-controlled adapters
     * }
     * ```
     */
    address: string;
} : {
    /**
     * Address is optional for legacy adapters.
     *
     * Legacy adapters without defined capabilities maintain backward compatibility
     * by allowing optional address specification.
     */
    address?: string;
};
/**
 * Generic operation context for adapter methods with compile-time address validation.
 *
 * This type provides compile-time enforcement of address requirements based on the
 * adapter's capabilities. The address field behavior is determined by the adapter's
 * address control model:
 *
 * - **User-controlled adapters** (default): The `address` field is forbidden (never) because
 *   the address is automatically resolved from the connected wallet or signer.
 * - **Developer-controlled adapters**: The `address` field is required (string) because
 *   each operation must explicitly specify which address to use.
 * - **Legacy adapters**: The `address` field remains optional for backward compatibility.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type to derive address requirements from
 *
 * @example
 * ```typescript
 * import { OperationContext } from '@core/adapter'
 *
 * // User-controlled adapter context (default - address forbidden)
 * type UserContext = OperationContext<{ addressContext: 'user-controlled', supportedChains: [] }>
 * const userCtx: UserContext = {
 *   chain: 'Ethereum'
 *   // address: '0x123...' // ❌ TypeScript error: address not allowed
 * }
 *
 * // Developer-controlled adapter context (explicit - address required)
 * type DevContext = OperationContext<{ addressContext: 'developer-controlled', supportedChains: [] }>
 * const devCtx: DevContext = {
 *   chain: 'Ethereum',
 *   address: '0x123...' // ✅ Required for developer-controlled
 * }
 * ```
 */
type OperationContext<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> = {
    /**
     * The blockchain network to use for this operation.
     */
    chain: ChainIdentifier;
} & AddressField<ExtractAddressContext<TAdapterCapabilities>>;
/**
 * Fully resolved context for an adapter operation, with concrete chain and address.
 *
 * This interface guarantees that both the blockchain network (`chain`) and the account
 * address (`address`) are present and valid. It is produced by resolving an {@link OperationContext},
 * which may have optional or conditional fields, into a form suitable for internal logic and action handlers.
 *
 * - `chain`: A fully resolved {@link ChainDefinition}, either explicitly provided or inferred from the adapter.
 * - `address`: A string representing the resolved account address, determined by the context or adapter,
 *   depending on the address control model (developer- or user-controlled).
 *
 * Use this type when an operation requires both the chain and address to be unambiguous and available.
 *
 * @example
 * ```ts
 * import { ResolvedOperationContext} from "@core/adapter"
 * import { Solana, ChainDefinition } from '@core/chains';
 *
 * const context: ResolvedOperationContext = {
 *   chain: Solana,
 *   address: '7Gk1v...abc123', // a valid Solana address
 * };
 *
 * // Use context.chain and context.address in adapter operations
 * ```
 */
interface ResolvedOperationContext {
    /**
     * The chain identifier for this operation.
     * Guaranteed to be defined - either from context or adapter default.
     */
    chain: ChainDefinition;
    /**
     * The address for this operation.
     * Guaranteed to be defined - either specified (developer-controlled) or resolved (user-controlled).
     */
    address: string;
}

/**
 * Base interface for all action parameter objects.
 *
 * Provide a compile-time marker to explicitly identify objects that represent
 * action parameters (leaf nodes) versus namespace containers that should be
 * traversed during type recursion.
 *
 * @remarks
 * This marker property exists only at the type level and is stripped away
 * during compilation. It serves as a deterministic way to identify action
 * parameter objects without relying on property name heuristics.
 *
 * All action parameter objects must extend this interface to be properly
 * recognized by the recursive utility types in the action system.
 */
interface ActionParameters {
    /**
     * Compile-time marker identifying this as an action parameter object.
     *
     * This property is used by the type system to distinguish between
     * namespace containers and action parameter definitions. It does not
     * exist at runtime and is purely for TypeScript's type checking.
     */
    readonly __isActionParams: true;
}

/**
 * EIP-2612 permit signature parameters for gasless token approvals.
 *
 * Contains the signature components and deadline required for permit-based
 * token spending authorization without requiring separate approval transactions.
 *
 * @example
 * ```typescript
 * const permitParams: PermitParams = {
 *   deadline: BigInt(Math.floor(Date.now() / 1000) + 3600), // 1 hour from now
 *   v: 27,
 *   r: '0x1234567890abcdef...',
 *   s: '0xfedcba0987654321...'
 * }
 * ```
 */
interface PermitParams {
    /**
     * Permit expiration timestamp (Unix timestamp in seconds).
     *
     * The permit signature becomes invalid after this timestamp.
     * Must be greater than the current block timestamp.
     */
    deadline: bigint;
    /**
     * Recovery parameter of the ECDSA signature (27 or 28).
     *
     * Used to recover the public key from the signature components.
     */
    v: number;
    /**
     * R component of the ECDSA signature.
     *
     * First 32 bytes of the signature as a hex string.
     */
    r: string;
    /**
     * S component of the ECDSA signature.
     *
     * Second 32 bytes of the signature as a hex string.
     */
    s: string;
}
/**
 * Action map for Circle's Cross-Chain Transfer Protocol (CCTP) version 2 operations.
 *
 * Define the parameter schemas for CCTP v2 actions that enable native USDC
 * transfers between supported blockchain networks. Use Circle's attestation
 * service to verify and complete cross-chain transactions with cryptographic
 * proof of burn and mint operations.
 *
 * @remarks
 * CCTP v2 represents Circle's native cross-chain transfer protocol that allows
 * USDC to move between chains without traditional lock-and-mint bridging.
 * Instead, USDC is burned on the source chain and minted natively on the
 * destination chain using cryptographic attestations.
 *
 * The protocol supports both "slow" (free) and "fast" (fee-based) transfer
 * modes, with configurable finality thresholds and destination execution
 * parameters for advanced use cases.
 *
 * @example
 * ```typescript
 * import type { CCTPv2ActionMap } from '@core/adapter/actions/cctp/v2'
 * import { mainnet, polygon } from '@core/chains'
 *
 * // Deposit and burn USDC for cross-chain transfer
 * const burnParams: CCTPv2ActionMap['depositForBurn'] = {
 *   amount: '1000000', // 1 USDC (6 decimals)
 *   mintRecipient: '0x742d35Cc6634C0532925a3b8D8E5e8d8D8e5e8d8D8e5e8',
 *   maxFee: '1000', // 0.001 USDC fast fee
 *   minFinalityThreshold: 65,
 *   fromChain: mainnet,
 *   toChain: polygon
 * }
 *
 * // Receive and mint USDC on destination chain
 * const receiveParams: CCTPv2ActionMap['receiveMessage'] = {
 *   eventNonce: '0x123abc...',
 *   attestation: '0xdef456...',
 *   message: '0x789012...',
 *   fromChain: mainnet,
 *   toChain: polygon
 * }
 * ```
 *
 * @see {@link ChainDefinitionWithCCTPv2} for supported chain definitions
 */
interface CCTPv2ActionMap {
    /**
     * Initiate a cross-chain USDC transfer by depositing and burning tokens on the source chain.
     *
     * Burn USDC tokens on the source chain and generate a message for attestation
     * by Circle's infrastructure. The burned tokens will be minted on the destination
     * chain once the attestation is obtained and the receive message is executed.
     *
     * @remarks
     * This action represents the first step in a CCTP cross-chain transfer. After
     * execution, you must wait for Circle's attestation service to observe the burn
     * event and provide a cryptographic attestation that can be used to mint the
     * equivalent amount on the destination chain.
     *
     * The `maxFee` parameter enables fast transfers through Circle's fast liquidity
     * network, where liquidity providers can fulfill transfers immediately in exchange
     * for a fee. Set to "0" for slower, free transfers that wait for full finality.
     */
    depositForBurn: ActionParameters & {
        /**
         * Amount of USDC to deposit and burn (in token's smallest unit).
         *
         * Specify the amount in the token's atomic units (e.g., for USDC with
         * 6 decimals, "1000000" represents 1 USDC). This amount will be burned
         * on the source chain and minted on the destination chain.
         */
        amount: bigint;
        /**
         * Address of the recipient who will receive minted tokens on the destination chain.
         *
         * Provide the destination address as a 32-byte hex string (bytes32 format).
         */
        mintRecipient: string;
        /**
         * Address authorized to call receiveMessage on the destination chain.
         *
         * Restrict who can execute the final minting step on the destination chain.
         * If not specified or set to bytes32(0), any address can call receiveMessage.
         * Use this for advanced integrations requiring specific execution control.
         *
         * @defaultValue bytes32(0) - allows any address to complete the transfer
         */
        destinationCaller?: string;
        /**
         * Maximum fee to pay for fast transfer fulfillment.
         *
         * Specify the maximum amount (in the same units as `amount`) you're willing
         * to pay for immediate liquidity. Set to "0" for free transfers that wait
         * for full chain finality. Higher fees increase the likelihood of fast
         * fulfillment.
         */
        maxFee: bigint;
        /**
         * Minimum finality threshold for attestation eligibility.
         *
         * Set the number of confirmations required before Circle's attestation
         * service will observe and attest to the burn event. Higher values
         * provide stronger finality guarantees but increase transfer time.
         * Typical values: 1000 for fast transfers, 2000 for maximum security.
         */
        minFinalityThreshold: number;
        /**
         * Source chain definition where tokens will be burned.
         */
        fromChain: ChainDefinitionWithCCTPv2;
        /**
         * Destination chain definition where tokens will be minted.
         */
        toChain: ChainDefinitionWithCCTPv2;
    };
    /**
     * Complete a cross-chain transfer by receiving and processing an attested message.
     *
     * Execute the final step of a CCTP transfer by submitting Circle's attestation
     * and the original message to mint USDC tokens on the destination chain.
     * This action consumes the attestation and delivers tokens to the specified
     * recipient from the original burn operation.
     *
     * @remarks
     * This action must be called after obtaining a valid attestation from Circle's
     * API for a corresponding `depositForBurn` operation. The attestation proves
     * that tokens were burned on the source chain and authorizes minting the
     * equivalent amount on the destination chain.
     *
     * The message parameter contains the original burn message data, while the
     * attestation provides the cryptographic proof. Both must match exactly
     * with Circle's records for the transaction to succeed.
     */
    receiveMessage: ActionParameters & {
        /**
         * Unique nonce identifying the specific burn event.
         *
         * Provide the event nonce from the MessageSent event emitted by the
         * depositForBurn transaction. This must be a 0x-prefixed 64-character
         * hex string representing the 32-byte nonce value.
         */
        readonly eventNonce: string;
        /**
         * Cryptographic attestation from Circle's infrastructure.
         *
         * Submit the attestation obtained from Circle's API that proves the
         * corresponding burn event occurred and was observed. This must be
         * a valid 0x-prefixed hex string containing Circle's signature data.
         */
        readonly attestation: string;
        /**
         * Original message bytes from the source chain burn event.
         *
         * Provide the raw message data emitted in the MessageSent event from
         * the depositForBurn transaction. This 0x-prefixed hex string contains
         * the encoded transfer details that will be verified against the attestation.
         */
        readonly message: string;
        /**
         * Source chain definition where the original burn occurred.
         */
        readonly fromChain: ChainDefinitionWithCCTPv2;
        /**
         * Destination chain definition where tokens will be minted.
         */
        readonly toChain: ChainDefinitionWithCCTPv2;
        /**
         * Optional destination wallet address on the destination chain to receive minted USDC.
         *
         * When provided (e.g., for Solana), the mint instruction will derive the
         * recipient's Associated Token Account (ATA) from this address instead of
         * the adapter's default address.
         */
        readonly destinationAddress?: string;
        /**
         * The mint recipient address from the decoded CCTP message.
         *
         * This is the actual address encoded in the burn message where tokens will be minted.
         * For Solana, this is already the Associated Token Account (ATA) address, not the owner.
         * For EVM chains, this is the recipient's wallet address.
         */
        readonly mintRecipient?: string;
    };
    /**
     * Initiate a cross-chain USDC transfer using a custom bridge contract with preapproval funnel.
     *
     * This action combines token approval and burning into a single transaction using
     * a custom bridge contract that supports preapproval functionality. It provides
     * enhanced gas efficiency by eliminating separate approval transactions while
     * maintaining the same developer interface as standard CCTP transfers.
     *
     * @remarks
     * This action is only available on chains that support custom bridge contracts,
     * as determined by `hasCustomContractSupport(chain, 'bridge')`. The custom bridge
     * handles token approval internally and supports advanced features like protocol
     * fees and custom routing logic.
     *
     * For basic use cases, this provides the same interface as `depositForBurn`.
     * For advanced use cases, optional protocol fee parameters enable custom fee
     * collection and revenue sharing models.
     *
     * @example
     * ```typescript
     * // Basic usage (same as depositForBurn)
     * await adapter.action('cctp.v2.customBurn', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: '0x...',
     *   maxFee: BigInt('1000'),
     *   minFinalityThreshold: 65
     * })
     *
     * // Advanced usage with protocol fees
     * await adapter.action('cctp.v2.customBurn', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: '0x...',
     *   maxFee: BigInt('1000'),
     *   minFinalityThreshold: 65,
     *   protocolFee: BigInt('100'),
     *   feeRecipient: '0xFeeRecipientAddress'
     * })
     * ```
     */
    customBurn: ActionParameters & {
        /**
         * Amount of USDC to burn (in token's smallest unit).
         *
         * Specify the amount in the token's atomic units (e.g., for USDC with
         * 6 decimals, 1000000n represents 1 USDC). This amount will be burned
         * on the source chain and minted on the destination chain.
         */
        amount: bigint;
        /**
         * Address of the recipient who will receive minted tokens on the destination chain.
         *
         * Provide the destination address as a 32-byte hex string (bytes32 format).
         */
        mintRecipient: string;
        /**
         * Address authorized to call receiveMessage on the destination chain.
         *
         * Restrict who can execute the final minting step on the destination chain.
         * If not specified or set to bytes32(0), any address can call receiveMessage.
         * Use this for advanced integrations requiring specific execution control.
         *
         * @defaultValue bytes32(0) - allows any address to complete the transfer
         */
        destinationCaller?: string;
        /**
         * Maximum fee to pay for fast transfer fulfillment.
         *
         * Specify the maximum amount (in the same units as `amount`) you're willing
         * to pay for immediate liquidity. Set to "0" for free transfers that wait
         * for full chain finality. Higher fees increase the likelihood of fast
         * fulfillment.
         */
        maxFee: bigint;
        /**
         * Minimum finality threshold for attestation eligibility.
         *
         * Set the number of confirmations required before Circle's attestation
         * service will observe and attest to the burn event. Higher values
         * provide stronger finality guarantees but increase transfer time.
         * Typical values: 65 for standard transfers, 2000 for maximum security.
         */
        minFinalityThreshold: number;
        /**
         * Protocol fee amount (in token's smallest unit).
         *
         * Additional fee charged by the custom bridge for enhanced functionality.
         * This fee is separate from the Circle fast transfer fee and is paid to
         * the specified fee recipient. Enables custom fee collection and revenue
         * sharing models for bridge operators.
         *
         * @defaultValue 0n - no protocol fee for basic usage
         */
        protocolFee?: bigint | undefined;
        /**
         * Address to receive the protocol fee.
         *
         * Wallet address where the protocol fee will be sent. This enables
         * custom fee collection and revenue sharing models for bridge operators.
         * Only relevant when protocolFee is greater than 0.
         *
         * @defaultValue bridge contract address - safe fallback for zero fees
         */
        feeRecipient?: string | undefined;
        /**
         * Source chain definition where tokens will be burned.
         */
        fromChain: ChainDefinitionWithCCTPv2;
        /**
         * Destination chain definition where tokens will be minted.
         */
        toChain: ChainDefinitionWithCCTPv2;
        /**
         * Permit parameters for the custom bridge contract.
         */
        permitParams?: PermitParams;
    };
    /**
     * Initiate a cross-chain USDC transfer using a custom bridge contract with hook data for CCTP forwarding.
     *
     * This action combines the custom bridge functionality with CCTP forwarding hookData.
     * It uses either `bridgeWithPreapprovalAndHook` or `bridgeWithPermitAndHook` contract
     * functions depending on whether permit parameters are provided.
     *
     * @remarks
     * When CCTP forwarding is enabled with custom burn, Circle's relay infrastructure will:
     * 1. Watch for the burn transaction with forwarding hookData
     * 2. Fetch the attestation automatically
     * 3. Submit the destination mint transaction on behalf of the user
     * 4. Deduct the relay fee from the minted USDC
     *
     * The hookData must be formatted with the CCTP forwarding magic bytes prefix
     * followed by version and length fields. Use the `buildForwardingHookData`
     * utility to construct properly formatted hookData.
     *
     * @example
     * ```typescript
     * import { buildForwardingHookData } from '@core/utils'
     * import { hasCustomContractSupport } from '@core/chains'
     *
     * if (hasCustomContractSupport(sourceChain, 'bridge')) {
     *   await adapter.action('cctp.v2.customBurnWithHook', {
     *     amount: BigInt('1000000'),
     *     mintRecipient: '0x...',
     *     maxFee: BigInt('50000'),
     *     minFinalityThreshold: 1000,
     *     fromChain: ethereum,
     *     toChain: base,
     *     hookData: buildForwardingHookData()
     *   })
     * }
     * ```
     */
    customBurnWithHook: CCTPv2ActionMap['customBurn'] & {
        /**
         * Hex-encoded hook data for CCTP forwarding.
         *
         * The hookData signals to Circle's Orbit relayer that forwarding is requested.
         * Must be formatted with the CCTP forwarding magic bytes prefix ("cctp-forward"
         * right-padded to 24 bytes) followed by uint32 version and uint32 length fields.
         *
         * Use the `buildForwardingHookData` utility to construct properly formatted hookData.
         */
        hookData: string;
    };
    /**
     * Initiate a cross-chain USDC transfer with hook data for CCTP forwarding.
     *
     * This action extends the standard `depositForBurn` with an additional `hookData`
     * parameter that signals to Circle's Orbit relayer that the user wants automated
     * attestation fetching and destination mint execution.
     *
     * @remarks
     * When CCTP forwarding is enabled, Circle's relay infrastructure will:
     * 1. Watch for the burn transaction with forwarding hookData
     * 2. Fetch the attestation automatically
     * 3. Submit the destination mint transaction on behalf of the user
     * 4. Deduct the relay fee from the minted USDC
     *
     * The hookData must be formatted with the CCTP forwarding magic bytes prefix
     * followed by version and length fields. Use the `buildForwardingHookData`
     * utility to construct properly formatted hookData.
     *
     * @example
     * ```typescript
     * import { buildForwardingHookData } from '@core/utils'
     *
     * await adapter.action('cctp.v2.depositForBurnWithHook', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: '0x...',
     *   maxFee: BigInt('50000'), // Must cover burn fee + forwarding fee
     *   minFinalityThreshold: 1000,
     *   fromChain: ethereum,
     *   toChain: base,
     *   hookData: buildForwardingHookData()
     * })
     * ```
     */
    depositForBurnWithHook: CCTPv2ActionMap['depositForBurn'] & {
        /**
         * Hex-encoded hook data for CCTP forwarding.
         *
         * The hookData signals to Circle's Orbit relayer that forwarding is requested.
         * Must be formatted with the CCTP forwarding magic bytes prefix ("cctp-forward"
         * right-padded to 24 bytes) followed by uint32 version and uint32 length fields.
         *
         * Use the `buildForwardingHookData` utility to construct properly formatted hookData.
         */
        hookData: string;
    };
    /**
     * Initiate a prepaid cross-chain USDC transfer through the `TokenMessengerWithFees` wrapper.
     *
     * Burn USDC on the source chain while collecting all fees up front against a
     * signed quote. The wrapper collects the fee via `FeeManager`, then delegates
     * to the unmodified `TokenMessengerV2`. When `hookData` is provided (the
     * GenericExecutor FORWARD path) the wrapper's `depositForBurnWithHookAndFees`
     * contract method is used; otherwise `depositForBurnWithFees` is used.
     *
     * @remarks
     * SDK/contract naming: this SDK action is `depositForBurnWithFees` but, when a
     * `hookData` is present, it dispatches to the `depositForBurnWithHookAndFees`
     * contract method on `TokenMessengerWithFees` (NOT on `TokenMessengerV2`).
     *
     * Fee payment channel (must match the quote's `feeToken`):
     * - Native fee (`feeToken` is the zero address): exactly `feeTotalAmount` is
     *   attached as `msg.value`.
     * - ERC-20 fee (e.g. USDC): no value is attached; the caller must first approve
     *   the wrapper for `feeTotalAmount` (see the provider's fee approval helper).
     *
     * @remarks
     * Unlike `depositForBurn`, the `TokenMessengerWithFees` contract methods do NOT
     * take `maxFee` or `minFinalityThreshold` — fee and finality behavior are
     * derived from the signed quote — so those fields are omitted from this action.
     *
     * @example
     * ```typescript
     * await adapter.action('cctp.v2.depositForBurnWithFees', {
     *   amount: BigInt('1000000'),
     *   mintRecipient: executorAddress,     // GenericExecutor (bytes32)
     *   destinationCaller: executorAddress, // GenericExecutor (bytes32)
     *   fromChain: ethereum,
     *   toChain: arc,
     *   hookData: geForwardHookData,        // cctp-forward-wrapped GenericExecutor blob
     *   claim: { signedQuote: '0x...', refundAddress: '0x...' },
     *   feeToken: '0x0000000000000000000000000000000000000000', // native
     *   feeTotalAmount: 3500000n,
     * })
     * ```
     */
    depositForBurnWithFees: Omit<CCTPv2ActionMap['depositForBurn'], 'maxFee' | 'minFinalityThreshold'> & {
        /**
         * Optional hex-encoded hook data for the GenericExecutor FORWARD path.
         *
         * When present, the `depositForBurnWithHookAndFees` contract method is used
         * and the blob must be wrapped in the `cctp-forward` envelope (the wrapper
         * rejects a FORWARD fee quote whose hook lacks it). When omitted, the plain
         * `depositForBurnWithFees` contract method is used.
         */
        hookData?: string;
        /**
         * Signed fee quote claim passed to the `TokenMessengerWithFees` wrapper.
         *
         * `signedQuote` is the `[uint8 0x01][abi.encode(Quote)]` blob returned by the
         * Fee Quote service; `refundAddress` receives any fee overpayment refund.
         */
        claim: QuoteClaim;
        /**
         * Fee token from the signed quote.
         *
         * The zero address (`0x000…0`) means the fee is paid in native currency and
         * is attached as `msg.value`. Any other address (e.g. USDC) means an ERC-20
         * fee that must be approved to the wrapper beforehand. This is independent of
         * `burnToken`, which is always USDC.
         */
        feeToken: string;
        /**
         * Total fee amount from the signed quote, in `feeToken` minor units.
         *
         * Firm only until the quote's `expiresAt`. For a native fee this is the exact
         * `msg.value`; for an ERC-20 fee this is the amount approved to the wrapper.
         */
        feeTotalAmount: bigint;
    };
}
/**
 * Signed fee quote claim consumed by the `TokenMessengerWithFees` wrapper.
 *
 * Mirrors the on-chain `IFeeManager.QuoteClaim` struct.
 *
 * @example
 * ```typescript
 * const claim: QuoteClaim = {
 *   signedQuote: '0x01...', // [uint8 0x01][abi.encode(Quote)]
 *   refundAddress: '0xUserWallet...',
 * }
 * ```
 */
interface QuoteClaim {
    /**
     * Opaque signed quote bytes (`0x` hex) from the fee-quote service
     * (`SignedFeeQuote.signedQuote` returned by `fetchFeeQuote`). Pass verbatim;
     * do not decode.
     *
     * The quote binds the FORWARD fee item to the on-chain call via `argsHash`;
     * passing a quote that does not match the burn args reverts `QuoteArgsMismatch`.
     */
    signedQuote: string;
    /**
     * Address that receives any refund of overpaid fees.
     *
     * Typically the user wallet that authorized the burn.
     */
    refundAddress: string;
}

/**
 * Central registry for Cross-Chain Transfer Protocol (CCTP) action namespaces.
 *
 * Define versioned action maps for CCTP operations across different protocol
 * versions. Each version key represents a specific CCTP implementation with
 * its own parameter schemas and operational requirements.
 *
 * @remarks
 * CCTP actions enable cross-chain USDC transfers through Circle's native
 * bridging protocol. Each version namespace contains actions specific to
 * that protocol iteration, allowing for protocol upgrades while maintaining
 * backward compatibility in the action system.
 *
 * This interface follows the same pattern as other action namespaces but
 * is organized by protocol version rather than token type.
 *
 * @see {@link CCTPv2ActionMap} for version 2 action definitions
 */
interface CCTPActionMap {
    /** CCTP version 2 operations for cross-chain USDC transfers. */
    readonly v2: CCTPv2ActionMap;
}

/**
 * Permit signature standards for gasless token approvals.
 *
 * Defines the permit types that can be used to approve token spending
 * without requiring a separate approval transaction.
 *
 * @remarks
 * - NONE: No permit, tokens must be pre-approved via separate transaction
 * - EIP2612: Standard ERC-20 permit (USDC, DAI v2, and most modern tokens)
 */
declare enum PermitType {
    /** No permit required - tokens must be pre-approved */
    NONE = 0,
    /** EIP-2612 standard permit */
    EIP2612 = 1
}
/**
 * Token input with permit signature for gasless approval.
 *
 * The Adapter Contract uses this to pull tokens from the user's wallet
 * using permit signatures instead of requiring separate approval transactions.
 *
 * Shared by the `swap.*` and `earn.*` action namespaces because both forward
 * `tokenInputs` unchanged to the adapter contract's `execute` call.
 *
 * @example
 * ```typescript
 * const tokenInput: TokenInput = {
 *   permitType: PermitType.EIP2612,
 *   token: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', // USDC
 *   amount: 1000000n, // 1 USDC
 *   permitCalldata: '0x...' // Encoded permit(value, deadline, v, r, s)
 * }
 * ```
 */
interface TokenInput {
    /**
     * Type of permit to execute.
     */
    permitType: PermitType;
    /**
     * Token contract address to pull from user.
     */
    token: `0x${string}`;
    /**
     * Amount of tokens to pull via permit.
     */
    amount: bigint;
    /**
     * ABI-encoded permit calldata.
     *
     * For EIP-2612: encode(value, deadline, v, r, s)
     *
     * @example '0x0000000000000000000000000000000000000000000000000000000000989680...'
     */
    permitCalldata: `0x${string}`;
}

/**
 * Parameters for executing a service-signed earn operation via the Adapter
 * smart contract on EVM chains.
 *
 * Shared across earn action keys: `earn.deposit`, `earn.withdraw`, and
 * `earn.claimRewards`. Each operation forwards the same `executeParams`,
 * `tokenInputs`, and `signature` triple to the adapter contract's `execute`
 * function. The service signs `executeParams` off-chain; the contract verifies
 * the signature on-chain.
 *
 * @example
 * ```typescript
 * import type { ActionPayload } from '@core/adapter'
 *
 * const params: ActionPayload<'earn.deposit'> = {
 *   executeParams: { instructions: [], tokens: [], execId: 1n, deadline: 0n, metadata: '0x' },
 *   tokenInputs: [],
 *   signature: '0x...',
 * }
 *
 * const prepared = await adapter.prepareAction('earn.deposit', params, { chain, address })
 * const txHash = await prepared.execute()
 * ```
 */
interface ExecuteEarnEVMParams extends ActionParameters {
    /**
     * Execution parameters returned by the earn service.
     *
     * Kept as an opaque record so the adapter forwards the service-signed struct
     * unchanged. The adapter contract ABI decodes it on-chain.
     */
    executeParams: Record<string, unknown>;
    /**
     * Token inputs with permit signatures for gasless approvals.
     *
     * Populated by the earn provider after it decides how token spending is
     * authorised. Today deposit uses a separate `token.approve` transaction and
     * passes `PermitType.NONE`; a future permit-enabled path can populate this
     * field without a breaking change.
     */
    tokenInputs: TokenInput[];
    /**
     * EIP-712 signature from the earn service proxy.
     *
     * The adapter contract verifies this signature on-chain. Passed through
     * unchanged.
     */
    signature: `0x${string}`;
}
/**
 * Parameters for earn execute actions across supported ecosystems.
 *
 * EVM-only today; becomes a union when a non-EVM adapter implementation
 * lands. Action handlers narrow via a property-based type guard, same
 * pattern as {@link ExecuteSwapParams}.
 */
type ExecuteEarnParams = ExecuteEarnEVMParams;
/**
 * Action map for earn operations.
 *
 * Each action key forwards the same `(executeParams, tokenInputs, signature)`
 * triple to the adapter contract. Provider-side orchestration performs any
 * required token approval; this action only prepares the adapter execute call.
 */
interface EarnActionMap {
    /**
     * Execute a service-signed deposit against the adapter contract.
     */
    readonly deposit: ExecuteEarnParams;
    /**
     * Execute a service-signed withdraw against the adapter contract.
     */
    readonly withdraw: ExecuteEarnParams;
    /**
     * Execute a service-signed claim rewards against the adapter contract.
     */
    readonly claimRewards: ExecuteEarnParams;
}

/**
 * Single instruction to execute within the Adapter Contract.
 *
 * Each instruction represents a contract call (swap, fee collection, etc.)
 * with pre-execution approval and post-execution validation.
 *
 * @example
 * ```typescript
 * const swapInstruction: Instruction = {
 *   target: '0x1231DEB6f5749EF6cE6943a275A1D3E7486F4EaE', // LiFi Diamond
 *   data: '0x...',  // LiFi swap calldata
 *   value: 0n,
 *   tokenIn: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48', // USDC
 *   amountToApprove: 1000000000n, // 1000 USDC to approve
 *   tokenOut: '0xdAC17F958D2ee523a2206206994597C13D831ec7', // USDT
 *   minTokenOut: 995000000n // 995 USDT minimum (0.5% slippage)
 * }
 * ```
 */
interface Instruction {
    /**
     * Target contract address to call.
     *
     * Can be a DEX router, fee taker contract, or token contract.
     */
    target: `0x${string}`;
    /**
     * ABI-encoded calldata for the target contract.
     */
    data: `0x${string}`;
    /**
     * ETH value to send with the call (for native token operations).
     *
     * @defaultValue 0n
     */
    value: bigint;
    /**
     * Token to approve to target before executing instruction.
     *
     * Set to zero address (0x00...00) to disable pre-approval.
     */
    tokenIn: `0x${string}`;
    /**
     * Amount of tokenIn to approve to target before executing instruction.
     *
     * @remarks
     * Field name matches the adapter contract's `amountToApprove` parameter exactly.
     *
     * @defaultValue 0n if tokenIn is zero address
     */
    amountToApprove: bigint;
    /**
     * Token to validate minimum balance after instruction.
     *
     * Set to zero address (0x00...00) to disable post-validation.
     */
    tokenOut: `0x${string}`;
    /**
     * Minimum required balance of tokenOut after instruction.
     *
     * @defaultValue 0n if tokenOut is zero address
     */
    minTokenOut: bigint;
}
/**
 * Token recipient for residual sweep.
 *
 * After all instructions complete, the Adapter Contract sweeps
 * any remaining balances to the specified beneficiaries.
 */
interface TokenRecipient {
    /**
     * Token contract address to sweep.
     */
    token: `0x${string}`;
    /**
     * Address to receive swept tokens.
     */
    beneficiary: `0x${string}`;
}
/**
 * Execution parameters for the Adapter Contract.
 *
 * This struct is signed via EIP-712 by the Circle proxy and verified
 * on-chain to ensure the execution is authorized.
 *
 * @remarks
 * The executeParams are provided by the stablecoin-service and must be
 * passed to the Adapter Contract exactly as received (no modification).
 *
 * @example
 * ```typescript
 * const executeParams: ExecuteParams = {
 *   instructions: [
 *     { target: dexRouter, data: swapCalldata, ... }
 *   ],
 *   tokens: [
 *     { token: USDC, beneficiary: userAddress },
 *     { token: USDT, beneficiary: userAddress }
 *   ],
 *   execId: 123456789n,
 *   deadline: BigInt(Math.floor(Date.now() / 1000) + 1800),
 *   metadata: '0x'
 * }
 * ```
 */
interface ExecuteParams {
    /**
     * Array of instructions to execute sequentially.
     *
     * Each instruction can be a swap, fee collection, or other contract call.
     */
    instructions: Instruction[];
    /**
     * Token recipients for residual sweep.
     *
     * Typically a 2-tuple: [tokenIn recipient, tokenOut recipient]
     */
    tokens: TokenRecipient[];
    /**
     * Unique execution identifier for replay protection.
     *
     * Must be globally unique and is marked as used after execution.
     */
    execId: bigint;
    /**
     * Execution deadline timestamp (Unix seconds).
     *
     * Transaction reverts if block.timestamp is greater than deadline.
     */
    deadline: bigint;
    /**
     * Optional metadata for tracking and analytics.
     */
    metadata: `0x${string}`;
}
/**
 * Parameters for executing a swap transaction via the Adapter smart contract.
 *
 * This action executes swap transactions through the Adapter Contract, which
 * handles token approvals via permits (EIP-2612, Permit2, etc.) and executes
 * multi-step swap instructions atomically on-chain.
 *
 * @remarks
 * The swap flow uses the Adapter Contract pattern:
 * 1. Service provides `executeParams` and `signature` (proxy-signed EIP-712)
 * 2. SDK builds `tokenInputs` with permit signatures for gasless approvals
 * 3. SDK calls AdapterContract.execute(executeParams, tokenInputs, signature)
 * 4. Adapter Contract pulls tokens via permits, executes swaps, validates outputs
 *
 * This enables:
 * - Single atomic transaction (permit + swap in one tx)
 * - Gasless approvals via EIP-2612/Permit2
 * - Slippage protection enforced on-chain
 * - Multi-step instructions (swap + fees) atomically
 *
 * **Permit Support**: The SDK constructs `TokenInput` with `permitCalldata`
 * containing the encoded permit signature. The Adapter Contract executes
 * the permit on-chain before pulling tokens.
 *
 * @example
 * ```typescript
 * import type { ExecuteSwapParams } from '@core/adapter'
 * import { createSwap } from '@core/service-client'
 * import { PermitType } from '@core/adapter'
 *
 * // Get swap transaction from service
 * const swapResponse = await createSwap({
 *   tokenInAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   tokenOutAddress: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
 *   tokenInChain: 'Ethereum',
 *   fromAddress: '0x...',
 *   toAddress: '0x...',
 *   amount: '1000000',
 *   apiKey: 'TEST_API_KEY:...',
 * })
 *
 * // Build token inputs with permit
 * const tokenInputs: TokenInput[] = [{
 *   permitType: PermitType.EIP2612,
 *   token: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   amount: 1000000n,
 *   permitCalldata: '0x...' // Encoded permit signature
 * }]
 *
 * // Prepare action parameters
 * const params: ExecuteSwapParams = {
 *   executeParams: swapResponse.transaction.executeParams,
 *   tokenInputs,
 *   signature: swapResponse.transaction.signature,
 *   inputAmount: BigInt(swapResponse.amount),
 *   tokenInAddress: swapResponse.tokenInAddress as `0x${string}`
 * }
 * ```
 */
interface ExecuteSwapEVMParams extends ActionParameters {
    /**
     * Execution parameters from the stablecoin-service.
     *
     * Contains instructions, token recipients, execution ID, deadline, and metadata.
     * This is an EIP-712 signed struct that the Adapter Contract validates.
     *
     * Provided by the service - do not modify.
     */
    executeParams: ExecuteParams;
    /**
     * Token inputs with permit signatures for gasless approvals.
     *
     * The SDK constructs this array with permit data for each token that needs
     * to be pulled from the user's wallet. The Adapter Contract executes these
     * permits on-chain before executing swap instructions.
     *
     * @remarks
     * For EIP-2612 permits, the SDK must:
     * 1. Build typed data with token, spender (Adapter), amount, nonce, deadline
     * 2. Get user signature via `adapter.signTypedData()`
     * 3. Encode as permitCalldata: encode(value, deadline, v, r, s)
     *
     * @example
     * ```typescript
     * [{
     *   permitType: PermitType.EIP2612,
     *   token: '0xUSDC',
     *   amount: 1000000n,
     *   permitCalldata: '0x...'
     * }]
     * ```
     */
    tokenInputs: TokenInput[];
    /**
     * EIP-712 signature from the Circle proxy service.
     *
     * The service signs the executeParams to authorize the execution.
     * The Adapter Contract verifies this signature on-chain.
     *
     * Provided by the service - do not modify.
     */
    signature: `0x${string}`;
    /**
     * Swap input amount in base units.
     *
     * @remarks
     * The amount of tokens being swapped, provided in the token's base units (e.g., wei for ETH,
     * smallest denomination for ERC20 tokens). This value should be extracted from the service
     * response, as it represents the authoritative swap amount for the operation.
     *
     * For native currency swaps (ETH → USDC), this amount is sent as the transaction `value`.
     * For ERC20 swaps (USDC → USDT), this amount determines the permit or approval quantity.
     *
     * @see CreateSwapResponse.amount - Service response field containing this value
     *
     * @example
     * ```typescript
     * import { createSwap } from '@core/service-client'
     *
     * // Get swap transaction from service
     * const response = await createSwap({
     *   tokenInAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
     *   amount: '1000000', // 1 USDC (6 decimals)
     *   ...
     * })
     *
     * // Prepare swap execution using service response amount
     * await adapter.prepareAction('swap.execute', {
     *   executeParams: response.transaction.executeParams,
     *   tokenInputs,
     *   signature: response.transaction.signature,
     *   inputAmount: BigInt(response.amount),
     *   tokenInAddress: response.tokenInAddress,
     * }, context)
     * ```
     */
    inputAmount: bigint;
    /**
     * Token address being swapped from.
     *
     * @remarks
     * Used to determine if the swap involves native currency (ETH, MATIC, etc.) or ERC20 tokens.
     * When tokenInAddress is NATIVE_TOKEN_ADDRESS (0xEeee...), the inputAmount is sent as tx.value.
     *
     * @see CreateSwapResponse.tokenInAddress - Service response field containing this value
     *
     * @example '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE' for ETH
     * @example '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48' for USDC
     */
    tokenInAddress: `0x${string}`;
}
/**
 * Parameters for executing a swap transaction on Solana.
 *
 * This action executes swap transactions on Solana chains by deserializing
 * and executing a pre-built transaction provided by the stablecoin-service.
 *
 * @remarks
 * Unlike EVM chains that use the Adapter Contract pattern, Solana swaps
 * execute a fully serialized transaction provided by the service. The
 * transaction is base64-encoded and contains all necessary instructions
 * for the swap operation.
 *
 * The service handles:
 * - DEX aggregator routing (Jupiter, etc.)
 * - Fee collection
 * - Slippage protection
 * - Token account management
 *
 * @example
 * ```typescript
 * import type { ExecuteSwapSolanaParams } from '@core/adapter'
 * import { createSwap } from '@core/service-client'
 *
 * // Get swap transaction from service
 * const swapResponse = await createSwap({
 *   tokenInAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *   tokenOutAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
 *   tokenInChain: 'Solana',
 *   fromAddress: 'YubQzu18FDqJRyNfG8JqHmsdbxhnoQqcKUHBdUkN6tP',
 *   toAddress: 'YubQzu18FDqJRyNfG8JqHmsdbxhnoQqcKUHBdUkN6tP',
 *   amount: '1000000',
 *   apiKey: 'TEST_API_KEY:...',
 * })
 *
 * // Prepare action parameters
 * const params: ExecuteSwapSolanaParams = {
 *   serializedTransaction: swapResponse.transaction.data
 * }
 * ```
 */
interface ExecuteSwapSolanaParams extends ActionParameters {
    /**
     * Base64-encoded serialized Solana transaction.
     *
     * This transaction is fully constructed by the stablecoin-service and
     * contains all swap instructions, fee payments, and token account setup.
     * The transaction must be deserialized, signed, and submitted to the network.
     *
     * Provided by the service - do not modify.
     *
     * @example 'AQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAQAJFQg...'
     */
    serializedTransaction: string;
}
/**
 * Parameters accepted by the swap.execute action, supporting both EVM and Solana chains.
 *
 * @remarks
 * This union type covers all chain-specific swap execution parameter interfaces
 * currently supported by the App Kit. Extend this union to support
 * additional blockchains as needed. Each member provides all fields required
 * to prepare and execute a pre-built swap transaction on its respective chain.
 *
 * **Type Narrowing**: The correct parameter type is inferred from the chain type
 * in the `OperationContext` passed to `adapter.prepareAction()`. Action handlers
 * use property-based type guards (checking for `executeParams`/`tokenInputs` for EVM
 * or `serializedTransaction` for Solana) to narrow the union type at runtime.
 *
 * - {@link ExecuteSwapEVMParams} - For EVM chains (has `executeParams` and `tokenInputs`)
 * - {@link ExecuteSwapSolanaParams} - For Solana chains (has `serializedTransaction`)
 */
type ExecuteSwapParams = ExecuteSwapEVMParams | ExecuteSwapSolanaParams;
/**
 * Action map for swap operations on EVM chains.
 *
 * This namespace contains actions related to token swapping operations.
 * These actions handle the execution of pre-built swap transactions from
 * DEX aggregators and routing services.
 *
 * @remarks
 * The swap namespace is designed to be extensible for future swap-related
 * operations such as multi-hop swaps, batched swaps, or swap-and-bridge
 * compositions.
 */
interface SwapActionMap {
    /**
     * Execute a pre-built swap transaction.
     *
     * This action prepares and executes swap transactions constructed by the
     * stablecoin-service API. It accepts transaction parameters (to, data, value)
     * and returns a prepared chain request suitable for gas estimation or execution.
     */
    readonly execute: ExecuteSwapParams;
}

interface TokenActionMap {
    /**
     * Set an allowance for a delegate to spend tokens on behalf of the wallet.
     *
     * On chains without native allowance support, this may return a noop result
     * indicating the step can be safely skipped.
     */
    approve: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address that will be approved to spend the tokens.
         */
        delegate: string;
        /**
         * The amount of tokens to approve for spending (in token's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Check the current allowance between an owner and spender for any token.
     *
     * On chains without allowance support, this typically returns the maximum
     * possible value to indicate unlimited spending capability.
     */
    allowance: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address of the wallet that owns the tokens. If not provided, it will be
         * automatically derived from the adapter context.
         */
        walletAddress?: string | undefined;
        /**
         * The address to check the allowance for.
         */
        delegate: string;
    };
    /**
     * Transfer tokens directly from the wallet to another address.
     */
    transfer: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address to send the tokens to.
         */
        to: string;
        /**
         * The amount of tokens to transfer (in token's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Transfer tokens from one address to another using a pre-approved allowance.
     *
     * On chains without allowance support, this may behave differently or throw
     * an error if the operation is not supported.
     */
    transferFrom: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address to transfer tokens from (must have given allowance to the caller).
         */
        from: string;
        /**
         * The address to send the tokens to.
         */
        to: string;
        /**
         * The amount of tokens to transfer (in token's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Get the current token balance for a wallet address.
     */
    balanceOf: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
        /**
         * The address to check the balance for. If not provided, it will be
         * automatically derived from the adapter context.
         */
        walletAddress?: string | undefined;
    };
    /**
     * Get the on-chain name of the token contract.
     *
     * This is a read-only operation. For USDC the value is also the EIP-712
     * domain name, which permit and authorize signing flows need.
     */
    name: ActionParameters & {
        /**
         * The contract address of the token.
         */
        tokenAddress: string;
    };
}

/**
 * USDC-specific operations that automatically resolve the token address.
 *
 * These include all standard ERC20 operations plus additional safety functions
 * that USDC supports. The interface provides the same core operations as
 * {@link TokenActionMap} but without requiring a `tokenAddress` parameter,
 * plus additional USDC-specific extensions.
 *
 * @example
 * ```typescript
 * // USDC operations (address auto-resolved)
 * await adapter.action('usdc.approve', {
 *   delegate: '0x1234...',
 *   amount: '1000000' // 1 USDC
 * })
 *
 * // USDC-specific safe allowance functions
 * await adapter.action('usdc.increaseAllowance', {
 *   delegate: '0x1234...',
 *   amount: '500000' // increase by 0.5 USDC
 * })
 *
 * // vs. general token operations (address required)
 * await adapter.action('token.approve', {
 *   tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
 *   delegate: '0x1234...',
 *   amount: '1000000'
 * })
 * ```
 */
type BaseUSDCActions = {
    [K in keyof TokenActionMap]: Omit<TokenActionMap[K], 'tokenAddress'>;
};
/**
 * USDC action map with both standard ERC20 operations and USDC-specific extensions.
 *
 * This provides all standard token operations plus additional safety functions
 * that USDC implements beyond the base ERC20 standard.
 */
interface USDCActionMap {
    /**
     * Set an allowance for a delegate to spend USDC tokens on behalf of the wallet.
     *
     * Automatically uses the USDC contract address for the current chain.
     * On chains without native allowance support, this may return a noop result.
     */
    approve: BaseUSDCActions['approve'];
    /**
     * Check the current allowance between an owner and spender for USDC tokens.
     *
     * Automatically uses the USDC contract address for the current chain.
     * This is a read-only operation.
     */
    allowance: BaseUSDCActions['allowance'];
    /**
     * Safely increase the allowance for a delegate to spend USDC tokens.
     *
     * This is a USDC-specific function that provides safer allowance management
     * compared to direct approve() calls. Automatically uses the USDC contract
     * address for the current chain.
     */
    increaseAllowance: ActionParameters & {
        /**
         * The address that will have their allowance increased.
         */
        delegate: string;
        /**
         * The amount to increase the allowance by (in USDC's smallest unit).
         */
        amount: bigint;
        /**
         * The chain definition for the current chain.
         */
        chain?: ChainDefinition;
    };
    /**
     * Safely decrease the allowance for a delegate to spend USDC tokens.
     *
     * This is a USDC-specific function that provides safer allowance management.
     * Automatically uses the USDC contract address for the current chain.
     */
    decreaseAllowance: ActionParameters & {
        /**
         * The address that will have their allowance decreased.
         */
        delegate: string;
        /**
         * The amount to decrease the allowance by (in USDC's smallest unit).
         */
        amount: bigint;
    };
    /**
     * Transfer USDC tokens directly from the wallet to another address.
     *
     * Automatically uses the USDC contract address for the current chain.
     */
    transfer: BaseUSDCActions['transfer'];
    /**
     * Transfer USDC tokens from one address to another using a pre-approved allowance.
     *
     * Automatically uses the USDC contract address for the current chain.
     * The caller must have sufficient allowance from the 'from' address.
     */
    transferFrom: BaseUSDCActions['transferFrom'];
    /**
     * Get the current USDC balance for a wallet address.
     *
     * Automatically uses the USDC contract address for the current chain.
     * This is a read-only operation.
     */
    balanceOf: Omit<BaseUSDCActions['balanceOf'], 'tokenAddress'>;
    /**
     * Get the EIP-712 domain name of the USDC contract on the current chain.
     *
     * Automatically uses the USDC contract address for the current chain.
     * This is a read-only operation with no parameters.
     */
    name: ActionParameters & {
        /**
         * Optional chain override; defaults to the operation context chain.
         */
        chain?: ChainDefinition;
    };
}

/**
 * USDT-specific operations that automatically resolve the token address.
 *
 * These include standard ERC20 operations. The interface provides the same core
 * operations as {@link TokenActionMap} but without requiring a `tokenAddress`
 * parameter.
 *
 * @example
 * ```typescript
 * // USDT operations (address auto-resolved)
 * await adapter.action('usdt.transfer', {
 *   to: '0x1234...',
 *   amount: '1000000' // 1 USDT
 * })
 *
 * // vs. general token operations (address required)
 * await adapter.action('token.transfer', {
 *   tokenAddress: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
 *   to: '0x1234...',
 *   amount: '1000000'
 * })
 * ```
 */
type BaseUSDTActions = {
    [K in keyof TokenActionMap]: Omit<TokenActionMap[K], 'tokenAddress'>;
};
/**
 * USDT action map with standard ERC20 operations.
 *
 * This provides standard token operations for USDT transfers.
 */
interface USDTActionMap {
    /**
     * Transfer USDT tokens directly from the wallet to another address.
     *
     * Automatically uses the USDT contract address for the current chain.
     */
    transfer: BaseUSDTActions['transfer'];
}

/**
 * Versioned wrapper for Gateway action namespaces.
 *
 * Follows the same pattern as {@link CCTPActionMap}: each version is a
 * nested namespace so that action keys read `gateway.v1.deposit`, etc.
 *
 * @see {@link GatewayV1ActionMap} for v1 action definitions
 */
interface GatewayActionMap {
    /** Gateway protocol v1 operations. */
    readonly v1: GatewayV1ActionMap;
}
/**
 * Action map for Circle Gateway Wallet v1 contract operations.
 *
 * Mirrors the GatewayWallet interface: deposit variants, delegate management,
 * and balance queries.
 *
 * @see https://developers.circle.com/gateway/references/contract-interfaces-and-events
 * @see https://developers.circle.com/gateway/references/solana-programs
 */
interface GatewayV1ActionMap {
    /**
     * Deposit tokens after approving the Gateway contract. Balance is credited to the caller.
     *
     * Corresponds to `deposit(address token, uint256 value)`.
     */
    deposit: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Deposit tokens on behalf of another address after approving. Balance is credited to `depositor`.
     *
     * Corresponds to `depositFor(address token, address depositor, uint256 value)`.
     */
    depositFor: ActionParameters & {
        /** Token contract address. */
        token: string;
        /** Address that will own the resulting balance. */
        depositor: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Deposit with EIP-2612 permit (gasless approval via signature).
     *
     * Corresponds to `depositWithPermit(token, owner, value, deadline, signature)` (bytes)
     * or the overload with (v, r, s). Use `signature` for EIP-7597 (SCA); use (v, r, s) for EOA.
     */
    depositWithPermit: ActionParameters & {
        /** Token contract address. */
        token: string;
        /** Depositor's address (owner in permit). */
        owner: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Permit deadline (Unix timestamp) or max uint256 for no expiration. */
        deadline: bigint;
        /** Signature as bytes (EIP-7597) or omit and use v, r, s. */
        signature?: `0x${string}`;
        /** ECDSA v (when not using signature bytes). */
        v?: number;
        /** ECDSA r (when not using signature bytes). */
        r?: `0x${string}`;
        /** ECDSA s (when not using signature bytes). */
        s?: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Deposit with EIP-3009 transferWithAuthorization (receiveWithAuthorization).
     *
     * Corresponds to `depositWithAuthorization(token, from, value, validAfter, validBefore, nonce, signature)`
     * or the overload with (v, r, s).
     */
    depositWithAuthorization: ActionParameters & {
        /** Token contract address. */
        token: string;
        /** Depositor's address (from in authorization). */
        from: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Unix timestamp after which the authorization is valid. */
        validAfter: bigint;
        /** Unix timestamp before which the authorization is valid. */
        validBefore: bigint;
        /** Unique nonce (bytes32). */
        nonce: `0x${string}`;
        /** Signature as bytes (EIP-7598) or omit and use v, r, s. */
        signature?: `0x${string}`;
        /** ECDSA v (when not using signature bytes). */
        v?: number;
        /** ECDSA r (when not using signature bytes). */
        r?: `0x${string}`;
        /** ECDSA s (when not using signature bytes). */
        s?: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Grant spending rights to a delegate on the caller's Gateway account.
     *
     * Corresponds to `addDelegate(address token, address delegate)`.
     */
    addDelegate: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Address to authorize as a delegate. */
        delegate: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Revoke spending rights from a delegate on the caller's Gateway account.
     *
     * Corresponds to `removeDelegate(address token, address delegate)`.
     */
    removeDelegate: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Address to revoke as a delegate. */
        delegate: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Check whether an address is authorized as a delegate for a depositor's balance.
     *
     * Corresponds to `isAuthorizedForBalance(address token, address depositor, address addr)`.
     */
    isDelegate: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** The depositor (balance owner) address. */
        depositor: string;
        /** The address to check for delegate status. */
        delegate: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
        /** EVM: specific block number to read state at (for finality-aware checks). */
        blockNumber?: bigint;
        /** Solana: commitment level for the account read. */
        commitment?: 'confirmed' | 'finalized';
    };
    /**
     * Start a delayed fund removal from a Gateway account.
     *
     * Corresponds to `initiateWithdrawal(address token, uint256 value)` (EVM)
     * or the `initiate_withdrawal` instruction (Solana).
     */
    initiateWithdrawal: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Amount in token's smallest unit. */
        value: bigint;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Complete a fund removal after the withdrawal delay has elapsed.
     *
     * Corresponds to `withdraw(address token)` (EVM) or the `withdraw`
     * instruction (Solana). No amount parameter -- the contract returns the
     * full pending withdrawal balance.
     */
    withdraw: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Read the pending withdrawal balance for a depositor.
     *
     * Corresponds to `withdrawingBalance(address token, address depositor)` (EVM)
     * or reading `withdrawing_amount` from the `GatewayDeposit` PDA (Solana).
     */
    withdrawingBalance: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** The depositor whose pending withdrawal to query. */
        depositor: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Read the block number at which a pending withdrawal can be completed.
     *
     * Corresponds to `withdrawalBlock(address token, address depositor)` (EVM)
     * or reading `withdrawal_block` from the `GatewayDeposit` PDA (Solana).
     */
    withdrawalBlock: ActionParameters & {
        /** Token contract address (e.g. USDC). */
        token: string;
        /** The depositor whose withdrawal block to query. */
        depositor: string;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Execute gatewayBurn on the Gateway Wallet contract.
     * Burns tokens from a source chain as part of a cross-chain spend.
     *
     * Corresponds to `gatewayBurn(bytes calldataBytes, bytes signature)`.
     */
    gatewayBurn: ActionParameters & {
        /** ABI-encoded burn intent calldata. */
        calldataBytes: `0x${string}`;
        /** Signature over the burn intent(s). */
        signature: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Execute gatewayMint on the Gateway Minter contract.
     * Mints tokens on the destination chain to complete a cross-chain spend.
     *
     * Corresponds to `gatewayMint(bytes attestationPayload, bytes signature)`.
     */
    gatewayMint: ActionParameters & {
        /** Attestation payload from the Gateway API. */
        attestation: `0x${string}`;
        /** Signature over the attestation. */
        signature: `0x${string}`;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
    /**
     * Sign burn intents using EIP-712 typed data (EVM) or binary encoding (Solana).
     * Returns the signature needed for the Gateway API transfer call.
     */
    signBurnIntents: ActionParameters & {
        /** EIP-712 typed data for EVM, or binary-encoded data for Solana. */
        typedData: unknown;
        /** Chain with Gateway v1 (optional; defaults to operation context chain). */
        chain?: ChainDefinition;
    };
}

/**
 * Native token-related action maps for the bridge kit.
 *
 * This module provides action definitions for native token operations.
 */
interface NativeActionMap {
    /**
     * Transfer native tokens directly from the wallet to another address.
     */
    transfer: ActionParameters & {
        /**
         * The chain to transfer the native tokens on.
         */
        chain?: ChainIdentifier;
        /**
         * The address to send the native tokens to.
         */
        to: string;
        /**
         * The amount of native tokens to transfer.
         */
        amount: bigint;
    };
    /**
     * Get the native token balance (SOL, ETH, etc.) for a wallet address.
     */
    balanceOf: ActionParameters & {
        /**
         * The address to check the native balance for. If not provided, it will be
         * automatically derived from the adapter context.
         */
        walletAddress?: string | undefined;
    };
}

/**
 * Central registry of all available action namespaces and their operations.
 *
 * Define the complete action map structure used throughout the bridge kit.
 * Each top-level key represents a namespace (e.g., 'token', 'usdc') containing
 * related operations. The structure supports arbitrary nesting depth through
 * the recursive utility types provided in this module.
 *
 * @remarks
 * This interface serves as the foundation for type-safe action dispatching
 * and provides compile-time validation of action keys and payload types.
 * All action-related utility types derive from this central definition.
 *
 * @see {@link ActionKeys} for dot-notation action paths
 * @see {@link ActionPayload} for extracting payload types
 */
interface ActionMap {
    /** CCTP-specific operations with automatic address resolution. */
    readonly cctp: CCTPActionMap;
    /** Gateway Wallet operations, versioned (e.g. gateway.v1.deposit). */
    readonly gateway: GatewayActionMap;
    /** Native token operations (ETH, SOL, MATIC, etc.). */
    readonly native: NativeActionMap;
    /** General token operations requiring explicit token addresses. */
    readonly token: TokenActionMap;
    /** USDC-specific operations with automatic address resolution. */
    readonly usdc: USDCActionMap;
    /** USDT-specific operations with automatic address resolution. */
    readonly usdt: USDTActionMap;
    /** Swap operations for DEX aggregator integrations. */
    readonly swap: SwapActionMap;
    /** Earn operations that execute service-signed payloads via the adapter contract. */
    readonly earn: EarnActionMap;
}
/**
 * Determine if a type represents an action parameter object (leaf node).
 *
 * Check whether a type extends the ActionParameters interface, which provides
 * an explicit marker for identifying action parameter objects versus namespace
 * containers that should be traversed during type recursion.
 *
 * @typeParam T - The type to examine for parameter object characteristics
 *
 * @remarks
 * This utility type provides deterministic leaf detection for the recursive
 * type system. By requiring all action parameter objects to extend the
 * ActionParameters interface, we eliminate the need for property name
 * heuristics and make the system more maintainable.
 *
 * @see {@link ActionParameters} for the base interface
 * @see {@link NestedKeys} for usage in path extraction
 */
type IsActionParameterObject<T> = T extends ActionParameters ? true : false;
/**
 * Recursively extract all nested keys from an object type as dot-notation string literals.
 *
 * Traverse object structures of arbitrary depth and generate string literal
 * types representing all possible paths through the structure using dot
 * notation. Stop recursion when encountering action parameter objects (leaves).
 *
 * @typeParam T - The object type to extract nested keys from
 *
 * @remarks
 * This type is the foundation for generating type-safe action paths in
 * dot notation. It automatically adapts to changes in the ActionMap
 * structure and supports unlimited nesting depth for future extensibility.
 *
 * The recursion stops when it encounters objects that match the
 * {@link IsActionParameterObject} criteria, ensuring that only valid
 * action paths are generated.
 *
 * @see {@link ActionKeys} for ActionMap-specific paths
 * @see {@link NestedValue} for extracting types at specific paths
 * @see {@link IsActionParameterObject} for leaf detection logic
 */
type NestedKeys<T> = {
    [K in Extract<keyof T, string>]: IsActionParameterObject<T[K]> extends true ? K : T[K] extends object ? `${K}.${NestedKeys<T[K]>}` : never;
}[Extract<keyof T, string>];
/**
 * Recursively extract the value type at a given dot-notation path.
 *
 * Navigate through nested object types using a dot-notation string path
 * and return the type of the value at that location. Parse the path
 * recursively by splitting on dots and traversing the object structure.
 *
 * @typeParam T - The object type to navigate through
 * @typeParam K - The dot-notation path as a string literal type
 *
 * @remarks
 * This utility type enables type-safe access to deeply nested object
 * properties using dot notation paths. It forms the foundation for
 * extracting payload types from action paths in the ActionMap.
 *
 * @see {@link ActionPayload} for ActionMap-specific value extraction
 * @see {@link NestedKeys} for generating valid path types
 */
type NestedValue<T, K extends string> = K extends `${infer First}.${infer Rest}` ? First extends keyof T ? NestedValue<T[First], Rest> : never : K extends keyof T ? T[K] : never;
/**
 * Union type of all nested action keys in dot notation.
 *
 * Generate string literal types for all possible action paths in the
 * ActionMap structure. Automatically adapt to changes in the ActionMap
 * and support arbitrary levels of nesting for future extensibility.
 *
 * @remarks
 * This type serves as the canonical source for all valid action identifiers
 * in the bridge kit. It ensures compile-time validation of action keys
 * and enables type-safe action dispatching throughout the application.
 *
 * @see {@link ActionPayload} for extracting parameter types
 * @see {@link NamespaceActions} for namespace-specific actions
 * @see {@link ActionMap} for the underlying structure
 */
type ActionKeys = NestedKeys<ActionMap>;
/**
 * Extract the payload type for a specific action based on its dot-notation key.
 *
 * Resolve the parameter type for any action by providing its complete path
 * in dot notation. Leverage the recursive NestedValue type to navigate to
 * the correct payload type regardless of nesting depth. The internal
 * ActionParameters marker is automatically removed from the result.
 *
 * @typeParam T - The action key in dot notation (must extend ActionKeys)
 *
 * @remarks
 * This utility type enables type-safe parameter passing for action
 * dispatching. It automatically infers the correct parameter shape
 * based on the action key, providing compile-time validation and
 * excellent IntelliSense support.
 *
 * The internal `__isActionParams` marker used for type system recursion
 * is automatically omitted from the resulting type, providing clean
 * parameter objects for consumers.
 *
 * @see {@link ActionKeys} for available action identifiers
 * @see {@link NestedValue} for the underlying path resolution logic
 */
type ActionPayload<T extends ActionKeys> = Omit<NestedValue<ActionMap, T>, '__isActionParams'>;

/**
 * Type-safe action handler function signature for specific action types.
 *
 * Defines the contract for functions that process action payloads and return
 * prepared chain requests. Each handler is strongly typed to accept only the
 * payload structure corresponding to its specific action key.
 *
 * @typeParam TActionKey - The specific action key this handler processes.
 * @param params - The action payload matching the specified action key.
 * @param context - The resolved operation context with concrete chain and address values.
 * @returns A promise resolving to a prepared chain request.
 *
 * @example
 * ```typescript
 * import type { ActionHandler } from '@core/adapter'
 *
 * const depositHandler: ActionHandler<'cctp.v2.depositForBurn'> = async (params, context) => {
 *   // context is always defined and has concrete chain and address values
 *   console.log(context.chain.name);
 *   console.log(context.address);
 *   // ... handler logic ...
 *   return preparedRequest;
 * }
 * ```
 */
type ActionHandler<TActionKey extends ActionKeys> = (params: ActionPayload<TActionKey>, context: ResolvedOperationContext) => Promise<PreparedChainRequest>;
/**
 * Type-safe mapping of all available action keys to their corresponding handlers.
 *
 * This type defines a registry object where each key is a valid action key
 * (as defined by {@link ActionKeys}) and each value is an {@link ActionHandler}
 * capable of processing the payload for that action. This enables strongly-typed
 * handler registration and lookup for all supported actions in the App Kits.
 *
 * @remarks
 * Each handler is typed as {@link ActionHandler}, which means the handler
 * must accept the payload type for the specific action key it is registered under.
 * This provides type safety for handler registration and execution, but does not
 * enforce per-key handler parameterization at the type level. For stricter per-key
 * typing, consider using mapped types or generic registry patterns.
 *
 * @example
 * ```typescript
 * import type { ActionHandlers } from '@core/adapter'
 * import type { ActionHandler } from '@core/adapter'
 *
 * const handlers: ActionHandlers = {
 *   'cctp.v2.depositForBurn': async (params, resolved) => {
 *     // params is correctly typed for 'cctp.v2.depositForBurn'
 *     // resolved has concrete chain and address values
 *     // ...handler logic...
 *   },
 *   'usdc.approve': async (params, resolved) => {
 *     // params is correctly typed for 'usdc.approve'
 *     // resolved has concrete chain and address values
 *     // ...handler logic...
 *   }
 * }
 * ```
 */
type ActionHandlers = {
    [K in ActionKeys]?: ActionHandler<K>;
};
/**
 * Type-safe registry for managing and executing blockchain action handlers.
 *
 * Provides a centralized system for registering action handlers with full
 * TypeScript type safety, ensuring that handlers can only be registered
 * with compatible action keys and payload types. Supports both individual
 * handler registration and batch registration operations.
 *
 * @remarks
 * The registry uses a Map internally for O(1) lookups and maintains type
 * safety through generic constraints and careful type assertions. All
 * type assertions are validated at registration time to ensure runtime
 * type safety matches compile-time guarantees.
 */
declare class ActionRegistry {
    readonly actionHandlers: Map<ActionKeys, ActionHandler<ActionKeys>>;
    /**
     * Register a type-safe action handler for a specific action key.
     *
     * Associates an action handler function with its corresponding action key,
     * ensuring compile-time type safety between the action and its expected
     * payload structure. The handler will be available for execution via
     * {@link executeAction}.
     *
     * @typeParam TActionKey - The specific action key being registered.
     * @param action - The action key to register the handler for.
     * @param handler - The handler function for processing this action type.
     * @returns Void.
     *
     * @throws Error When action parameter is not a valid string.
     * @throws TypeError When handler parameter is not a function.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     * import type { ActionHandler } from '@core/adapter'
     *
     * const registry = new ActionRegistry()
     *
     * // Register a CCTP deposit handler
     * const depositHandler: ActionHandler<'cctp.v2.depositForBurn'> = async (params, resolved) => {
     *   console.log('Processing deposit:', params.amount)
     *   return {
     *     chainId: params.chainId,
     *     data: '0x...',
     *     to: '0x...',
     *     value: '0'
     *   }
     * }
     *
     * registry.registerHandler('cctp.v2.depositForBurn', depositHandler)
     * ```
     */
    registerHandler<TActionKey extends ActionKeys>(action: TActionKey, handler: ActionHandler<TActionKey>): void;
    /**
     * Register multiple action handlers in a single operation.
     *
     * Efficiently register multiple handlers from a record object, where keys
     * are action identifiers and values are their corresponding handler
     * functions. Provides a convenient way to bulk-register handlers while
     * maintaining type safety.
     *
     * @param handlers - A record mapping action keys to their handler functions.
     * @returns Void.
     *
     * @throws {Error} When handlers parameter is not a valid object.
     * @throws {Error} When any individual handler registration fails.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     * import type { ActionHandler, ActionHandlers } from '@core/adapter'
     *
     * const registry = new ActionRegistry()
     *
     * // Register multiple handlers at once
     * const tokenHandlers: ActionHandlers = {
     *   'token.approve': async (params, resolved) => ({
     *     chainId: resolved.chain,
     *     data: '0x095ea7b3...',
     *     to: params.tokenAddress,
     *     value: '0'
     *   }),
     *   'token.transfer': async (params, resolved) => ({
     *     chainId: resolved.chain,
     *     data: '0xa9059cbb...',
     *     to: params.tokenAddress,
     *     value: '0'
     *   })
     * }
     *
     * registry.registerHandlers(tokenHandlers)
     * console.log('Registered multiple token handlers')
     * ```
     */
    registerHandlers(handlers: ActionHandlers): void;
    /**
     * Check whether a specific action is supported by this registry.
     *
     * Determine if a handler has been registered for the given action key.
     * Use this method to conditionally execute actions or provide appropriate
     * error messages when actions are not available.
     *
     * @param action - The action key to check for support.
     * @returns True if the action is supported, false otherwise.
     *
     * @throws {Error} When action parameter is not a valid string.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     *
     * const registry = new ActionRegistry()
     *
     * // Check if actions are supported before attempting to use them
     * if (registry.supportsAction('token.approve')) {
     *   console.log('Token approval is supported')
     * } else {
     *   console.log('Token approval not available')
     * }
     *
     * // Conditional logic based on support
     * const action = 'cctp.v2.depositForBurn'
     * if (registry.supportsAction(action)) {
     *   // Safe to execute
     *   console.log(`${action} is available`)
     * } else {
     *   console.warn(`${action} is not registered`)
     * }
     * ```
     */
    supportsAction(action: ActionKeys): boolean;
    /**
     * Execute a registered action handler with type-safe parameters.
     *
     * Look up and execute the handler associated with the given action key,
     * passing the provided parameters and context, returning the resulting prepared
     * chain request. TypeScript ensures the parameters match the expected
     * structure for the specified action.
     *
     * @typeParam TActionKey - The specific action key being executed.
     * @param action - The action key identifying which handler to execute.
     * @param params - The parameters to pass to the action handler.
     * @param context - The resolved operation context with concrete chain and address values.
     * @returns A promise resolving to the prepared chain request.
     * @throws {KitError} When the handler execution fails with a structured error.
     * @throws {Error} When no handler is registered for the specified action.
     * @throws {Error} When the handler execution fails with an unstructured error.
     *
     * @example
     * ```typescript
     * import { ActionRegistry } from '@core/adapter'
     * import type { ChainEnum } from '@core/chains'
     *
     * const registry = new ActionRegistry()
     *
     * // First register a handler
     * registry.registerHandler('token.approve', async (params, context) => ({
     *   chainId: context.chain, // Always defined
     *   data: '0x095ea7b3...',
     *   to: params.tokenAddress,
     *   value: '0'
     * }))
     *
     * // Execute the action with resolved context (typically called from adapter.prepareAction)
     * const resolvedContext = { chain: 'Base', address: '0x123...' }
     * const result = await registry.executeAction('token.approve', {
     *   chainId: ChainEnum.Ethereum,
     *   tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
     *   delegate: '0x1234567890123456789012345678901234567890',
     *   amount: '1000000'
     * }, resolvedContext)
     *
     * console.log('Transaction prepared:', result.data)
     * ```
     */
    executeAction<TActionKey extends ActionKeys>(action: TActionKey, params: ActionPayload<TActionKey>, context: ResolvedOperationContext): Promise<PreparedChainRequest>;
}

/**
 * Canonical list of actions that do not prepare or submit transactions.
 *
 * @internal
 */
declare const READ_ACTION_KEYS: readonly ["token.allowance", "token.balanceOf", "token.name", "native.balanceOf", "usdc.allowance", "usdc.balanceOf", "usdc.name", "gateway.v1.isDelegate", "gateway.v1.withdrawingBalance", "gateway.v1.withdrawalBlock", "gateway.v1.signBurnIntents"];
/**
 * Action keys that execute without preparing or submitting a transaction.
 *
 * @remarks
 * Derive this type from the canonical runtime list so compile-time and runtime
 * classification cannot drift. `gateway.v1.signBurnIntents` is included
 * because the action system models off-chain signing as a read action: it does
 * not prepare a chain request.
 *
 * @example
 * ```typescript
 * import type { ReadActionKey } from '@core/adapter'
 *
 * const action: ReadActionKey = 'token.allowance'
 * ```
 */
type ReadActionKey = (typeof READ_ACTION_KEYS)[number];

/**
 * Defines the capabilities of an adapter, including address handling patterns and supported chains.
 *
 * @interface TAdapterCapabilities
 * @category Types
 * @description
 * This interface specifies how an adapter manages address control and which blockchain networks it supports.
 * It is used for capability discovery, validation, and to inform consumers about the adapter's operational model.
 *
 * The `addressContext` property determines both address selection behavior and bridge API requirements:
 * - `'user-controlled'`: User controls addresses through wallet UI, address optional in operations
 * - `'developer-controlled'`: Service manages addresses programmatically, address required in operations
 *
 * @example
 * ```typescript
 * // Browser wallet adapter (user-controlled)
 * const capabilities: AdapterCapabilities = {
 *   addressContext: 'user-controlled', // User selects address in wallet UI
 *   supportedChains: [Ethereum, Base, Polygon]
 * }
 *
 * // Enterprise provider adapter (developer-controlled)
 * const capabilities: AdapterCapabilities = {
 *   addressContext: 'developer-controlled', // Address must be specified per operation
 *   supportedChains: [Ethereum, Base, Solana]
 * }
 * ```
 */
interface AdapterCapabilities {
    /**
     * Defines who controls address selection for wallet operations.
     *
     * - `'user-controlled'`: User controls addresses through wallet UI (browser wallets, hardware wallets)
     *   - Address is implicit in bridge operations (uses wallet's current address)
     *   - Adapter may listen for accountsChanged/chainChanged events
     *   - Suitable for MetaMask, Coinbase Wallet, WalletConnect, private keys, etc.
     *
     * - `'developer-controlled'`: Service manages addresses programmatically (enterprise providers)
     *   - Address must be explicitly provided in bridge operations
     *   - No event listening (addresses controlled programmatically)
     *   - Suitable for Fireblocks, Circle Wallets, institutional custody, etc.
     */
    addressContext: 'user-controlled' | 'developer-controlled';
    /**
     * The set of blockchain networks this adapter supports.
     * Used for validation, capability discovery, and to restrict operations to supported chains.
     *
     * @remarks
     * Typed `readonly` to match the `@core/adapter-base` `AdapterCapabilities`
     * shape, so the /next adapters (which preserve `readonly` capabilities per
     * PR #853 A1) remain structurally assignable to this legacy `Adapter`
     * contract. The collection is only ever read, never mutated.
     */
    supportedChains: readonly ChainDefinition[];
}
/**
 * Abstract class defining the standard interface for an adapter that interacts with a specific blockchain.
 *
 * An `Adapter` is responsible for encapsulating chain-specific logic necessary to
 * perform operations like sending transactions, querying balances, or interacting with smart contracts.
 * Implementations of this class will provide concrete logic for a particular blockchain protocol.
 *
 * This abstraction allows the App Kit to work with multiple blockchains in a uniform way.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type for compile-time address validation.
 * When provided, enables strict typing of operation context based on the adapter's address control model.
 */
declare abstract class Adapter<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> {
    /**
     * The type of the chain for this adapter.
     *
     * - For concrete adapters, this should be a real chain type (e.g., `'evm'`, `'solana'`, etc.) from the ChainType union.
     * - For hybrid adapters (adapters that route to concrete adapters supporting multiple ecosystems),
     *   set this property to the string literal `'hybrid'`.
     *
     * Note: `'hybrid'` is not a legal ChainType and should only be used as a marker for multi-ecosystem adapters.
     * Hybrid adapters do not interact directly with any chain, but instead route requests to a concrete underlying adapter.
     *
     * @example
     *   // For an EVM-only adapter:
     *   chainType = 'evm'
     *
     *   // For a hybrid adapter:
     *   chainType = 'hybrid'
     */
    abstract chainType: ChainType | 'hybrid';
    /**
     * Capabilities of this adapter, defining address control model and supported chains.
     *
     * This property determines how the adapter behaves, especially for address selection
     * and bridge API requirements. The `addressContext` must match the adapter's type parameter.
     *
     * @remarks
     * The `addressContext` value must align with the adapter's generic type parameter for proper
     * type safety in bridge operations.
     *
     * @example
     * ```typescript
     * // User-controlled adapter (private key, browser wallet)
     * capabilities = {
     *   addressContext: 'user-controlled', // Address implicit in bridge operations
     *   supportedChains: [Ethereum, Base, Polygon]
     * }
     *
     * // Developer-controlled adapter (enterprise provider)
     * capabilities = {
     *   addressContext: 'developer-controlled', // Address required in bridge operations
     *   supportedChains: [Ethereum, Base, Solana]
     * }
     * ```
     */
    capabilities?: TAdapterCapabilities;
    /**
     * Registry of available actions for this adapter.
     *
     * The {@link ActionRegistry} provides a catalog of supported operations
     * (such as token transfers, approvals, etc.) that can be performed by this adapter
     * on the connected blockchain. This enables dynamic discovery and invocation
     * of chain-specific or cross-chain actions in a type-safe manner.
     *
     * @readonly
     */
    readonly actionRegistry: ActionRegistry;
    /**
     * Prepares (but does not execute) an action for the connected blockchain.
     *
     * This method looks up the appropriate action handler for the given action key
     * and prepares the transaction request using the provided parameters. The returned
     * {@link PreparedChainRequest} allows developers to estimate gas costs and execute
     * the transaction at a later time, enabling pre-flight simulation and deferred execution.
     *
     * **Compile-time Address Validation**: When used with typed adapters that have capabilities,
     * this method enforces address requirements at compile time:
     * - **User-controlled adapters**: The `address` field is forbidden in the context
     * - **Developer-controlled adapters**: The `address` field is required in the context
     * - **Legacy adapters**: The `address` field remains optional for backward compatibility
     *
     * @remarks
     * This method does not send any transaction to the network. Instead, it returns a
     * prepared request object with `estimate()` and `execute()` methods, allowing
     * developers to inspect, simulate, or submit the transaction as needed.
     *
     * @param action - The action key identifying which handler to use for preparation.
     * @param params - The parameters to pass to the action handler.
     * @param ctx - Operation context with compile-time validated address requirements based on adapter capabilities.
     * @returns A promise that resolves to a {@link PreparedChainRequest} for estimation and execution.
     * @throws Error If the specified action key does not correspond to a registered handler.
     * @throws Error If the provided parameters are invalid for the action.
     * @throws Error If the operation context cannot be resolved.
     *
     * @example
     * ```typescript
     * // User-controlled adapter (address forbidden)
     * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
     * await userAdapter.prepareAction('token.approve', params, {
     *   chain: 'Ethereum'
     *   // address: '0x123...' // ❌ TypeScript error: address not allowed
     * })
     *
     * // Developer-controlled adapter (address required)
     * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
     * await devAdapter.prepareAction('token.approve', params, {
     *   chain: 'Ethereum',
     *   address: '0x123...' // ✅ Required for developer-controlled
     * })
     * ```
     */
    prepareAction<TActionKey extends ActionKeys>(action: TActionKey, params: ActionPayload<TActionKey>, ctx: OperationContext<TAdapterCapabilities>): Promise<PreparedChainRequest>;
    /**
     * Execute a non-transaction action without routing through transaction preparation.
     *
     * @remarks
     * Use this seam for balance, allowance, contract-state, and other actions
     * classified as reads. It never calls {@link Adapter.prepareAction}, so
     * transaction authorization wrappers only observe actions that can produce a
     * signable chain request.
     *
     * @typeParam TActionKey - The read action key.
     * @param action - The read action to execute.
     * @param params - The parameters for the read action.
     * @param ctx - The operation context.
     * @returns The raw action response.
     * @throws {KitError} When the key is not a read action or no handler is registered.
     * @throws Error When the operation context or action handler fails.
     *
     * @example
     * ```typescript
     * import { Ethereum } from '@core/chains'
     *
     * const balance = await adapter.readAction(
     *   'token.balanceOf',
     *   { tokenAddress, walletAddress },
     *   { chain: Ethereum },
     * )
     * ```
     *
     * @internal
     */
    readAction<TActionKey extends ReadActionKey>(action: TActionKey, params: ActionPayload<TActionKey>, ctx: OperationContext<TAdapterCapabilities>): Promise<unknown>;
    /**
     * Read the current token allowance a delegate holds over an owner's tokens.
     *
     * @remarks
     * Perform a network read through {@link Adapter.readAction}. This method
     * never routes through {@link Adapter.prepareAction}. On chains without an
     * allowance model, such as Solana, return the maximum uint256 value.
     *
     * @param params - The token to query and the delegate whose allowance is being read.
     * @param ctx - Operation context with compile-time validated address requirements.
     * @returns A promise resolving to the current allowance in the token's base units.
     * @throws {KitError} When the adapter does not register a `token.allowance` handler.
     * @throws Error When the operation context or action handler fails.
     *
     * @example
     * ```typescript
     * import type { Adapter } from '@core/adapter'
     * import { Ethereum } from '@core/chains'
     *
     * declare const adapter: Adapter
     *
     * const allowance = await adapter.getTokenAllowance(
     *   {
     *     tokenAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
     *     delegate: '0x1111111111111111111111111111111111111111',
     *   },
     *   { chain: Ethereum },
     * )
     * console.log(allowance) // 1000000n
     * ```
     */
    getTokenAllowance(params: ActionPayload<'token.allowance'>, ctx: OperationContext<TAdapterCapabilities>): Promise<bigint>;
    /**
     * Prepares a transaction for future gas estimation and execution.
     *
     * This method should handle any preliminary steps required before a transaction
     * can be estimated or sent. This might include things like serializing transaction
     * data, but it should NOT yet send anything to the network.
     *
     * The returned object contains two functions:
     *  - `estimate()`: Asynchronously calculates and returns the {@link EstimatedGas} for the prepared transaction.
     *  - `execute()`: Asynchronously executes the prepared transaction and returns a promise that resolves
     *                 with the transaction result (e.g., a transaction hash, receipt, or other chain-specific response).
     *
     * **Compile-time Address Validation**: When used with typed adapters that have capabilities,
     * this method enforces address requirements at compile time:
     * - **User-controlled adapters**: The `address` field is forbidden in the context
     * - **Developer-controlled adapters**: The `address` field is required in the context
     * - **Legacy adapters**: The `address` field remains optional for backward compatibility
     *
     * @remarks
     * The specific parameters for `prepare` might vary greatly between chain implementations.
     * Consider defining a generic type or a base type for `transactionRequest` if common patterns emerge,
     * or allow `...args: any[]` if extreme flexibility is needed by implementers.
     * For this abstract definition, we keep it parameter-less, assuming implementations will add specific
     * parameters as needed for their `prepare` method (e.g. `prepare(txDetails: MyChainTxDetails)`).
     *
     * @param params - The prepared chain request parameters for the specific blockchain.
     * @param ctx - Operation context with compile-time validated address requirements based on adapter capabilities.
     * @returns An object containing `estimate` and `execute` methods for the prepared transaction.
     *
     * @example
     * ```typescript
     * // User-controlled adapter (address forbidden)
     * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
     * await userAdapter.prepare(params, {
     *   chain: 'Ethereum'
     *   // address: '0x123...' // ❌ TypeScript error: address not allowed
     * })
     *
     * // Developer-controlled adapter (address required)
     * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
     * await devAdapter.prepare(params, {
     *   chain: 'Ethereum',
     *   address: '0x123...' // ✅ Required for developer-controlled
     * })
     * ```
     */
    abstract prepare(params: PreparedChainRequestParams, ctx: OperationContext<TAdapterCapabilities>): Promise<PreparedChainRequest>;
    /**
     * Retrieves the public address of the connected wallet.
     *
     * This address is used as the default sender for transactions
     * and interactions initiated by this adapter.
     *
     * @param chain - The chain to use for address resolution.
     * @returns A promise that resolves to the blockchain address as a string.
     */
    abstract getAddress(chain: ChainDefinition): Promise<string>;
    /**
     * Switches the adapter to operate on the specified chain.
     *
     * This abstract method must be implemented by concrete adapters to handle their specific
     * chain switching logic. The behavior varies by adapter type:
     * - **Private key adapters**: Recreate clients with new RPC endpoints
     * - **Browser wallet adapters**: Request chain switch via EIP-1193 or equivalent
     * - **Multi-entity adapters**: Typically a no-op (operations are contextual)
     *
     * @param chain - The target chain to switch to.
     * @returns A promise that resolves when the chain switch is complete.
     * @throws When the chain switching fails or is not supported.
     *
     * @remarks
     * This method is called by `ensureChain()` after validation is complete.
     * Implementations should focus only on the actual switching logic, not validation.
     *
     * @example
     * ```typescript
     * // EVM adapter implementation
     * protected async switchToChain(chain: ChainDefinition): Promise<void> {
     *   if (chain.type !== 'evm') {
     *     throw new Error('Only EVM chains supported')
     *   }
     *   await this.recreateWalletClient(chain)
     * }
     *
     * // Multi-entity adapter implementation
     * protected async switchToChain(chain: ChainDefinition): Promise<void> {
     *   // No-op - operations are contextual
     *   return
     * }
     * ```
     */
    abstract switchToChain(chain: ChainDefinition): Promise<void>;
    /**
     * Ensures the adapter is operating on the specified chain, switching if necessary.
     *
     * This method provides a unified interface for establishing chain preconditions across different adapter types.
     * The behavior varies based on the adapter's capabilities:
     * - **Private key adapters**: Recreate clients with new RPC endpoints
     * - **Browser wallet adapters**: Request chain switch via EIP-1193 or equivalent
     * - **Multi-entity adapters**: Validate chain support (operations are contextual)
     *
     * @param chain - The target chain for operations.
     * @returns A promise that resolves when the adapter is operating on the specified chain.
     * @throws When the target chain is not supported or chain switching fails.
     *
     * @remarks
     * This method always calls `switchToChain()` to ensure consistency across all adapter types.
     * The underlying implementations handle idempotent switching efficiently (e.g., browser wallets
     * gracefully handle switching to the current chain, private key adapters recreate lightweight clients).
     *
     * @example
     * ```typescript
     * // Private key adapter - switches chains seamlessly
     * await privateKeyAdapter.ensureChain(Base)
     *
     * // Browser wallet - requests user to switch chains
     * await metamaskAdapter.ensureChain(Polygon)
     *
     * // Multi-entity adapter - validates chain is supported
     * await circleWalletsAdapter.ensureChain(Ethereum)
     * ```
     */
    ensureChain(targetChain: ChainDefinition): Promise<void>;
    /**
     * Validate that the target chain is supported by this adapter.
     *
     * @param targetChain - The chain to validate.
     * @throws KitError with INVALID_CHAIN code if the chain is not supported by this adapter.
     */
    validateChainSupport(targetChain: ChainDefinition): void;
    /**
     * Waits for a transaction to be mined and confirmed on the blockchain.
     *
     * This method should block until the transaction is confirmed on the blockchain.
     * The response includes comprehensive transaction details for the confirmed transaction.
     *
     * @param txHash - The hash of the transaction to wait for.
     * @param config - Optional configuration for waiting behavior including timeout and confirmations.
     * @param chain - The chain definition where the transaction was submitted.
     * @returns Promise resolving to comprehensive transaction details.
     */
    abstract waitForTransaction(txHash: string, config: WaitForTransactionConfig | undefined, chain: ChainDefinition): Promise<WaitForTransactionResponse>;
    /**
     * Calculate the total transaction fee including compute cost and buffer for the configured chain.
     *
     * This method computes the fee by multiplying the base compute units by the current
     * fee rate, then adds a configurable buffer to account for fee fluctuations and ensure
     * transaction success. The buffer is specified in basis points (1 basis point = 0.01%).
     *
     * @param baseComputeUnits - The base compute units for the transaction (gas for EVM, compute units for Solana, etc.).
     * @param bufferBasisPoints - The buffer to add as basis points (e.g., 500 = 5%). Defaults to implementation-specific value.
     * @param chain - The chain definition to calculate fees for.
     * @returns A promise that resolves to the total transaction fee as a bigint.
     */
    abstract calculateTransactionFee(baseComputeUnits: bigint, bufferBasisPoints: bigint | undefined, chain: ChainDefinition): Promise<EstimatedGas>;
    /**
     * Get the decimal places for a token address on a given chain.
     *
     * This method fetches the number of decimal places from a token contract.
     * Different chain types implement this differently:
     * - EVM: Calls the `decimals()` function on ERC-20 contracts
     * - Solana: Reads the `decimals` field from the SPL token mint account
     *
     * @param tokenAddress - The token contract address (EVM) or mint address (Solana)
     * @param chain - The chain definition where the token is deployed
     * @returns Promise resolving to the number of decimal places for the token
     * @throws Error when the token contract doesn't exist or decimals cannot be fetched
     *
     * @example
     * ```typescript
     * import { EthersAdapter } from '@circle-fin/adapter-ethers-v6'
     * import { Ethereum } from '@core/chains'
     *
     * const adapter = new EthersAdapter({ signer })
     *
     * // Fetch decimals for DAI token
     * const decimals = await adapter.getTokenDecimals(
     *   '0x6B175474E89094C44Da98b954EedeAC495271d0F',
     *   Ethereum
     * )
     * console.log(decimals) // 18
     * ```
     */
    abstract getTokenDecimals(tokenAddress: string, chain: ChainDefinition): Promise<number>;
}

/**
 * Module augmentation to register known token symbols.
 *
 * @remarks
 * This file augments the `TokenSymbolRegistry` interface to provide
 * type-safe autocomplete for built-in tokens.
 *
 * When imported, TypeScript will recognize 'USDC' as a valid
 * `TokenSymbol` value with autocomplete support.
 *
 * Other packages or applications can create their own augmentations
 * to add additional tokens.
 *
 * @example
 * ```typescript
 * import '@core/tokens' // Automatically includes this augmentation
 *
 * const symbol: TokenSymbol = 'USDC' // ✓ Autocomplete shows USDC
 * ```
 */
declare module './types' {
    /**
     * Module augmentation: Adds known token symbols as valid keys
     * to the TokenSymbolRegistry interface.
     *
     * Keys are explicitly listed to ensure IDE autocomplete works properly.
     */
    interface TokenSymbolRegistry {
        USDC: true;
        USDT: true;
        EURC: true;
        DAI: true;
        USDE: true;
        PYUSD: true;
        WETH: true;
        WBTC: true;
        WSOL: true;
        WAVAX: true;
        WPOL: true;
        ETH: true;
        POL: true;
        PLUME: true;
        MON: true;
        cirBTC: true;
    }
}

/**
 * Module augmentation to register Blockchain enum values as ChainIdentifiers.
 *
 * @remarks
 * This file augments the `ChainRegistry` interface to provide type-safe
 * autocomplete for all `Blockchain` enum values from `@core/chains`.
 *
 * When this augmentation is imported (via `@core/tokens`), TypeScript will
 * recognize all blockchain identifiers as valid `ChainIdentifier` values
 * with IDE autocomplete support.
 *
 * The `Blockchain` enum values are converted to their string representations,
 * enabling both enum values and string literals to be accepted as chain identifiers.
 *
 * @example
 * ```typescript
 * import { Blockchain } from '@core/chains'
 * import type { ChainIdentifier } from '@core/tokens'
 *
 * // Using enum value
 * const chain1: ChainIdentifier = Blockchain.Ethereum
 *
 * // Using string literal (with autocomplete!)
 * const chain2: ChainIdentifier = 'Base'
 *
 * // Arbitrary strings also work (escape hatch for custom chains)
 * const chain3: ChainIdentifier = 'my-custom-chain'
 * ```
 */

declare module './types' {
    /**
     * Module augmentation: Adds all Blockchain enum values as valid keys
     * to the ChainRegistry interface for type-safe chain identifier support.
     *
     * This ensures both enum property access (e.g., Blockchain.Ethereum) and plain
     * string literals (e.g., 'Ethereum') are accepted by TypeScript as chain keys,
     * providing robust autocomplete and error checking.
     *
     * NOTE:
     * - This interface intentionally has no body. It merges a mapped Record type
     *   into ChainRegistry solely for type augmentation.
     * - This empty-body construct is a necessary TypeScript idiom for module
     *   augmentation with Record types—directly listing mapped keys is not
     *   feasible in interface extensions.
     *
     * eslint-disable-next-line directives below suppress linter complaints about
     * the empty interface/mapping, which are benign and required for this pattern.
     */
    interface ChainRegistry extends Record<`${Blockchain}`, true> {
    }
}

/**
 * Type utility that infers the final adapter capabilities from partial overrides.
 * This provides clean type inference without complex conditional types.
 */
type InferAdapterCapabilities<T extends Partial<AdapterCapabilities>> = T & {
    addressContext: T extends {
        addressContext: infer A;
    } ? A : 'user-controlled';
    supportedChains: T extends {
        supportedChains: infer S;
    } ? S : ChainDefinition[];
};

/**
 * Abstract base class for Solana-compatible blockchain adapters.
 *
 * This class extends the generic `Adapter` to provide Solana-specific functionality
 * for interacting with Solana blockchain networks. It automatically registers
 * Solana-specific action handlers during construction and sets the chain type to 'solana'.
 *
 * Implementations must provide transport-specific methods for connection management,
 * signing, and transaction execution while inheriting shared Solana functionality
 * for address formatting, fee calculation, and chain detection.
 *
 * @typeParam TConnection - The connection type used by the transport layer
 * @typeParam TSigner - The signer type used by the transport layer
 *
 * @remarks
 * The generic parameters provide type safety while maintaining maximum flexibility
 * for different Solana transport implementations like \@solana/web3.js and \@solana/kit.
 * Individual adapters specify their concrete types when extending this base class.
 */
declare abstract class SolanaBaseAdapter<TConnection = unknown, TSigner = unknown, TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> extends Adapter<TAdapterCapabilities> {
    /**
     * The type of chain this adapter is for.
     */
    chainType: ChainType;
    /**
     * The constructor for the Solana adapter base.
     *
     * @remarks
     * This constructor registers the action handlers for the Solana adapter.
     */
    constructor();
    /**
     * Gets the connection instance for blockchain operations.
     *
     * @param chainDefinition - The chain definition for connection initialization (required).
     * @returns The connection instance used for network communication.
     *
     * @remarks
     * Different implementations may return different connection types:
     * - \@solana/web3.js adapters return Connection
     * - \@solana/kit adapters return their kit-specific connection
     *
     * Connections are cached per chain for efficient multi-chain operations.
     */
    abstract getConnection(chainDefinition: ChainDefinition): TConnection;
    /**
     * Reads the native SOL balance for a given address.
     *
     * This abstract method must be implemented by concrete adapters to fetch
     * the native SOL balance using their specific client libraries.
     *
     * @param address - The wallet address to check the balance for.
     * @param chain - The chain definition to fetch the balance from.
     * @returns Promise resolving to the balance in lamports as a bigint.
     * @throws Error when balance retrieval fails.
     */
    abstract readNativeBalance(address: string, chain: ChainDefinition): Promise<bigint>;
    /**
     * Gets the signer instance for transaction authorization.
     *
     * @param chainDefinition - The chain definition for signer initialization (required).
     * @returns Promise resolving to the signer instance.
     *
     * @remarks
     * Different implementations may return different signer types:
     * - \@solana/web3.js adapters return Signer (Keypair, etc.)
     * - \@solana/kit adapters return their kit-specific signer
     *
     * Signers are cached per chain for API consistency.
     */
    abstract getSigner(ctx: OperationContext<TAdapterCapabilities>): Promise<TSigner>;
    /**
     * Gets an AnchorProvider instance for Anchor-based programs.
     *
     * @param chainDefinition - The chain definition for provider initialization (required).
     * @returns Promise resolving to the AnchorProvider instance.
     *
     * @remarks
     * This method must be implemented by transport-specific adapters to provide
     * access to an AnchorProvider for interacting with Anchor-based programs.
     * Different implementations may create the provider differently based on
     * their transport layer. The chain definition is used for initializing the
     * underlying connection. AnchorProviders are cached per chain.
     */
    abstract getAnchorProvider(ctx: OperationContext<TAdapterCapabilities>): Promise<AnchorProvider>;
    /**
     * Prepares a Solana transaction for execution.
     *
     * @param params - The transaction parameters including instructions and configuration.
     * @returns Promise resolving to a prepared chain request.
     *
     * @remarks
     * This method must handle transport-specific transaction preparation,
     * including validation, simulation, and request object creation.
     */
    abstract prepare(params: SolanaPreparedChainRequestParams | SolanaSignMessagePreparedChainRequestParams, ctx: OperationContext<TAdapterCapabilities>): Promise<PreparedChainRequest>;
    /**
     * Calculates the estimated gas (transaction fee) for Solana operations.
     *
     * @param baseComputeUnits - The base compute units for the transaction.
     * @param bufferBasisPoints - Optional buffer to add as basis points (default: 500 = 5%).
     * @param chain - The Solana chain to calculate fees for (required for connection).
     * @returns Promise resolving to the estimated gas information.
     *
     * @remarks
     * This method provides a unified interface for fee calculation across
     * different Solana transport implementations. The buffer helps account
     * for fee fluctuations and network congestion.
     *
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * // Calculate fee for a transaction requiring 200,000 compute units with default buffer
     * const fee = await adapter.calculateTransactionFee(200000n, undefined, Solana)
     * console.log(`Estimated fee: ${fee.fee} lamports`)
     *
     * // Calculate fee with custom 5% buffer
     * const feeWithCustomBuffer = await adapter.calculateTransactionFee(200000n, 500n, Solana)
     * console.log(`Estimated fee with custom buffer: ${feeWithCustomBuffer.fee} lamports`)
     * ```
     */
    abstract calculateTransactionFee(baseComputeUnits: bigint, bufferBasisPoints: bigint | undefined, chain: ChainDefinition): Promise<EstimatedGas>;
    /**
     * Waits for a transaction to be confirmed and returns the transaction details.
     *
     * @param txHash - The transaction signature to wait for.
     * @param config - Optional configuration for confirmation requirements.
     * @param chain - The Solana chain to wait for transaction on (required for connection).
     * @returns Promise resolving to transaction confirmation details.
     *
     * @remarks
     * This method provides a unified interface for transaction confirmation
     * across different Solana transport implementations.
     *
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * // Wait for transaction with default settings
     * const result = await adapter.waitForTransaction(signature, undefined, Solana)
     * console.log(`Transaction ${result.status}: ${result.transactionHash}`)
     * ```
     */
    abstract waitForTransaction(txHash: string, config: WaitForTransactionConfig | undefined, chain: ChainDefinition): Promise<WaitForTransactionResponse>;
    /**
     * Gets the address of the connected wallet/signer.
     *
     * @param chain - The chain to use for address resolution.
     * @returns Promise resolving to the address string.
     *
     * @remarks
     * This method must be implemented by transport-specific adapters to return
     * the public address of the connected signer.
     */
    abstract getAddress(chain: ChainDefinition): Promise<string>;
    /**
     * Reads the balance of a SPL token for a given wallet address.
     *
     * @param tokenMint - The token mint address to check balance for.
     * @param walletAddress - The wallet address to check the balance for.
     * @param chain - The Solana chain to query (required for connection).
     * @returns Promise resolving to the token balance as a string.
     *
     * @remarks
     * This method abstracts token balance reading across different Solana transports.
     * Each implementation uses its specific connection type to query the associated
     * token account and return the balance.
     */
    abstract readTokenBalance(tokenMint: string, walletAddress: string, chain: ChainDefinition): Promise<string>;
    /**
     * Checks if an account exists at the given address.
     *
     * @param address - The account address to check.
     * @param chain - The Solana chain to query (required for connection).
     * @returns Promise resolving to true if account exists, false otherwise.
     *
     * @remarks
     * This abstracts account existence checking across different Solana transports.
     * Used by CCTP actions to verify associated token accounts exist.
     */
    abstract checkAccountExists(address: string, chain: ChainDefinition): Promise<boolean>;
    /**
     * Gets the associated token account address for a given mint and owner.
     *
     * @param mint - The token mint address.
     * @param owner - The owner's public key address.
     * @param chain - The Solana chain context (required for API consistency).
     * @returns Promise resolving to the associated token account address.
     *
     * @remarks
     * This abstracts ATA derivation across different Solana transports.
     * Used by CCTP and token operations. While ATA derivation is deterministic
     * and doesn't require network access, the chain parameter is included for
     * API consistency with other adapter methods.
     */
    abstract getAssociatedTokenAccount(mint: string, owner: string, _chain: ChainDefinition): Promise<string>;
    /**
     * Get the decimal places for an SPL token on Solana.
     *
     * This method fetches the mint account data and reads the `decimals` field.
     * The connection is obtained via `getConnection()` to support different
     * Solana transport implementations.
     *
     * @param mintAddress - The SPL token mint address
     * @param chain - The Solana chain definition where the token is deployed
     * @returns Promise resolving to the number of decimal places
     * @throws Error when the mint account doesn't exist or decimals cannot be fetched
     *
     * @example
     * ```typescript
     * import { SolanaAdapter } from '@circle-fin/adapter-solana'
     * import { Solana } from '@core/chains'
     *
     * const adapter = new SolanaAdapter({ connection, signer })
     *
     * // Fetch decimals for USDC on Solana
     * const decimals = await adapter.getTokenDecimals(
     *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
     *   Solana
     * )
     * console.log(decimals) // 6
     * ```
     */
    getTokenDecimals(mintAddress: string, chain: ChainDefinition): Promise<number>;
}

/**
 * Configuration options for initializing a SolanaAdapter instance.
 *
 * @interface SolanaAdapterOptions
 * @category Types
 * @description
 * Provides the necessary client instances for blockchain interactions on Solana. This includes the network connection and the signing authority (wallet or keypair).
 *
 * The Solana {@link Connection} instance used to communicate with the Solana cluster. This object is responsible for querying blockchain state, submitting transactions, and interacting with the network.
 * The {@link Signer} instance or a function returning a Promise of a Signer. The signer is responsible for authorizing transactions. It can be a direct keypair or a function for lazy initialization (e.g., for hardware wallets or browser extensions).
 *
 * @example
 * ```typescript
 * import { Connection, Keypair } from '@solana/web3.js';
 * import { SolanaAdapter } from '@circle-fin/adapter-solana';
 * import { Solana } from '@core/chains';
 * import bs58 from 'bs58';
 *
 * // Example 1: Direct signer (traditional approach)
 * const connection = new Connection('https://api.mainnet-beta.solana.com');
 * const keypair = Keypair.fromSecretKey(bs58.decode(process.env.SOLANA_PRIVATE_KEY));
 *
 * const adapter = new SolanaAdapter({
 *   connection,
 *   signer: keypair,
 * }, {
 *   addressContext: 'developer-controlled',
 *   supportedChains: [Solana],
 * });
 *
 * // Example 2: Context-aware lazy initialization (advanced)
 * const adapterWithLazySigner = new SolanaAdapter({
 *   connection,
 *   signer: async (ctx) => {
 *     // Access operation context for dynamic signer selection
 *     console.log('Initializing signer for chain:', ctx.chain.name);
 *     return await initializeSignerForChain(ctx.chain);
 *   },
 * }, {
 *   addressContext: 'user-controlled',
 *   supportedChains: [Solana],
 * });
 * ```
 */
interface SolanaAdapterOptions<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> {
    /**
     * The Solana Connection instance for blockchain interactions.
     * @remarks
     * If omitted, the adapter lazily creates a connection using `getConnection` (preferred)
     * or a built-in default based on the chain provided via OperationContext.
     */
    connection?: Connection;
    /**
     * Optional chain-aware connection factory for lazy initialization.
     * @remarks
     * When provided, the adapter defers connection creation until the first operation and
     * calls this function with the chain resolved from OperationContext.
     */
    getConnection?: (params: {
        chain: ChainDefinition;
    }) => Connection;
    /**
     * The Solana Signer for transaction signing or a function that returns a Promise of Signer.
     * @remarks
     * Used for transaction signing and address derivation. Can be provided as a function for
     * lazy initialization, which is useful for hardware wallets or browser-based signers.
     *
     * The function receives an OperationContext parameter that provides information about
     * the current operation (chain, address, etc.), enabling context-aware signer selection.
     * Functions that don't need the context can simply ignore the parameter for backwards compatibility.
     */
    signer: Signer | ((ctx: OperationContext<TAdapterCapabilities>) => Promise<Signer>);
}
/**
 * Parameters for building a Solana VersionedTransaction.
 */
/**
 * A `SolanaAdapter` implementation using `@solana/web3.js` for Solana blockchain interactions.
 *
 * This class encapsulates Solana-specific logic, using a `Connection` for reading data
 * and sending transactions, and a `Signer` for transaction signing. It provides
 * transaction fee estimation, preparation, and execution capabilities with full
 * OperationContext support for multi-chain operations.
 *
 *
 * @remarks
 * The constructor accepts a `@solana/web3.js` `Connection` and `Signer` and
 * provides methods like `prepare`, `getAddress`, etc., that utilize these
 * clients for blockchain interactions. Supports both user-controlled and
 * developer-controlled address contexts via capabilities configuration.
 *
 * @example
 * ```typescript
 * import { Connection, Keypair, PublicKey, SystemProgram } from '@solana/web3.js'
 * import { createSolanaAdapterFromPrivateKey } from '@circle-fin/adapter-solana'
 * import bs58 from 'bs58'
 *
 * async function main() {
 *   const connection = new Connection('https://api.devnet.solana.com')
 *   const signer = Keypair.fromSecretKey(bs58.decode('YOUR_BASE58_PRIVATE_KEY'))
 *
 *   // Prefer factories to construct adapters with correct capabilities
 *   const adapter = createSolanaAdapterFromPrivateKey({
 *     privateKey: bs58.encode(signer.secretKey),
 *     connection,
 *      capabilities optional – defaults to developer-controlled with Solana chains
 *   })
 *
 *   const address = await adapter.getAddress()
 *
 *   const prepared = await adapter.prepare({
 *     instructions: [
 *       SystemProgram.transfer({
 *         fromPubkey: signer.publicKey,
 *         toPubkey: new PublicKey('RECIPIENT_PUBLIC_KEY'), // Replace with a recipient's public key
 *         lamports: 1000000,
 *       }),
 *     ],
 *   });
 *
 *   const fee = await prepared.estimate();
 *   console.log('Estimated transaction fee (lamports):', fee);
 *
 *   const txSignature = await prepared.execute();
 *   console.log('Transaction executed:', txSignature);
 * }
 * ```
 */
declare class SolanaAdapter<TAdapterCapabilities extends AdapterCapabilities = AdapterCapabilities> extends SolanaBaseAdapter<Connection, Signer, TAdapterCapabilities> {
    /**
     * Configuration options for this SolanaAdapter instance.
     */
    options: SolanaAdapterOptions<TAdapterCapabilities>;
    /**
     * Cached Connection instances per chain for efficient multi-chain operations.
     * @remarks
     * Connections are cached using chain name as the key to enable seamless
     * switching between multiple Solana chains (mainnet, devnet, testnet) within
     * a single adapter instance.
     */
    private readonly cachedConnections;
    /**
     * Cached Signer instances per chain.
     * @remarks
     * Signers are cached per chain for consistency with other adapters and to
     * support potential future chain-specific signer configurations, though
     * Solana signers are typically chain-agnostic.
     */
    private readonly cachedSigners;
    /**
     * Cached AnchorProvider instances per chain.
     * @remarks
     * AnchorProviders combine connection + wallet and are chain-specific,
     * so we cache them per chain for efficient multi-chain operations.
     */
    private readonly cachedAnchorProviders;
    /** Ongoing signer initialization promises to prevent duplicate initialization */
    private readonly signerInitPromises;
    /**
     * Create a new SolanaAdapter instance for Solana blockchain interactions.
     *
     * This constructor creates an adapter using the OperationContext pattern, requiring
     * explicit capabilities configuration for type safety. It validates both the options
     * and capabilities at construction time to ensure proper configuration.
     *
     * @param options - Configuration options with connection and signer.
     * @param capabilities - Adapter capabilities defining address control and supported chains.
     * @throws Error when options validation fails.
     * @throws Error when capabilities validation fails.
     * @throws Error when capabilities.addressContext is not explicitly defined.
     * @throws Error when capabilities.supportedChains contains non-Solana chains.
     *
     * @example
     * ```typescript
     * import { createSolanaAdapterFromPrivateKey } from '@circle-fin/adapter-solana'
     * import { SolanaDevnet } from '@core/chains'
     *
     * const adapter = createSolanaAdapterFromPrivateKey({
     *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
     *   capabilities: {
     *     addressContext: 'user-controlled',
     *     supportedChains: [SolanaDevnet],
     *   },
     * })
     * ```
     */
    constructor(options: SolanaAdapterOptions<TAdapterCapabilities>, capabilities: TAdapterCapabilities);
    /**
     * Resets all cached state in the adapter, including Solana-specific caches.
     *
     * This method extends the base class resetState() to also clear Solana-specific
     * caches like connections, signers, and anchor providers. It ensures a clean state when
     * the adapter needs to be reinitialized (e.g., after chain or account changes).
     *
     * @override
     * @remarks
     * When the adapter state needs to be reset (e.g., user changes wallet accounts,
     * switches chains in a dramatic way, or the connection becomes stale), this method
     * clears all cached state to force re-initialization on next access.
     *
     * **What gets cleared:**
     * - Base class caches: `cachedAddress` and `cachedChain`
     * - Solana-specific caches: all connections, signers, and anchor providers
     *
     * @example
     * ```typescript
     * // Called automatically during certain chain switches
     * await adapter.switchToChain(SolanaDevnet)
     *
     * // Or called manually to clear all caches
     * adapter.resetState()
     *
     * // Next call will reinitialize
     * const connection = adapter.getConnection(Solana) // Creates new connection
     * ```
     */
    resetState(): void;
    /**
     * Generates a cache key from the operation context.
     *
     * @param ctx - The operation context to generate a key for.
     * @returns A string key for caching purposes.
     *
     * @remarks
     * The cache key is based on the chain name and address from the context.
     * This ensures signers are properly cached per unique context combination,
     * which is critical for developer-controlled adapters where the address
     * can vary per operation.
     */
    private generateSignerCacheKey;
    /**
     * Gets the validated Solana Connection instance with per-chain caching.
     *
     * @param chainDefinition - The chain definition for connection initialization (required).
     * @returns The validated {@link Connection} instance used for all blockchain operations.
     *
     * @remarks
     * This method ensures that the connection is always valid and up-to-date. It is used
     * internally by all methods that require network access. Connections are cached per
     * chain to enable efficient multi-chain operations.
     *
     * **Caching Strategy:**
     * - If a cached connection exists for the chain, it is returned immediately
     * - Otherwise, a new connection is created using `options.getConnection` or `options.connection`
     * - The connection is then cached using the chain name as the key
     * - Caches are cleared via `resetState()` when needed
     *
     * @example
     * ```typescript
     * import { Solana, SolanaDevnet } from '@core/chains'
     *
     * // Get connection for specific chain (lazy initialization)
     * const mainnetConn = adapter.getConnection(Solana)
     * const devnetConn = adapter.getConnection(SolanaDevnet)
     * // Each chain gets its own cached connection
     * ```
     */
    getConnection(chainDefinition: ChainDefinition): Connection;
    /**
     * Gets the validated Solana Signer instance with context-aware caching.
     *
     * @param ctx - The operation context for signer initialization.
     * @returns A Promise resolving to the validated {@link Signer} instance.
     *
     * @remarks
     * This method supports both direct signer objects and lazy-initialized signers
     * (e.g., for hardware wallets or browser extensions). Signers are cached per
     * operation context to prevent redundant initialization. Multiple concurrent
     * calls with the same context will share the initialization promise.
     *
     * **Caching Strategy:**
     * - Signers are cached using both chain and address as cache key
     * - For developer-controlled adapters, different addresses get separate signers
     * - For user-controlled adapters, signers are cached per chain
     * - Promise-based deduplication prevents race conditions on concurrent calls
     *
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * // Get signer (cached per context for consistency)
     * const signer = await adapter.getSigner({ chain: Solana })
     * ```
     */
    getSigner(ctx: OperationContext<TAdapterCapabilities>): Promise<Signer>;
    /**
     * Gets an AnchorProvider instance with per-chain caching.
     *
     * @param chainDefinition - The chain definition for initialization (required).
     * @returns The AnchorProvider instance for the specified chain.
     *
     * @remarks
     * Uses a simple wallet wrapper that works in all environments, avoiding Node.js-specific
     * dependencies. AnchorProviders are cached per chain since they combine a chain-specific
     * connection with a wallet. This enables efficient multi-chain operations where each chain
     * maintains its own provider instance.
     *
     * **Caching Strategy:**
     * - AnchorProviders are cached using chain name as the key
     * - Each chain gets its own provider with dedicated connection
     * - Caches are cleared via `resetState()` when switching or resetting
     *
     * @example
     * ```typescript
     * import { Solana, SolanaDevnet } from '@core/chains'
     *
     * // Get provider for specific chain
     * const mainnetProvider = await adapter.getAnchorProvider(Solana)
     * const devnetProvider = await adapter.getAnchorProvider(SolanaDevnet)
     * // Each chain has its own cached provider
     * ```
     */
    getAnchorProvider(ctx: OperationContext<TAdapterCapabilities>): Promise<AnchorProvider>;
    /**
     * Returns the effective blockhash for a transaction.
     *
     * @param connection - The Solana {@link Connection} instance used to fetch the latest blockhash if needed.
     * @param providedRecentBlockhash - (Optional) A recent blockhash to use for the transaction. If not provided, the latest blockhash will be fetched from the network.
     * @returns The blockhash string to be used in the transaction.
     *
     * @remarks
     * Blockhashes are required for transaction finality and replay protection. This method ensures a valid blockhash is always used.
     */
    private getEffectiveBlockhash;
    /**
     * Builds a Solana VersionedTransaction from the provided parameters.
     *
     * @param params - The {@link BuildVersionedTransactionParams} object containing all required and optional fields for constructing the transaction.
     *   - instructions: An array of {@link TransactionInstruction} objects representing the actions to be performed.
     *   - signer: The {@link Signer} responsible for authorizing the transaction.
     *   - feePayer: (Optional) The {@link PublicKey} of the account paying the transaction fee. Defaults to the signer's public key if not provided.
     *   - nonceInfo: (Optional) Durable nonce information for advanced transaction replay protection.
     *   - blockhash: The recent blockhash to use for the transaction.
     *   - computeUnitLimit: (Optional) The maximum number of compute units the transaction is allowed to consume.
     *   - addressLookupTableAccounts: (Optional) Address Lookup Table accounts for transaction compression.
     *
     * @returns The constructed {@link VersionedTransaction} ready for simulation or execution.
     *
     * @remarks
     * This method is used internally to ensure all transactions are constructed in a consistent, type-safe manner.
     * When Address Lookup Table accounts are provided, the transaction size is compressed by using
     * shorter indices instead of full 32-byte addresses for frequently-used accounts.
     */
    private buildVersionedTransaction;
    /**
     * Estimates the transaction fee for a given set of instructions or serialized transaction.
     *
     * @param connection - The Solana Connection instance to use for estimation.
     * @param signer - The Signer instance to use for transaction signing.
     * @param params - The {@link SolanaPreparedChainRequestParams} object containing either transaction instructions or a serialized transaction.
     * @param overrides - (Optional) {@link SolanaEstimateOverrides} to customize compute unit limits or other estimation parameters.
     * @returns A Promise resolving to an {@link EstimatedGas} object, which includes the estimated gas, gas price, and total fee as a string.
     * @throws \{Error\} When connection.getFeeForMessage() fails.
     * @throws \{Error\} When blockhash retrieval fails.
     * @throws \{Error\} When serializedTransaction validation or deserialization fails.
     *
     * @remarks
     * This method supports two flows:
     * 1. **Instructions flow**: Builds a new transaction from provided instructions
     * 2. **Serialized transaction flow**: Uses a pre-built serialized transaction (which may be partially signed)
     *
     * The connection and signer are passed as parameters to avoid redundant calls to getConnection/getSigner.
     */
    private estimate;
    /**
     * Simulates the execution of a Solana transaction using the provided instructions and context, without actually broadcasting it to the network.
     *
     * @param connection - The Solana {@link Connection} instance used to communicate with the cluster.
     * @param signer - The {@link Signer} responsible for authorizing the transaction (typically the wallet or keypair).
     * @param params - The {@link SolanaPreparedChainRequestParams} object containing all transaction details (instructions, fee payer, nonce, etc.).
     * @throws KitError if simulation fails.
     *
     * @remarks
     * This method performs a pre-flight simulation of the transaction without submitting
     * it to the network, consuming no SOL and making no state changes. It's automatically
     * called before transaction execution to catch errors early.
     *
     * **Error Handling:**
     * When simulation fails, the method delegates to `handleSimulationError` which provides
     * intelligent error detection and user-friendly messages for common issues:
     * - Insufficient SOL for ATA creation and transaction fees
     * - Insufficient token (USDC) balance
     * - Missing accounts or ATAs
     * - Anchor program errors and constraint violations
     *
     * All error messages include wallet address, network information, and remediation steps.
     *
     * @example
     * ```typescript
     * await adapter.simulateTransaction(
     *   connection,
     *   signer,
     *   { instructions: [SystemProgram.transfer({ fromPubkey, toPubkey, lamports })], feePayer }
     * );
     * // If no error is thrown, the transaction is likely to succeed if sent.
     * ```
     */
    private simulateTransaction;
    /**
     * Executes the prepared Solana transaction.
     *
     * @param connection - The Solana {@link Connection} instance used to send the transaction to the network.
     * @param signer - The {@link Signer} responsible for signing the transaction.
     * @param params - The {@link SolanaPreparedChainRequestParams} object containing all transaction details (instructions, fee payer, nonce, etc.).
     * @param overrides - (Optional) {@link SolanaExecuteOverrides} to customize execution parameters (e.g., preflight commitment, retries).
     * @returns A Promise resolving to the transaction signature string, which can be used to track the transaction on the blockchain.
     *
     * @throws Error with detailed message if pre-flight simulation fails (insufficient SOL, invalid state, etc.).
     * @throws Error if the transaction fails to confirm or is rejected by the network.
     *
     * @remarks
     * This method performs the complete transaction execution flow:
     *
     * 1. **Pre-flight Simulation**: Simulates the transaction to catch errors before submission
     * 2. **Transaction Signing**: Signs the transaction with the provided signer(s)
     * 3. **Network Submission**: Sends the signed transaction to the Solana network
     * 4. **Confirmation**: Waits for transaction confirmation based on commitment level
     *
     * The pre-flight simulation provides detailed, actionable error messages for common
     * issues like insufficient SOL for ATA creation or insufficient token balances.
     */
    execute(connection: Connection, signer: Signer, params: SolanaPreparedChainRequestParams, overrides?: SolanaExecuteOverrides): Promise<string>;
    /**
     * Executes a pre-built serialized transaction.
     */
    private executeSerializedTransaction;
    /**
     * Executes a transaction built from instructions.
     */
    private executeInstructionsTransaction;
    /**
     * Signs and sends transaction using a provider-based signer (e.g., wallet adapter).
     */
    private sendWithProviderSigner;
    /**
     * Signs and sends transaction using a keypair-based signer.
     */
    private sendWithKeypairSigner;
    /**
     * Confirms transaction and throws if reverted.
     */
    private confirmAndValidate;
    /**
     * Prepares a Solana transaction for execution, including pre-flight simulation.
     *
     * @param params - The {@link SolanaPreparedChainRequestParams} object containing either transaction instructions or a serialized transaction.
     * @param ctx - The {@link OperationContext} containing the chain and address context for this operation.
     * @returns A Promise resolving to a {@link PreparedChainRequest} object, which exposes `estimate` and `execute` methods for the prepared transaction.
     *
     * @throws Error When neither instructions nor serializedTransaction is provided.
     * @throws Error When both instructions and serializedTransaction are provided (mutually exclusive).
     * @throws Error When the target chain is not a Solana chain.
     * @throws Error When OperationContext resolution fails or capabilities are not configured.
     * @throws Error When pre-flight simulation fails (transaction would revert on-chain).
     *
     * @remarks
     * This method supports two flows:
     * 1. **Instructions flow**: Builds a new transaction from provided instructions
     * 2. **Serialized transaction flow**: Uses a pre-built serialized transaction (e.g., from Jupiter)
     *
     * The two flows are mutually exclusive - provide either `instructions` or `serializedTransaction`, not both.
     *
     * @example
     * ```typescript
     * // Instructions flow
     * const adapter = new SolanaAdapter({ connection, signer });
     * const prepared = await adapter.prepare(
     *   {
     *     instructions: [instruction],
     *     feePayer: publicKey
     *   },
     *   { chain: SolanaMainnet }
     * );
     *
     * // Serialized transaction flow (e.g., from Jupiter)
     * const prepared = await adapter.prepare(
     *   {
     *     serializedTransaction: jupiterSwapTransaction
     *   },
     *   { chain: SolanaMainnet }
     * );
     * ```
     */
    prepare(params: SolanaPreparedChainRequestParams, ctx: OperationContext<TAdapterCapabilities>): Promise<PreparedChainRequest>;
    /**
     * Calculate the total transaction fee including compute cost and buffer for Solana.
     *
     * @param baseComputeUnits - The base compute units for the transaction. This represents the computational resources required by the transaction.
     * @param bufferBasisPoints - (Optional) The buffer to add as basis points (e.g., 500 = 5%). Defaults to 500 (5%). This helps account for fee fluctuations and ensures transaction success.
     * @returns A Promise resolving to an EstimatedGas object with:
     * - fee: Total fee in lamports as a string.
     * - gas: Base compute units as a bigint.
     * - gasPrice: Micro-lamports per compute unit as a bigint.
     *
     * @throws Throws an error if the network request fails or the fee calculation fails for any reason.
     *
     * @remarks
     * This method is useful for applications that want to display or pre-fund the expected transaction fee, including a safety margin.
     *
     * @example
     * ```typescript
     * const adapter = new SolanaAdapter({ connection, signer });
     *
     * // Calculate transaction fee with default 5% buffer
     * const fee = await adapter.calculateTransactionFee(200000n);
     * console.log('Transaction fee:', fee.fee, 'lamports');
     *
     * // Calculate transaction fee with custom 10% buffer
     * const feeWithCustomBuffer = await adapter.calculateTransactionFee(200000n, 1000n);
     * console.log('Transaction fee with custom buffer:', feeWithCustomBuffer.fee, 'lamports');
     * ```
     */
    calculateTransactionFee(baseComputeUnits: bigint, bufferBasisPoints: bigint | undefined, chain: ChainDefinition): Promise<EstimatedGas>;
    /**
     * Retrieves the connected wallet address.
     *
     * @param chain - The chain to use for address resolution.
     * @returns A promise that resolves to the connected wallet address.
     * @throws When the wallet has no addresses available.
     * @throws When no chain is provided (should not happen with OperationContext pattern).
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * const adapter = new SolanaAdapter({ connection, signer });
     * const address = await adapter.getAddress(Solana);
     * console.log('Adapter Address', address);
     * ```
     */
    getAddress(chain: ChainDefinition): Promise<string>;
    /**
     * Switches the adapter to operate on the specified Solana chain.
     *
     * For Solana adapters, this is typically a no-op as Solana applications
     * usually don't switch between mainnet/devnet dynamically. All validation
     * is handled by the base class ensureChain method.
     *
     * @returns A promise that resolves immediately (no-op).
     */
    switchToChain(): Promise<void>;
    /**
     * Reads the balance of a SPL token for a given wallet address.
     *
     * @param tokenMint - The token mint address to check balance for.
     * @param walletAddress - The wallet address to check the balance for.
     * @param chain - The Solana chain to query (required for connection).
     * @returns Promise resolving to the token balance as a string.
     *
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * const balance = await adapter.readTokenBalance(
     *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC mint
     *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN', // Wallet address
     *   Solana // Chain context required
     * );
     * console.log(`Balance: ${balance}`); // e.g. "1000000" for 1 USDC
     * ```
     */
    readTokenBalance(tokenMint: string, walletAddress: string, chain: ChainDefinition): Promise<string>;
    /**
     * Checks if an account exists at the given address.
     *
     * @param address - The account address to check.
     * @param chain - The Solana chain to query (required for connection).
     * @returns Promise resolving to true if account exists, false otherwise.
     *
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * const exists = await adapter.checkAccountExists(
     *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
     *   Solana
     * );
     * ```
     */
    checkAccountExists(address: string, chain: ChainDefinition): Promise<boolean>;
    /**
     * Reads the native SOL balance for a given address.
     *
     * @param address - The wallet address to check the balance for.
     * @param chain - The chain definition to fetch the balance from.
     * @returns Promise resolving to the balance in lamports as a bigint.
     * @throws Error when balance retrieval fails.
     *
     * @example
     * ```typescript
     * const balance = await adapter.readNativeBalance(
     *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
     *   Solana
     * )
     * console.log('Balance:', balance.toString(), 'lamports')
     * ```
     */
    readNativeBalance(address: string, chain: ChainDefinition): Promise<bigint>;
    /**
     * Gets the associated token account address for a given mint and owner.
     *
     * @param mint - The token mint address.
     * @param owner - The owner's public key address.
     * @param chain - The Solana chain to query. Used to establish an RPC connection
     *   for detecting whether the mint belongs to the standard Token Program or
     *   Token-2022, which determines the correct ATA derivation.
     * @returns Promise resolving to the associated token account address.
     *
     * @remarks
     * This method makes a network call (`getAccountInfo`) to detect the mint's
     * owning program before deriving the ATA. Token-2022 mints (e.g. PYUSD)
     * require a different program ID for correct ATA derivation.
     *
     * **Performance:** Each invocation incurs one `getAccountInfo` round-trip.
     * Callers that resolve ATAs in bulk should consider caching results.
     *
     * @throws Throws if the RPC call fails (network timeout, rate limit, etc.)
     *   or if the mint/owner addresses are invalid.
     *
     * @example
     * ```typescript
     * import { Solana } from '@core/chains'
     *
     * const ata = await adapter.getAssociatedTokenAccount(
     *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC mint
     *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN', // Owner
     *   Solana
     * );
     * ```
     */
    getAssociatedTokenAccount(mint: string, owner: string, chain: ChainDefinition): Promise<string>;
    /**
     * Waits for a Solana transaction to be confirmed and returns the transaction details.
     *
     * @param txHash - The transaction signature (hash) to wait for. This is a base58-encoded string returned by the network when a transaction is submitted.
     * @param config - (Optional) {@link WaitForTransactionConfig} object specifying confirmation requirements, timeout, and transaction version.
     * @returns A Promise resolving to a {@link WaitForTransactionResponse} object containing transaction status, block info, gas usage, and more.
     *
     * @throws Throws an error if the transaction hash is invalid, the config parameters are invalid, the transaction is not found, or if network issues occur.
     *
     * @remarks
     * This method polls the blockchain until the specified transaction is confirmed with the required number of confirmations. It provides comprehensive transaction details once the transaction is finalized.
     *
     * @example
     * ```typescript
     * const adapter = new SolanaAdapter({ connection, signer });
     * const response = await adapter.waitForTransaction('4hpDKV9zXy...', {
     *   confirmations: 1,
     *   timeout: 30000,
     *   maxSupportedTransactionVersion: 0,
     * });
     * console.log('Transaction status:', response.status);
     * console.log('Block number:', response.blockNumber);
     * ```
     */
    waitForTransaction(txHash: string, config: WaitForTransactionConfig | undefined, chain: ChainDefinition): Promise<WaitForTransactionResponse>;
}

/**
 * Configuration parameters for creating a SolanaAdapter from a private key.
 *
 * @interface CreateSolanaAdapterFromPrivateKeyParams
 * @category Types
 * @description Defines the parameters required to create a SolanaAdapter instance
 * from a private key (supports Base58, Base64, or JSON array formats) for server-side or programmatic wallet operations.
 *
 * @example
 * ```typescript
 * import { CreateSolanaAdapterFromPrivateKeyParams } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet } from '@core/chains'
 *
 * // Using capabilities to declare supported chains
 * const params: CreateSolanaAdapterFromPrivateKeyParams = {
 *   privateKey: 'your-private-key', // Base58, Base64, or JSON array format
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet],
 *   },
 * }
 * ```
 */
interface CreateSolanaAdapterFromPrivateKeyParams<TCapabilities extends Partial<AdapterCapabilities> = object> {
    /**
     * The private key for wallet operations in one of several supported formats.
     * @remarks
     * Supports multiple private key formats for developer convenience:
     * - **Base58** (most common): e.g., '5Kk...'
     * - **Base64**: Standard base64 encoded bytes
     * - **JSON array**: Array of numbers representing bytes, e.g., '[1,2,3,...]'
     *
     * The function will automatically detect and decode the format. This should be:
     * - A securely generated private key
     * - Kept confidential and never exposed in client-side code
     * - Used only in server-side or secure environments
     *
     * The private key will be automatically decoded and used to create a Keypair for signing transactions.
     */
    privateKey: string;
    /**
     * Optional pre-configured Connection instance.
     * @remarks
     * If not provided, a default Connection will be created using the
     * default RPC endpoints for the specified chain. Custom connections
     * can provide:
     * - Optimized RPC endpoints (Helius, QuickNode, Alchemy, etc.)
     * - Custom commitment levels and timeouts
     * - Load balancing across multiple RPC providers
     * - Custom retry logic or caching
     * - Rate limiting compliance
     */
    connection?: Connection;
    /**
     * Optional capabilities configuration for the adapter.
     * @remarks
     * Defines the adapter's address control model and supported chains.
     * - `addressContext`: Determines address control model ('user-controlled')
     * - `supportedChains`: Array of supported blockchain networks
     * If not provided, defaults to user-controlled address context with all chains supported.
     * `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`
     */
    capabilities?: TCapabilities;
}
/**
 * @deprecated Use {@link CreateSolanaAdapterFromPrivateKeyParams} instead.
 *
 * Configuration parameters for creating a SolanaAdapter from a private key.
 *
 * @interface CreateAdapterFromPrivateKeyParams
 * @category Types
 * @description Defines the parameters required to create a SolanaAdapter instance
 * from a private key (supports Base58, Base64, or JSON array formats) for server-side or programmatic wallet operations.
 *
 * @example
 * ```typescript
 * import { CreateAdapterFromPrivateKeyParams } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet } from '@core/chains'
 *
 * // Using capabilities to declare supported chains
 * const params: CreateAdapterFromPrivateKeyParams = {
 *   privateKey: 'your-private-key', // Base58, Base64, or JSON array format
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet],
 *   },
 * }
 * ```
 */
type CreateAdapterFromPrivateKeyParams<TCapabilities extends Partial<AdapterCapabilities> = object> = CreateSolanaAdapterFromPrivateKeyParams<TCapabilities>;
/**
 * Create a SolanaAdapter from a private key.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a private key string. It automatically detects and handles multiple key formats
 * (Base58, Base64, or JSON array) and creates a connection to the appropriate Solana network.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain` (callers may pass `OperationContext.chain` if needed).
 *
 * @param options - Configuration options containing private key, optional connection, and optional capabilities
 * @returns A configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with environment variable (defaults: user-controlled, Solana chains)
 * const adapter = createSolanaAdapterFromPrivateKey({ privateKey: process.env.SOLANA_PRIVATE_KEY! })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = createSolanaAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override capabilities explicitly
 * const adapter = createSolanaAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */
declare function createSolanaAdapterFromPrivateKey<const TCapabilities extends Partial<AdapterCapabilities> = object>({ privateKey, connection, capabilities, }: CreateSolanaAdapterFromPrivateKeyParams<TCapabilities>): SolanaAdapter<InferAdapterCapabilities<TCapabilities>>;
/**
 * @deprecated Use {@link createSolanaAdapterFromPrivateKey} instead.
 *
 * Create a SolanaAdapter from a private key.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a private key string. It automatically detects and handles multiple key formats
 * (Base58, Base64, or JSON array) and creates a connection to the appropriate Solana network.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain` (callers may pass `OperationContext.chain` if needed).
 *
 * @param options - Configuration options containing private key, optional connection, and optional capabilities
 * @returns A configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with environment variable (defaults: user-controlled, Solana chains)
 * const adapter = createAdapterFromPrivateKey({ privateKey: process.env.SOLANA_PRIVATE_KEY! })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = createAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override capabilities explicitly
 * const adapter = createAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */
declare const createAdapterFromPrivateKey: typeof createSolanaAdapterFromPrivateKey;

/**
 * Solana wallet provider interface based on the Solana Wallet Standard.
 * This interface is implemented by wallet providers like Phantom, Solflare, etc.
 */
interface SolanaWalletProvider {
    /** Whether the wallet is currently connected */
    isConnected: boolean;
    /** The current public key of the connected wallet */
    publicKey?: {
        toString(): string;
    };
    /** Connect to the wallet */
    connect(): Promise<{
        publicKey: {
            toString(): string;
        };
    }>;
    /** Disconnect from the wallet */
    disconnect(): Promise<void>;
    /** Sign a transaction */
    signTransaction(transaction: unknown): Promise<unknown>;
    /** Sign multiple transactions */
    signAllTransactions?(transactions: unknown[]): Promise<unknown[]>;
    /** Sign a message */
    signMessage?(message: Uint8Array): Promise<{
        signature: Uint8Array;
    }>;
}

/**
 * Configuration parameters for creating a SolanaAdapter from a wallet provider.
 *
 * @interface CreateSolanaAdapterFromProviderParams
 * @category Types
 * @description Defines the parameters required to create a SolanaAdapter instance
 * from a Solana wallet provider (such as Phantom, Solflare, Backpack, etc.).
 *
 * @example
 * ```typescript
 * import { createSolanaAdapterFromProvider } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet, Solana } from '@core/chains'
 *
 * // Using capabilities to declare supported chains
 * const params: CreateSolanaAdapterFromProviderParams = {
 *   provider: window.solana,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [Solana],
 *   },
 * }
 * ```
 */
interface CreateSolanaAdapterFromProviderParams {
    /**
     * The Solana wallet provider for wallet operations.
     * @remarks
     * This should be a valid Solana wallet provider such as:
     * - Browser wallet providers (Phantom, Solflare, Backpack, etc.)
     * - Custom providers that implement the Solana Wallet Standard
     * - Mobile wallet providers via WalletConnect
     *
     * The provider must support the required methods:
     * - `connect()` for requesting account access
     * - `disconnect()` for disconnecting from the wallet
     * - `signTransaction()` and `signAllTransactions()` for signing
     * - `signMessage()` for message signing
     */
    provider: SolanaWalletProvider;
    /**
     * Optional pre-configured Connection instance.
     * @remarks
     * If not provided, a default Connection will be created using the
     * default RPC endpoints for the specified chain. Custom connections
     * can provide optimized RPC endpoints, caching, or other enhancements.
     *
     */
    connection?: Connection;
    /**
     * Optional capabilities configuration for the adapter.
     * @remarks
     * Defines the adapter's address control model and supported chains.
     * - `addressContext`: Determines address control model ('user-controlled' or 'developer-controlled')
     * - `supportedChains`: Array of supported blockchain networks
     * If not provided, defaults to user-controlled address context with all chains supported.
     * `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`
     * For provider-based adapters, this typically uses 'user-controlled' since users manage addresses through wallet UI.
     */
    capabilities?: Partial<AdapterCapabilities>;
}
/**
 * @deprecated Use {@link CreateSolanaAdapterFromProviderParams} instead.
 *
 * Configuration parameters for creating a SolanaAdapter from a wallet provider.
 *
 * @interface CreateAdapterFromProviderParams
 * @category Types
 * @description Defines the parameters required to create a SolanaAdapter instance
 * from a Solana wallet provider (such as Phantom, Solflare, Backpack, etc.).
 *
 * @example
 * ```typescript
 * import { createSolanaAdapterFromProvider } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet, Solana } from '@core/chains'
 *
 * // Using capabilities to declare supported chains
 * const params: CreateAdapterFromProviderParams = {
 *   provider: window.solana,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [Solana],
 *   },
 * }
 * ```
 */
type CreateAdapterFromProviderParams = CreateSolanaAdapterFromProviderParams;
/**
 * Create a SolanaAdapter from a Solana wallet provider.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a browser wallet provider like Phantom, Solflare, or Backpack. It handles
 * the wallet connection and creates a signer adapter that implements the Solana
 * Signer interface.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain`; OperationContext provides the chain per operation.
 *
 * OperationContext notes:
 * - The returned adapter supports the `OperationContext` pattern across actions.
 * - For user-controlled adapters, `ctx.address` is ignored (resolved from wallet).
 *
 * @param options - Configuration options for creating the adapter. Contains:
 *   - provider: The Solana wallet provider (e.g., window.solana)
 *   - connection: Optional pre-configured Connection instance
 *   - capabilities: Optional capabilities for addressContext and supportedChains
 * @returns A Promise that resolves to a configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with Phantom wallet (defaults: user-controlled, Solana chains; defaultChain is set)
 * const adapter = await createSolanaAdapterFromProvider({ provider: window.solana })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = await createSolanaAdapterFromProvider({
 *   provider: window.solana,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override supportedChains via capabilities (sets adapter.defaultChain to first entry)
 * const adapter = await createSolanaAdapterFromProvider({
 *   provider: window.solana,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */
declare function createSolanaAdapterFromProvider({ provider, connection, capabilities, }: CreateSolanaAdapterFromProviderParams): Promise<SolanaAdapter>;
/**
 * @deprecated Use {@link createSolanaAdapterFromProvider} instead.
 *
 * Create a SolanaAdapter from a Solana wallet provider.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a browser wallet provider like Phantom, Solflare, or Backpack. It handles
 * the wallet connection and creates a signer adapter that implements the Solana
 * Signer interface.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain`; OperationContext provides the chain per operation.
 *
 * OperationContext notes:
 * - The returned adapter supports the `OperationContext` pattern across actions.
 * - For user-controlled adapters, `ctx.address` is ignored (resolved from wallet).
 *
 * @param options - Configuration options for creating the adapter. Contains:
 *   - provider: The Solana wallet provider (e.g., window.solana)
 *   - connection: Optional pre-configured Connection instance
 *   - capabilities: Optional capabilities for addressContext and supportedChains
 * @returns A Promise that resolves to a configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with Phantom wallet (defaults: user-controlled, Solana chains; defaultChain is set)
 * const adapter = await createAdapterFromProvider({ provider: window.solana })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = await createAdapterFromProvider({
 *   provider: window.solana,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override supportedChains via capabilities (sets adapter.defaultChain to first entry)
 * const adapter = await createAdapterFromProvider({
 *   provider: window.solana,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */
declare const createAdapterFromProvider: typeof createSolanaAdapterFromProvider;

export { Blockchain, SolanaAdapter, createAdapterFromPrivateKey, createAdapterFromProvider, createSolanaAdapterFromPrivateKey, createSolanaAdapterFromProvider };
export type { CreateAdapterFromPrivateKeyParams, CreateAdapterFromProviderParams, CreateSolanaAdapterFromPrivateKeyParams, CreateSolanaAdapterFromProviderParams, SolanaAdapterOptions };
