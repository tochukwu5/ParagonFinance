# @circle-fin/adapter-solana

## 1.7.1

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.7.0

### Minor Changes

- Add `getTokenAllowance()` for reading a token allowance directly, returning base
  units as a `bigint`. Reads no longer arrive at `prepareAction`, so wrappers
  around it aren't affected. On Solana this returns the maximum uint256 value.
- Add a `token.name` read action that returns the on-chain name of a token
  contract. Call it with any token selector, for example `{ token: 'USDC' }` or a
  raw contract address. EVM adapters read the contract. Solana adapters report the
  action as unsupported.

  This also restores the `usdc.name` alias, which the `./next` adapters did not
  register. `UnifiedBalanceKit.deposit()` stopped with an
  `INPUT_UNSUPPORTED_ACTION` error before it sent any transaction. The default
  `authorize` strategy and the `permit` strategy both read the USDC contract name.
  All `allowanceStrategy` values now succeed, so the `'approve'` workaround is no
  longer necessary. Circle Wallets user-controlled wallets were affected too,
  because `createCircleUserWalletAdapter` composes
  `@circle-fin/adapter-viem-v2/next`.

  The token registry also gains the USDC address for Celo Alfajores, so `usdc.*`
  actions now resolve on that chain.

  `usdc.name` is deprecated, like the other `usdc.*` aliases. Use `token.name`
  with `{ token: 'USDC' }` instead.

  `usdc.name` is one exception among the `usdc.*` aliases. It always reads the
  chain's default USDC address, and it ignores a custom token registry override.
  This matches the address that Gateway's `permit` and `authorize` signatures
  target, so the two stay consistent. If your token registry overrides USDC and
  you need that override's contract name, call `token.name` with the explicit
  address instead of `usdc.name`.

### Patch Changes

- If an adapter does not implement `getTokenDecimals()`, it now throws a `KitError` instead of a plain `Error`. The `/next` adapters in this release implement it. No call-site change.
- Fix token operations on Solana for an SPL mint that is not in the built-in token registry. On the `/next` entry point, `getTokenDecimals()` now reads the decimal count from the mint account, so it accepts a raw mint address and not only a registry symbol. An invalid mint address, or a chain that is not Solana, now throws a `KitError`. No action is required.

## 1.6.5

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.6.4

### Patch Changes

- Make the SDK safe to bundle and run in browsers/client-side apps.

  - Browser requests omit Node-only headers that would cause CORS failures, including EarnKit’s SDK-version header.
  - Solana operations in App Kit, Adapter Solana Kit, and Gateway work in a browser without requiring a consumer-provided `Buffer` polyfill.
  - Supplying a `kitKey` or Circle Wallets `apiKey` in a browser now fails early. Keep those secrets on the server and forward a prepared transaction or other safe result to the client.

## 1.6.3

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.6.2

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.6.1

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.6.0

### Minor Changes

- Add cooperative cancellation via `AbortSignal`. When an `AbortSignal` is
  supplied through the invocation context, operations check it **before**
  signing/broadcasting and throw `NETWORK_ABORTED` (`3008`) if already aborted,
  and the wait for confirmation aborts promptly when the signal fires. After a
  transaction is broadcast, aborting only stops the local wait — the
  transaction is **not** cancelled on-chain.

- Bound adapter actions and the lifecycle events they emit now carry a
  human-readable `description`, so loggers, metrics, and tracing tools can
  label each step without decoding its internal name. Action registry entries
  exposed through the action dispatch include `description`, and the events
  those actions emit carry it too.

- Introduce the next-generation adapter architecture via `@circle-fin/adapter-solana/next`.

  This release ships a ground-up redesign of the Solana adapter — built around composable primitives, a unified fee model, and first-class observability — while staying fully backward-compatible with the Bridge Kit and all existing providers.

  Import from `/next` today, change nothing else:

  ```ts
  import { createSolanaAdapterFromPrivateKey } from "@circle-fin/adapter-solana/next";
  ```

  What's new:

  - `simulate()` on every prepared transaction — catch errors before paying fees.
  - Consistent `{ fee, units, unitPrice }` fee model across EVM and Solana.
  - Built-in structured logging and pluggable metrics (`runtime` option).
  - Token registry — resolve tokens by symbol instead of hard-coding mint addresses.
  - Configurable confirmation timeouts and automatic retry with exponential backoff.

  This architecture will become the default entrypoint in the next major release.

## 1.5.10

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.5.9

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.5.8

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.5.7

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.5.6

### Patch Changes

- Updated chain registry to include Pharos (mainnet and testnet) — see `@circle-fin/bridge-kit` for bridging support.

## 1.5.5

### Patch Changes

- Bundled Gateway v1 action handlers for Unified Balance Kit on-chain operations

## 1.5.4

### Patch Changes

- Update HyperEVM mainnet explorer URL to resolve location-restricted access issues
- Improved search discoverability

## 1.5.3

### Patch Changes

- Add support for Solana as a forwarder destination

## 1.5.2

### Patch Changes

- Updated chain registry metadata

## 1.5.1

### Patch Changes

- Internal dependency updates. No user-facing changes.

## 1.5.0

### Minor Changes

- Add pre-signed transaction support for multi-signature workflows. Pass a `serializedTransaction` (Uint8Array) to `prepare()` to execute partially signed transactions with additional co-signers.

## 1.4.0

### Minor Changes

Add Circle Forwarder support for CCTP v2 bridging.

Forwarding is a relay-assisted mode where Circle observes the burn transaction,
retrieves attestation data, and submits the destination mint on the user's
behalf. This removes most destination-side orchestration from client code.

What this enables:

- Opt-in forwarding with `useForwarder: true` so Circle handles destination mint
  submission.
- Forwarder-only destinations (no destination adapter required) using
  `{ recipientAddress, chain, useForwarder: true }`.
- Forwarding-fee-aware estimation and max-fee calculation when `maxFee` is
  auto-derived.
- New hook-based burn actions: `cctp.v2.depositForBurnWithHook` and
  `cctp.v2.customBurnWithHook`.
- New forwarding helpers: `buildForwardingHookData` and
  `buildForwardingHookDataBuffer`.
- Chain-level forwarding metadata via `cctp.forwarderSupported` for route
  capability checks.

Compatibility:

- Existing non-forwarded bridge flows remain unchanged.
- If you set `config.maxFee` manually, include any expected forwarding fee.

## 1.3.1

### Patch Changes

- Internal dependency updates for compatibility with the latest core packages. No user-facing changes.

## 1.3.0

### Minor Changes

- Add `native.balanceOf` action to query native token balances (ETH, SOL, etc.)
  - Added `NativeActionMap` with `balanceOf` action to check native token balance for any wallet address
  - Added abstract `readNativeBalance(address, chain)` method to base adapters
  - Implemented `readNativeBalance` in all concrete adapters (Viem, Ethers, Solana, SolanaKit)
  - Registered `native.balanceOf` action handlers for EVM and Solana chains
  - Balance reads are gas-free operations returning balance as string (wei for EVM, lamports for Solana)

### Patch Changes

- Add Address Lookup Table (ALT) support and explicit compute unit limits for Solana CCTP transactions:
  - CCTP mint transactions now use ALT compression to reduce transaction size
  - Explicit compute unit limit (350k) set for mint operations to prevent budget failures
  - New `addressLookupTableAccounts` and `addressLookupTableAddresses` options in prepared params

## 1.2.1

### Patch Changes

- c4e3076: Resolved a compatibility issue in the solana adapter.
  - Solana adapter now gracefully handles WebSocket-related issues with RPC providers that lack WebSocket support.

## 1.2.0

### Minor Changes

- **Improved error detection**: Transactions are now validated before execution, catching issues like insufficient SOL balance, missing token accounts, or insufficient token balance early. This helps you avoid failed transactions and provides actionable error messages with specific remediation steps.
- **Enhanced error messages**: Error messages now include detailed context about your wallet balance, required amounts, and specific airdrop commands for devnet testing. References to Solana SDK documentation are included for easier debugging.
- **Better reliability**: Consistent error handling across all Solana adapters ensures a uniform developer experience regardless of which Solana library you're using.
- Clearer solana factory names eliminate aliasing when using multiple adapters. Prefer `createSolanaAdapterFromProvider` and `createSolanaAdapterFromPrivateKey` over the deprecated generic `createAdapterFromProvider` and `createAdapterFromPrivateKey`. Existing code works unchanged.

### Patch Changes

- Fix unclear error messages when Solana wallet lacks SOL for ATA creation during CCTP operations. Users now receive detailed balance information, exact SOL requirements, and network-specific funding instructions instead of cryptic blockchain errors. Applies to mint, burn, and depositForBurn actions.

- Add `SolanaNetwork` type export for type-safe network identification.

## 1.1.2

### Patch Changes

- Fixed adapter `getAddress()` types to match function logic by requiring a `chain` parameter, and updated documentation accordingly.
- Fixed an issue where bridging USDC to Solana would fail when specifying a recipient address different from the transaction signing wallet. The adapter was creating the Associated Token Account (ATA) for the wrong wallet, causing the bridge transaction to fail. The adapter now correctly creates the ATA for the specified recipient address and delivers USDC to that address. This enables sending USDC to other Solana addresses and is essential for applications using programmatic wallet management and custody solutions.

  Additionally improved error messages when the destination wallet has insufficient SOL balance to cover transaction fees and account rent, making it easier to diagnose and resolve common issues.

- Improved error handling with more informative and consistent error messages.

  Errors now include:

  - Specific error codes for programmatic handling
  - Error type categorization (BALANCE, ONCHAIN, RPC, NETWORK)
  - Recoverability information (FATAL vs RETRYABLE)
  - Clearer error messages with chain context
  - Original error details preserved for debugging

- Fixed bug where tokens could be burned when bridging to unsupported chains. Bridge operations now fail immediately if the adapter doesn't support the source or destination chain, before any tokens are approved or burned. Error messages now clearly list all supported chains when an unsupported chain is used, and chain validation errors use the correct `INVALID_CHAIN` error code instead of `UNSUPPORTED_ROUTE`.

## 1.1.1

### Patch Changes

- Improves the Solana CCTP v2 custom burn flow to ensure developer fee payouts never fail due to a missing associated token account (ATA). The instruction builder now checks for the existence of the developer fee recipient’s ATA and, if absent, emits an idempotent creation instruction.

## 1.1.0

### Minor Changes

- Add context-aware lazy signer initialization for advanced use cases

  The `signer` option in `SolanaAdapterOptions` now supports context-aware functions that receive operation context (chain, address, etc.) as a parameter. This enables:

  - **Dynamic signer selection** based on chain or address context
  - **Hardware wallet integration** with lazy initialization
  - **KMS and secure key management** support
  - **Multi-chain applications** with chain-specific signers

  **New capability:**

  ```typescript
  const adapter = new SolanaAdapter(
    {
      connection,
      signer: async (ctx) => {
        // Access operation context for dynamic signer selection
        console.log("Signing for chain:", ctx.chain.name);

        // Select signer based on chain, address, or other context
        if (ctx.chain.name === "Solana") {
          return await getMainnetSigner();
        } else {
          return await getDevnetSigner();
        }
      },
    },
    capabilities
  );
  ```

  **Backward compatible:** All existing code continues to work without changes. Signer functions can ignore the context parameter if not needed.

  **Performance improvements:** Signers are now cached per operation context with proper deduplication to prevent race conditions during concurrent initialization.

- Improves static gas estimate values for contract calls. Updates adapters' `prepare()` method so that transaction simulation is now performed only during `execute()`, not during `estimate()`. Adds an optional fallback parameter to `estimate()` for cases where gas estimation fails.

### Patch Changes

- Fix CommonJS compatibility by correcting file extensions and package exports. This resolves a "ReferenceError: require is not defined" error that occurred when using packages in CommonJS projects with ts-node.

## 1.0.1

### Patch Changes

- Add support for Arc Testnet chain definition. Arc is Circle's EVM-compatible Layer-1 blockchain designed for stablecoin finance and asset
  tokenization, featuring USDC as the native gas token and sub-second finality via the Malachite BFT consensus engine.
- Improve error messages for developer-controlled address contexts. Calling `getAddress()` on an adapter configured with `addressContext: 'developer-controlled'` now throws a clear error explaining that addresses must be provided explicitly in the operation context.
- Update Sonic Testnet chain definition to canonical network. The `SonicTestnet` chain definition now points to the official Sonic Testnet (chainId: 14601) instead of the deprecated Sonic Blaze Testnet (chainId: 57054). The RPC endpoint has been updated to `https://rpc.testnet.soniclabs.com`, the display name simplified to "Sonic Testnet", and the USDC contract address updated to the new deployment.

  **Breaking Changes:**

  - **Chain ID:** 57054 → 14601
  - **RPC Endpoint:** `https://rpc.blaze.soniclabs.com` → `https://rpc.testnet.soniclabs.com`
  - **USDC Address:** `0xA4879Fed32Ecbef99399e5cbC247E533421C4eC6` → `0x0BA304580ee7c9a980CF72e55f5Ed2E9fd30Bc51`

  **Migration:** If you were using `SonicTestnet`, your application will automatically connect to the new network upon upgrading. Any accounts, contracts, or transactions on the old Blaze testnet (chainId: 57054) will need to be recreated on the new testnet.

## 1.0.0

### Major Changes

- # Solana Adapter 1.0.0 Release 🎉

  Native Solana blockchain adapter enabling seamless USDC transfers between Solana and EVM networks - bridging the gap between Solana's high-performance architecture and the broader EVM ecosystem.

  ## 🚀 Native Solana Features

  - **Full Solana Integration**: Complete support for Solana's unique architecture and transaction model
  - **USDC SPL Token Support**: Native handling of USDC as SPL tokens on Solana
  - **High Performance**: Optimized for Solana's high-throughput, low-latency network
  - **Cross-chain Bridging**: Seamless EVM ↔ Solana USDC transfers via CCTP

  ## 🔗 Network Support

  - **Solana Mainnet**: Full production support for mainnet operations
  - **Solana Devnet**: Complete testnet support for development and testing
  - **Custom RPC Support**: Flexible RPC endpoint configuration for different providers
  - **Connection Management**: Intelligent connection handling with automatic failover

  ## 💼 Flexible Address Management

  **User-Controlled Adapters**

  - Wallet integration with popular Solana wallets (Phantom, Solflare, etc.)
  - Automatic address resolution from connected wallet providers
  - Real-time account change detection and handling

  **Developer-Controlled Adapters**

  - Private key-based signing for server-side applications
  - Deterministic address generation for automated systems
  - Secure keypair management following Solana best practices

  ```typescript
  // User-controlled adapter with wallet
  const adapter = createAdapterFromWallet(wallet);

  // Developer-controlled adapter with private key
  const adapter = createAdapterFromKeypair({
    keypair: Keypair.fromSecretKey(secretKey),
  });
  ```

  ## ⚡ Solana-Optimized Performance

  - **Efficient Transaction Building**: Optimized transaction construction for Solana's model
  - **Smart Fee Calculation**: Dynamic fee estimation with priority fee support
  - **Compute Unit Optimization**: Intelligent compute unit allocation for cost efficiency
  - **Parallel Processing**: Support for Solana's parallel transaction processing

  ## 🪙 SPL Token Management

  - **USDC SPL Token**: Native support for USDC as SPL token on Solana
  - **Associated Token Accounts**: Automatic ATA creation and management
  - **Token Balance Tracking**: Real-time balance monitoring and updates
  - **Multi-token Support**: Extensible architecture for future token support

  ## 🔐 Solana Security

  - **Keypair Security**: Secure handling of Solana keypairs and signing
  - **Transaction Validation**: Comprehensive validation of transaction parameters
  - **Program Interaction**: Safe interaction with Solana programs and instructions
  - **Error Handling**: Detailed error reporting for Solana-specific issues

  ## 🌉 Cross-chain Capabilities

  - **EVM ↔ Solana Bridging**: Seamless USDC transfers between Solana and EVM chains
  - **CCTP Integration**: Native support for Circle's Cross-Chain Transfer Protocol
  - **Attestation Handling**: Automatic management of cross-chain attestations
  - **Finality Tracking**: Real-time monitoring of cross-chain transfer progress

  ## 🛠️ Developer Experience

  - **TypeScript Support**: Full type safety with comprehensive TypeScript definitions
  - **Rich Documentation**: Detailed JSDoc with Solana-specific examples and patterns
  - **Solana Web3.js Integration**: Built on the official Solana Web3.js library
  - **Testing Support**: Comprehensive testing utilities for Solana development

  This adapter brings Solana's unique capabilities into the cross-chain USDC ecosystem, enabling developers to leverage Solana's speed and efficiency while maintaining seamless interoperability with EVM networks.
