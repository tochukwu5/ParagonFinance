/**
 * Copyright (c) 2026, Circle Internet Group, Inc. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

// Buffer polyfill setup - executes before any other code
// Ensures globalThis.Buffer is available for Solana libraries
const { Buffer } = require('buffer');
if (typeof globalThis !== 'undefined' && typeof globalThis.Buffer === 'undefined') {
    globalThis.Buffer = Buffer;
}
if (typeof window !== 'undefined' && typeof window.Buffer === 'undefined') {
    window.Buffer = Buffer;
}


var zod = require('zod');
var pino = require('pino');
var anchor = require('@coral-xyz/anchor');
var web3_js = require('@solana/web3.js');
var bn_js = require('bn.js');
var bs58 = require('bs58');
var ed25519 = require('@noble/curves/ed25519');
var buffer = require('buffer');
var bytes = require('@ethersproject/bytes');
var address = require('@ethersproject/address');

function _interopDefault (e) { return e && e.__esModule ? e.default : e; }

var pino__default = /*#__PURE__*/_interopDefault(pino);
var bs58__default = /*#__PURE__*/_interopDefault(bs58);

/**
 * Valid recoverability values for error handling strategies.
 *
 * - FATAL errors are thrown immediately (invalid inputs, insufficient funds)
 * - RETRYABLE errors are returned when a flow fails to start but could work later
 * - RESUMABLE errors are returned when a flow fails mid-execution but can be continued
 */ const RECOVERABILITY_VALUES = [
    'RETRYABLE',
    'RESUMABLE',
    'FATAL'
];
/**
 * Error type constants for categorizing errors by origin.
 *
 * This const object provides a reference for error types, enabling
 * IDE autocomplete and preventing typos when creating custom errors.
 *
 * @remarks
 * While internal error definitions use string literals with type annotations
 * for strict type safety, this constant is useful for developers creating
 * custom error instances or checking error types programmatically.
 *
 * @example
 * ```typescript
 * import { ERROR_TYPES, KitError } from '@core/errors'
 *
 * // Use for type checking
 * if (error.type === ERROR_TYPES.BALANCE) {
 *   console.log('This is a balance error')
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Use as reference when creating custom errors
 * const error = new KitError({
 *   code: 9999,
 *   name: 'CUSTOM_ERROR',
 *   type: ERROR_TYPES.BALANCE,  // IDE autocomplete works here
 *   recoverability: 'FATAL',
 *   message: 'Custom balance error'
 * })
 * ```
 */ const ERROR_TYPES = {
    /** User input validation and parameter checking */ INPUT: 'INPUT',
    /** Insufficient token balances and amount validation */ BALANCE: 'BALANCE',
    /** On-chain execution: reverts, gas issues, transaction failures */ ONCHAIN: 'ONCHAIN',
    /** Blockchain RPC provider issues and endpoint problems */ RPC: 'RPC',
    /** Internet connectivity, DNS resolution, connection issues */ NETWORK: 'NETWORK',
    /** API throttling, request frequency limits errors */ RATE_LIMIT: 'RATE_LIMIT',
    /** Service errors */ SERVICE: 'SERVICE',
    /** Upstream provider/AMM liquidity unavailable for the requested size */ LIQUIDITY: 'LIQUIDITY',
    /** Catch-all for unrecognized errors (code 0) */ UNKNOWN: 'UNKNOWN'
};
/**
 * Array of valid error type values for validation.
 * Derived from ERROR_TYPES const object.
 */ const ERROR_TYPE_VALUES = Object.values(ERROR_TYPES);

// Create mutable arrays for Zod enum validation
const RECOVERABILITY_ARRAY = [
    ...RECOVERABILITY_VALUES
];
const ERROR_TYPE_ARRAY = [
    ...ERROR_TYPE_VALUES
];
/**
 * Error code ranges for validation.
 * Single source of truth for valid error code ranges.
 *
 * Note: Code 0 is special - it's the UNKNOWN catch-all error.
 */ const ERROR_CODE_RANGES = [
    {
        min: 1000,
        max: 1999,
        type: 'INPUT'
    },
    {
        min: 3000,
        max: 3999,
        type: 'NETWORK'
    },
    {
        min: 4000,
        max: 4999,
        type: 'RPC'
    },
    {
        min: 5000,
        max: 5999,
        type: 'ONCHAIN'
    },
    {
        min: 6000,
        max: 6999,
        type: 'LIQUIDITY'
    },
    {
        min: 7000,
        max: 7999,
        type: 'RATE_LIMIT'
    },
    {
        min: 8000,
        max: 8999,
        type: 'SERVICE'
    },
    {
        min: 9000,
        max: 9999,
        type: 'BALANCE'
    }
];
/** Special code for UNKNOWN errors */ const UNKNOWN_ERROR_CODE = 0;
/**
 * Zod schema for validating ErrorDetails objects.
 *
 * This schema provides runtime validation for all ErrorDetails properties,
 * ensuring type safety and proper error handling for JavaScript consumers.
 *
 * @example
 * ```typescript
 * import { errorDetailsSchema } from '@core/errors'
 *
 * const result = errorDetailsSchema.safeParse({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Source and destination networks must be different'
 * })
 *
 * if (!result.success) {
 *   console.error('Validation failed:', result.error.issues)
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Runtime error
 * const result = errorDetailsSchema.safeParse({
 *   code: 9001,
 *   name: 'BALANCE_INSUFFICIENT_TOKEN',
 *   type: 'BALANCE',
 *   recoverability: 'FATAL',
 *   message: 'Insufficient USDC balance'
 * })
 * ```
 */ const errorDetailsSchema = zod.z.object({
    /**
   * Numeric identifier following standardized ranges:
   * - 0: UNKNOWN - Catch-all for unrecognized errors
   * - 1000-1999: INPUT errors - Parameter validation
   * - 3000-3999: NETWORK errors - Connectivity issues
   * - 4000-4999: RPC errors - Provider issues, gas estimation
   * - 5000-5999: ONCHAIN errors - Transaction/simulation failures
   * - 6000-6999: LIQUIDITY errors - Insufficient upstream liquidity
   * - 7000-7999: RATE_LIMIT errors - API throttling
   * - 8000-8999: SERVICE errors - Internal service errors
   * - 9000-9999: BALANCE errors - Insufficient funds
   */ code: zod.z.number().int('Error code must be an integer').refine((code)=>code === UNKNOWN_ERROR_CODE || ERROR_CODE_RANGES.some((range)=>code >= range.min && code <= range.max), {
        message: 'Error code must be 0 (UNKNOWN) or in valid ranges: 1000-1999 (INPUT), 3000-3999 (NETWORK), 4000-4999 (RPC), 5000-5999 (ONCHAIN), 6000-6999 (LIQUIDITY), 7000-7999 (RATE_LIMIT), 8000-8999 (SERVICE), 9000-9999 (BALANCE)'
    }),
    /** Human-readable ID (e.g., "INPUT_NETWORK_MISMATCH", "BALANCE_INSUFFICIENT_TOKEN") */ name: zod.z.string().min(1, 'Error name must be a non-empty string').regex(/^[A-Z_][A-Z0-9_]*$/, 'Error name must match pattern: ^[A-Z_][A-Z0-9_]*$'),
    /** Error category indicating where the error originated */ type: zod.z.enum(ERROR_TYPE_ARRAY, {
        errorMap: ()=>({
                message: 'Error type must be one of: INPUT, BALANCE, ONCHAIN, RPC, NETWORK, RATE_LIMIT, SERVICE, LIQUIDITY, UNKNOWN'
            })
    }),
    /** Error handling strategy */ recoverability: zod.z.enum(RECOVERABILITY_ARRAY, {
        errorMap: ()=>({
                message: 'Recoverability must be one of: RETRYABLE, RESUMABLE, FATAL'
            })
    }),
    /** User-friendly explanation with context */ message: zod.z.string().min(1, 'Error message must be a non-empty string').max(1000, 'Error message must be 1000 characters or less'),
    /** Raw error details, context, or the original error that caused this one. */ cause: zod.z.object({
        /** Free-form error payload from underlying system */ trace: zod.z.unknown().optional()
    }).optional()
});

/**
 * Validates an ErrorDetails object using Zod schema.
 *
 * @param details - The object to validate
 * @returns The validated ErrorDetails object
 * @throws TypeError When validation fails
 *
 * @example
 * ```typescript
 * import { validateErrorDetails } from '@core/errors'
 *
 * try {
 *   const validDetails = validateErrorDetails({
 *     code: 1001,
 *     name: 'NETWORK_MISMATCH',
 *     recoverability: 'FATAL',
 *     message: 'Source and destination networks must be different'
 *   })
 * } catch (error) {
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */ function validateErrorDetails(details) {
    const result = errorDetailsSchema.safeParse(details);
    if (!result.success) {
        const issues = result.error.issues.map((issue)=>`${issue.path.join('.')}: ${issue.message}`).join(', ');
        throw new TypeError(`Invalid ErrorDetails: ${issues}`);
    }
    return result.data;
}

/**
 * Maximum length for error messages in fallback validation errors.
 *
 * KitError enforces a 1000-character limit on error messages. When creating
 * fallback validation errors that combine multiple Zod issues, we use 950
 * characters to leave a 50-character buffer for:
 * - The error message prefix ("Invalid bridge parameters: ")
 * - Potential encoding differences or formatting overhead
 * - Safety margin to prevent KitError constructor failures
 *
 * This ensures that even with concatenated issue summaries, the final message
 * stays within KitError's constraints.
 */ const MAX_MESSAGE_LENGTH = 950;

/**
 * Structured error class for App Kit operations.
 *
 * This class extends the native Error class while implementing the ErrorDetails
 * interface, providing a consistent error format for programmatic handling
 * across the App Kits ecosystem. All properties are immutable to ensure
 * error objects cannot be modified after creation.
 *
 * @example
 * ```typescript
 * import { KitError } from '@core/errors'
 *
 * const error = new KitError({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Cannot bridge between mainnet and testnet'
 * })
 *
 * if (error instanceof KitError) {
 *   console.log(`Error ${error.code}: ${error.name}`)
 *   // → "Error 1001: INPUT_NETWORK_MISMATCH"
 * }
 * ```
 *
 * @example
 * ```typescript
 * import { KitError } from '@core/errors'
 *
 * // Error with cause information
 * const error = new KitError({
 *   code: 1002,
 *   name: 'INPUT_INVALID_AMOUNT',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Amount must be greater than zero',
 *   cause: {
 *     trace: { providedAmount: -100, minimumAmount: 0 }
 *   }
 * })
 *
 * throw error
 * ```
 */ /**
 * Brand symbol for `KitError`.
 *
 * @remarks
 * Uses `Symbol.for(...)` (the global symbol registry) rather than a
 * module-local `Symbol(...)`, so every `dist/*` bundle that compiles
 * this file ends up with the *same* symbol identity. This is the
 * mechanism that makes {@link isKitError} robust across multiple
 * separately-bundled copies of `@core/errors` — `instanceof` fails
 * cross-bundle (each bundle has its own `KitError` constructor),
 * but a registry symbol resolves to the same value in every bundle.
 *
 * Exported for use by {@link isKitError} only — consumers should
 * treat this as an implementation detail and call `isKitError`
 * instead of inspecting the brand directly.
 *
 * @internal
 */ const KIT_ERROR_BRAND = Symbol.for('circle.KitError');
class KitError extends Error {
    /** Numeric identifier following standardized ranges (1000+ for INPUT errors) */ code;
    /** Human-readable ID (e.g., "NETWORK_MISMATCH") */ name;
    /** Error category indicating where the error originated */ type;
    /** Error handling strategy */ recoverability;
    /** Raw error details, context, or the original error that caused this one. */ cause;
    /**
   * Create a new KitError instance.
   *
   * @param details - The error details object containing all required properties.
   * @throws \{TypeError\} When details parameter is missing or invalid.
   */ constructor(details){
        // Truncate message if it exceeds maximum length to prevent validation errors
        let message = details.message;
        if (message.length > MAX_MESSAGE_LENGTH) {
            message = `${message.slice(0, MAX_MESSAGE_LENGTH - 3)}...`;
        }
        const truncatedDetails = {
            ...details,
            message
        };
        // Validate input at runtime for JavaScript consumers using Zod
        const validatedDetails = validateErrorDetails(truncatedDetails);
        super(validatedDetails.message);
        // Set properties as readonly at runtime
        Object.defineProperties(this, {
            // Brand stamp. Non-enumerable so JSON.stringify / console.log do
            // not dump a `[Symbol(circle.KitError)]: true` line into operator
            // logs, but observable to anyone holding `KIT_ERROR_BRAND`. The
            // symbol is registered (`Symbol.for`) so distinct `dist/*` copies
            // of `@core/errors` resolve to the same identity, which is what
            // makes the brand a cross-bundle-safe replacement for the
            // `instanceof KitError` check used previously.
            [KIT_ERROR_BRAND]: {
                value: true,
                writable: false,
                enumerable: false,
                configurable: false
            },
            name: {
                value: validatedDetails.name,
                writable: false,
                enumerable: true,
                configurable: false
            },
            code: {
                value: validatedDetails.code,
                writable: false,
                enumerable: true,
                configurable: false
            },
            type: {
                value: validatedDetails.type,
                writable: false,
                enumerable: true,
                configurable: false
            },
            recoverability: {
                value: validatedDetails.recoverability,
                writable: false,
                enumerable: true,
                configurable: false
            },
            ...validatedDetails.cause && {
                cause: {
                    value: validatedDetails.cause,
                    writable: false,
                    enumerable: true,
                    configurable: false
                }
            }
        });
    }
}

/**
 * Standardized error code ranges for consistent categorization:
 *
 * - 0: UNKNOWN - Catch-all for unrecognized errors
 * - 1000-1999: INPUT errors - Parameter validation, input format errors
 * - 3000-3999: NETWORK errors - Internet connectivity, DNS, connection issues
 * - 4000-4999: RPC errors - Blockchain provider issues, gas estimation, nonce errors
 * - 5000-5999: ONCHAIN errors - Transaction/simulation failures, gas exhaustion, reverts
 * - 6000-6999: LIQUIDITY errors - Upstream provider/AMM liquidity unavailable
 * - 7000-7999: RATE_LIMIT errors - API throttling, request frequency limits
 * - 8000-8999: SERVICE errors - Internal service errors, server failures
 * - 9000-9999: BALANCE errors - Insufficient funds, token balance, allowance
 */ /**
 * Standardized error definitions for INPUT type errors.
 *
 * Each entry combines the numeric error code, string name, and type
 * to ensure consistency when creating error instances.
 *
 * Error codes follow a hierarchical numbering scheme where the first digit
 * indicates the error category (1 = INPUT) and subsequent digits provide
 * specific error identification within that category.
 *
 *
 * @example
 * ```typescript
 * import { InputError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...InputError.NETWORK_MISMATCH,
 *   recoverability: 'FATAL',
 *   message: 'Source and destination networks must be different'
 * })
 *
 * // Access code, name, and type individually if needed
 * console.log(InputError.NETWORK_MISMATCH.code)  // 1001
 * console.log(InputError.NETWORK_MISMATCH.name)  // 'INPUT_NETWORK_MISMATCH'
 * console.log(InputError.NETWORK_MISMATCH.type)  // 'INPUT'
 * ```
 */ const InputError = {
    /** Network type mismatch between chains (mainnet vs testnet) */ NETWORK_MISMATCH: {
        code: 1001,
        name: 'INPUT_NETWORK_MISMATCH',
        type: 'INPUT'
    },
    /** Invalid amount format or value (negative, zero, or malformed) */ INVALID_AMOUNT: {
        code: 1002,
        name: 'INPUT_INVALID_AMOUNT',
        type: 'INPUT'
    },
    /** Unsupported or invalid bridge route configuration */ UNSUPPORTED_ROUTE: {
        code: 1003,
        name: 'INPUT_UNSUPPORTED_ROUTE',
        type: 'INPUT'
    },
    /** Invalid wallet or contract address format */ INVALID_ADDRESS: {
        code: 1004,
        name: 'INPUT_INVALID_ADDRESS',
        type: 'INPUT'
    },
    /** Invalid or unsupported chain identifier */ INVALID_CHAIN: {
        code: 1005,
        name: 'INPUT_INVALID_CHAIN',
        type: 'INPUT'
    },
    /** Unsupported token for chain */ UNSUPPORTED_TOKEN: {
        code: 1006,
        name: 'INPUT_UNSUPPORTED_TOKEN',
        type: 'INPUT'
    },
    /** Insufficient swap amount for the token pair */ INSUFFICIENT_SWAP_AMOUNT: {
        code: 1007,
        name: 'INPUT_INSUFFICIENT_SWAP_AMOUNT',
        type: 'INPUT'
    },
    /** Action not supported by this adapter / ecosystem */ UNSUPPORTED_ACTION: {
        code: 1008,
        name: 'INPUT_UNSUPPORTED_ACTION',
        type: 'INPUT'
    },
    /** No route satisfies the slippage or minimum-output constraint */ SLIPPAGE_CONSTRAINT_NOT_MET: {
        code: 1009,
        name: 'INPUT_SLIPPAGE_CONSTRAINT_NOT_MET',
        type: 'INPUT'
    },
    /** Wallet is on a different chain than the operation targets */ CHAIN_MISMATCH: {
        code: 1010,
        name: 'INPUT_CHAIN_MISMATCH',
        type: 'INPUT'
    },
    /** User rejected a chain-switch or add-chain prompt */ CHAIN_SWITCH_REJECTED: {
        code: 1011,
        name: 'INPUT_CHAIN_SWITCH_REJECTED',
        type: 'INPUT'
    },
    /** Wallet does not recognise the target chain and cannot add it */ UNRECOGNIZED_CHAIN: {
        code: 1012,
        name: 'INPUT_UNRECOGNIZED_CHAIN',
        type: 'INPUT'
    },
    /** Swap amount is outside the upstream provider's accepted bounds */ AMOUNT_OUT_OF_RANGE: {
        code: 1013,
        name: 'INPUT_AMOUNT_OUT_OF_RANGE',
        type: 'INPUT'
    },
    /** General validation failure for complex validation rules */ VALIDATION_FAILED: {
        code: 1098,
        name: 'INPUT_VALIDATION_FAILED',
        type: 'INPUT'
    },
    /** User cancelled wallet interaction (signature, transaction, connection) */ USER_CANCELLED: {
        code: 1099,
        name: 'INPUT_USER_CANCELLED',
        type: 'INPUT'
    }
};
/**
 * Standardized error definitions for BALANCE type errors.
 *
 * BALANCE errors indicate insufficient funds or allowance issues
 * that prevent transaction execution.
 *
 * @example
 * ```typescript
 * import { BalanceError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...BalanceError.INSUFFICIENT_TOKEN,
 *   recoverability: 'FATAL',
 *   message: 'Insufficient USDC balance on Ethereum',
 *   cause: { trace: { required: '100', available: '50' } }
 * })
 * ```
 */ const BalanceError = {
    /** Insufficient token balance for transaction */ INSUFFICIENT_TOKEN: {
        code: 9001,
        name: 'BALANCE_INSUFFICIENT_TOKEN',
        type: 'BALANCE'
    },
    /** Insufficient native token (ETH/SOL/etc) for gas fees */ INSUFFICIENT_GAS: {
        code: 9002,
        name: 'BALANCE_INSUFFICIENT_GAS',
        type: 'BALANCE'
    }};
/**
 * Standardized error definitions for ONCHAIN type errors.
 *
 * ONCHAIN errors occur during transaction execution, simulation,
 * or interaction with smart contracts on the blockchain.
 *
 * @example
 * ```typescript
 * import { OnchainError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...OnchainError.SIMULATION_FAILED,
 *   recoverability: 'FATAL',
 *   message: 'Simulation failed: ERC20 transfer amount exceeds balance',
 *   cause: { trace: { reason: 'ERC20: transfer amount exceeds balance' } }
 * })
 * ```
 */ const OnchainError = {
    /** Transaction reverted on-chain after execution */ TRANSACTION_REVERTED: {
        code: 5001,
        name: 'ONCHAIN_TRANSACTION_REVERTED',
        type: 'ONCHAIN'
    },
    /** Pre-flight transaction simulation failed */ SIMULATION_FAILED: {
        code: 5002,
        name: 'ONCHAIN_SIMULATION_FAILED',
        type: 'ONCHAIN'
    },
    /** Transaction ran out of gas during execution */ OUT_OF_GAS: {
        code: 5003,
        name: 'ONCHAIN_OUT_OF_GAS',
        type: 'ONCHAIN'
    },
    /** Transaction size exceeds blockchain limit */ TRANSACTION_TOO_LARGE: {
        code: 5005,
        name: 'ONCHAIN_TRANSACTION_TOO_LARGE',
        type: 'ONCHAIN'
    }};
/**
 * Standardized error definitions for RPC type errors.
 *
 * RPC errors occur when communicating with blockchain RPC providers,
 * including endpoint failures, invalid responses, and provider-specific issues.
 *
 * @example
 * ```typescript
 * import { RpcError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...RpcError.ENDPOINT_ERROR,
 *   recoverability: 'RETRYABLE',
 *   message: 'RPC endpoint unavailable on Ethereum',
 *   cause: { trace: { endpoint: 'https://mainnet.infura.io' } }
 * })
 * ```
 */ const RpcError = {
    /** RPC endpoint returned error or is unavailable */ ENDPOINT_ERROR: {
        code: 4001,
        name: 'RPC_ENDPOINT_ERROR',
        type: 'RPC'
    },
    /** Nonce-related errors from RPC provider */ NONCE_ERROR: {
        code: 4003,
        name: 'RPC_NONCE_ERROR',
        type: 'RPC'
    }
};
/**
 * Standardized error definitions for NETWORK type errors.
 *
 * NETWORK errors indicate connectivity issues at the network layer,
 * including DNS failures, connection timeouts, and unreachable endpoints.
 *
 * @example
 * ```typescript
 * import { NetworkError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...NetworkError.CONNECTION_FAILED,
 *   recoverability: 'RETRYABLE',
 *   message: 'Failed to connect to Ethereum network',
 *   cause: { trace: { error: 'ECONNREFUSED' } }
 * })
 * ```
 */ const NetworkError = {
    /** Network connection failed or unreachable */ CONNECTION_FAILED: {
        code: 3001,
        name: 'NETWORK_CONNECTION_FAILED',
        type: 'NETWORK'
    },
    /** Network request timeout */ TIMEOUT: {
        code: 3002,
        name: 'NETWORK_TIMEOUT',
        type: 'NETWORK'
    },
    /**
   * A long-running operation was aborted via its `AbortSignal` before it
   * could complete (e.g. a caller cancelled `waitForTransaction`). For
   * post-broadcast waits this stops the local wait only — the transaction
   * may still settle on-chain.
   */ ABORTED: {
        code: 3008,
        name: 'NETWORK_ABORTED',
        type: 'NETWORK'
    }
};
/**
 * Special error code for unknown/unrecognized errors.
 *
 * @remarks
 * Code `0` is reserved for catch-all errors that don't match any known type.
 * This is the fallback when error normalization can't categorize an error.
 *
 * @example
 * ```typescript
 * import { UnknownError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...UnknownError.UNKNOWN,
 *   recoverability: 'FATAL',
 *   message: 'An unexpected error occurred',
 *   cause: { trace: originalError }
 * })
 * ```
 */ const UnknownError = {
    /** Catch-all for errors that don't fit any known category. Code 0 = "no code". */ UNKNOWN: {
        code: 0,
        name: 'UNKNOWN',
        type: 'UNKNOWN'
    }
};

/**
 * Creates error for invalid wallet address format.
 *
 * This error is thrown when the provided address doesn't match the expected
 * format for the specified chain.
 *
 * @param address - The invalid address string
 * @param chain - Chain name where address is invalid
 * @param expectedFormat - Description of expected address format
 * @returns KitError with address details and format requirements
 *
 * @example
 * ```typescript
 * import { createInvalidAddressError } from '@core/errors'
 *
 * throw createInvalidAddressError('0x123', 'Ethereum', '42-character hex string starting with 0x')
 * // Message: "Invalid address '0x123' for Ethereum. Expected 42-character hex string starting with 0x."
 *
 * throw createInvalidAddressError('invalid', 'Solana', 'base58-encoded string')
 * // Message: "Invalid address 'invalid' for Solana. Expected base58-encoded string."
 * ```
 */ function createInvalidAddressError(address, chain, expectedFormat) {
    const errorDetails = {
        ...InputError.INVALID_ADDRESS,
        recoverability: 'FATAL',
        message: `Invalid address '${address}' for ${chain}. Expected ${expectedFormat}.`,
        cause: {
            trace: {
                address,
                chain,
                expectedFormat
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for invalid chain configuration.
 *
 * This error is thrown when the provided chain doesn't meet the required
 * configuration or is not supported for the operation.
 *
 * @param chain - The invalid chain name or identifier
 * @param reason - Specific reason why chain is invalid
 * @returns KitError with chain details and validation rule
 *
 * @example
 * ```typescript
 * import { createInvalidChainError } from '@core/errors'
 *
 * throw createInvalidChainError('UnknownChain', 'Chain is not supported by this bridge')
 * // Message: "Invalid chain 'UnknownChain': Chain is not supported by this bridge"
 * ```
 */ function createInvalidChainError(chain, reason) {
    const errorDetails = {
        ...InputError.INVALID_CHAIN,
        recoverability: 'FATAL',
        message: `Invalid chain '${chain}': ${reason}.`,
        cause: {
            trace: {
                chain,
                reason
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates an error for a user-rejected wallet interaction.
 *
 * This error is thrown when the end user explicitly declines a wallet
 * prompt — a signature, transaction, or connection request. It maps to
 * `INPUT_USER_CANCELLED` (code 1099, `FATAL`) so the pipeline does not
 * retry an action the user deliberately declined.
 *
 * Shared by both the EVM and Solana error normalizers so that bare
 * user-rejection strings (e.g. MetaMask's "User denied transaction
 * signature", Phantom's "User rejected the request") normalise to one
 * canonical error shape across chains.
 *
 * @param chain - The chain name for the error context.
 * @param trace - Optional additional trace fields (e.g. a redacted
 *   `rawError`). The canonical `chain` field always wins over any
 *   caller-supplied `chain` key.
 * @returns KitError with USER_CANCELLED code and FATAL recoverability.
 *
 * @example
 * ```typescript
 * import { createUserRejectedError } from '@core/errors'
 *
 * throw createUserRejectedError('Ethereum')
 * // Message: "The Ethereum request was rejected by the user."
 * ```
 */ function createUserRejectedError(chain, trace) {
    const errorDetails = {
        ...InputError.USER_CANCELLED,
        recoverability: 'FATAL',
        message: `The ${chain} request was rejected by the user.`,
        cause: {
            // Spread caller trace FIRST so the canonical `chain` field always
            // wins — telemetry keys off it and must not be clobbered.
            trace: {
                ...trace,
                chain
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for general validation failure.
 *
 * This error is thrown when input validation fails for reasons not covered
 * by more specific error types.
 *
 * @param field - The field that failed validation
 * @param value - The invalid value (can be any type)
 * @param reason - Specific reason why validation failed
 * @returns KitError with validation details
 *
 * @example
 * ```typescript
 * import { createValidationFailedError } from '@core/errors'
 *
 * throw createValidationFailedError('recipient', 'invalid@email', 'Must be a valid wallet address')
 * // Message: "Validation failed for 'recipient': 'invalid@email' - Must be a valid wallet address"
 *
 * throw createValidationFailedError('chainId', 999, 'Unsupported chain ID')
 * // Message: "Validation failed for 'chainId': 999 - Unsupported chain ID"
 *
 * throw createValidationFailedError('config', { invalid: true }, 'Missing required properties')
 * // Message: "Validation failed for 'config': [object Object] - Missing required properties"
 * ```
 */ function createValidationFailedError(field, value, reason) {
    // Convert value to string for display, handling different types appropriately
    let valueString;
    if (typeof value === 'string') {
        valueString = `'${value}'`;
    } else if (typeof value === 'object' && value !== null) {
        valueString = JSON.stringify(value);
    } else {
        valueString = String(value);
    }
    const errorDetails = {
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: `Validation failed for '${field}': ${valueString} - ${reason}.`,
        cause: {
            trace: {
                field,
                value,
                reason
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates a KitError from a Zod validation error with detailed error information.
 *
 * This factory function converts Zod validation failures into standardized KitError
 * instances with INPUT_VALIDATION_FAILED code (1098). It extracts all Zod issues
 * and includes them in both the error message and trace for debugging, providing
 * developers with comprehensive validation feedback.
 *
 * The error message includes all validation errors concatenated with semicolons.
 *
 * @param zodError - The Zod validation error containing one or more validation issues
 * @param context - Context string describing what was being validated (e.g., 'bridge parameters', 'user input')
 * @returns KitError with INPUT_VALIDATION_FAILED code and structured validation details
 *
 * @example
 * ```typescript
 * import { createValidationErrorFromZod } from '@core/errors'
 * import { z } from 'zod'
 *
 * const schema = z.object({
 *   name: z.string().min(3),
 *   age: z.number().positive()
 * })
 *
 * const result = schema.safeParse({ name: 'ab', age: -1 })
 * if (!result.success) {
 *   throw createValidationErrorFromZod(result.error, 'user data')
 * }
 * // Throws: KitError with message:
 * // "Invalid user data: name: String must contain at least 3 character(s); age: Number must be greater than 0"
 * // And cause.trace.validationErrors containing all validation errors as an array
 * ```
 *
 * @example
 * ```typescript
 * // Usage in validation functions
 * import { createValidationErrorFromZod } from '@core/errors'
 *
 * function validateBridgeParams(params: unknown): asserts params is BridgeParams {
 *   const result = bridgeParamsSchema.safeParse(params)
 *   if (!result.success) {
 *     throw createValidationErrorFromZod(result.error, 'bridge parameters')
 *   }
 * }
 * ```
 */ function createValidationErrorFromZod(zodError, context) {
    // Format each Zod issue as "path: message"
    const validationErrors = zodError.issues.map((issue)=>{
        const path = issue.path.length > 0 ? `${issue.path.join('.')}: ` : '';
        return `${path}${issue.message}`;
    });
    // Join all errors with semicolons to show complete validation feedback
    const issueSummary = validationErrors.join('; ');
    const allErrors = issueSummary || 'Invalid Input';
    // Build full message from context and validation errors
    const fullMessage = `Invalid ${context}: ${allErrors}`;
    const errorDetails = {
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: fullMessage,
        cause: {
            trace: {
                validationErrors,
                zodError: zodError.message,
                zodIssues: zodError.issues
            }
        }
    };
    return new KitError(errorDetails);
}

/**
 * Creates error for insufficient token balance.
 *
 * This error is thrown when a wallet does not have enough tokens to
 * complete a transaction. The error is FATAL as it requires user
 * intervention to add funds.
 *
 * @param chain - The blockchain network where the balance check failed
 * @param token - The token symbol (e.g., 'USDC', 'ETH')
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with insufficient token balance details
 *
 * @example
 * ```typescript
 * import { createInsufficientTokenBalanceError } from '@core/errors'
 *
 * throw createInsufficientTokenBalanceError('Ethereum', 'USDC')
 * // Message: "Insufficient USDC balance on Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * try {
 *   await transfer(...)
 * } catch (error) {
 *   throw createInsufficientTokenBalanceError('Base', 'USDC', {
 *     rawError: error,
 *     balance: '1000000',
 *     amount: '5000000',
 *   })
 * }
 * ```
 */ function createInsufficientTokenBalanceError(chain, token, trace) {
    return new KitError({
        ...BalanceError.INSUFFICIENT_TOKEN,
        recoverability: 'FATAL',
        message: `Insufficient ${token} balance on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
                token
            }
        }
    });
}
/**
 * Creates error for insufficient gas funds.
 *
 * This error is thrown when a wallet does not have enough native tokens
 * (ETH, SOL, etc.) to pay for transaction gas fees. The error is FATAL
 * as it requires user intervention to add gas funds.
 *
 * @param chain - The blockchain network where the gas check failed
 * @param nativeToken - Native token symbol (e.g. 'ETH', 'SOL', 'AVAX') for a specific message, defaults to 'native token'
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with insufficient gas details
 *
 * @example
 * ```typescript
 * import { createInsufficientGasError } from '@core/errors'
 *
 * throw createInsufficientGasError('Ethereum')
 * // Message: "Insufficient native token on Ethereum to cover gas fees"
 *
 * throw createInsufficientGasError('Ethereum', 'ETH')
 * // Message: "Insufficient ETH on Ethereum to cover gas fees"
 * ```
 *
 * @example
 * ```typescript
 * throw createInsufficientGasError('Ethereum', 'ETH', {
 *   rawError: error,
 *   walletAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
 * })
 * ```
 */ function createInsufficientGasError(chain, nativeToken = 'native token', trace) {
    return new KitError({
        ...BalanceError.INSUFFICIENT_GAS,
        recoverability: 'FATAL',
        message: `Insufficient ${nativeToken} on ${chain} to cover gas fees`,
        cause: {
            trace: {
                ...trace,
                chain
            }
        }
    });
}

/**
 * Creates error for transaction simulation failures.
 *
 * This error is thrown when a pre-flight transaction simulation fails,
 * typically due to contract logic that would revert. The error is FATAL
 * as it indicates the transaction would fail if submitted.
 *
 * @param chain - The blockchain network where the simulation failed
 * @param reason - The reason for simulation failure (e.g., revert message)
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with simulation failure details
 *
 * @example
 * ```typescript
 * import { createSimulationFailedError } from '@core/errors'
 *
 * throw createSimulationFailedError('Ethereum', 'ERC20: insufficient allowance')
 * // Message: "Simulation failed on Ethereum: ERC20: insufficient allowance"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * throw createSimulationFailedError('Ethereum', 'ERC20: insufficient allowance', {
 *   rawError: error,
 *   txHash: '0x1234...',
 *   gasLimit: '21000',
 * })
 * ```
 */ function createSimulationFailedError(chain, reason, trace) {
    return new KitError({
        ...OnchainError.SIMULATION_FAILED,
        recoverability: 'FATAL',
        message: `Simulation failed on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason
            }
        }
    });
}
/**
 * Creates error for transaction reverts.
 *
 * This error is thrown when a transaction is submitted and confirmed
 * but reverts on-chain. The error is FATAL as it indicates the
 * transaction executed but failed.
 *
 * @param chain - The blockchain network where the transaction reverted
 * @param reason - The reason for the revert (e.g., revert message)
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @param txHash - The transaction hash if the transaction was submitted (optional)
 * @param explorerUrl - The block explorer URL for the transaction (optional)
 * @returns KitError with transaction revert details
 *
 * @example
 * ```typescript
 * import { createTransactionRevertedError } from '@core/errors'
 *
 * throw createTransactionRevertedError('Base', 'Slippage exceeded')
 * // Message: "Transaction reverted on Base: Slippage exceeded"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context and transaction details for debugging
 * throw createTransactionRevertedError(
 *   'Base',
 *   'Slippage exceeded',
 *   { rawError: error },
 *   '0x123...',
 *   'https://basescan.org/tx/0x123...'
 * )
 * ```
 */ function createTransactionRevertedError(chain, reason, trace, txHash, explorerUrl) {
    return new KitError({
        ...OnchainError.TRANSACTION_REVERTED,
        recoverability: 'FATAL',
        message: `Transaction reverted on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason,
                ...txHash !== undefined,
                ...explorerUrl !== undefined
            }
        }
    });
}
/**
 * Creates error for out of gas failures.
 *
 * This error is thrown when a transaction runs out of gas during execution.
 * The error is FATAL as it requires adjusting gas limits or transaction logic.
 *
 * @param chain - The blockchain network where the transaction ran out of gas
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @param txHash - The transaction hash if the transaction was submitted (optional)
 * @param explorerUrl - The block explorer URL for the transaction (optional)
 * @returns KitError with out of gas details
 *
 * @example
 * ```typescript
 * import { createOutOfGasError } from '@core/errors'
 *
 * throw createOutOfGasError('Polygon')
 * // Message: "Transaction ran out of gas on Polygon"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * throw createOutOfGasError('Polygon', {
 *   gasUsed: '50000',
 *   gasLimit: '45000',
 * },
 *  '0xabc...',
 *   'https://polygonscan.com/tx/0xabc...'
 * )
 * ```
 */ function createOutOfGasError(chain, trace, txHash, explorerUrl) {
    return new KitError({
        ...OnchainError.OUT_OF_GAS,
        recoverability: 'FATAL',
        message: `Transaction ran out of gas on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
                ...txHash !== undefined,
                ...explorerUrl !== undefined
            }
        }
    });
}
/**
 * Creates error for transaction size exceeding blockchain limits.
 *
 * This error is thrown when a transaction's serialized size exceeds
 * the blockchain's maximum transaction size limit. The error is FATAL
 * as it requires reducing the transaction size (e.g., fewer instructions,
 * smaller data payloads, or splitting into multiple transactions).
 *
 * Common on Solana where transactions have strict size limits (e.g., max 1232 bytes).
 *
 * @param chain - The blockchain network where the size limit was exceeded
 * @param rawError - The original error from the underlying system (optional)
 * @returns KitError with transaction size exceeded details
 *
 * @example
 * ```typescript
 * import { createTransactionTooLargeError } from '@core/errors'
 *
 * throw createTransactionTooLargeError('Solana')
 * // Message: "Transaction size exceeds limit on Solana"
 * ```
 *
 * @example
 * ```typescript
 * import { createTransactionTooLargeError } from '@core/errors'
 *
 * // With raw error containing size details
 * throw createTransactionTooLargeError(
 *   'Solana',
 *   new Error('transaction too large: max: encoded/raw 1644/1232')
 * )
 * // Error includes size information in cause.trace
 * ```
 */ function createTransactionTooLargeError(chain, rawError) {
    return new KitError({
        ...OnchainError.TRANSACTION_TOO_LARGE,
        recoverability: 'FATAL',
        message: `Transaction size exceeds limit on ${chain}`,
        cause: {
            trace: {
                chain,
                rawError
            }
        }
    });
}

/**
 * Create error for RPC endpoint failures.
 *
 * Throw when an RPC provider endpoint fails, returns an error,
 * or is unavailable. The error is RETRYABLE as RPC issues are often temporary.
 *
 * @param chain - The blockchain network where the RPC error occurred.
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with RPC endpoint error details.
 *
 * @example
 * ```typescript
 * import { createRpcEndpointError } from '@core/errors'
 *
 * throw createRpcEndpointError('Ethereum')
 * // Message: "RPC endpoint error on Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * throw createRpcEndpointError('Ethereum', {
 *   rawError: error,
 *   endpoint: 'https://mainnet.infura.io/v3/...',
 *   statusCode: 429,
 * })
 * ```
 */ function createRpcEndpointError(chain, trace) {
    return new KitError({
        ...RpcError.ENDPOINT_ERROR,
        recoverability: 'RETRYABLE',
        message: `RPC endpoint error on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain
            }
        }
    });
}
/**
 * Create error for nonce-related RPC failures.
 *
 * Throw when a transaction is rejected due to a nonce mismatch (too low
 * or too high). The error is RETRYABLE because re-fetching the current
 * nonce and resubmitting usually resolves the issue.
 *
 * @param chain - The blockchain network where the nonce error occurred.
 * @param reason - Human-readable reason (e.g. "nonce too low").
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with RPC nonce error details.
 *
 * @example
 * ```typescript
 * import { createRpcNonceError } from '@core/errors'
 *
 * throw createRpcNonceError('Ethereum', 'nonce too low')
 * ```
 */ function createRpcNonceError(chain, reason, trace) {
    return new KitError({
        ...RpcError.NONCE_ERROR,
        recoverability: 'RETRYABLE',
        message: `Nonce error on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason
            }
        }
    });
}

/**
 * Create error for network connection failures.
 *
 * Throw when network connectivity issues prevent reaching
 * the blockchain network. The error is RETRYABLE as network issues are
 * often temporary.
 *
 * @param chain - The blockchain network where the connection failed.
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with network connection error details.
 *
 * @example
 * ```typescript
 * import { createNetworkConnectionError } from '@core/errors'
 *
 * throw createNetworkConnectionError('Ethereum')
 * // Message: "Network connection failed for Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * throw createNetworkConnectionError('Ethereum', {
 *   rawError: error,
 *   endpoint: 'https://eth-mainnet.g.alchemy.com/v2/...',
 *   retryCount: 3,
 * })
 * ```
 */ function createNetworkConnectionError(chain, trace) {
    return new KitError({
        ...NetworkError.CONNECTION_FAILED,
        recoverability: 'RETRYABLE',
        message: `Network connection failed for ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain
            }
        }
    });
}
/**
 * Create error for network timeout failures.
 *
 * Throw when a network request times out. The error is RETRYABLE as
 * timeouts are typically transient.
 *
 * @param chain - The blockchain network where the timeout occurred.
 * @param reason - Human-readable reason (e.g. "request timed out after 30s").
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with network timeout details.
 *
 * @example
 * ```typescript
 * import { createNetworkTimeoutError } from '@core/errors'
 *
 * throw createNetworkTimeoutError('Ethereum', 'request timed out after 30000ms')
 * ```
 */ function createNetworkTimeoutError(chain, reason, trace) {
    return new KitError({
        ...NetworkError.TIMEOUT,
        recoverability: 'RETRYABLE',
        message: `Network timeout on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason
            }
        }
    });
}

/**
 * Create an error for unexpected or unrecognized failures.
 *
 * @remarks
 * **This is a last resort.** Always prefer throwing a more specific error
 * when possible. Use this only when:
 *
 * - The error doesn't match any known error type
 * - You're in a catch-all handler that must return a KitError
 * - The original error provides no actionable information
 *
 * Better alternatives exist for most cases:
 * - Network issues → `createNetworkConnectionError`
 * - RPC failures → `createRpcEndpointError`
 * - Invalid input → `createValidationFailedError`
 * - Balance issues → `createInsufficientTokenBalanceError`
 *
 * @param options - Options for creating the error.
 * @returns KitError with code 0 (UNKNOWN).
 *
 * @example
 * ```typescript
 * import { createUnknownError } from '@core/errors'
 *
 * // Only use when no better error type fits
 * throw createUnknownError({
 *   message: 'Unexpected failure in third-party library',
 *   cause: originalError,
 * })
 * ```
 */ function createUnknownError(options = {}) {
    const { message = 'An unexpected error occurred', recoverability = 'FATAL', cause } = options;
    // Extract original error message if available
    let fullMessage = message;
    if (cause !== null && cause !== undefined) {
        if (cause instanceof Error) {
            fullMessage = `${message}: ${cause.message}`;
        } else if (typeof cause === 'string' && cause.length > 0) {
            fullMessage = `${message}: ${cause}`;
        }
    }
    return new KitError({
        ...UnknownError.UNKNOWN,
        recoverability,
        message: fullMessage,
        cause: {
            trace: cause
        }
    });
}

/**
 * Type guard to check if an error is a KitError instance.
 *
 * This guard enables TypeScript to narrow the type from `unknown` to
 * `KitError`, providing access to structured error properties like
 * code, name, and recoverability.
 *
 * @remarks
 * **Cross-bundle safety.** Each `dist/*` bundle that depends on
 * `@core/errors` ships its own compiled `KitError` class, so a bare
 * `instanceof KitError` check returns `false` for errors thrown by
 * code in a *different* bundle even though both classes are
 * structurally identical. This guard works across bundles by
 * checking the registry-symbol brand
 * (`Symbol.for('circle.KitError')`) the canonical
 * {@link KitError} constructor stamps onto every instance.
 * `instanceof` is kept as a fast first check for the common
 * single-bundle case.
 *
 * @param error - Unknown error to check
 * @returns True if error is KitError with proper type narrowing
 *
 * @example
 * ```typescript
 * import { isKitError } from '@core/errors'
 *
 * try {
 *   await kit.bridge(params)
 * } catch (error) {
 *   if (isKitError(error)) {
 *     // TypeScript knows this is KitError
 *     console.log(`Structured error: ${error.name} (${error.code})`)
 *   } else {
 *     console.log('Regular error:', error)
 *   }
 * }
 * ```
 */ function isKitError(error) {
    if (error instanceof KitError) return true;
    // Cross-bundle fallback: check the registry-symbol brand so errors
    // thrown by a separately-bundled copy of `@core/errors` (e.g. a kit
    // that vendors its own `dist/*`) classify correctly. The symbol is
    // resolved via `Symbol.for(...)`, which guarantees identity across
    // realms — distinct `KitError` constructors stamp the same symbol.
    return error !== null && typeof error === 'object' && error[KIT_ERROR_BRAND] === true;
}
/**
 * Error codes that are considered retryable by default.
 *
 * @remarks
 * These are typically transient errors that may succeed on retry:
 * - Network connectivity issues (3001, 3002)
 * - Provider unavailability (4001, 4002)
 *
 * **Nonce errors are deliberately excluded.** A nonce error on submission
 * (`RPC_NONCE_ERROR`, 4003) is genuinely ambiguous: it can mean the
 * transaction was already accepted by the node (so the nonce has moved),
 * that a concurrent transaction from the same key used the nonce, or
 * that the local nonce tracker drifted. Automatic generic retry in
 * these cases can either produce a duplicate transaction (when the
 * original landed) or a nonce-conflict flip-flop. Nonce retries are
 * handled by adapter-local, bounded loops (see the ethers execute
 * primitive) that resync against the latest on-chain state.
 */ const DEFAULT_RETRYABLE_ERROR_CODES = [
    // Network errors
    3001,
    3002,
    // Provider errors
    4001,
    4002
];
/**
 * Checks if an error is retryable.
 *
 * @remarks
 * Check order for KitError instances:
 * 1. If `recoverability === 'RETRYABLE'` or `recoverability === 'RESUMABLE'`,
 *    return `true` immediately (priority check).
 * 2. Otherwise, check if `error.code` is in `DEFAULT_RETRYABLE_ERROR_CODES` (fallback check).
 * 3. Non-KitError instances always return `false`.
 *
 * This two-tier approach allows both explicit recoverability control and
 * backward-compatible code-based retry logic.
 *
 * RETRYABLE errors indicate transient failures that may succeed on
 * subsequent attempts, such as network timeouts or temporary service
 * unavailability. These errors are safe to retry after a delay.
 *
 * RESUMABLE errors indicate a multi-phase operation that completed some phases
 * before failing (for example, a token approval landed but the execution
 * transaction failed). They are also retryable — re-running the operation is
 * safe — but callers that have a kit-level `retry()` should prefer it so that
 * already-completed phases are skipped.
 *
 * @param error - Unknown error to check
 * @returns True if error is retryable
 *
 * @example
 * ```typescript
 * import { isRetryableError } from '@core/errors'
 *
 * try {
 *   await kit.bridge(params)
 * } catch (error) {
 *   if (isRetryableError(error)) {
 *     // Implement retry logic with exponential backoff
 *     setTimeout(() => retryOperation(), 5000)
 *   }
 * }
 * ```
 *
 * @example
 * ```typescript
 * import { isRetryableError, createNetworkConnectionError, KitError } from '@core/errors'
 *
 * // KitError with RETRYABLE recoverability (priority check)
 * const error1 = createNetworkConnectionError('Ethereum')
 * isRetryableError(error1) // true
 *
 * // KitError with default retryable code (fallback check)
 * const error2 = new KitError({
 *   code: 3002, // NETWORK_TIMEOUT - in DEFAULT_RETRYABLE_ERROR_CODES
 *   name: 'NETWORK_TIMEOUT',
 *   type: 'NETWORK',
 *   recoverability: 'FATAL', // Not RETRYABLE
 *   message: 'Timeout',
 * })
 * isRetryableError(error2) // true (code 3002 is in default list)
 *
 * // KitError with non-retryable code and FATAL recoverability
 * const error3 = new KitError({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Invalid input',
 * })
 * isRetryableError(error3) // false
 *
 * // KitError with RESUMABLE recoverability (partially-completed operation)
 * const error4 = new KitError({
 *   code: 8101,
 *   name: 'EARN_EXECUTION_FAILED',
 *   type: 'SERVICE',
 *   recoverability: 'RESUMABLE',
 *   message: 'Execution failed after approval',
 * })
 * isRetryableError(error4) // true
 *
 * // Non-KitError
 * const error5 = new Error('Standard error')
 * isRetryableError(error5) // false
 * ```
 */ function isRetryableError(error) {
    // Use proper type guard to check if it's a KitError
    if (isKitError(error)) {
        // Priority check: explicit recoverability. RESUMABLE errors are a subset of
        // retryable errors — re-running the operation is safe, but a kit-level
        // retry() can resume from the failed phase instead.
        if (error.recoverability === 'RETRYABLE' || error.recoverability === 'RESUMABLE') {
            return true;
        }
        // Fallback check: error code against default retryable codes
        return DEFAULT_RETRYABLE_ERROR_CODES.includes(error.code);
    }
    return false;
}
/**
 * Safely extracts error message from any error type.
 *
 * This utility handles different error types gracefully, extracting
 * meaningful messages from Error instances, string errors, or providing
 * a fallback for unknown error types. Never throws.
 *
 * @param error - Unknown error to extract message from
 * @returns Error message string, or fallback message
 *
 * @example
 * ```typescript
 * import { getErrorMessage } from '@core/errors'
 *
 * try {
 *   await riskyOperation()
 * } catch (error) {
 *   const message = getErrorMessage(error)
 *   console.log('Error occurred:', message)
 *   // Works with Error, KitError, string, or any other type
 * }
 * ```
 */ function getErrorMessage(error) {
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message);
    }
    return 'An unknown error occurred';
}
/**
 * Extract structured error information for logging and events.
 *
 * @remarks
 * Safely extracts error information from any thrown value, handling:
 * - KitError objects (message preserved - safe to log)
 * - Standard Error objects (message redacted for security)
 * - Plain objects with name/message/code (message redacted)
 * - Primitive values (logged as-is since they contain no structured data)
 *
 * For security, only KitError messages are included. Other error messages are
 * redacted to prevent logging sensitive data like tokens or PII.
 *
 * @param error - The error to extract info from.
 * @returns Structured error information.
 *
 * @example
 * ```typescript
 * import { extractErrorInfo } from '@core/errors'
 *
 * // Standard Error - message is redacted for security
 * const info1 = extractErrorInfo(new Error('Something went wrong'))
 * // { name: 'Error', message: 'An error occurred. See error name and code for details.' }
 *
 * // KitError - message is preserved (safe type)
 * const error = createNetworkConnectionError('Ethereum')
 * const info2 = extractErrorInfo(error)
 * // { name: 'NETWORK_CONNECTION_FAILED', message: 'Network connection failed for Ethereum', code: 3001 }
 *
 * // Primitive value - logged as-is
 * const info3 = extractErrorInfo('string error')
 * // { name: 'UnknownError', message: 'string error' }
 * ```
 */ function extractErrorInfo(error) {
    if (error === null || typeof error !== 'object') {
        return {
            name: 'UnknownError',
            message: String(error)
        };
    }
    const err = error;
    // Only preserve messages for KitError instances (safe type)
    // For other errors, redact message for security
    const errorMessage = isKitError(error) ? getErrorMessage(error) : 'An error occurred. See error name and code for details.';
    const info = {
        name: err.name ?? 'UnknownError',
        message: errorMessage
    };
    if (typeof err.code === 'number') {
        info.code = err.code;
    }
    if (isKitError(error)) {
        info.type = error.type;
    }
    return info;
}

/**
 * Log-safe error redaction for `KitError.cause.trace` fields.
 *
 * @packageDocumentation
 */ // ============================================================================
// Message redactor (operator-configurable secret scrubbing)
// ============================================================================
/**
 * A pluggable redactor for the `message` strings that flow onto
 * `KitError.cause.trace`.
 *
 * @remarks
 * Two equivalent shapes are accepted:
 *
 * 1. **`readonly RegExp[]`** — the common case. Each pattern is run
 *    against the message; matches are replaced with `[REDACTED]`.
 *    The operator owns the `g` flag — pass a global regex to scrub
 *    every occurrence, a non-global regex to scrub the first one.
 *
 * 2. **`(message: string) => string`** — escape hatch for callers
 *    who want full control over the substitution (different
 *    placeholders per pattern, length-preserving redaction for
 *    log-volume parity, format-preserving encryption, etc.).
 *
 * @public
 */ /**
 * Known RPC provider host suffixes scrubbed by the default redactor.
 *
 * @remarks
 * The default redactor (see {@link composeRedactor} and
 * {@link defaultMessageRedactor}) finds every `https?:` / `wss?:` URL
 * in an error message, parses each one with the platform `URL`
 * constructor, and replaces it with `[REDACTED]` if the parsed
 * hostname ends with one of these suffixes. Adding a new provider is
 * a one-line change and cannot be wrong: there is no regex shape to
 * audit, no anchor-vs-quantifier trade-off, no
 * {@link https://owasp.org/www-community/attacks/Regular_expression_Denial_of_Service_-_ReDoS | ReDoS}
 * surface — the worst case is over-redaction (an unrelated URL on
 * the same host suffix gets scrubbed) which is the safe failure
 * mode.
 *
 * Suffixes covered:
 *
 * | Provider | Suffix |
 * | --- | --- |
 * | Alchemy | `.g.alchemy.com` |
 * | Infura | `.infura.io` |
 * | QuickNode | `.quiknode.pro` |
 * | Ankr | `.ankr.com` |
 * | Chainstack | `.p2pify.com` |
 * | Tenderly | `.gateway.tenderly.co` |
 * | BlockPI | `.blockpi.network` |
 * | GetBlock | `.getblock.io` |
 * | Moralis | `.moralis-nodes.com` |
 * | Helius | `.helius-rpc.com`, `.helius.xyz` |
 * | Triton | `.rpcpool.com` |
 *
 * Compose this list with your own self-hosted RPC suffixes via
 * {@link composeRedactor}.
 *
 * @public
 */ const DEFAULT_RPC_HOST_SUFFIXES = Object.freeze([
    '.g.alchemy.com',
    '.infura.io',
    '.quiknode.pro',
    '.ankr.com',
    '.p2pify.com',
    '.gateway.tenderly.co',
    '.blockpi.network',
    '.getblock.io',
    '.moralis-nodes.com',
    '.helius-rpc.com',
    '.helius.xyz',
    '.rpcpool.com'
]);
/**
 * Built-in non-URL redaction patterns applied alongside the
 * URL-host scrubber.
 *
 * @remarks
 * Two simple patterns:
 *
 * - **Generic credential-bearing query strings** — `?api-key=…`,
 *   `?apikey=…`, `?api-token=…`, `?access-token=…`, `?auth-token=…`,
 *   `?app-key=…`, plus bare `?key=…` / `?token=…` / `?secret=…`.
 *   Catches the case where a self-hosted RPC bakes the credential
 *   into a query string instead of the path. Single canonical-name
 *   alternation; complexity is well under SonarQube S5856's
 *   20-complexity bound.
 * - **Bearer header tokens** — `Bearer <token>` with bounded body
 *   length and a `(?<![A-Za-z])` anchor so it can't be matched as a
 *   tail-fragment of a longer word.
 *
 * Provider-specific URL-host scrubbing lives in
 * {@link DEFAULT_RPC_HOST_SUFFIXES} (parsed via `URL`) rather than as
 * regexes here — the host-list approach is CodeQL-clean (no
 * `js/regex/missing-anchor` heuristic match), false-positive-free
 * (provider URLs cannot accidentally collide with calldata or tx
 * hashes), and trivial to extend (one string per provider).
 *
 * @public
 */ const DEFAULT_RPC_REDACTION_PATTERNS = Object.freeze([
    /[?&](?:(?:api|access|auth|app)[-_]?)?(?:key|token|secret)=[^&\s"'<>`]{1,256}/gi,
    /(?<![A-Za-z])Bearer\s+[A-Za-z0-9._~+/=-]{16,512}/g
]);
/**
 * Generic URL extractor used by {@link composeRedactor}.
 *
 * @remarks
 * Matches any `http://`, `https://`, `ws://`, or `wss://` URL,
 * bounded to 2 048 characters (longest URL Chrome / Firefox / IE
 * accept in practice; well below any reasonable error-message
 * payload). The regex is intentionally generic — it does **not**
 * encode any provider host shape — so CodeQL's
 * `js/regex/missing-anchor` heuristic (which targets URL-validation
 * regexes that look for a specific host) does not fire. All
 * provider classification happens in JS via `URL` parsing + string
 * suffix matching, never in regex.
 */ const URL_EXTRACTOR = /(?<![A-Za-z0-9])(?:https?|wss?):\/\/[^\s"'<>`]{1,2048}/g;
/**
 * Construct a redactor function from a host-suffix list and a
 * non-URL pattern list.
 *
 * @remarks
 * Each invocation:
 *
 * 1. Finds every URL in the message via {@link URL_EXTRACTOR}.
 * 2. Parses each candidate with the platform `URL` constructor (the
 *    same one browsers and Node use for `fetch()` / `new Request()`),
 *    discarding common trailing punctuation.
 * 3. Replaces the URL with `[REDACTED]` if its parsed hostname ends
 *    with one of the configured suffixes.
 * 4. Applies every regex in `patterns` (Bearer headers, query-string
 *    credentials, plus any operator-supplied additions).
 *
 * Both arrays default to the SDK's built-ins
 * ({@link DEFAULT_RPC_HOST_SUFFIXES} and
 * {@link DEFAULT_RPC_REDACTION_PATTERNS}); pass either to override.
 *
 * @param opts - Optional override for the default suffix list and/or
 *   pattern list.
 * @returns A pure `(message: string) => string` function suitable for
 *   passing to {@link setMessageRedactor}.
 *
 * @example
 * Add your self-hosted RPC URL to the host-suffix list (most common
 * extension shape):
 *
 * ```typescript
 * import {
 *   composeRedactor,
 *   setMessageRedactor,
 *   DEFAULT_RPC_HOST_SUFFIXES,
 * } from '@core/errors'
 *
 * setMessageRedactor(
 *   composeRedactor({
 *     hostSuffixes: [...DEFAULT_RPC_HOST_SUFFIXES, '.rpc.my-corp.example'],
 *   }),
 * )
 * ```
 *
 * @example
 * Add a custom non-URL pattern (e.g. a corporate header token):
 *
 * ```typescript
 * setMessageRedactor(
 *   composeRedactor({
 *     patterns: [
 *       ...DEFAULT_RPC_REDACTION_PATTERNS,
 *       /X-Corp-Token:\s+[A-Za-z0-9_-]{16,128}/g,
 *     ],
 *   }),
 * )
 * ```
 *
 * @public
 */ function composeRedactor(opts) {
    const hostSuffixes = opts?.hostSuffixes ?? DEFAULT_RPC_HOST_SUFFIXES;
    const patterns = opts?.patterns ?? DEFAULT_RPC_REDACTION_PATTERNS;
    return (message)=>{
        let result = message.replaceAll(URL_EXTRACTOR, (url)=>{
            // Common trailing punctuation that error-message templates put
            // immediately after a URL (`Status: 401.`, `(see ...)`, `[1]`).
            // Strip before parsing so the `URL` parser doesn't reject
            // `eth-mainnet.g.alchemy.com.` (or accept it with a trailing
            // dot in `hostname` and miss the suffix match). Implemented as
            // a length-bounded string loop instead of a `/[.,;)\]>]+$/`
            // regex so CodeQL `js/redos-on-uncontrolled-input` cannot
            // flag a polynomial-time backtracking shape on operator-
            // controlled error text.
            const TRIM_CHARS = '.,;)]>';
            let end = url.length;
            const cap = Math.max(end - 16, 0) // bound the loop, length-cap 16
            ;
            while(end > cap && TRIM_CHARS.includes(url.charAt(end - 1))){
                end--;
            }
            const trimmed = end === url.length ? url : url.slice(0, end);
            let parsed;
            try {
                parsed = new URL(trimmed);
            } catch  {
                return url;
            }
            // HTTP-Basic userinfo (`user:pass@host`) is a credential by
            // definition — scrub it regardless of host, so enterprise /
            // self-hosted RPC URLs that don't match a known provider suffix
            // still get redacted.
            if (parsed.username !== '' || parsed.password !== '') {
                return '[REDACTED]';
            }
            const host = parsed.hostname.toLowerCase();
            return hostSuffixes.some((suffix)=>host.endsWith(suffix)) ? '[REDACTED]' : url;
        });
        for (const pattern of patterns){
            result = result.replaceAll(pattern, '[REDACTED]');
        }
        return result;
    };
}
/**
 * The SDK's default message redactor: scrubs URLs whose hostname
 * matches a {@link DEFAULT_RPC_HOST_SUFFIXES} entry, plus the
 * patterns in {@link DEFAULT_RPC_REDACTION_PATTERNS}.
 *
 * @remarks
 * Active at module load and re-installed by
 * {@link resetMessageRedactor}. Operators who want to layer
 * additional redaction on top of (rather than replace) the defaults
 * can call this directly inside a custom function form:
 *
 * ```typescript
 * setMessageRedactor((msg) =>
 *   defaultMessageRedactor(msg).replace(/myExtraPattern/g, '[REDACTED]'),
 * )
 * ```
 *
 * For most extension cases prefer {@link composeRedactor}, which
 * gives the same result with structured options instead of a
 * post-hoc pipe.
 *
 * @public
 */ const defaultMessageRedactor = composeRedactor();
let activeRedactor = defaultMessageRedactor;
/**
 * Apply the active redactor to an arbitrary message string.
 *
 * @remarks
 * Adapters call this on every string they place on `cause.trace`
 * other than the redacted `rawError` itself — viem `shortMessage`,
 * ethers `error.info.requestUrl`, the provider's `reason` field,
 * etc. When no redactor is configured this is the identity function,
 * so the cost on the no-redactor path is one `if`.
 *
 * @param message - The string to scrub.
 * @returns The redacted string. The original is returned untouched
 *   when no redactor is configured.
 *
 * @example
 * ```typescript
 * import { redactErrorMessage, setMessageRedactor } from '@core/errors'
 *
 * setMessageRedactor([/[A-Fa-f0-9]{32,64}/g])
 * redactErrorMessage('failed: 0xabc...64chars...')
 * //   => 'failed: [REDACTED]'
 * ```
 *
 * @public
 */ function redactErrorMessage(message) {
    if (activeRedactor === undefined) return message;
    // `setMessageRedactor` eagerly compiles the array form into a
    // `composeRedactor`-wrapped function, so by the time we reach
    // here `activeRedactor` is always a function. The runtime
    // `typeof` guard exists for completeness — if a future
    // contributor introduces a setter path that bypasses the
    // compilation step, the guard keeps the dispatch correct.
    if (typeof activeRedactor === 'function') return activeRedactor(message);
    // Fallback (unreachable in normal use). See note above.
    return composeRedactor({
        patterns: activeRedactor,
        hostSuffixes: []
    })(message);
}
// ============================================================================
// Object-graph redaction
// ============================================================================
/**
 * Redact an `unknown` error to a small, log-safe shape.
 *
 * @remarks
 * Wallet libraries (viem, ethers, web3-provider-engine, …) routinely
 * attach provider-injected fields to thrown errors: configured RPC URLs,
 * API keys, opaque internal state, the originating `XMLHttpRequest`,
 * and so on. Embedding the raw object directly inside `KitError.cause.trace`
 * means anyone who later JSON-serialises a `KitError` for telemetry leaks
 * those fields into logs.
 *
 * This helper extracts only the two fields that are useful for
 * post-mortem debugging — `name` and `message` — while never exposing the
 * underlying object graph. The `message` is run through the operator's
 * configured {@link setMessageRedactor | message redactor} (if any) so
 * that secrets the provider has interpolated into the message string
 * itself can be scrubbed. Non-`Error` throws (raw strings, plain
 * objects, primitives) are stringified with `String(error)` and then
 * run through the same redactor, so a secret-bearing string throw
 * (e.g. WalletConnect / older mobile wallets) is scrubbed too.
 *
 * **Two redaction layers, two responsibilities.**
 *
 * - **Object-graph stripping (this function, always on)** — drops
 *   extra properties such as `request`, `requestUrl`, `info`, the
 *   originating `XMLHttpRequest`, the configured `transport.url`,
 *   etc. Without this, viem/ethers errors round-trip with the full
 *   provider state graph attached.
 * - **Message-content scrubbing (configured via
 *   {@link setMessageRedactor}, opt-in)** — handles the case where
 *   the provider has already formatted secrets into `error.message`
 *   itself. Notably, ethers v6's `makeError()` formats info keys
 *   directly into the message:
 *
 * ```
 * missing response (requestUrl="https://mainnet.infura.io/v3/MY_KEY", code=SERVER_ERROR, ...)
 * ```
 *
 *   Viem's `HttpRequestError` exhibits the same pattern via
 *   `shortMessage`, which carries the configured URL with API path.
 *   Without a redactor, the API key rides on `cause.trace.rawError.message`
 *   verbatim. With one configured, every match is replaced with
 *   `[REDACTED]` (or the operator's custom substitution).
 *
 * The split is intentional: there is no universal URL/secret
 * heuristic that won't false-positive on legitimate payloads
 * (mainnet addresses, contract revert reasons, raw call data), so
 * the SDK refuses to guess. Operators who know which patterns
 * appear in *their* RPC URLs configure the policy with one call
 * to {@link setMessageRedactor}.
 *
 * @param error - Anything thrown by a third-party wallet/provider library.
 * @returns A `{ name, message }` pair for `Error` instances (with
 *   `message` run through the active redactor); the stringified value —
 *   also run through the active redactor — otherwise. Always JSON-safe.
 *
 * @example
 * ```typescript
 * import { redactRawError, setMessageRedactor } from '@core/errors'
 *
 * setMessageRedactor([/infura\.io\/v3\/[a-z0-9]+/gi])
 * const err = new Error('failed: https://mainnet.infura.io/v3/abc123')
 * redactRawError(err)
 * //   => { name: 'Error', message: 'failed: https://[REDACTED]' }
 * ```
 *
 * @public
 */ function redactRawError(error) {
    if (error instanceof Error) {
        return {
            name: error.name,
            message: redactErrorMessage(error.message)
        };
    }
    // Non-Error throws (raw strings from WalletConnect / older mobile
    // wallets, plain objects, primitives) are stringified and then run
    // through the active redactor. A raw string throw can carry a secret
    // RPC URL just like an `Error.message` does, so it must be scrubbed
    // rather than returned verbatim.
    return redactErrorMessage(String(error));
}

/**
 * @packageDocumentation
 * @module ChainDefinitions
 *
 * This module provides a complete type system for blockchain chain definitions.
 * It supports both EVM and non‑EVM chains, token configurations, and multiple
 * versions of the Cross-Chain Transfer Protocol (CCTP). Additionally, utility types
 * are provided to extract subsets of chains (e.g. chains supporting USDC, EURC, or specific
 * CCTP versions) from a provided collection.
 *
 * All types are fully documented with TSDoc to maximize developer experience.
 */ // -----------------------------------------------------------------------------
// Currency and Base Types
// -----------------------------------------------------------------------------
/**
 * Represents basic information about a currency or token.
 * @category Types
 * @description Provides the essential properties of a cryptocurrency or token.
 * @example
 * ```typescript
 * const ethCurrency: Currency = {
 *   name: "Ether",
 *   symbol: "ETH",
 *   decimals: 18
 * };
 * ```
 */ var Blockchain;
(function(Blockchain) {
    Blockchain["Algorand"] = "Algorand";
    Blockchain["Algorand_Testnet"] = "Algorand_Testnet";
    Blockchain["Aptos"] = "Aptos";
    Blockchain["Aptos_Testnet"] = "Aptos_Testnet";
    Blockchain["Arc_Testnet"] = "Arc_Testnet";
    Blockchain["Arbitrum"] = "Arbitrum";
    Blockchain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    Blockchain["Avalanche"] = "Avalanche";
    Blockchain["Avalanche_Fuji"] = "Avalanche_Fuji";
    Blockchain["Base"] = "Base";
    Blockchain["Base_Sepolia"] = "Base_Sepolia";
    Blockchain["Celo"] = "Celo";
    Blockchain["Celo_Alfajores_Testnet"] = "Celo_Alfajores_Testnet";
    Blockchain["Codex"] = "Codex";
    Blockchain["Codex_Testnet"] = "Codex_Testnet";
    Blockchain["Cronos"] = "Cronos";
    Blockchain["Cronos_Testnet"] = "Cronos_Testnet";
    Blockchain["Edge"] = "Edge";
    Blockchain["Edge_Testnet"] = "Edge_Testnet";
    Blockchain["Ethereum"] = "Ethereum";
    Blockchain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    Blockchain["Hedera"] = "Hedera";
    Blockchain["Hedera_Testnet"] = "Hedera_Testnet";
    Blockchain["HyperEVM"] = "HyperEVM";
    Blockchain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    Blockchain["Injective"] = "Injective";
    Blockchain["Injective_Testnet"] = "Injective_Testnet";
    Blockchain["Ink"] = "Ink";
    Blockchain["Ink_Testnet"] = "Ink_Testnet";
    Blockchain["Linea"] = "Linea";
    Blockchain["Linea_Sepolia"] = "Linea_Sepolia";
    Blockchain["Monad"] = "Monad";
    Blockchain["Monad_Testnet"] = "Monad_Testnet";
    Blockchain["Morph"] = "Morph";
    Blockchain["Morph_Testnet"] = "Morph_Testnet";
    Blockchain["NEAR"] = "NEAR";
    Blockchain["NEAR_Testnet"] = "NEAR_Testnet";
    Blockchain["Noble"] = "Noble";
    Blockchain["Noble_Testnet"] = "Noble_Testnet";
    Blockchain["Optimism"] = "Optimism";
    Blockchain["Optimism_Sepolia"] = "Optimism_Sepolia";
    Blockchain["Pharos"] = "Pharos";
    Blockchain["Pharos_Testnet"] = "Pharos_Testnet";
    Blockchain["Plasma"] = "Plasma";
    Blockchain["Plasma_Testnet"] = "Plasma_Testnet";
    Blockchain["Polkadot_Asset_Hub"] = "Polkadot_Asset_Hub";
    Blockchain["Polkadot_Westmint"] = "Polkadot_Westmint";
    Blockchain["Plume"] = "Plume";
    Blockchain["Plume_Testnet"] = "Plume_Testnet";
    Blockchain["Polygon"] = "Polygon";
    Blockchain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    Blockchain["Sei"] = "Sei";
    Blockchain["Sei_Testnet"] = "Sei_Testnet";
    Blockchain["Solana"] = "Solana";
    Blockchain["Solana_Devnet"] = "Solana_Devnet";
    Blockchain["Sonic"] = "Sonic";
    Blockchain["Sonic_Testnet"] = "Sonic_Testnet";
    Blockchain["Stellar"] = "Stellar";
    Blockchain["Stellar_Testnet"] = "Stellar_Testnet";
    Blockchain["Sui"] = "Sui";
    Blockchain["Sui_Testnet"] = "Sui_Testnet";
    Blockchain["Unichain"] = "Unichain";
    Blockchain["Unichain_Sepolia"] = "Unichain_Sepolia";
    Blockchain["World_Chain"] = "World_Chain";
    Blockchain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
    Blockchain["XDC"] = "XDC";
    Blockchain["XDC_Apothem"] = "XDC_Apothem";
    Blockchain["X_Layer"] = "X_Layer";
    Blockchain["X_Layer_Testnet"] = "X_Layer_Testnet";
    Blockchain["ZKSync_Era"] = "ZKSync_Era";
    Blockchain["ZKSync_Sepolia"] = "ZKSync_Sepolia";
})(Blockchain || (Blockchain = {}));
var SwapChain;
(function(SwapChain) {
    // Original 4 chains
    SwapChain["Ethereum"] = "Ethereum";
    SwapChain["Base"] = "Base";
    SwapChain["Polygon"] = "Polygon";
    SwapChain["Solana"] = "Solana";
    // Additional supported chains
    SwapChain["Arbitrum"] = "Arbitrum";
    SwapChain["Optimism"] = "Optimism";
    SwapChain["Avalanche"] = "Avalanche";
    SwapChain["Linea"] = "Linea";
    SwapChain["Ink"] = "Ink";
    SwapChain["World_Chain"] = "World_Chain";
    SwapChain["Unichain"] = "Unichain";
    SwapChain["Plume"] = "Plume";
    SwapChain["Sei"] = "Sei";
    SwapChain["Sonic"] = "Sonic";
    SwapChain["XDC"] = "XDC";
    SwapChain["HyperEVM"] = "HyperEVM";
    SwapChain["Monad"] = "Monad";
    // Testnet chains with swap support
    SwapChain["Arc_Testnet"] = "Arc_Testnet";
})(SwapChain || (SwapChain = {}));
var BridgeChain;
(function(BridgeChain) {
    // Mainnet chains with CCTPv2 support
    BridgeChain["Arbitrum"] = "Arbitrum";
    BridgeChain["Avalanche"] = "Avalanche";
    BridgeChain["Base"] = "Base";
    BridgeChain["Codex"] = "Codex";
    BridgeChain["Cronos"] = "Cronos";
    BridgeChain["Edge"] = "Edge";
    BridgeChain["Ethereum"] = "Ethereum";
    BridgeChain["HyperEVM"] = "HyperEVM";
    BridgeChain["Injective"] = "Injective";
    BridgeChain["Ink"] = "Ink";
    BridgeChain["Linea"] = "Linea";
    BridgeChain["Monad"] = "Monad";
    BridgeChain["Morph"] = "Morph";
    BridgeChain["Optimism"] = "Optimism";
    BridgeChain["Pharos"] = "Pharos";
    BridgeChain["Plasma"] = "Plasma";
    BridgeChain["Plume"] = "Plume";
    BridgeChain["Polygon"] = "Polygon";
    BridgeChain["Sei"] = "Sei";
    BridgeChain["Solana"] = "Solana";
    BridgeChain["Sonic"] = "Sonic";
    BridgeChain["Unichain"] = "Unichain";
    BridgeChain["World_Chain"] = "World_Chain";
    BridgeChain["XDC"] = "XDC";
    BridgeChain["X_Layer"] = "X_Layer";
    // Testnet chains with CCTPv2 support
    BridgeChain["Arc_Testnet"] = "Arc_Testnet";
    BridgeChain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    BridgeChain["Avalanche_Fuji"] = "Avalanche_Fuji";
    BridgeChain["Base_Sepolia"] = "Base_Sepolia";
    BridgeChain["Codex_Testnet"] = "Codex_Testnet";
    BridgeChain["Cronos_Testnet"] = "Cronos_Testnet";
    BridgeChain["Edge_Testnet"] = "Edge_Testnet";
    BridgeChain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    BridgeChain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    BridgeChain["Injective_Testnet"] = "Injective_Testnet";
    BridgeChain["Ink_Testnet"] = "Ink_Testnet";
    BridgeChain["Linea_Sepolia"] = "Linea_Sepolia";
    BridgeChain["Monad_Testnet"] = "Monad_Testnet";
    BridgeChain["Morph_Testnet"] = "Morph_Testnet";
    BridgeChain["Optimism_Sepolia"] = "Optimism_Sepolia";
    BridgeChain["Pharos_Testnet"] = "Pharos_Testnet";
    BridgeChain["Plasma_Testnet"] = "Plasma_Testnet";
    BridgeChain["Plume_Testnet"] = "Plume_Testnet";
    BridgeChain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    BridgeChain["Sei_Testnet"] = "Sei_Testnet";
    BridgeChain["Solana_Devnet"] = "Solana_Devnet";
    BridgeChain["Sonic_Testnet"] = "Sonic_Testnet";
    BridgeChain["Unichain_Sepolia"] = "Unichain_Sepolia";
    BridgeChain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
    BridgeChain["XDC_Apothem"] = "XDC_Apothem";
    BridgeChain["X_Layer_Testnet"] = "X_Layer_Testnet";
})(BridgeChain || (BridgeChain = {}));
var UnifiedBalanceChain;
(function(UnifiedBalanceChain) {
    // Mainnet chains with Gateway V1 support
    UnifiedBalanceChain["Arbitrum"] = "Arbitrum";
    UnifiedBalanceChain["Avalanche"] = "Avalanche";
    UnifiedBalanceChain["Base"] = "Base";
    UnifiedBalanceChain["Ethereum"] = "Ethereum";
    UnifiedBalanceChain["HyperEVM"] = "HyperEVM";
    UnifiedBalanceChain["Optimism"] = "Optimism";
    UnifiedBalanceChain["Polygon"] = "Polygon";
    UnifiedBalanceChain["Sei"] = "Sei";
    UnifiedBalanceChain["Solana"] = "Solana";
    UnifiedBalanceChain["Sonic"] = "Sonic";
    UnifiedBalanceChain["Unichain"] = "Unichain";
    UnifiedBalanceChain["World_Chain"] = "World_Chain";
    // Testnet chains with Gateway V1 support
    UnifiedBalanceChain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    UnifiedBalanceChain["Arc_Testnet"] = "Arc_Testnet";
    UnifiedBalanceChain["Avalanche_Fuji"] = "Avalanche_Fuji";
    UnifiedBalanceChain["Base_Sepolia"] = "Base_Sepolia";
    UnifiedBalanceChain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    UnifiedBalanceChain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    UnifiedBalanceChain["Optimism_Sepolia"] = "Optimism_Sepolia";
    UnifiedBalanceChain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    UnifiedBalanceChain["Sei_Testnet"] = "Sei_Testnet";
    UnifiedBalanceChain["Solana_Devnet"] = "Solana_Devnet";
    UnifiedBalanceChain["Sonic_Testnet"] = "Sonic_Testnet";
    UnifiedBalanceChain["Unichain_Sepolia"] = "Unichain_Sepolia";
    UnifiedBalanceChain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
})(UnifiedBalanceChain || (UnifiedBalanceChain = {}));
var EarnChain;
(function(EarnChain) {
    EarnChain["Arc_Testnet"] = "Arc_Testnet";
})(EarnChain || (EarnChain = {}));
/**
 * Blockchains supported as the source chain for cross-chain Earn deposits.
 *
 * Single source of truth for the source allowlist: the Earn Service bridge
 * route map is `satisfies`-checked against {@link EarnBridgeSourceBlockchain},
 * and both the type and the runtime validation schema derive from this array.
 *
 * @example
 * ```typescript
 * import { EARN_BRIDGE_SOURCE_BLOCKCHAINS } from '@core/chains'
 *
 * console.log(EARN_BRIDGE_SOURCE_BLOCKCHAINS.join(', '))
 * ```
 */ const EARN_BRIDGE_SOURCE_BLOCKCHAINS = [
    "Arbitrum_Sepolia",
    "Base_Sepolia",
    "Ethereum_Sepolia"
];
/**
 * Blockchains supported as the destination (vault) chain for cross-chain Earn
 * deposits. Single source of truth for the destination allowlist.
 *
 * @example
 * ```typescript
 * import { EARN_BRIDGE_DESTINATION_BLOCKCHAINS } from '@core/chains'
 *
 * console.log(EARN_BRIDGE_DESTINATION_BLOCKCHAINS.join(', '))
 * ```
 */ const EARN_BRIDGE_DESTINATION_BLOCKCHAINS = [
    "Arc_Testnet"
];

/**
 * Helper function to define a chain with proper TypeScript typing.
 *
 * This utility function works with TypeScript's `as const` assertion to create
 * strongly-typed, immutable chain definition objects. It preserves literal types
 * from the input and ensures the resulting object maintains all type information.
 *
 * When used with `as const`, it allows TypeScript to infer the most specific
 * possible types for all properties, including string literals and numeric literals,
 * rather than widening them to general types like string or number.
 * @typeParam T - The specific chain definition type (must extend ChainDefinition)
 * @param chain - The chain definition object, typically with an `as const` assertion
 * @returns The same chain definition with preserved literal types
 * @example
 * ```typescript
 * // Define an EVM chain with literal types preserved
 * const Ethereum = defineChain({
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   usdcAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   eurcAddress: null,
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       TokenMessengerV1: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
 *       MessageTransmitterV1: '0x0a992d191deec32afe36203ad87d7d289a738f81'
 *     }
 *   }
 * } as const);
 * ```
 */ function defineChain(chain) {
    return chain;
}

/**
 * Algorand Mainnet chain definition
 * @remarks
 * This represents the official production network for the Algorand blockchain.
 */ const Algorand = defineChain({
    type: 'algorand',
    chain: Blockchain.Algorand,
    name: 'Algorand',
    title: 'Algorand Mainnet',
    nativeCurrency: {
        name: 'Algo',
        symbol: 'ALGO',
        decimals: 6
    },
    isTestnet: false,
    explorerUrl: 'https://explorer.perawallet.app/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet-api.algonode.cloud'
    ],
    eurcAddress: null,
    usdcAddress: '31566704',
    usdtAddress: null,
    cctp: null
});

/**
 * Algorand Testnet chain definition
 * @remarks
 * This represents the official testnet for the Algorand blockchain.
 */ const AlgorandTestnet = defineChain({
    type: 'algorand',
    chain: Blockchain.Algorand_Testnet,
    name: 'Algorand Testnet',
    title: 'Algorand Test Network',
    nativeCurrency: {
        name: 'Algo',
        symbol: 'ALGO',
        decimals: 6
    },
    isTestnet: true,
    explorerUrl: 'https://testnet.explorer.perawallet.app/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-api.algonode.cloud'
    ],
    eurcAddress: null,
    usdcAddress: '10458941',
    usdtAddress: null,
    cctp: null
});

/**
 * Aptos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Aptos blockchain.
 */ const Aptos = defineChain({
    type: 'aptos',
    chain: Blockchain.Aptos,
    name: 'Aptos',
    title: 'Aptos Mainnet',
    nativeCurrency: {
        name: 'Aptos',
        symbol: 'APT',
        decimals: 8
    },
    isTestnet: false,
    explorerUrl: 'https://explorer.aptoslabs.com/txn/{hash}?network=mainnet',
    rpcEndpoints: [
        'https://fullnode.mainnet.aptoslabs.com/v1'
    ],
    eurcAddress: null,
    usdcAddress: '0xbae207659db88bea0cbead6da0ed00aac12edcdda169e591cd41c94180b46f3b',
    usdtAddress: '0x357b0b74bc833e95a115ad22604854d6b0fca151cecd94111770e5d6ffc9dc2b',
    cctp: {
        domain: 9,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9bce6734f7b63e835108e3bd8c36743d4709fe435f44791918801d0989640a9d',
                messageTransmitter: '0x177e17751820e4b4371873ca8c30279be63bdea63b88ed0f2239c2eea10f1772',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Aptos Testnet chain definition
 * @remarks
 * This represents the official test network for the Aptos blockchain.
 */ const AptosTestnet = defineChain({
    type: 'aptos',
    chain: Blockchain.Aptos_Testnet,
    name: 'Aptos Testnet',
    title: 'Aptos Test Network',
    nativeCurrency: {
        name: 'Aptos',
        symbol: 'APT',
        decimals: 8
    },
    isTestnet: true,
    explorerUrl: 'https://explorer.aptoslabs.com/txn/{hash}?network=testnet',
    rpcEndpoints: [
        'https://fullnode.testnet.aptoslabs.com/v1'
    ],
    eurcAddress: null,
    usdcAddress: '0x69091fbab5f7d635ee7ac5098cf0c1efbe31d68fec0f2cd565e8d168daf52832',
    usdtAddress: null,
    cctp: {
        domain: 9,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x5f9b937419dda90aa06c1836b7847f65bbbe3f1217567758dc2488be31a477b9',
                messageTransmitter: '0x081e86cebf457a0c6004f35bd648a2794698f52e0dde09a48619dcd3d4cc23d9',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * @packageDocumentation
 * @module SwapTokenRegistry
 *
 * Central swap token registry for swap-supported tokens.
 *
 * Contains metadata for all tokens that can be used in swap operations,
 * including decimals, categories, and descriptions. All packages should import
 * from this registry instead of maintaining separate token lists.
 */ /**
 * Swap token metadata.
 */ /**
 * Complete swap token registry - single source of truth for all swap-supported tokens.
 *
 * @remarks
 * All packages should import from this registry for swap operations.
 * Adding a new swap token requires updating only this registry.
 *
 * The NATIVE token is handled separately as it resolves dynamically based on chain.
 *
 * @example
 * ```typescript
 * import { SWAP_TOKEN_REGISTRY } from '@core/chains'
 *
 * // Get token decimals
 * const decimals = SWAP_TOKEN_REGISTRY.USDC.decimals  // 6
 *
 * // Check if token is stablecoin
 * const isStable = SWAP_TOKEN_REGISTRY.DAI.category === 'stablecoin'  // true
 * ```
 */ const SWAP_TOKEN_REGISTRY = {
    // ============================================================================
    // Stablecoins (6 decimals)
    // ============================================================================
    USDC: {
        symbol: 'USDC',
        decimals: 6,
        category: 'stablecoin',
        description: 'USD Coin'
    },
    EURC: {
        symbol: 'EURC',
        decimals: 6,
        category: 'stablecoin',
        description: 'Euro Coin'
    },
    USDT: {
        symbol: 'USDT',
        decimals: 6,
        category: 'stablecoin',
        description: 'Tether USD'
    },
    PYUSD: {
        symbol: 'PYUSD',
        decimals: 6,
        category: 'stablecoin',
        description: 'PayPal USD'
    },
    // ============================================================================
    // Stablecoins (18 decimals)
    // ============================================================================
    DAI: {
        symbol: 'DAI',
        decimals: 18,
        category: 'stablecoin',
        description: 'MakerDAO stablecoin'
    },
    USDE: {
        symbol: 'USDE',
        decimals: 18,
        category: 'stablecoin',
        description: 'Ethena USD (synthetic dollar)'
    },
    // ============================================================================
    // Wrapped Tokens
    // ============================================================================
    WBTC: {
        symbol: 'WBTC',
        decimals: 8,
        category: 'wrapped',
        description: 'Wrapped Bitcoin'
    },
    WETH: {
        symbol: 'WETH',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Ethereum'
    },
    WSOL: {
        symbol: 'WSOL',
        decimals: 9,
        category: 'wrapped',
        description: 'Wrapped Solana'
    },
    WAVAX: {
        symbol: 'WAVAX',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Avalanche'
    },
    WPOL: {
        symbol: 'WPOL',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Polygon'
    },
    CIRBTC: {
        symbol: 'CIRBTC',
        decimals: 8,
        category: 'wrapped',
        description: 'Circle Bitcoin'
    }
};
/**
 * Special NATIVE token constant for swap operations.
 *
 * @remarks
 * NATIVE is handled separately from SWAP_TOKEN_REGISTRY because it resolves
 * dynamically based on the chain (ETH on Ethereum, SOL on Solana, etc.).
 * Its decimals are chain-specific.
 */ const NATIVE_TOKEN = 'NATIVE';
/**
 * Array of all supported swap token symbols including NATIVE.
 * Useful for iteration, validation, and filtering.
 */ [
    ...Object.keys(SWAP_TOKEN_REGISTRY),
    NATIVE_TOKEN
];

/**
 * The bridge contract address for EVM testnet networks.
 *
 * This contract handles USDC transfers on testnet environments across
 * EVM-compatible chains. Use this address when deploying or testing
 * cross-chain USDC transfers on test networks.
 */ const BRIDGE_CONTRACT_EVM_TESTNET = '0xC5567a5E3370d4DBfB0540025078e283e36A363d';
/**
 * The bridge contract address for EVM mainnet networks.
 *
 * This contract handles USDC transfers on mainnet environments across
 * EVM-compatible chains. Use this address for production cross-chain
 * USDC transfers on live networks.
 */ const BRIDGE_CONTRACT_EVM_MAINNET = '0xB3FA262d0fB521cc93bE83d87b322b8A23DAf3F0';
/**
 * The adapter contract address for EVM mainnet networks.
 *
 * This contract serves as an adapter for integrating with various protocols
 * on EVM-compatible chains. Use this address for mainnet adapter integrations.
 */ const ADAPTER_CONTRACT_EVM_MAINNET = '0x7FB8c7260b63934d8da38aF902f87ae6e284a845';
/**
 * The adapter contract address for EVM testnet networks.
 *
 * This contract serves as an adapter for integrating with various protocols
 * on EVM-compatible testnet chains. Use this address for testnet adapter
 * integrations (e.g., Arc Testnet).
 */ const ADAPTER_CONTRACT_EVM_TESTNET = '0xBBD70b01a1CAbc96d5b7b129Ae1AAabdf50dd40b';
/**
 * The GatewayWallet contract address for EVM mainnet networks.
 *
 * This contract manages wallet operations for Gateway transactions
 * on mainnet environments across EVM-compatible chains.
 */ const GATEWAY_WALLET_EVM_MAINNET = '0x77777777Dcc4d5A8B6E418Fd04D8997ef11000eE';
/**
 * The GatewayMinter contract address for EVM mainnet networks.
 *
 * This contract handles minting operations for Gateway transactions
 * on mainnet environments across EVM-compatible chains.
 */ const GATEWAY_MINTER_EVM_MAINNET = '0x2222222d7164433c4C09B0b0D809a9b52C04C205';
/**
 * The GatewayWallet contract address for EVM testnet networks.
 *
 * This contract manages wallet operations for Gateway transactions
 * on testnet environments across EVM-compatible chains.
 */ const GATEWAY_WALLET_EVM_TESTNET = '0x0077777d7EBA4688BDeF3E311b846F25870A19B9';
/**
 * The GatewayMinter contract address for EVM testnet networks.
 *
 * This contract handles minting operations for Gateway transactions
 * on testnet environments across EVM-compatible chains.
 */ const GATEWAY_MINTER_EVM_TESTNET = '0x0022222ABE238Cc2C7Bb1f21003F0a260052475B';
/**
 * The GatewayWallet program address for Solana mainnet.
 *
 * This program manages wallet operations for Gateway transactions
 * on Solana mainnet.
 */ const GATEWAY_WALLET_SOLANA_MAINNET = 'GATEwy4YxeiEbRJLwB6dXgg7q61e6zBPrMzYj5h1pRXQ';
/**
 * The GatewayMinter program address for Solana mainnet.
 *
 * This program handles minting operations for Gateway transactions
 * on Solana mainnet.
 */ const GATEWAY_MINTER_SOLANA_MAINNET = 'GATEm5SoBJiSw1v2Pz1iPBgUYkXzCUJ27XSXhDfSyzVZ';
/**
 * The GatewayWallet program address for Solana devnet.
 *
 * This program manages wallet operations for Gateway transactions
 * on Solana devnet.
 */ const GATEWAY_WALLET_SOLANA_DEVNET = 'GATEwdfmYNELfp5wDmmR6noSr2vHnAfBPMm2PvCzX5vu';
/**
 * The GatewayMinter program address for Solana devnet.
 *
 * This program handles minting operations for Gateway transactions
 * on Solana devnet.
 */ const GATEWAY_MINTER_SOLANA_DEVNET = 'GATEmKK2ECL1brEngQZWCgMWPbvrEYqsV6u29dAaHavr';
/** TokenMessengerWithFees address shared by enabled EVM mainnet sources. */ const TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET = '0x71f54F818671cD0D7ea140Da213e5C8b5C92a408';
/** TokenMessengerWithFees address shared by enabled EVM testnet sources. */ const TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET = '0x8745D906D67C346E5eb1aEEED38Eb87F34DF0C0A';

/**
 * Arc Testnet chain definition
 * @remarks
 * This represents the test network for the Arc blockchain,
 * Circle's EVM-compatible Layer-1 designed for stablecoin finance
 * and asset tokenization. Arc uses USDC as the native gas token and
 * features the Malachite Byzantine Fault Tolerant (BFT) consensus
 * engine for sub-second finality.
 */ const ArcTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Arc_Testnet,
    name: 'Arc Testnet',
    title: 'ArcTestnet',
    nativeCurrency: {
        name: 'USDC',
        symbol: 'USDC',
        // Arc uses native USDC with 18 decimals for gas payments (EVM standard).
        // Note: The ERC-20 USDC contract at usdcAddress uses 6 decimals.
        // See: https://docs.arc.network/arc/references/contract-addresses
        decimals: 18
    },
    chainId: 5042002,
    isTestnet: true,
    explorerUrl: 'https://testnet.arcscan.app/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.testnet.arc.network/'
    ],
    eurcAddress: '0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a',
    usdcAddress: '0x3600000000000000000000000000000000000000',
    usdtAddress: null,
    cctp: {
        domain: 26,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 26,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
                // DepositForHandler the GenericExecutor calls to run a fast cross-chain
                // deposit into the GatewayWallet above.
                depositForHandler: '0xD05E7D2E7d30b92c5F17d7d0fC575fce231F1A48'
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Arbitrum Mainnet chain definition
 * @remarks
 * This represents the official production network for the Arbitrum blockchain.
 */ const Arbitrum = defineChain({
    type: 'evm',
    chain: Blockchain.Arbitrum,
    name: 'Arbitrum',
    title: 'Arbitrum Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 42161,
    isTestnet: false,
    explorerUrl: 'https://arbiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://arb1.arbitrum.io/rpc'
    ],
    eurcAddress: null,
    usdcAddress: '0xaf88d065e77c8cc2239327c5edb3a432268e5831',
    usdtAddress: null,
    cctp: {
        domain: 3,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x19330d10D9Cc8751218eaf51E8885D058642E08A',
                messageTransmitter: '0xC30362313FBBA5cf9163F0bb16a0e01f01A896ca',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 3,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Arbitrum Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Arbitrum blockchain on Sepolia.
 */ const ArbitrumSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Arbitrum_Sepolia,
    name: 'Arbitrum Sepolia',
    title: 'Arbitrum Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 421614,
    isTestnet: true,
    explorerUrl: 'https://sepolia.arbiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia-rollup.arbitrum.io/rpc'
    ],
    eurcAddress: null,
    usdcAddress: '0x75faf114eafb1BDbe2F0316DF893fd58CE46AA4d',
    usdtAddress: null,
    cctp: {
        domain: 3,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0xaCF1ceeF35caAc005e15888dDb8A3515C41B4872',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 3,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Avalanche Mainnet chain definition
 * @remarks
 * This represents the official production network for the Avalanche blockchain.
 */ const Avalanche = defineChain({
    type: 'evm',
    chain: Blockchain.Avalanche,
    name: 'Avalanche',
    title: 'Avalanche Mainnet',
    nativeCurrency: {
        name: 'Avalanche',
        symbol: 'AVAX',
        decimals: 18
    },
    chainId: 43114,
    isTestnet: false,
    explorerUrl: 'https://subnets.avax.network/c-chain/tx/{hash}',
    rpcEndpoints: [
        'https://api.avax.network/ext/bc/C/rpc'
    ],
    eurcAddress: '0xc891eb4cbdeff6e073e859e987815ed1505c2acd',
    usdcAddress: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
    usdtAddress: '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7',
    cctp: {
        domain: 1,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x6b25532e1060ce10cc3b0a99e5683b91bfde6982',
                messageTransmitter: '0x8186359af5f57fbb40c6b14a588d2a59c0c29880',
                confirmations: 1
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 1,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Avalanche Fuji Testnet chain definition
 * @remarks
 * This represents the official test network for the Avalanche blockchain.
 */ const AvalancheFuji = defineChain({
    type: 'evm',
    chain: Blockchain.Avalanche_Fuji,
    name: 'Avalanche Fuji',
    title: 'Avalanche Fuji Testnet',
    nativeCurrency: {
        name: 'Avalanche',
        symbol: 'AVAX',
        decimals: 18
    },
    chainId: 43113,
    isTestnet: true,
    explorerUrl: 'https://subnets-test.avax.network/c-chain/tx/{hash}',
    eurcAddress: '0x5e44db7996c682e92a960b65ac713a54ad815c6b',
    usdcAddress: '0x5425890298aed601595a70ab815c96711a31bc65',
    usdtAddress: null,
    cctp: {
        domain: 1,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0xeb08f243e5d3fcff26a9e38ae5520a669f4019d0',
                messageTransmitter: '0xa9fb1b3009dcb79e2fe346c16a604b8fa8ae0a79',
                confirmations: 1
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    rpcEndpoints: [
        'https://api.avax-test.network/ext/bc/C/rpc'
    ],
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 1,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Base chain definition
 * @remarks
 * This represents the official production network for the Base blockchain.
 */ const Base = defineChain({
    type: 'evm',
    chain: Blockchain.Base,
    name: 'Base',
    title: 'Base Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 8453,
    isTestnet: false,
    explorerUrl: 'https://basescan.org/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.base.org',
        'https://base.publicnode.com'
    ],
    eurcAddress: '0x60a3e35cc302bfa44cb288bc5a4f316fdb1adb42',
    usdcAddress: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    usdtAddress: null,
    cctp: {
        domain: 6,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x1682Ae6375C4E4A97e4B583BC394c861A46D8962',
                messageTransmitter: '0xAD09780d193884d503182aD4588450C416D6F9D4',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 6,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Base Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Base blockchain on Sepolia.
 */ const BaseSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Base_Sepolia,
    name: 'Base Sepolia',
    title: 'Base Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 84532,
    isTestnet: true,
    explorerUrl: 'https://sepolia.basescan.org/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.base.org'
    ],
    eurcAddress: '0x808456652fdb597867f38412077A9182bf77359F',
    usdcAddress: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
    usdtAddress: null,
    cctp: {
        domain: 6,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 6,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Celo Mainnet chain definition
 * @remarks
 * This represents the official production network for the Celo blockchain.
 */ const Celo = defineChain({
    type: 'evm',
    chain: Blockchain.Celo,
    name: 'Celo',
    title: 'Celo Mainnet',
    nativeCurrency: {
        name: 'Celo',
        symbol: 'CELO',
        decimals: 18
    },
    chainId: 42220,
    isTestnet: false,
    explorerUrl: 'https://celoscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://forno.celo.org'
    ],
    eurcAddress: null,
    usdcAddress: '0xcebA9300f2b948710d2653dD7B07f33A8B32118C',
    usdtAddress: '0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e',
    cctp: null
});

/**
 * Celo Alfajores Testnet chain definition
 * @remarks
 * This represents the official test network for the Celo blockchain.
 */ const CeloAlfajoresTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Celo_Alfajores_Testnet,
    name: 'Celo Alfajores',
    title: 'Celo Alfajores Testnet',
    nativeCurrency: {
        name: 'Celo',
        symbol: 'CELO',
        decimals: 18
    },
    chainId: 44787,
    isTestnet: true,
    explorerUrl: 'https://alfajores.celoscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://alfajores-forno.celo-testnet.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B',
    usdtAddress: null,
    cctp: null
});

/**
 * Codex Mainnet chain definition
 * @remarks
 * This represents the main network for the Codex blockchain.
 */ const Codex = defineChain({
    type: 'evm',
    chain: Blockchain.Codex,
    name: 'Codex Mainnet',
    title: 'Codex Mainnet',
    nativeCurrency: {
        name: 'ETH',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 81224,
    isTestnet: false,
    explorerUrl: 'https://explorer.codex.xyz/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.codex.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0xd996633a415985DBd7D6D12f4A4343E31f5037cf',
    usdtAddress: null,
    cctp: {
        domain: 12,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Codex Testnet chain definition
 * @remarks
 * This represents the test network for the Codex blockchain.
 */ const CodexTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Codex_Testnet,
    name: 'Codex Testnet',
    title: 'Codex Testnet',
    nativeCurrency: {
        name: 'ETH',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 812242,
    isTestnet: true,
    explorerUrl: 'https://explorer.codex-stg.xyz/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.codex-stg.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0x6d7f141b6819C2c9CC2f818e6ad549E7Ca090F8f',
    usdtAddress: null,
    cctp: {
        domain: 12,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Cronos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Cronos blockchain.
 * Cronos is an EVM-compatible blockchain.
 */ const Cronos = defineChain({
    type: 'evm',
    chain: Blockchain.Cronos,
    name: 'Cronos',
    title: 'Cronos Mainnet',
    nativeCurrency: {
        name: 'Cronos',
        symbol: 'CRO',
        decimals: 18
    },
    chainId: 25,
    isTestnet: false,
    explorerUrl: 'https://cronoscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://evm.cronos.org'
    ],
    eurcAddress: '0xA6dE01a2d62C6B5f3525d768f34d276652C554c8',
    usdcAddress: '0x3D7F2C478aAfdB65542BCB44bCeeC05849999d2D',
    usdtAddress: null,
    cctp: {
        domain: 32,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Cronos Testnet chain definition
 * @remarks
 * This represents the official test network for the Cronos blockchain.
 * Cronos is an EVM-compatible blockchain.
 */ const CronosTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Cronos_Testnet,
    name: 'Cronos Testnet',
    title: 'Cronos Testnet',
    nativeCurrency: {
        name: 'CRO',
        symbol: 'tCRO',
        decimals: 18
    },
    chainId: 338,
    isTestnet: true,
    explorerUrl: 'https://explorer.cronos.org/testnet/tx/{hash}',
    rpcEndpoints: [
        'https://evm-t3.cronos.org'
    ],
    eurcAddress: '0x31f7538adb53cF16350e6B0c89d03D91b7D12c46',
    usdcAddress: '0xEb33dc5fac03833e132593659e1dE7256aB59794',
    usdtAddress: null,
    cctp: {
        domain: 32,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Edge Mainnet chain definition
 * @remarks
 * This represents the official production network for the Edge blockchain.
 * Edge is an EVM-compatible blockchain.
 */ const Edge = defineChain({
    type: 'evm',
    chain: Blockchain.Edge,
    name: 'Edge',
    title: 'Edge Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 3343,
    isTestnet: false,
    explorerUrl: 'https://pro.edgex.exchange/en-US/explorer/tx/{hash}',
    rpcEndpoints: [
        'https://edge-mainnet.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x98d2919b9A214E6Fa5384AC81E6864bA686Ad74c',
    usdtAddress: null,
    cctp: {
        domain: 28,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x98706A006bc632Df31CAdFCBD43F38887ce2ca5c',
                messageTransmitter: '0x5b61381Fc9e58E70EfC13a4A97516997019198ee',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: '0x6D1AaE1c34Aeb582022916a67f2A655C6f4eDFF2'
    }
});

/**
 * Edge Testnet chain definition
 * @remarks
 * This represents the official test network for the Edge blockchain.
 * Edge is an EVM-compatible blockchain.
 */ const EdgeTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Edge_Testnet,
    name: 'Edge Testnet',
    title: 'Edge Testnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 33431,
    isTestnet: true,
    explorerUrl: 'https://edge-testnet.explorer.alchemy.com/tx/{hash}',
    rpcEndpoints: [
        'https://edge-testnet.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x2d9F7CAD728051AA35Ecdc472a14cf8cDF5CFD6B',
    usdtAddress: null,
    cctp: {
        domain: 28,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Ethereum Mainnet chain definition
 * @remarks
 * This represents the official production network for the Ethereum blockchain.
 */ const Ethereum = defineChain({
    type: 'evm',
    chain: Blockchain.Ethereum,
    name: 'Ethereum',
    title: 'Ethereum Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 1,
    isTestnet: false,
    explorerUrl: 'https://etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://ethereum-rpc.publicnode.com',
        'https://ethereum.publicnode.com'
    ],
    eurcAddress: '0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c',
    usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    usdtAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
    cctp: {
        domain: 0,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
                messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 2
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 0,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Ethereum Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Ethereum blockchain on Sepolia.
 */ const EthereumSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Ethereum_Sepolia,
    name: 'Ethereum Sepolia',
    title: 'Ethereum Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 11155111,
    isTestnet: true,
    explorerUrl: 'https://sepolia.etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://ethereum-sepolia-rpc.publicnode.com'
    ],
    eurcAddress: '0x08210F9170F89Ab7658F0B5E3fF39b0E03C594D4',
    usdcAddress: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
    usdtAddress: null,
    cctp: {
        domain: 0,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 2
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 0,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Hedera Mainnet chain definition
 * @remarks
 * This represents the official production network for the Hedera blockchain.
 */ const Hedera = defineChain({
    type: 'hedera',
    chain: Blockchain.Hedera,
    name: 'Hedera',
    title: 'Hedera Mainnet',
    nativeCurrency: {
        name: 'HBAR',
        symbol: 'HBAR',
        decimals: 18
    },
    isTestnet: false,
    explorerUrl: 'https://hashscan.io/mainnet/transaction/{hash}',
    rpcEndpoints: [
        'https://mainnet.hashio.io/api'
    ],
    eurcAddress: null,
    usdcAddress: '0.0.456858',
    usdtAddress: null,
    cctp: null
});

/**
 * Hedera Testnet chain definition
 * @remarks
 * This represents the official test network for the Hedera blockchain.
 */ const HederaTestnet = defineChain({
    type: 'hedera',
    chain: Blockchain.Hedera_Testnet,
    name: 'Hedera Testnet',
    title: 'Hedera Test Network',
    nativeCurrency: {
        name: 'HBAR',
        symbol: 'HBAR',
        decimals: 18
    },
    isTestnet: true,
    explorerUrl: 'https://hashscan.io/testnet/transaction/{hash}',
    rpcEndpoints: [
        'https://testnet.hashio.io/api'
    ],
    eurcAddress: null,
    usdcAddress: '0.0.429274',
    usdtAddress: null,
    cctp: null
});

/**
 * HyperEVM Mainnet chain definition
 * @remarks
 * This represents the official production network for the HyperEVM blockchain.
 * HyperEVM is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const HyperEVM = defineChain({
    type: 'evm',
    chain: Blockchain.HyperEVM,
    name: 'HyperEVM',
    title: 'HyperEVM Mainnet',
    nativeCurrency: {
        name: 'Hype',
        symbol: 'HYPE',
        decimals: 18
    },
    chainId: 999,
    isTestnet: false,
    explorerUrl: 'https://hyperevmscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.hyperliquid.xyz/evm'
    ],
    eurcAddress: null,
    usdcAddress: '0xb88339CB7199b77E23DB6E890353E22632Ba630f',
    usdtAddress: null,
    cctp: {
        domain: 19,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 19,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * HyperEVM Testnet chain definition
 * @remarks
 * This represents the official testnet for the HyperEVM blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const HyperEVMTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.HyperEVM_Testnet,
    name: 'HyperEVM Testnet',
    title: 'HyperEVM Test Network',
    nativeCurrency: {
        name: 'Hype',
        symbol: 'HYPE',
        decimals: 18
    },
    chainId: 998,
    isTestnet: true,
    explorerUrl: 'https://app.hyperliquid-testnet.xyz/explorer/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.hyperliquid-testnet.xyz/evm'
    ],
    eurcAddress: null,
    usdcAddress: '0x2B3370eE501B4a559b57D449569354196457D8Ab',
    usdtAddress: null,
    cctp: {
        domain: 19,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 19,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Injective Mainnet chain definition
 * @remarks
 * This represents the official production network for the Injective blockchain.
 * Injective is a high-performance, interoperable Layer-1 blockchain built for
 * finance, with an EVM execution layer on top of a Cosmos SDK base and
 * sub-second block finality.
 */ const Injective = defineChain({
    type: 'evm',
    chain: Blockchain.Injective,
    name: 'Injective',
    title: 'Injective Mainnet',
    nativeCurrency: {
        name: 'Injective',
        symbol: 'INJ',
        decimals: 18
    },
    chainId: 1776,
    isTestnet: false,
    explorerUrl: 'https://injscan.com/transaction/{hash}',
    rpcEndpoints: [
        'https://sentry.evm-rpc.injective.network'
    ],
    eurcAddress: null,
    usdcAddress: '0xa00C59fF5a080D2b954d0c75e46E22a0c371235a',
    usdtAddress: null,
    cctp: {
        domain: 29,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Injective Testnet chain definition
 * @remarks
 * This represents the official test network for the Injective blockchain.
 * Injective is a high-performance, interoperable Layer-1 blockchain built for
 * finance, with an EVM execution layer on top of a Cosmos SDK base and
 * sub-second block finality.
 */ const InjectiveTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Injective_Testnet,
    name: 'Injective Testnet',
    title: 'Injective Testnet',
    nativeCurrency: {
        name: 'Injective',
        symbol: 'INJ',
        decimals: 18
    },
    chainId: 1439,
    isTestnet: true,
    explorerUrl: 'https://testnet.explorer.injective.network/transaction/{hash}',
    rpcEndpoints: [
        'https://k8s.testnet.json-rpc.injective.network'
    ],
    eurcAddress: null,
    usdcAddress: '0x0C382e685bbeeFE5d3d9C29e29E341fEE8E84C5d',
    usdtAddress: null,
    cctp: {
        domain: 29,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Ink Mainnet chain definition
 * @remarks
 * This represents the official production network for the Ink blockchain.
 * Ink is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const Ink = defineChain({
    type: 'evm',
    chain: Blockchain.Ink,
    name: 'Ink',
    title: 'Ink Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 57073,
    isTestnet: false,
    explorerUrl: 'https://explorer.inkonchain.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-gel.inkonchain.com',
        'https://rpc-qnd.inkonchain.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x2D270e6886d130D724215A266106e6832161EAEd',
    usdtAddress: null,
    cctp: {
        domain: 21,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Ink Testnet chain definition
 * @remarks
 * This represents the official testnet for the Ink blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const InkTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Ink_Testnet,
    name: 'Ink Sepolia',
    title: 'Ink Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 763373,
    isTestnet: true,
    explorerUrl: 'https://explorer-sepolia.inkonchain.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-gel-sepolia.inkonchain.com',
        'https://rpc-qnd-sepolia.inkonchain.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xFabab97dCE620294D2B0b0e46C68964e326300Ac',
    usdtAddress: null,
    cctp: {
        domain: 21,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Linea Mainnet chain definition
 * @remarks
 * This represents the official production network for the Linea blockchain.
 */ const Linea = defineChain({
    type: 'evm',
    chain: Blockchain.Linea,
    name: 'Linea',
    title: 'Linea Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 59144,
    isTestnet: false,
    explorerUrl: 'https://lineascan.build/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.linea.build'
    ],
    eurcAddress: null,
    usdcAddress: '0x176211869ca2b568f2a7d4ee941e073a821ee1ff',
    usdtAddress: null,
    cctp: {
        domain: 11,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Linea Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Linea blockchain on Sepolia.
 */ const LineaSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Linea_Sepolia,
    name: 'Linea Sepolia',
    title: 'Linea Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 59141,
    isTestnet: true,
    explorerUrl: 'https://sepolia.lineascan.build/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.sepolia.linea.build'
    ],
    eurcAddress: null,
    usdcAddress: '0xfece4462d57bd51a6a552365a011b95f0e16d9b7',
    usdtAddress: null,
    cctp: {
        domain: 11,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Monad Mainnet chain definition
 * @remarks
 * This represents the official production network for the Monad blockchain.
 * Monad is a high-performance EVM-compatible Layer-1 blockchain featuring
 * over 10,000 TPS, sub-second finality, and near-zero gas fees.
 */ const Monad = defineChain({
    type: 'evm',
    chain: Blockchain.Monad,
    name: 'Monad',
    title: 'Monad Mainnet',
    nativeCurrency: {
        name: 'Monad',
        symbol: 'MON',
        decimals: 18
    },
    chainId: 143,
    isTestnet: false,
    explorerUrl: 'https://monadscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.monad.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0x754704Bc059F8C67012fEd69BC8A327a5aafb603',
    usdtAddress: null,
    cctp: {
        domain: 15,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Monad Testnet chain definition
 * @remarks
 * This represents the official test network for the Monad blockchain.
 * Monad is a high-performance EVM-compatible Layer-1 blockchain featuring
 * over 10,000 TPS, sub-second finality, and near-zero gas fees.
 */ const MonadTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Monad_Testnet,
    name: 'Monad Testnet',
    title: 'Monad Testnet',
    nativeCurrency: {
        name: 'Monad',
        symbol: 'MON',
        decimals: 18
    },
    chainId: 10143,
    isTestnet: true,
    explorerUrl: 'https://testnet.monadscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-rpc.monad.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0x534b2f3A21130d7a60830c2Df862319e593943A3',
    usdtAddress: null,
    cctp: {
        domain: 15,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Morph Mainnet chain definition
 * @remarks
 * This represents the official production network for the Morph blockchain.
 * Morph is an EVM-compatible Layer-2 blockchain built on the OP Stack.
 */ const Morph = defineChain({
    type: 'evm',
    chain: Blockchain.Morph,
    name: 'Morph',
    title: 'Morph Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 2818,
    isTestnet: false,
    explorerUrl: 'https://explorer.morph.network/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.morphl2.io'
    ],
    eurcAddress: null,
    usdcAddress: '0xCfb1186F4e93D60E60a8bDd997427D1F33bc372B',
    usdtAddress: null,
    cctp: {
        domain: 30,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 64,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Morph Hoodi Testnet chain definition
 * @remarks
 * This represents the official test network for the Morph blockchain.
 * Morph is an EVM-compatible Layer-2 blockchain built on the OP Stack.
 */ const MorphTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Morph_Testnet,
    name: 'Morph Hoodi',
    title: 'Morph Hoodi Testnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 2910,
    isTestnet: true,
    explorerUrl: 'https://explorer-hoodi.morphl2.io/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-hoodi.morphl2.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x7433b41C6c5e1d58D4Da99483609520255ab661B',
    usdtAddress: null,
    cctp: {
        domain: 30,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 64,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * NEAR Protocol Mainnet chain definition
 * @remarks
 * This represents the official production network for the NEAR Protocol blockchain.
 */ const NEAR = defineChain({
    type: 'near',
    chain: Blockchain.NEAR,
    name: 'NEAR Protocol',
    title: 'NEAR Mainnet',
    nativeCurrency: {
        name: 'NEAR',
        symbol: 'NEAR',
        decimals: 24
    },
    isTestnet: false,
    explorerUrl: 'https://nearblocks.io/txns/{hash}',
    rpcEndpoints: [
        'https://eth-rpc.mainnet.near.org'
    ],
    eurcAddress: null,
    usdcAddress: '17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1',
    usdtAddress: 'usdt.tether-token.near',
    cctp: null
});

/**
 * NEAR Testnet chain definition
 * @remarks
 * This represents the official test network for the NEAR Protocol blockchain.
 */ const NEARTestnet = defineChain({
    type: 'near',
    chain: Blockchain.NEAR_Testnet,
    name: 'NEAR Protocol Testnet',
    title: 'NEAR Test Network',
    nativeCurrency: {
        name: 'NEAR',
        symbol: 'NEAR',
        decimals: 24
    },
    isTestnet: true,
    explorerUrl: 'https://testnet.nearblocks.io/txns/{hash}',
    rpcEndpoints: [
        'https://eth-rpc.testnet.near.org'
    ],
    eurcAddress: null,
    usdcAddress: '3e2210e1184b45b64c8a434c0a7e7b23cc04ea7eb7a6c3c32520d03d4afcb8af',
    usdtAddress: null,
    cctp: null
});

/**
 * Noble Mainnet chain definition
 * @remarks
 * This represents the official production network for the Noble blockchain.
 */ const Noble = defineChain({
    type: 'noble',
    chain: Blockchain.Noble,
    name: 'Noble',
    title: 'Noble Mainnet',
    nativeCurrency: {
        name: 'Noble USDC',
        symbol: 'USDC',
        decimals: 6
    },
    isTestnet: false,
    explorerUrl: 'https://www.mintscan.io/noble/tx/{hash}',
    rpcEndpoints: [
        'https://noble-rpc.polkachu.com'
    ],
    eurcAddress: null,
    usdcAddress: 'uusdc',
    usdtAddress: null,
    cctp: {
        domain: 4,
        contracts: {
            v1: {
                type: 'merged',
                contract: 'noble12l2w4ugfz4m6dd73yysz477jszqnfughxvkss5',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Noble Testnet chain definition
 * @remarks
 * This represents the official test network for the Noble blockchain.
 */ const NobleTestnet = defineChain({
    type: 'noble',
    chain: Blockchain.Noble_Testnet,
    name: 'Noble Testnet',
    title: 'Noble Test Network',
    nativeCurrency: {
        name: 'Noble USDC',
        symbol: 'USDC',
        decimals: 6
    },
    isTestnet: true,
    explorerUrl: 'https://www.mintscan.io/noble-testnet/tx/{hash}',
    rpcEndpoints: [
        'https://noble-testnet-rpc.polkachu.com'
    ],
    eurcAddress: null,
    usdcAddress: 'uusdc',
    usdtAddress: null,
    cctp: {
        domain: 4,
        contracts: {
            v1: {
                type: 'merged',
                contract: 'noble12l2w4ugfz4m6dd73yysz477jszqnfughxvkss5',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Optimism Mainnet chain definition
 * @remarks
 * This represents the official production network for the Optimism blockchain.
 */ const Optimism = defineChain({
    type: 'evm',
    chain: Blockchain.Optimism,
    name: 'Optimism',
    title: 'Optimism Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 10,
    isTestnet: false,
    explorerUrl: 'https://optimistic.etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.optimism.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
    usdtAddress: null,
    cctp: {
        domain: 2,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x2B4069517957735bE00ceE0fadAE88a26365528f',
                messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 2,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Optimism Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Optimism blockchain on Sepolia.
 */ const OptimismSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Optimism_Sepolia,
    name: 'Optimism Sepolia',
    title: 'Optimism Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 11155420,
    isTestnet: true,
    explorerUrl: 'https://sepolia-optimistic.etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.optimism.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x5fd84259d66Cd46123540766Be93DFE6D43130D7',
    usdtAddress: null,
    cctp: {
        domain: 2,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 2,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Pharos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Pharos blockchain.
 * Pharos is a modular, full-stack parallel Layer 1 blockchain with
 * sub-second finality and EVM compatibility.
 */ const Pharos = defineChain({
    type: 'evm',
    chain: Blockchain.Pharos,
    name: 'Pharos',
    title: 'Pharos Mainnet',
    nativeCurrency: {
        name: 'Pharos',
        symbol: 'PHAROS',
        decimals: 18
    },
    chainId: 1672,
    isTestnet: false,
    explorerUrl: 'https://pharos.socialscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.pharos.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0xC879C018dB60520F4355C26eD1a6D572cdAC1815',
    usdtAddress: null,
    cctp: {
        domain: 31,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Pharos Atlantic Testnet chain definition
 * @remarks
 * This represents the official test network for the Pharos blockchain.
 * Pharos is a modular, full-stack parallel Layer 1 blockchain with
 * sub-second finality and EVM compatibility.
 */ const PharosTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Pharos_Testnet,
    name: 'Pharos Atlantic',
    title: 'Pharos Atlantic Testnet',
    nativeCurrency: {
        name: 'Pharos',
        symbol: 'PHAROS',
        decimals: 18
    },
    chainId: 688689,
    isTestnet: true,
    explorerUrl: 'https://atlantic.pharosscan.xyz/tx/{hash}',
    rpcEndpoints: [
        'https://atlantic.dplabs-internal.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xcfC8330f4BCAB529c625D12781b1C19466A9Fc8B',
    usdtAddress: null,
    cctp: {
        domain: 31,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Plasma Mainnet chain definition
 * @remarks
 * This represents the official production network for the Plasma blockchain.
 * Plasma is an EVM-equivalent Layer 1 blockchain purpose-built for global
 * stablecoin payments, with deterministic BFT finality (PlasmaBFT/Fast-HotStuff).
 */ const Plasma = defineChain({
    type: 'evm',
    chain: Blockchain.Plasma,
    name: 'Plasma',
    title: 'Plasma Mainnet',
    nativeCurrency: {
        name: 'Plasma',
        symbol: 'XPL',
        decimals: 18
    },
    chainId: 9745,
    isTestnet: false,
    explorerUrl: 'https://plasmascan.to/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.plasma.to'
    ],
    eurcAddress: '0x3EE196E78d4d4248b849B8E1C7F44C5457FAFD2C',
    usdcAddress: '0x2d661C89D812261039AF9764eceaAee884f5F67F',
    usdtAddress: null,
    cctp: {
        domain: 33,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 3,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Plasma Testnet chain definition
 * @remarks
 * This represents the official test network for the Plasma blockchain.
 * Plasma is an EVM-equivalent Layer 1 blockchain purpose-built for global
 * stablecoin payments, with deterministic BFT finality (PlasmaBFT/Fast-HotStuff).
 */ const PlasmaTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Plasma_Testnet,
    name: 'Plasma Testnet',
    title: 'Plasma Testnet',
    nativeCurrency: {
        name: 'Plasma',
        symbol: 'XPL',
        decimals: 18
    },
    chainId: 9746,
    isTestnet: true,
    explorerUrl: 'https://testnet.plasmascan.to/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-rpc.plasma.to'
    ],
    eurcAddress: '0x98AfA0F93Dd993B736399f9074eDcEBD1985A330',
    usdcAddress: '0xE67Fb267022cBA8064Dd388CC2FED724F3120D9D',
    usdtAddress: null,
    cctp: {
        domain: 33,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 3,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Plume Mainnet chain definition
 * @remarks
 * This represents the official production network for the Plume blockchain.
 * Plume is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const Plume = defineChain({
    type: 'evm',
    chain: Blockchain.Plume,
    name: 'Plume',
    title: 'Plume Mainnet',
    nativeCurrency: {
        name: 'Plume',
        symbol: 'PLUME',
        decimals: 18
    },
    chainId: 98866,
    isTestnet: false,
    explorerUrl: 'https://explorer.plume.org/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.plume.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x222365EF19F7947e5484218551B56bb3965Aa7aF',
    usdtAddress: null,
    cctp: {
        domain: 22,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Plume Testnet chain definition
 * @remarks
 * This represents the official testnet for the Plume blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const PlumeTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Plume_Testnet,
    name: 'Plume Testnet',
    title: 'Plume Test Network',
    nativeCurrency: {
        name: 'Plume',
        symbol: 'PLUME',
        decimals: 18
    },
    chainId: 98867,
    isTestnet: true,
    explorerUrl: 'https://testnet-explorer.plume.org/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-rpc.plume.org'
    ],
    eurcAddress: null,
    usdcAddress: '0xcB5f30e335672893c7eb944B374c196392C19D18',
    usdtAddress: null,
    cctp: {
        domain: 22,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Polkadot Asset Hub chain definition
 * @remarks
 * This represents the official asset management parachain for the Polkadot blockchain.
 */ const PolkadotAssetHub = defineChain({
    type: 'polkadot',
    chain: Blockchain.Polkadot_Asset_Hub,
    name: 'Polkadot Asset Hub',
    title: 'Polkadot Asset Hub',
    nativeCurrency: {
        name: 'Polkadot',
        symbol: 'DOT',
        decimals: 10
    },
    isTestnet: false,
    explorerUrl: 'https://polkadot.subscan.io/extrinsic/{hash}',
    rpcEndpoints: [
        'https://asset-hub-polkadot-rpc.n.dwellir.com'
    ],
    eurcAddress: null,
    usdcAddress: '1337',
    usdtAddress: '1984',
    cctp: null
});

/**
 * Polkadot Westmint chain definition
 * @remarks
 * This represents an asset management parachain in the Polkadot ecosystem.
 */ const PolkadotWestmint = defineChain({
    type: 'polkadot',
    chain: Blockchain.Polkadot_Westmint,
    name: 'Polkadot Westmint',
    title: 'Polkadot Westmint',
    nativeCurrency: {
        name: 'Polkadot',
        symbol: 'DOT',
        decimals: 10
    },
    isTestnet: false,
    explorerUrl: 'https://assethub-polkadot.subscan.io/extrinsic/{hash}',
    rpcEndpoints: [
        'https://westmint-rpc.polkadot.io'
    ],
    eurcAddress: null,
    usdcAddress: 'Asset ID 31337',
    usdtAddress: null,
    cctp: null
});

/**
 * Polygon Mainnet chain definition
 * @remarks
 * This represents the official production network for the Polygon blockchain.
 */ const Polygon = defineChain({
    type: 'evm',
    chain: Blockchain.Polygon,
    name: 'Polygon',
    title: 'Polygon Mainnet',
    nativeCurrency: {
        name: 'POL',
        symbol: 'POL',
        decimals: 18
    },
    chainId: 137,
    isTestnet: false,
    explorerUrl: 'https://polygonscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://polygon.publicnode.com',
        'https://polygon.drpc.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
    usdtAddress: null,
    cctp: {
        domain: 7,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9daF8c91AEFAE50b9c0E69629D3F6Ca40cA3B3FE',
                messageTransmitter: '0xF3be9355363857F3e001be68856A2f96b4C39Ba9',
                confirmations: 200
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 33,
                fastConfirmations: 13
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 7,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Polygon Amoy Testnet chain definition
 * @remarks
 * This represents the official test network for the Polygon blockchain.
 */ const PolygonAmoy = defineChain({
    type: 'evm',
    chain: Blockchain.Polygon_Amoy_Testnet,
    name: 'Polygon Amoy',
    title: 'Polygon Amoy Testnet',
    nativeCurrency: {
        name: 'POL',
        symbol: 'POL',
        decimals: 18
    },
    chainId: 80002,
    isTestnet: true,
    explorerUrl: 'https://amoy.polygonscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://polygon-amoy-bor-rpc.publicnode.com',
        'https://polygon-amoy.drpc.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582',
    usdtAddress: null,
    cctp: {
        domain: 7,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 200
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 33,
                fastConfirmations: 13
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 7,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sei Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sei blockchain.
 * Sei is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const Sei = defineChain({
    type: 'evm',
    chain: Blockchain.Sei,
    name: 'Sei',
    title: 'Sei Mainnet',
    nativeCurrency: {
        name: 'Sei',
        symbol: 'SEI',
        decimals: 18
    },
    chainId: 1329,
    isTestnet: false,
    explorerUrl: 'https://seiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://evm-rpc.sei-apis.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392',
    usdtAddress: null,
    cctp: {
        domain: 16,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 16,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sei Testnet chain definition
 * @remarks
 * This represents the official testnet for the Sei blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const SeiTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Sei_Testnet,
    name: 'Sei Testnet',
    title: 'Sei Test Network',
    nativeCurrency: {
        name: 'Sei',
        symbol: 'SEI',
        decimals: 18
    },
    chainId: 1328,
    isTestnet: true,
    explorerUrl: 'https://testnet.seiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://evm-rpc-testnet.sei-apis.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x4fCF1784B31630811181f670Aea7A7bEF803eaED',
    usdtAddress: null,
    cctp: {
        domain: 16,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 16,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sonic Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sonic blockchain.
 */ const Sonic = defineChain({
    type: 'evm',
    chain: Blockchain.Sonic,
    name: 'Sonic',
    title: 'Sonic Mainnet',
    nativeCurrency: {
        name: 'Sonic',
        symbol: 'S',
        decimals: 18
    },
    chainId: 146,
    isTestnet: false,
    explorerUrl: 'https://sonicscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.soniclabs.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x29219dd400f2Bf60E5a23d13Be72B486D4038894',
    usdtAddress: null,
    cctp: {
        domain: 13,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 13,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sonic Testnet chain definition
 * @remarks
 * This represents the official test network for the Sonic blockchain.
 */ const SonicTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.Sonic_Testnet,
    name: 'Sonic Testnet',
    title: 'Sonic Testnet',
    nativeCurrency: {
        name: 'Sonic',
        symbol: 'S',
        decimals: 18
    },
    chainId: 14601,
    isTestnet: true,
    explorerUrl: 'https://testnet.sonicscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.testnet.soniclabs.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x0BA304580ee7c9a980CF72e55f5Ed2E9fd30Bc51',
    usdtAddress: null,
    cctp: {
        domain: 13,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 13,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Solana Mainnet chain definition
 * @remarks
 * This represents the official production network for the Solana blockchain.
 */ const Solana = defineChain({
    type: 'solana',
    chain: Blockchain.Solana,
    name: 'Solana',
    title: 'Solana Mainnet',
    nativeCurrency: {
        name: 'Solana',
        symbol: 'SOL',
        decimals: 9
    },
    isTestnet: false,
    explorerUrl: 'https://solscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://api.mainnet-beta.solana.com'
    ],
    eurcAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
    usdcAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    usdtAddress: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
    cctp: {
        domain: 5,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
                messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd',
                confirmations: 32
            },
            v2: {
                type: 'split',
                tokenMessenger: 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe',
                messageTransmitter: 'CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC',
                confirmations: 32,
                fastConfirmations: 3
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: 'DFaauJEjmiHkPs1JG89A4p95hDWi9m9SAEERY1LQJiC3'
    },
    gateway: {
        domain: 5,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_SOLANA_MAINNET,
                minter: GATEWAY_MINTER_SOLANA_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Solana Devnet chain definition
 * @remarks
 * This represents the development test network for the Solana blockchain.
 */ const SolanaDevnet = defineChain({
    type: 'solana',
    chain: Blockchain.Solana_Devnet,
    name: 'Solana Devnet',
    title: 'Solana Development Network',
    nativeCurrency: {
        name: 'Solana',
        symbol: 'SOL',
        decimals: 9
    },
    isTestnet: true,
    explorerUrl: 'https://solscan.io/tx/{hash}?cluster=devnet',
    eurcAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
    usdcAddress: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
    usdtAddress: null,
    cctp: {
        domain: 5,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
                messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd',
                confirmations: 32
            },
            v2: {
                type: 'split',
                tokenMessenger: 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe',
                messageTransmitter: 'CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC',
                confirmations: 32,
                fastConfirmations: 3
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: 'DFaauJEjmiHkPs1JG89A4p95hDWi9m9SAEERY1LQJiC3'
    },
    rpcEndpoints: [
        'https://api.devnet.solana.com'
    ],
    gateway: {
        domain: 5,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_SOLANA_DEVNET,
                minter: GATEWAY_MINTER_SOLANA_DEVNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Stellar Mainnet chain definition
 * @remarks
 * This represents the official production network for the Stellar blockchain.
 */ const Stellar = defineChain({
    type: 'stellar',
    chain: Blockchain.Stellar,
    name: 'Stellar',
    title: 'Stellar Mainnet',
    nativeCurrency: {
        name: 'Stellar Lumens',
        symbol: 'XLM',
        decimals: 7
    },
    isTestnet: false,
    explorerUrl: 'https://stellar.expert/explorer/public/tx/{hash}',
    rpcEndpoints: [
        'https://horizon.stellar.org'
    ],
    eurcAddress: 'EURC-GDHU6WRG4IEQXM5NZ4BMPKOXHW76MZM4Y2IEMFDVXBSDP6SJY4ITNPP2',
    usdcAddress: 'USDC-GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN',
    usdtAddress: null,
    cctp: null
});

/**
 * Stellar Testnet chain definition
 * @remarks
 * This represents the official test network for the Stellar blockchain.
 */ const StellarTestnet = defineChain({
    type: 'stellar',
    chain: Blockchain.Stellar_Testnet,
    name: 'Stellar Testnet',
    title: 'Stellar Test Network',
    nativeCurrency: {
        name: 'Stellar Lumens',
        symbol: 'XLM',
        decimals: 7
    },
    isTestnet: true,
    explorerUrl: 'https://stellar.expert/explorer/testnet/tx/{hash}',
    rpcEndpoints: [
        'https://horizon-testnet.stellar.org'
    ],
    eurcAddress: 'EURC-GB3Q6QDZYTHWT7E5PVS3W7FUT5GVAFC5KSZFFLPU25GO7VTC3NM2ZTVO',
    usdcAddress: 'USDC-GBBD47IF6LWK7P7MDEVSCWR7DPUWV3NY3DTQEVFL4NAT4AQH3ZLLFLA5',
    usdtAddress: null,
    cctp: null
});

/**
 * Sui Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sui blockchain.
 */ const Sui = defineChain({
    type: 'sui',
    chain: Blockchain.Sui,
    name: 'Sui',
    title: 'Sui Mainnet',
    nativeCurrency: {
        name: 'Sui',
        symbol: 'SUI',
        decimals: 9
    },
    isTestnet: false,
    explorerUrl: 'https://suiscan.xyz/mainnet/tx/{hash}',
    rpcEndpoints: [
        'https://fullnode.mainnet.sui.io'
    ],
    eurcAddress: null,
    usdcAddress: '0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC',
    usdtAddress: null,
    cctp: {
        domain: 8,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x2aa6c5d56376c371f88a6cc42e852824994993cb9bab8d3e6450cbe3cb32b94e',
                messageTransmitter: '0x08d87d37ba49e785dde270a83f8e979605b03dc552b5548f26fdf2f49bf7ed1b',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Sui Testnet chain definition
 * @remarks
 * This represents the official test network for the Sui blockchain.
 */ const SuiTestnet = defineChain({
    type: 'sui',
    chain: Blockchain.Sui_Testnet,
    name: 'Sui Testnet',
    title: 'Sui Test Network',
    nativeCurrency: {
        name: 'Sui',
        symbol: 'SUI',
        decimals: 9
    },
    isTestnet: true,
    explorerUrl: 'https://suiscan.xyz/testnet/tx/{hash}',
    rpcEndpoints: [
        'https://fullnode.testnet.sui.io'
    ],
    eurcAddress: null,
    usdcAddress: '0xa1ec7fc00a6f40db9693ad1415d0c193ad3906494428cf252621037bd7117e29::usdc::USDC',
    usdtAddress: null,
    cctp: {
        domain: 8,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x31cc14d80c175ae39777c0238f20594c6d4869cfab199f40b69f3319956b8beb',
                messageTransmitter: '0x4931e06dce648b3931f890035bd196920770e913e43e45990b383f6486fdd0a5',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Unichain Mainnet chain definition
 * @remarks
 * This represents the official production network for the Unichain blockchain.
 */ const Unichain = defineChain({
    type: 'evm',
    chain: Blockchain.Unichain,
    name: 'Unichain',
    title: 'Unichain Mainnet',
    nativeCurrency: {
        name: 'Uni',
        symbol: 'UNI',
        decimals: 18
    },
    chainId: 130,
    isTestnet: false,
    explorerUrl: 'https://unichain.blockscout.com/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.unichain.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x078D782b760474a361dDA0AF3839290b0EF57AD6',
    usdtAddress: null,
    cctp: {
        domain: 10,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x4e744b28E787c3aD0e810eD65A24461D4ac5a762',
                messageTransmitter: '0x353bE9E2E38AB1D19104534e4edC21c643Df86f4',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 10,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Unichain Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Unichain blockchain.
 */ const UnichainSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.Unichain_Sepolia,
    name: 'Unichain Sepolia',
    title: 'Unichain Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Uni',
        symbol: 'UNI',
        decimals: 18
    },
    chainId: 1301,
    isTestnet: true,
    explorerUrl: 'https://unichain-sepolia.blockscout.com/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.unichain.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x31d0220469e10c4E71834a79b1f276d740d3768F',
    usdtAddress: null,
    cctp: {
        domain: 10,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x8ed94B8dAd2Dc5453862ea5e316A8e71AAed9782',
                messageTransmitter: '0xbc498c326533d675cf571B90A2Ced265ACb7d086',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 10,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * World Chain chain definition
 * @remarks
 * This represents the main network for the World Chain blockchain.
 */ const WorldChain = defineChain({
    type: 'evm',
    chain: Blockchain.World_Chain,
    name: 'World Chain',
    title: 'World Chain',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 480,
    isTestnet: false,
    explorerUrl: 'https://worldscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://worldchain-mainnet.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x79A02482A880bCE3F13e09Da970dC34db4CD24d1',
    usdtAddress: null,
    cctp: {
        domain: 14,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cF5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 14,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * World Chain Sepolia chain definition
 * @remarks
 * This represents the test network for the World Chain blockchain.
 */ const WorldChainSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.World_Chain_Sepolia,
    name: 'World Chain Sepolia',
    title: 'World Chain Sepolia',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 4801,
    isTestnet: true,
    explorerUrl: 'https://sepolia.worldscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://worldchain-sepolia.drpc.org',
        'https://worldchain-sepolia.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x66145f38cBAC35Ca6F1Dfb4914dF98F1614aeA88',
    usdtAddress: null,
    cctp: {
        domain: 14,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 14,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * XDC Mainnet chain definition
 * @remarks
 * This represents the official production network for the XDC blockchain.
 * XDC is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const XDC = defineChain({
    type: 'evm',
    chain: Blockchain.XDC,
    name: 'XDC',
    title: 'XDC Mainnet',
    nativeCurrency: {
        name: 'XDC',
        symbol: 'XDC',
        decimals: 18
    },
    chainId: 50,
    isTestnet: false,
    explorerUrl: 'https://xdcscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://erpc.xdcrpc.com',
        'https://erpc.xinfin.network'
    ],
    eurcAddress: null,
    usdcAddress: '0xfA2958CB79b0491CC627c1557F441eF849Ca8eb1',
    usdtAddress: null,
    cctp: {
        domain: 18,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 3,
                fastConfirmations: 3
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * XDC Apothem Testnet chain definition
 * @remarks
 * This represents the official test network for the XDC Network, known as Apothem.
 */ const XDCApothem = defineChain({
    type: 'evm',
    chain: Blockchain.XDC_Apothem,
    name: 'Apothem Network',
    title: 'Apothem Network',
    nativeCurrency: {
        name: 'TXDC',
        symbol: 'TXDC',
        decimals: 18
    },
    chainId: 51,
    isTestnet: true,
    explorerUrl: 'https://testnet.xdcscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://erpc.apothem.network'
    ],
    eurcAddress: null,
    usdcAddress: '0xb5AB69F7bBada22B28e79C8FFAECe55eF1c771D4',
    usdtAddress: null,
    cctp: {
        domain: 18,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 3,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * X Layer Mainnet chain definition
 * @remarks
 * This represents the official production network for the X Layer blockchain.
 * X Layer is an EVM-compatible OP Stack Layer-2 blockchain built by OKX,
 * using OKB as its native gas token. (Migrated from Polygon zkEVM/CDK to the
 * OP Stack on 2025-10-27; older docs describing it as zkEVM are obsolete.)
 */ const XLayer = defineChain({
    type: 'evm',
    chain: Blockchain.X_Layer,
    name: 'X Layer',
    title: 'X Layer Mainnet',
    nativeCurrency: {
        name: 'OKB',
        symbol: 'OKB',
        decimals: 18
    },
    chainId: 196,
    isTestnet: false,
    explorerUrl: 'https://www.oklink.com/xlayer/tx/{hash}',
    rpcEndpoints: [
        'https://xlayerrpc.okx.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xB6CEceAB302E2E4948951eE7843FC24E92933061',
    usdtAddress: null,
    cctp: {
        domain: 37,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * X Layer Testnet chain definition
 * @remarks
 * This represents the official test network for the X Layer blockchain.
 * X Layer is an EVM-compatible OP Stack Layer-2 blockchain built by OKX,
 * using OKB as its native gas token. (Migrated from Polygon zkEVM/CDK to the
 * OP Stack on 2025-10-27; older docs describing it as zkEVM are obsolete.)
 */ const XLayerTestnet = defineChain({
    type: 'evm',
    chain: Blockchain.X_Layer_Testnet,
    name: 'X Layer Testnet',
    title: 'X Layer Testnet',
    nativeCurrency: {
        name: 'OKB',
        symbol: 'OKB',
        decimals: 18
    },
    chainId: 1952,
    isTestnet: true,
    // Deliberately not oklink.com (used for mainnet): viem's bundled OKLink
    // testnet URL targets the deprecated pre-rebrand chain ID 195, not this
    // chain's ID (1952). Verified against the internal chain-expansion-scripts
    // config (`v2config.sandbox.yml`) — do not "normalize" this to match mainnet.
    explorerUrl: 'https://web3.okx.com/explorer/x-layer-testnet/tx/{hash}',
    rpcEndpoints: [
        'https://testrpc.xlayer.tech'
    ],
    eurcAddress: null,
    usdcAddress: '0xDec90b78111Ba2fc6FC6d84d8B9ec159A2d4b9B3',
    usdtAddress: null,
    cctp: {
        domain: 37,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * ZKSync Era Mainnet chain definition
 * @remarks
 * This represents the official production network for the ZKSync Era blockchain.
 */ const ZKSyncEra = defineChain({
    type: 'evm',
    chain: Blockchain.ZKSync_Era,
    name: 'ZKSync Era',
    title: 'ZKSync Era Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 324,
    isTestnet: false,
    explorerUrl: 'https://explorer.zksync.io/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.era.zksync.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4',
    usdtAddress: null,
    cctp: null
});

/**
 * ZKSync Era Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the ZKSync Era blockchain on Sepolia.
 */ const ZKSyncEraSepolia = defineChain({
    type: 'evm',
    chain: Blockchain.ZKSync_Sepolia,
    name: 'ZKSync Era Sepolia',
    title: 'ZKSync Era Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 300,
    isTestnet: true,
    explorerUrl: 'https://sepolia.explorer.zksync.io/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.era.zksync.dev'
    ],
    eurcAddress: null,
    usdcAddress: '0xAe045DE5638162fa134807Cb558E15A3F5A7F853',
    usdtAddress: null,
    cctp: null
});

var Blockchains = {
  __proto__: null,
  Algorand: Algorand,
  AlgorandTestnet: AlgorandTestnet,
  Aptos: Aptos,
  AptosTestnet: AptosTestnet,
  Arbitrum: Arbitrum,
  ArbitrumSepolia: ArbitrumSepolia,
  ArcTestnet: ArcTestnet,
  Avalanche: Avalanche,
  AvalancheFuji: AvalancheFuji,
  Base: Base,
  BaseSepolia: BaseSepolia,
  Celo: Celo,
  CeloAlfajoresTestnet: CeloAlfajoresTestnet,
  Codex: Codex,
  CodexTestnet: CodexTestnet,
  Cronos: Cronos,
  CronosTestnet: CronosTestnet,
  Edge: Edge,
  EdgeTestnet: EdgeTestnet,
  Ethereum: Ethereum,
  EthereumSepolia: EthereumSepolia,
  Hedera: Hedera,
  HederaTestnet: HederaTestnet,
  HyperEVM: HyperEVM,
  HyperEVMTestnet: HyperEVMTestnet,
  Injective: Injective,
  InjectiveTestnet: InjectiveTestnet,
  Ink: Ink,
  InkTestnet: InkTestnet,
  Linea: Linea,
  LineaSepolia: LineaSepolia,
  Monad: Monad,
  MonadTestnet: MonadTestnet,
  Morph: Morph,
  MorphTestnet: MorphTestnet,
  NEAR: NEAR,
  NEARTestnet: NEARTestnet,
  Noble: Noble,
  NobleTestnet: NobleTestnet,
  Optimism: Optimism,
  OptimismSepolia: OptimismSepolia,
  Pharos: Pharos,
  PharosTestnet: PharosTestnet,
  Plasma: Plasma,
  PlasmaTestnet: PlasmaTestnet,
  Plume: Plume,
  PlumeTestnet: PlumeTestnet,
  PolkadotAssetHub: PolkadotAssetHub,
  PolkadotWestmint: PolkadotWestmint,
  Polygon: Polygon,
  PolygonAmoy: PolygonAmoy,
  Sei: Sei,
  SeiTestnet: SeiTestnet,
  Solana: Solana,
  SolanaDevnet: SolanaDevnet,
  Sonic: Sonic,
  SonicTestnet: SonicTestnet,
  Stellar: Stellar,
  StellarTestnet: StellarTestnet,
  Sui: Sui,
  SuiTestnet: SuiTestnet,
  Unichain: Unichain,
  UnichainSepolia: UnichainSepolia,
  WorldChain: WorldChain,
  WorldChainSepolia: WorldChainSepolia,
  XDC: XDC,
  XDCApothem: XDCApothem,
  XLayer: XLayer,
  XLayerTestnet: XLayerTestnet,
  ZKSyncEra: ZKSyncEra,
  ZKSyncEraSepolia: ZKSyncEraSepolia
};

/**
 * Checks if a given chain supports Circle's Cross-Chain Transfer Protocol (CCTP) version 2.
 *
 * This guard function examines a chain definition to determine if it has CCTP v2 contract
 * configurations. It's used to validate that both source and destination chains
 * support CCTP v2 before attempting a transfer.
 *
 * @param chain - The chain definition to check for CCTP v2 support
 * @returns `true` if the chain supports CCTP v2 (has v2 contracts configured), `false` otherwise
 *
 * @example
 * ```typescript
 * import { isCCTPV2Supported } from '@circle-fin/bridge-kit'
 *
 * const isSupported = isCCTPV2Supported(ethChainDefinition)
 * console.log(isSupported) // true
 * ```
 */ function isCCTPV2Supported(chain) {
    return chain.cctp?.contracts.v2 !== undefined;
}

/**
 * Check whether a given chain supports Gateway protocol version 1.
 *
 * This type guard function examines a chain definition to determine if it has Gateway v1
 * contract configurations. It checks that the chain has a gateway object with a
 * `contracts.v1` entry present.
 *
 * @param chain - The chain definition to check for Gateway v1 support
 * @returns `true` if `chain.gateway?.contracts?.v1` is defined, `false` otherwise
 *
 * @example
 * ```typescript
 * import { isGatewayV1Supported, Base } from '@core/chains'
 *
 * if (isGatewayV1Supported(Base)) {
 *   // TypeScript knows Base.gateway is defined here
 *   console.log('Gateway domain:', Base.gateway.domain)
 *   console.log('Wallet address:', Base.gateway.contracts.v1.wallet)
 *   console.log('Minter address:', Base.gateway.contracts.v1.minter)
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Usage in conditional flow
 * function getGatewayWalletAddress(chain: ChainDefinition): string | null {
 *   if (isGatewayV1Supported(chain)) {
 *     return chain.gateway.contracts.v1.wallet
 *   }
 *   return null
 * }
 * ```
 */ function isGatewayV1Supported(chain) {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- JS consumers may pass a gateway object without contracts
    return chain.gateway?.contracts?.v1 !== undefined;
}

/**
 * Zod schema for validating Gateway v1 contract addresses.
 *
 * @example
 * ```typescript
 * gatewayV1ContractsSchema.parse({
 *   wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *   minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 * })
 * ```
 */ const gatewayV1ContractsSchema = zod.z.object({
    wallet: zod.z.string({
        required_error: 'Gateway wallet address is required. Please provide a valid contract address.',
        invalid_type_error: 'Gateway wallet address must be a string.'
    }).min(1, 'Gateway wallet address cannot be empty.'),
    minter: zod.z.string({
        required_error: 'Gateway minter address is required. Please provide a valid contract address.',
        invalid_type_error: 'Gateway minter address must be a string.'
    }).min(1, 'Gateway minter address cannot be empty.'),
    depositForHandler: zod.z.string({
        invalid_type_error: 'Gateway depositForHandler address must be a string.'
    }).min(1, 'Gateway depositForHandler address cannot be empty.').optional()
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Zod schema for validating the versioned Gateway contracts map.
 *
 * @description Mirrors the {@link GatewayContracts} type: a partial map of
 * protocol versions to their contract addresses, following the same pattern
 * as {@link CCTPContracts}.
 *
 * @example
 * ```typescript
 * gatewayContractsSchema.parse({
 *   v1: {
 *     wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *     minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *   }
 * })
 * ```
 */ const gatewayContractsSchema = zod.z.object({
    v1: gatewayV1ContractsSchema.optional()
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Zod schema for validating the full Gateway configuration.
 *
 * @description Mirrors the {@link GatewayConfig} type: a domain number plus
 * a versioned contracts map, following the same pattern as {@link CCTPConfig}.
 *
 * @example
 * ```typescript
 * gatewayConfigSchema.parse({
 *   domain: 6,
 *   contracts: {
 *     v1: {
 *       wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *       minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *     }
 *   }
 * })
 * ```
 */ const gatewayConfigSchema = zod.z.object({
    domain: zod.z.number({
        required_error: 'Gateway domain is required. Please provide a valid domain number.',
        invalid_type_error: 'Gateway domain must be a number.'
    }),
    contracts: gatewayContractsSchema,
    forwarderSupported: zod.z.object({
        source: zod.z.boolean(),
        destination: zod.z.boolean()
    })
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Base schema for common chain definition properties.
 * This contains all properties shared between EVM and non-EVM chains.
 */ const baseChainDefinitionSchema = zod.z.object({
    chain: zod.z.nativeEnum(Blockchain, {
        required_error: 'Chain enum is required. Please provide a valid Blockchain enum value.',
        invalid_type_error: 'Chain must be a valid Blockchain enum value.'
    }),
    name: zod.z.string({
        required_error: 'Chain name is required. Please provide a valid chain name.',
        invalid_type_error: 'Chain name must be a string.'
    }),
    title: zod.z.string().optional(),
    nativeCurrency: zod.z.object({
        name: zod.z.string(),
        symbol: zod.z.string(),
        decimals: zod.z.number()
    }),
    isTestnet: zod.z.boolean({
        required_error: 'isTestnet is required. Please specify whether this is a testnet.',
        invalid_type_error: 'isTestnet must be a boolean.'
    }),
    explorerUrl: zod.z.string({
        required_error: 'Explorer URL is required. Please provide a valid explorer URL.',
        invalid_type_error: 'Explorer URL must be a string.'
    }),
    rpcEndpoints: zod.z.array(zod.z.string()),
    eurcAddress: zod.z.string().nullable(),
    usdcAddress: zod.z.string().nullable(),
    usdtAddress: zod.z.string().nullable(),
    cctp: zod.z.any().nullable(),
    kitContracts: zod.z.object({
        bridge: zod.z.string().optional(),
        adapter: zod.z.string().optional()
    }).optional(),
    gateway: gatewayConfigSchema.optional()
});
/**
 * Zod schema for validating EVM chain definitions specifically.
 * This schema extends the base schema with EVM-specific properties.
 *
 * @example
 * ```typescript
 * import { evmChainDefinitionSchema } from '@core/chains/validation'
 * import { Blockchain } from '@core/chains'
 *
 * const ethereumChain = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   name: 'Ethereum',
 *   chainId: 1,
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   explorerUrl: 'https://etherscan.io/tx/{hash}',
 *   usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
 *   eurcAddress: null,
 *   cctp: null
 * }
 *
 * const result = evmChainDefinitionSchema.safeParse(ethereumChain)
 * if (result.success) {
 *   console.log('EVM chain definition is valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */ const evmChainDefinitionSchema = baseChainDefinitionSchema.extend({
    type: zod.z.literal('evm'),
    chainId: zod.z.number({
        required_error: 'EVM chains must have a chainId. Please provide a valid EVM chain ID.',
        invalid_type_error: 'EVM chain ID must be a number.'
    })
}).strict() //// Reject any additional properties not defined in the schema
;
/**
 * Zod schema for validating non-EVM chain definitions.
 * This schema extends the base schema with non-EVM specific properties.
 */ const nonEvmChainDefinitionSchema = baseChainDefinitionSchema.extend({
    type: zod.z.enum([
        'algorand',
        'avalanche',
        'solana',
        'aptos',
        'near',
        'stellar',
        'sui',
        'hedera',
        'noble',
        'polkadot'
    ])
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Discriminated union schema for all chain definitions.
 * This schema validates different chain types based on their 'type' field.
 *
 * @example
 * ```typescript
 * import { chainDefinitionSchema } from '@core/chains/validation'
 * import { Blockchain } from '@core/chains'
 *
 * // EVM chain
 * chainDefinitionSchema.parse({
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   // ... other properties
 * })
 *
 * // Non-EVM chain
 * chainDefinitionSchema.parse({
 *   type: 'solana',
 *   chain: Blockchain.Solana,
 *   // ... other properties (no chainId)
 * })
 * ```
 */ const chainDefinitionSchema = zod.z.discriminatedUnion('type', [
    evmChainDefinitionSchema,
    nonEvmChainDefinitionSchema
]);
/**
 * Zod schema for validating chain identifiers.
 * This schema accepts either a string blockchain identifier, a Blockchain enum value,
 * or a full ChainDefinition object.
 *
 * @example
 * ```typescript
 * import { chainIdentifierSchema } from '@core/chains/validation'
 * import { Blockchain, Ethereum } from '@core/chains'
 *
 * // All of these are valid:
 * chainIdentifierSchema.parse('Ethereum')
 * chainIdentifierSchema.parse(Blockchain.Ethereum)
 * chainIdentifierSchema.parse(Ethereum)
 * ```
 */ const chainIdentifierSchema = zod.z.union([
    zod.z.string().refine((val)=>val in Blockchain, 'Must be a valid Blockchain enum value as string'),
    zod.z.nativeEnum(Blockchain),
    chainDefinitionSchema
]);
/**
 * Zod schema for validating swap-specific chain identifiers.
 *
 * Validates chains based on:
 * - CCTPv2 support (adapter contract deployed)
 * - Mainnet only (no testnets)
 * - At least one supported token available
 *
 */ zod.z.union([
    // String blockchain identifier (accepts SwapChain enum values)
    zod.z.string().refine((val)=>val in SwapChain, (val)=>({
            message: `"${val}" is not a supported swap chain. ` + `Supported chains: ${Object.values(SwapChain).join(', ')}`
        })),
    // SwapChain enum
    zod.z.nativeEnum(SwapChain),
    // ChainDefinition object (checks if chain.chain is in SwapChain)
    chainDefinitionSchema.refine((chain)=>chain.chain in SwapChain, (chain)=>({
            message: `"${chain.chain}" is not a supported swap chain. ` + `Supported chains: ${Object.values(SwapChain).join(', ')}`
        }))
]);
/**
 * Zod schema for validating bridge chain identifiers.
 *
 * This schema validates that the provided chain is supported for CCTPv2 bridging.
 * It accepts either a BridgeChain enum value, a string matching a BridgeChain value,
 * or a ChainDefinition for a supported chain.
 *
 * Use this schema when validating chain parameters for bridge operations to ensure
 * only CCTPv2-supported chains are accepted at runtime.
 *
 * @example
 * ```typescript
 * import { bridgeChainIdentifierSchema } from '@core/chains/validation'
 * import { BridgeChain, Chains } from '@core/chains'
 *
 * // Valid - BridgeChain enum value
 * bridgeChainIdentifierSchema.parse(BridgeChain.Ethereum)
 *
 * // Valid - string literal
 * bridgeChainIdentifierSchema.parse('Base_Sepolia')
 *
 * // Valid - ChainDefinition (validated by CCTP support)
 * bridgeChainIdentifierSchema.parse(Chains.Solana)
 *
 * // Invalid - Algorand is not in BridgeChain (throws ZodError)
 * bridgeChainIdentifierSchema.parse('Algorand')
 * ```
 *
 * @see {@link BridgeChain} for the enum of supported chains.
 */ zod.z.union([
    zod.z.string().refine((val)=>val in BridgeChain, (val)=>({
            message: `Chain "${val}" is not supported for bridging. Only chains in the BridgeChain enum support CCTPv2 bridging.`
        })),
    chainDefinitionSchema.refine((chainDef)=>chainDef.chain in BridgeChain, (chainDef)=>({
            message: `Chain "${chainDef.name}" (${chainDef.chain}) is not supported for bridging. Only chains in the BridgeChain enum support CCTPv2 bridging.`
        }))
]);
/**
 * Zod schema for validating earn-specific chain identifiers.
 *
 * Validate that the provided chain is supported for earn (vault
 * deposit/withdraw) operations. Currently only Arc Testnet is
 * supported.
 *
 * Accept an EarnChain enum value, a matching string literal, or
 * a ChainDefinition for a supported chain.
 *
 * @example
 * ```typescript
 * import { earnChainIdentifierSchema } from '@core/chains'
 * import { ArcTestnet, EarnChain } from '@core/chains'
 *
 * // Valid
 * earnChainIdentifierSchema.parse(EarnChain.Arc_Testnet)
 * earnChainIdentifierSchema.parse('Arc_Testnet')
 * earnChainIdentifierSchema.parse(ArcTestnet)
 *
 * // Invalid (throws ZodError)
 * earnChainIdentifierSchema.parse('Solana')
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>val in EarnChain, (val)=>({
            message: `"${val}" is not a supported earn chain. ` + `Supported chains: ${Object.values(EarnChain).join(', ')}`
        })),
    zod.z.nativeEnum(EarnChain),
    chainDefinitionSchema.refine((chain)=>chain.chain in EarnChain, (chain)=>({
            message: `"${chain.chain}" is not a supported earn chain. ` + `Supported chains: ${Object.values(EarnChain).join(', ')}`
        }))
]);
// Widened views so `.includes()` accepts arbitrary strings under strict TS.
const EARN_BRIDGE_SOURCE_CHAIN_VALUES = EARN_BRIDGE_SOURCE_BLOCKCHAINS;
const EARN_BRIDGE_DESTINATION_CHAIN_VALUES = EARN_BRIDGE_DESTINATION_BLOCKCHAINS;
/**
 * Zod schema for validating the source chain of a cross-chain Earn deposit.
 *
 * Accept a supported source Blockchain value, a matching string literal, or a
 * ChainDefinition for a supported source chain. Source chains are Ethereum
 * Sepolia, Arbitrum Sepolia, and Base Sepolia.
 *
 * @example
 * ```typescript
 * import { earnBridgeSourceChainIdentifierSchema } from '@core/chains'
 *
 * // Valid
 * earnBridgeSourceChainIdentifierSchema.parse('Ethereum_Sepolia')
 *
 * // Invalid (throws ZodError)
 * earnBridgeSourceChainIdentifierSchema.parse('Arc_Testnet')
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>EARN_BRIDGE_SOURCE_CHAIN_VALUES.includes(val), (val)=>({
            message: `"${val}" is not a supported cross-chain Earn source chain. ` + `Supported chains: ${EARN_BRIDGE_SOURCE_BLOCKCHAINS.join(', ')}`
        })),
    chainDefinitionSchema.refine((chain)=>EARN_BRIDGE_SOURCE_CHAIN_VALUES.includes(chain.chain), (chain)=>({
            message: `"${chain.chain}" is not a supported cross-chain Earn source chain. ` + `Supported chains: ${EARN_BRIDGE_SOURCE_BLOCKCHAINS.join(', ')}`
        }))
]);
/**
 * Zod schema for validating the destination chain of a cross-chain Earn
 * deposit.
 *
 * Accept a supported destination Blockchain value, a matching string literal,
 * or a ChainDefinition for a supported destination chain. Currently only Arc
 * Testnet is supported.
 *
 * @example
 * ```typescript
 * import { earnBridgeDestinationChainIdentifierSchema } from '@core/chains'
 *
 * // Valid
 * earnBridgeDestinationChainIdentifierSchema.parse('Arc_Testnet')
 *
 * // Invalid (throws ZodError)
 * earnBridgeDestinationChainIdentifierSchema.parse('Ethereum_Sepolia')
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>EARN_BRIDGE_DESTINATION_CHAIN_VALUES.includes(val), (val)=>({
            message: `"${val}" is not a supported cross-chain Earn destination chain. ` + `Supported chains: ${EARN_BRIDGE_DESTINATION_BLOCKCHAINS.join(', ')}`
        })),
    chainDefinitionSchema.refine((chain)=>EARN_BRIDGE_DESTINATION_CHAIN_VALUES.includes(chain.chain), (chain)=>({
            message: `"${chain.chain}" is not a supported cross-chain Earn destination chain. ` + `Supported chains: ${EARN_BRIDGE_DESTINATION_BLOCKCHAINS.join(', ')}`
        }))
]);
/**
 * Zod schema for validating unified balance chain identifiers.
 *
 * This schema validates that the provided chain is supported for unified balance operations.
 * It accepts either a UnifiedBalanceChain enum value, a string matching a UnifiedBalanceChain value,
 * or a ChainDefinition for a supported chain.
 *
 * Use this schema when validating chain parameters for unified balance operations to ensure
 * only Gateway V1-supported chains are accepted at runtime.
 *
 * @example
 * ```typescript
 * import { unifiedBalanceChainIdentifierSchema } from '@core/chains/validation'
 * import { UnifiedBalanceChain, Chains } from '@core/chains'
 *
 * // Valid - UnifiedBalanceChain enum value
 * unifiedBalanceChainIdentifierSchema.parse(UnifiedBalanceChain.Ethereum)
 *
 * // Valid - string literal
 * unifiedBalanceChainIdentifierSchema.parse('Ethereum')
 *
 * // Invalid - Algorand is not in UnifiedBalanceChain (throws ZodError)
 * unifiedBalanceChainIdentifierSchema.parse('Algorand')
 * ```
 *
 * @see {@link UnifiedBalanceChain} for the enum of supported chains.
 */ const supportedUnifiedBalanceChains = Object.keys(UnifiedBalanceChain).join(', ');
zod.z.union([
    zod.z.string().refine((val)=>val in UnifiedBalanceChain, (val)=>({
            message: `Chain "${val}" is not supported for unified balance operations. Supported chains: ${supportedUnifiedBalanceChains}.`
        })),
    chainDefinitionSchema.refine((chainDef)=>chainDef.chain in UnifiedBalanceChain, (chainDef)=>({
            message: `Chain "${chainDef.name}" (${chainDef.chain}) is not supported for unified balance operations. Supported chains: ${supportedUnifiedBalanceChains}.`
        }))
]);

// Internal enum used after input normalization.
const swapTokenEnumSchema = zod.z.enum([
    ...Object.keys(SWAP_TOKEN_REGISTRY),
    NATIVE_TOKEN
]);
/**
 * Zod schema for validating supported swap token symbols.
 *
 * Accepts any token symbol from the SWAP_TOKEN_REGISTRY plus NATIVE.
 * Input matching is case-insensitive and normalized to uppercase.
 *
 * @example
 * ```typescript
 * import { supportedSwapTokenSchema } from '@core/chains'
 *
 * const result = supportedSwapTokenSchema.safeParse('USDC')
 * if (result.success) {
 *   console.log('Valid swap token:', result.data)
 * }
 * ```
 */ zod.z.string().transform((value)=>value.toUpperCase()).pipe(swapTokenEnumSchema);

/**
 * Retrieve a chain definition by its blockchain enum value.
 *
 * Searches the set of known chain definitions and returns the one matching the provided
 * blockchain enum or string value. Throws an error if no matching chain is found.
 *
 * @param blockchain - The blockchain enum or its string representation to look up.
 * @returns The corresponding ChainDefinition object for the given blockchain.
 *
 * @throws Error If no chain definition is found for the provided enum value.
 *
 * @example
 * ```typescript
 * import { getChainByEnum } from '@core/chains'
 * import { Blockchain } from '@core/chains'
 *
 * const ethereum = getChainByEnum(Blockchain.Ethereum)
 * console.log(ethereum.name) // "Ethereum"
 * ```
 */ const getChainByEnum = (blockchain)=>{
    const chain = Object.values(Blockchains).find((chain)=>{
        return chain.chain === blockchain;
    });
    if (!chain) {
        throw new Error(`No chain definition found for blockchain: ${blockchain}`);
    }
    return chain;
};

/**
 * Resolves a flexible chain identifier to a ChainDefinition.
 *
 * This function handles all three supported formats:
 * - ChainDefinition objects (passed through unchanged)
 * - Blockchain enum values (resolved via getChainByEnum)
 * - String literals of blockchain values (resolved via getChainByEnum)
 *
 * @param chainIdentifier - The chain identifier to resolve
 * @returns The resolved ChainDefinition object
 * @throws Error if the chain identifier cannot be resolved
 *
 * @example
 * ```typescript
 * import { resolveChainIdentifier } from '@core/chains'
 * import { Blockchain, Ethereum } from '@core/chains'
 *
 * // All of these resolve to the same ChainDefinition:
 * const chain1 = resolveChainIdentifier(Ethereum)
 * const chain2 = resolveChainIdentifier(Blockchain.Ethereum)
 * const chain3 = resolveChainIdentifier('Ethereum')
 * ```
 */ function resolveChainIdentifier(chainIdentifier) {
    // Handle null explicitly (typeof null === 'object' in JavaScript)
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (chainIdentifier === null) {
        throw new Error(`Invalid chain identifier type: null. Expected ChainDefinition object, Blockchain enum, or string literal.`);
    }
    // If it's already a ChainDefinition object, return it unchanged
    if (typeof chainIdentifier === 'object') {
        return chainIdentifier;
    }
    // If it's a string or enum value, resolve it via getChainByEnum
    if (typeof chainIdentifier === 'string') {
        return getChainByEnum(chainIdentifier);
    }
    // This should never happen with proper typing, but provide a fallback
    throw new Error(`Invalid chain identifier type: ${typeof chainIdentifier}. Expected ChainDefinition object, Blockchain enum, or string literal.`);
}

/**
 * Extract the default RPC endpoint from a chain definition.
 *
 * This utility function provides a standardized way to access the primary
 * RPC endpoint from a chain definition. It returns the first endpoint in
 * the rpcEndpoints array, which is considered the primary/default endpoint.
 *
 * @param chain - The chain definition containing RPC endpoints
 * @returns The default RPC endpoint URL
 * @throws Error when no RPC endpoints are available
 *
 * @example
 * ```typescript
 * import { getDefaultRpcEndpoint } from '@core/chains'
 * import { Ethereum } from '@core/chains'
 *
 * // Get the default RPC endpoint for Ethereum
 * const rpcUrl = getDefaultRpcEndpoint(Ethereum)
 * console.log(rpcUrl) // "https://cloudflare-eth.com"
 * ```
 *
 * @example
 * ```typescript
 * import { getDefaultRpcEndpoint } from '@core/chains'
 * import { resolveChainIdentifier } from '@core/chains'
 *
 * // Use with dynamic chain resolution
 * const chain = resolveChainIdentifier('Polygon')
 * const rpcUrl = getDefaultRpcEndpoint(chain)
 * console.log(rpcUrl) // "https://polygon.publicnode.com"
 * ```
 *
 * @example
 * ```typescript
 * import { getDefaultRpcEndpoint } from '@core/chains'
 * import { createPublicClient, http } from 'viem'
 * import { getViemChainByEnum } from '@adapters/viem.v2'
 *
 * // Use with viem PublicClient creation
 * const chain = resolveChainIdentifier('Ethereum')
 * const viemChain = getViemChainByEnum(chain.chain)
 * const rpcUrl = getDefaultRpcEndpoint(chain)
 *
 * const publicClient = createPublicClient({
 *   chain: viemChain,
 *   transport: http(rpcUrl)
 * })
 * ```
 */ function getDefaultRpcEndpoint(chain) {
    const defaultEndpoint = chain.rpcEndpoints[0];
    if (defaultEndpoint === undefined || defaultEndpoint === '') {
        throw new Error(`No RPC endpoints found for chain ${chain.name}. Please ensure the chain definition includes default RPC endpoints.`);
    }
    return defaultEndpoint;
}

/**
 * Create a structured error for token resolution failures.
 *
 * @remarks
 * Returns a `KitError` with `INPUT_UNSUPPORTED_TOKEN` code (1006).
 * The error trace contains the selector and chain context for debugging.
 *
 * @param message - Human-readable error description.
 * @param selector - The token selector that failed to resolve.
 * @param chainId - The chain being resolved for (optional).
 * @param cause - The underlying error, if any (optional).
 * @returns A KitError with INPUT type and FATAL recoverability.
 *
 * @example
 * ```typescript
 * throw createTokenResolutionError(
 *   'Unknown token symbol: FAKE',
 *   'FAKE',
 *   'Ethereum'
 * )
 * ```
 */ function createTokenResolutionError(message, selector, chainId, cause) {
    const trace = {
        selector,
        ...chainId === undefined ? {} : {
            chainId
        },
        ...{} 
    };
    return new KitError({
        ...InputError.UNSUPPORTED_TOKEN,
        recoverability: 'FATAL',
        message,
        cause: {
            trace
        }
    });
}

/**
 * USDC token definition with addresses and metadata.
 *
 * @remarks
 * This is the built-in USDC definition used by the TokenRegistry.
 * Includes all known USDC addresses across supported chains.
 *
 * Keys use the `Blockchain` enum for type safety. Both enum values
 * and string literals are supported:
 * - `Blockchain.Ethereum` or `'Ethereum'`
 *
 * @example
 * ```typescript
 * import { USDC } from '@core/tokens'
 * import { Blockchain } from '@core/chains'
 *
 * console.log(USDC.symbol)   // 'USDC'
 * console.log(USDC.decimals) // 6
 * console.log(USDC.locators[Blockchain.Ethereum])
 * // '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
 * ```
 */ const USDC = {
    symbol: 'USDC',
    decimals: 6,
    locators: {
        // =========================================================================
        // Mainnets (alphabetically sorted)
        // =========================================================================
        [Blockchain.Arbitrum]: '0xaf88d065e77c8cC2239327C5EDb3A432268e5831',
        [Blockchain.Avalanche]: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
        [Blockchain.Base]: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
        [Blockchain.Celo]: '0xcebA9300f2b948710d2653dD7B07f33A8B32118C',
        [Blockchain.Codex]: '0xd996633a415985DBd7D6D12f4A4343E31f5037cf',
        [Blockchain.Cronos]: '0x3D7F2C478aAfdB65542BCB44bCeeC05849999d2D',
        [Blockchain.Edge]: '0x98d2919b9A214E6Fa5384AC81E6864bA686Ad74c',
        [Blockchain.Ethereum]: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
        [Blockchain.Hedera]: '0.0.456858',
        [Blockchain.HyperEVM]: '0xb88339CB7199b77E23DB6E890353E22632Ba630f',
        [Blockchain.Injective]: '0xa00C59fF5a080D2b954d0c75e46E22a0c371235a',
        [Blockchain.Ink]: '0x2D270e6886d130D724215A266106e6832161EAEd',
        [Blockchain.Linea]: '0x176211869ca2b568f2a7d4ee941e073a821ee1ff',
        [Blockchain.Monad]: '0x754704Bc059F8C67012fEd69BC8A327a5aafb603',
        [Blockchain.Morph]: '0xCfb1186F4e93D60E60a8bDd997427D1F33bc372B',
        [Blockchain.NEAR]: '17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1',
        [Blockchain.Noble]: 'uusdc',
        [Blockchain.Optimism]: '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
        [Blockchain.Pharos]: '0xC879C018dB60520F4355C26eD1a6D572cdAC1815',
        [Blockchain.Plasma]: '0x2d661C89D812261039AF9764eceaAee884f5F67F',
        [Blockchain.Plume]: '0x222365EF19F7947e5484218551B56bb3965Aa7aF',
        [Blockchain.Polkadot_Asset_Hub]: '1337',
        [Blockchain.Polygon]: '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
        [Blockchain.Sei]: '0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392',
        [Blockchain.Solana]: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
        [Blockchain.Sonic]: '0x29219dd400f2Bf60E5a23d13Be72B486D4038894',
        [Blockchain.Stellar]: 'USDC-GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN',
        [Blockchain.Sui]: '0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC',
        [Blockchain.Unichain]: '0x078D782b760474a361dDA0AF3839290b0EF57AD6',
        [Blockchain.World_Chain]: '0x79A02482A880bCE3F13e09Da970dC34db4CD24d1',
        [Blockchain.XDC]: '0xfA2958CB79b0491CC627c1557F441eF849Ca8eb1',
        [Blockchain.X_Layer]: '0xB6CEceAB302E2E4948951eE7843FC24E92933061',
        [Blockchain.ZKSync_Era]: '0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4',
        // =========================================================================
        // Testnets (alphabetically sorted)
        // =========================================================================
        [Blockchain.Arc_Testnet]: '0x3600000000000000000000000000000000000000',
        [Blockchain.Arbitrum_Sepolia]: '0x75faf114eafb1BDbe2F0316DF893fd58CE46AA4d',
        [Blockchain.Avalanche_Fuji]: '0x5425890298aed601595a70AB815c96711a31Bc65',
        [Blockchain.Base_Sepolia]: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
        [Blockchain.Celo_Alfajores_Testnet]: '0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B',
        [Blockchain.Codex_Testnet]: '0x6d7f141b6819C2c9CC2f818e6ad549E7Ca090F8f',
        [Blockchain.Cronos_Testnet]: '0xEb33dc5fac03833e132593659e1dE7256aB59794',
        [Blockchain.Edge_Testnet]: '0x2d9F7CAD728051AA35Ecdc472a14cf8cDF5CFD6B',
        [Blockchain.Ethereum_Sepolia]: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
        [Blockchain.Hedera_Testnet]: '0.0.429274',
        [Blockchain.HyperEVM_Testnet]: '0x2B3370eE501B4a559b57D449569354196457D8Ab',
        [Blockchain.Injective_Testnet]: '0x0C382e685bbeeFE5d3d9C29e29E341fEE8E84C5d',
        [Blockchain.Ink_Testnet]: '0xFabab97dCE620294D2B0b0e46C68964e326300Ac',
        [Blockchain.Linea_Sepolia]: '0xfece4462d57bd51a6a552365a011b95f0e16d9b7',
        [Blockchain.Monad_Testnet]: '0x534b2f3A21130d7a60830c2Df862319e593943A3',
        [Blockchain.Morph_Testnet]: '0x7433b41C6c5e1d58D4Da99483609520255ab661B',
        [Blockchain.NEAR_Testnet]: '3e2210e1184b45b64c8a434c0a7e7b23cc04ea7eb7a6c3c32520d03d4afcb8af',
        [Blockchain.Noble_Testnet]: 'uusdc',
        [Blockchain.Optimism_Sepolia]: '0x5fd84259d66Cd46123540766Be93DFE6D43130D7',
        [Blockchain.Pharos_Testnet]: '0xcfC8330f4BCAB529c625D12781b1C19466A9Fc8B',
        [Blockchain.Plasma_Testnet]: '0xE67Fb267022cBA8064Dd388CC2FED724F3120D9D',
        [Blockchain.Plume_Testnet]: '0xcB5f30e335672893c7eb944B374c196392C19D18',
        [Blockchain.Polkadot_Westmint]: '31337',
        [Blockchain.Polygon_Amoy_Testnet]: '0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582',
        [Blockchain.Sei_Testnet]: '0x4fCF1784B31630811181f670Aea7A7bEF803eaED',
        [Blockchain.Solana_Devnet]: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
        [Blockchain.Sonic_Testnet]: '0x0BA304580ee7c9a980CF72e55f5Ed2E9fd30Bc51',
        [Blockchain.Stellar_Testnet]: 'USDC-GBBD47IF6LWK7P7MDEVSCWR7DPUWV3NY3DTQEVFL4NAT4AQH3ZLLFLA5',
        [Blockchain.Sui_Testnet]: '0xa1ec7fc00a6f40db9693ad1415d0c193ad3906494428cf252621037bd7117e29::usdc::USDC',
        [Blockchain.Unichain_Sepolia]: '0x31d0220469e10c4E71834a79b1f276d740d3768F',
        [Blockchain.World_Chain_Sepolia]: '0x66145f38cBAC35Ca6F1Dfb4914dF98F1614aeA88',
        [Blockchain.XDC_Apothem]: '0xb5AB69F7bBada22B28e79C8FFAECe55eF1c771D4',
        [Blockchain.X_Layer_Testnet]: '0xDec90b78111Ba2fc6FC6d84d8B9ec159A2d4b9B3',
        [Blockchain.ZKSync_Sepolia]: '0xAe045DE5638162fa134807Cb558E15A3F5A7F853'
    }
};

/**
 * USDT (Tether) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in USDT definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */ const USDT = {
    symbol: 'USDT',
    decimals: 6,
    locators: {
        [Blockchain.Aptos]: '0x357b0b74bc833e95a115ad22604854d6b0fca151cecd94111770e5d6ffc9dc2b',
        [Blockchain.Arbitrum]: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
        [Blockchain.Avalanche]: '0x9702230A8Ea53601f5cD2dc00fDBc13d4dF4A8c7',
        [Blockchain.Celo]: '0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e',
        [Blockchain.Ethereum]: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
        [Blockchain.HyperEVM]: '0xb8ce59fc3717ada4c02eadf9682a9e934f625ebb',
        [Blockchain.Ink]: '0x0200C29006150606B650577BBE7B6248F58470c1',
        [Blockchain.Linea]: '0xA219439258ca9da29E9Cc4cE5596924745e12B93',
        [Blockchain.Monad]: '0xe7cd86e13AC4309349F30B3435a9d337750fC82D',
        [Blockchain.NEAR]: 'usdt.tether-token.near',
        [Blockchain.Optimism]: '0x94b008aA00579c1307B0EF2c499aD98a8ce58e58',
        [Blockchain.Polkadot_Asset_Hub]: '1984',
        [Blockchain.Polygon]: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F',
        [Blockchain.Sei]: '0x9151434b16b9763660705744891fA906F660EcC5',
        [Blockchain.Solana]: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
        [Blockchain.Unichain]: '0x9151434b16b9763660705744891fA906F660EcC5'
    }
};

/**
 * EURC (Euro Coin) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in EURC definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */ const EURC = {
    symbol: 'EURC',
    decimals: 6,
    locators: {
        // =========================================================================
        // Mainnets
        // =========================================================================
        [Blockchain.Avalanche]: '0xc891EB4cbdEFf6e073e859e987815Ed1505c2ACD',
        [Blockchain.Base]: '0x60a3E35Cc302bFA44Cb288Bc5a4F316Fdb1adb42',
        [Blockchain.Cronos]: '0xA6dE01a2d62C6B5f3525d768f34d276652C554c8',
        [Blockchain.Ethereum]: '0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c',
        [Blockchain.Plasma]: '0x3EE196E78d4d4248b849B8E1C7F44C5457FAFD2C',
        [Blockchain.Solana]: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
        [Blockchain.World_Chain]: '0x1C60ba0A0eD1019e8Eb035E6daF4155A5cE2380B',
        // =========================================================================
        // Testnets
        // =========================================================================
        [Blockchain.Arc_Testnet]: '0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a',
        [Blockchain.Base_Sepolia]: '0x808456652fdb597867f38412077A9182bf77359F',
        [Blockchain.Cronos_Testnet]: '0x31f7538adb53cF16350e6B0c89d03D91b7D12c46',
        [Blockchain.Ethereum_Sepolia]: '0x08210F9170F89Ab7658F0B5E3fF39b0E03C594D4',
        [Blockchain.Plasma_Testnet]: '0x98AfA0F93Dd993B736399f9074eDcEBD1985A330'
    }
};

/**
 * DAI (Maker DAO) stablecoin token definition with addresses and metadata.
 *
 * @remarks
 * Built-in DAI definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */ const DAI = {
    symbol: 'DAI',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 8
    },
    locators: {
        [Blockchain.Arbitrum]: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1',
        [Blockchain.Avalanche]: '0xd586E7F844cEa2F87f50152665BCbc2C279D8d70',
        [Blockchain.Base]: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb',
        [Blockchain.Ethereum]: '0x6B175474E89094C44Da98b954EedeAC495271d0F',
        [Blockchain.Linea]: '0x4AF15ec2A0BD43Db75dd04E62FAA3B8EF36b00d5',
        [Blockchain.Optimism]: '0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1',
        [Blockchain.Polygon]: '0x8f3Cf7ad23Cd3CaDbD9735AFf958023239c6A063',
        [Blockchain.Solana]: 'EjmyN6qEC1Tf1JxiG1ae7UTJhUxSwk1TCWNWqxWV4J6o'
    }
};

/**
 * USDe (Ethena) synthetic dollar token definition with addresses and metadata.
 *
 * @remarks
 * Built-in USDE definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */ const USDE = {
    symbol: 'USDe',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 9
    },
    locators: {
        [Blockchain.Arbitrum]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Base]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Ethereum]: '0x4c9EDD5852cd905f086C759E8383e09bff1E68B3',
        [Blockchain.Linea]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Optimism]: '0x5d3a1Ff2b6BAb83b63cd9AD0787074081a52ef34',
        [Blockchain.Solana]: 'DEkqHyPN7GMRJ5cArtQFAWefqbZb33Hyf6s5iCwjEonT'
    }
};

/**
 * PYUSD (PayPal USD) stablecoin token definition with addresses and metadata.
 *
 * @remarks
 * Built-in PYUSD definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */ const PYUSD = {
    symbol: 'PYUSD',
    decimals: 6,
    locators: {
        [Blockchain.Arbitrum]: '0x46850aD61C2B7d64d08c9C754F45254596696984',
        [Blockchain.Ethereum]: '0x6c3ea9036406852006290770BEdFcAbA0e23A0e8',
        [Blockchain.Solana]: '2b1kV6DkPAnxd5ixfnxCpjxmKwqjjaYmCZfHsFu24GXo'
    }
};

/**
 * WETH (Wrapped Ether) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WETH definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WETH is available.
 */ const WETH = {
    symbol: 'WETH',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 9
    },
    locators: {
        [Blockchain.Arbitrum]: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
        [Blockchain.Avalanche]: '0x49D5c2BdFfac6CE2BFdB6640F4F80f226bc10bAB',
        [Blockchain.Base]: '0x4200000000000000000000000000000000000006',
        [Blockchain.Ethereum]: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
        [Blockchain.Optimism]: '0x4200000000000000000000000000000000000006',
        [Blockchain.Polygon]: '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619',
        [Blockchain.Solana]: '7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs'
    }
};

/**
 * WBTC (Wrapped Bitcoin) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WBTC definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WBTC is available.
 */ const WBTC = {
    symbol: 'WBTC',
    decimals: 8,
    locators: {
        [Blockchain.Ethereum]: '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599',
        [Blockchain.Arbitrum]: '0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f',
        [Blockchain.Avalanche]: '0x50b7545627a5162F82A992c33b87aDc75187B218'
    }
};

/**
 * WSOL (Wrapped SOL) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WSOL definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WSOL is available.
 */ const WSOL = {
    symbol: 'WSOL',
    decimals: 9,
    locators: {
        [Blockchain.Solana]: 'So11111111111111111111111111111111111111112'
    }
};

/**
 * WAVAX (Wrapped AVAX) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WAVAX definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WAVAX is available.
 */ const WAVAX = {
    symbol: 'WAVAX',
    decimals: 18,
    locators: {
        [Blockchain.Avalanche]: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7'
    }
};

/**
 * WPOL (Wrapped POL) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in WPOL definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains where WPOL is available.
 */ const WPOL = {
    symbol: 'WPOL',
    decimals: 18,
    locators: {
        [Blockchain.Polygon]: '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270'
    }
};

/**
 * ETH (native Ether alias) token definition with metadata.
 *
 * @remarks
 * Built-in ETH definition for the TokenRegistry. Used as a symbol alias
 * for native ETH (e.g. in swap flows). Chain locators are TBD and will
 * be added when addresses are available. Use raw selector with
 * locator + decimals where native gas token is represented as a contract.
 */ const ETH = {
    symbol: 'ETH',
    decimals: 18,
    locators: {}
};

/**
 * POL (Polygon native token) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in POL definition for the TokenRegistry. Includes chain locators
 * where POL is available as a bridged/wrapped asset.
 */ const POL = {
    symbol: 'POL',
    decimals: 18,
    locators: {
        [Blockchain.Ethereum]: '0x455e53CBB86018Ac2B8092FdCd39d8444aFFC3F6'
    }
};

/**
 * PLUME (Plume network token) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in PLUME definition for the TokenRegistry. Includes chain locators
 * where PLUME is available.
 */ const PLUME = {
    symbol: 'PLUME',
    decimals: 18,
    locators: {
        [Blockchain.Ethereum]: '0x4C1746A800D224393fE2470C70A35717eD4eA5F1'
    }
};

/**
 * MON token definition with Solana mint metadata.
 *
 * @remarks
 * Built-in MON definition for the TokenRegistry. Includes chain locators
 * for swap-supported chains.
 */ const MON = {
    symbol: 'MON',
    decimals: 18,
    chainDecimals: {
        [Blockchain.Solana]: 8
    },
    locators: {
        [Blockchain.Solana]: 'CrAr4RRJMBVwRsZtT62pEhfA9H5utymC2mVx8e7FreP2'
    }
};

/**
 * cirBTC (Circle Bitcoin) token definition with addresses and metadata.
 *
 * @remarks
 * Built-in cirBTC definition for the TokenRegistry.
 *
 * @example
 * ```typescript
 * import { CIRBTC } from '@core/tokens'
 * import { Blockchain } from '@core/chains'
 *
 * console.log(CIRBTC.symbol)   // 'cirBTC'
 * console.log(CIRBTC.decimals) // 8
 * console.log(CIRBTC.locators[Blockchain.Arc_Testnet])
 * // '0xf0C4a4CE82A5746AbAAd9425360Ab04fbBA432BF'
 * ```
 */ const CIRBTC = {
    symbol: 'cirBTC',
    decimals: 8,
    locators: {
        // =========================================================================
        // Mainnets
        // =========================================================================
        [Blockchain.Ethereum]: '0x72DFB2E44f59C5AD2bAFE84314E5b99a7cd5075E',
        // =========================================================================
        // Testnets
        // =========================================================================
        [Blockchain.Arc_Testnet]: '0xf0C4a4CE82A5746AbAAd9425360Ab04fbBA432BF',
        [Blockchain.Ethereum_Sepolia]: '0x3a3fe695F684Bf9b9e43CF43C2b895Ea5e392bB3'
    }
};

/**
 * Built-in token definitions for stablecoins and common swap/runtime tokens.
 *
 * @remarks
 * Each token file contains both the address map and the full token definition.
 * These are automatically used as defaults in the TokenRegistry.
 *
 * @packageDocumentation
 */ // Re-export for consumers
/**
 * All default token definitions.
 *
 * @remarks
 * These tokens are automatically included in the TokenRegistry when created
 * without explicit defaults. Extensions can override these definitions.
 * Includes USDC, USDT, EURC, DAI, USDE, PYUSD, WETH, WBTC, WSOL, WAVAX,
 * WPOL, ETH, POL, PLUME, MON, and cirBTC.
 *
 * @example
 * ```typescript
 * import { createTokenRegistry } from '@core/tokens'
 *
 * // Registry uses these by default
 * const registry = createTokenRegistry()
 *
 * // Add custom tokens (built-ins are still included)
 * const customRegistry = createTokenRegistry({
 *   tokens: [myCustomToken],
 * })
 * ```
 */ const DEFAULT_TOKENS = [
    USDC,
    USDT,
    EURC,
    DAI,
    USDE,
    PYUSD,
    WETH,
    WBTC,
    WSOL,
    WAVAX,
    WPOL,
    ETH,
    POL,
    PLUME,
    MON,
    CIRBTC
];
/**
 * Uppercased token symbols approved for swap fee collection.
 *
 * @remarks
 * Derived from {@link DEFAULT_TOKENS} so all consumers share a single
 * allowlist source and stay in sync when defaults change.
 */ new Set(DEFAULT_TOKENS.map((t)=>t.symbol.toUpperCase()));

/**
 * Resolve the effective decimals for a token on a specific chain.
 *
 * Returns the chain-specific override from `chainDecimals` when available,
 * otherwise falls back to the token's default `decimals`.
 *
 * @param token - The token definition to resolve decimals for.
 * @param chain - Optional chain identifier. When omitted, the default decimals are returned.
 * @returns The number of decimal places for the token on the given chain.
 *
 * @example
 * ```typescript
 * import { resolveTokenDecimals } from '\@core/tokens'
 *
 * // DAI: 18 decimals on EVM, 8 on Solana
 * resolveTokenDecimals(DAI)            // 18 (default)
 * resolveTokenDecimals(DAI, 'Solana')  // 8  (chain override)
 * resolveTokenDecimals(DAI, 'Ethereum') // 18 (no override, falls back)
 * ```
 */ function resolveTokenDecimals(token, chain) {
    if (chain === undefined) {
        return token.decimals;
    }
    return token.chainDecimals?.[chain] ?? token.decimals;
}

/**
 * Check if a selector is a raw token selector (object form).
 *
 * @param selector - The token selector to check.
 * @returns True if the selector is a raw token selector.
 */ function isRawSelector(selector) {
    return typeof selector === 'object' && 'locator' in selector;
}
/**
 * Normalize a symbol to uppercase for case-insensitive lookup.
 *
 * @param symbol - The symbol to normalize.
 * @returns The normalized (uppercase) symbol.
 */ function normalizeSymbol(symbol) {
    return symbol.toUpperCase();
}
/**
 * Normalize a locator for stable chain-aware lookup.
 *
 * @remarks
 * EVM-style addresses (`0x...`) are normalized to lowercase for
 * case-insensitive matching. Non-EVM locators keep original casing.
 */ function normalizeLocator(locator) {
    if (locator.startsWith('0x') || locator.startsWith('0X')) {
        return locator.toLowerCase();
    }
    return locator;
}
/**
 * Build a stable map key for a chain + locator pair.
 */ function buildAddressKey(chainId, locator) {
    return `${chainId}::${normalizeLocator(locator)}`;
}
/**
 * Create a token registry with built-in tokens and optional extensions.
 *
 * @remarks
 * The registry always includes built-in tokens (DEFAULT_TOKENS) like USDC.
 * Custom tokens are merged on top - use this to add new tokens or override
 * built-in definitions.
 *
 * @param options - Configuration options for the registry.
 * @returns A token registry instance.
 *
 * @example
 * ```typescript
 * import { createTokenRegistry } from '@core/tokens'
 *
 * // Create registry with built-in tokens (USDC, etc.)
 * const registry = createTokenRegistry()
 *
 * // Resolve USDC on Ethereum
 * const usdc = registry.resolve('USDC', 'Ethereum')
 * console.log(usdc.locator) // '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'
 * console.log(usdc.decimals) // 6
 * ```
 *
 * @example
 * ```typescript
 * // Add custom tokens (built-ins are still included)
 * const myToken: TokenDefinition = {
 *   symbol: 'MY',
 *   decimals: 18,
 *   locators: { Ethereum: '0x...' },
 * }
 *
 * const registry = createTokenRegistry({ tokens: [myToken] })
 * registry.resolve('USDC', 'Ethereum') // Still works!
 * registry.resolve('MY', 'Ethereum')   // Also works
 * ```
 *
 * @example
 * ```typescript
 * // Override a built-in token
 * const customUsdc: TokenDefinition = {
 *   symbol: 'USDC',
 *   decimals: 6,
 *   locators: { MyChain: '0xCustomAddress' },
 * }
 *
 * const registry = createTokenRegistry({ tokens: [customUsdc] })
 * // Now USDC resolves to customUsdc definition
 * ```
 *
 * @example
 * ```typescript
 * // Resolve arbitrary tokens by raw locator
 * const registry = createTokenRegistry()
 * const token = registry.resolve(
 *   { locator: '0x1234...', decimals: 18 },
 *   'Ethereum'
 * )
 * ```
 */ function createTokenRegistry(options = {}) {
    const { tokens = [], requireDecimals = false } = options;
    // Build the token map: always start with DEFAULT_TOKENS, then add custom tokens
    const tokenMap = new Map();
    // Add built-in tokens first
    for (const def of DEFAULT_TOKENS){
        tokenMap.set(normalizeSymbol(def.symbol), def);
    }
    // Custom tokens override built-ins
    for (const def of tokens){
        tokenMap.set(normalizeSymbol(def.symbol), def);
    }
    // Build an address index from the resolved token map so overrides win.
    const addressMap = new Map();
    for (const token of tokenMap.values()){
        for (const [chainId, locator] of Object.entries(token.locators)){
            if (typeof locator !== 'string' || locator.trim() === '') {
                continue;
            }
            addressMap.set(buildAddressKey(chainId, locator), token);
        }
    }
    /**
   * Resolve a bare string selector to token information.
   *
   * @remarks
   * Tries symbol lookup first, then falls back to address lookup against the
   * registry's address index. The fallback lets legacy callers (and the
   * adapter-compat layer) pass a raw on-chain address as a bare string without
   * having to construct a `{ locator, decimals }` object — decimals are
   * recovered from the registered token definition.
   */ function resolveSymbol(symbol, chainId) {
        const normalizedSymbol = normalizeSymbol(symbol);
        const definition = tokenMap.get(normalizedSymbol);
        if (definition !== undefined) {
            const locator = definition.locators[chainId];
            if (locator === undefined || locator.trim() === '') {
                throw createTokenResolutionError(`Token ${symbol} has no locator for chain ${chainId}`, symbol, chainId);
            }
            const decimals = resolveTokenDecimals(definition, chainId);
            return {
                symbol: definition.symbol,
                decimals,
                locator: normalizeLocator(locator)
            };
        }
        // Fallback: treat the bare string as an address and look it up in the
        // address index. Resolves legacy callers that pass raw token addresses
        // (e.g. Solana mints, EVM contract addresses) without wrapping them in a
        // RawTokenSelector.
        const addressMatch = addressMap.get(buildAddressKey(chainId, symbol));
        if (addressMatch !== undefined) {
            const locator = addressMatch.locators[chainId];
            if (locator !== undefined && locator.trim() !== '') {
                return {
                    symbol: addressMatch.symbol,
                    decimals: resolveTokenDecimals(addressMatch, chainId),
                    locator: normalizeLocator(locator)
                };
            }
        }
        throw createTokenResolutionError(`Unknown token or address: ${symbol}. Register it via createTokenRegistry({ tokens: [...] }) or use a raw selector.`, symbol, chainId);
    }
    /**
   * Resolve a raw selector to token information.
   */ function resolveRaw(selector, chainId) {
        const { locator, decimals } = selector;
        // Validate locator
        if (!locator || typeof locator !== 'string') {
            throw createTokenResolutionError('Raw selector must have a valid locator string', selector, chainId);
        }
        // Decimals are always required for raw selectors
        if (decimals === undefined) {
            const message = requireDecimals ? 'Decimals required for raw token selector (requireDecimals: true)' : 'Decimals required for raw token selector. Provide { locator, decimals }.';
            throw createTokenResolutionError(message, selector, chainId);
        }
        // Validate decimals
        if (typeof decimals !== 'number' || decimals < 0 || !Number.isInteger(decimals)) {
            throw createTokenResolutionError(`Invalid decimals: ${String(decimals)}. Must be a non-negative integer.`, selector, chainId);
        }
        return {
            decimals,
            locator: normalizeLocator(locator)
        };
    }
    return {
        resolve (selector, chainId) {
            // Runtime validation of inputs - these checks are for JS consumers
            // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
            if (selector === null || selector === undefined) {
                throw createTokenResolutionError('Token selector cannot be null or undefined', selector, chainId);
            }
            if (chainId === '' || typeof chainId !== 'string') {
                throw createTokenResolutionError('Chain ID is required for token resolution', selector, chainId);
            }
            // Dispatch based on selector type
            if (isRawSelector(selector)) {
                return resolveRaw(selector, chainId);
            }
            if (typeof selector === 'string') {
                return resolveSymbol(selector, chainId);
            }
            throw createTokenResolutionError(`Invalid selector type: ${typeof selector}. Expected string or object with locator.`, selector, chainId);
        },
        resolveByAddress (address, chainId) {
            if (!address || typeof address !== 'string') {
                throw createTokenResolutionError('Token address is required for address resolution', {
                    locator: address
                }, chainId);
            }
            if (chainId === '' || typeof chainId !== 'string') {
                throw createTokenResolutionError('Chain ID is required for token resolution', {
                    locator: address
                }, chainId);
            }
            const definition = addressMap.get(buildAddressKey(chainId, address));
            if (definition === undefined) {
                throw createTokenResolutionError(`Unknown token address: ${address} for chain ${chainId}`, {
                    locator: address
                }, chainId);
            }
            const locator = definition.locators[chainId];
            if (locator === undefined || locator.trim() === '') {
                throw createTokenResolutionError(`Token ${definition.symbol} has no locator for chain ${chainId}`, definition.symbol, chainId);
            }
            const decimals = resolveTokenDecimals(definition, chainId);
            return {
                symbol: definition.symbol,
                decimals,
                locator: normalizeLocator(locator)
            };
        },
        get (symbol) {
            if (!symbol || typeof symbol !== 'string') {
                return undefined;
            }
            return tokenMap.get(normalizeSymbol(symbol));
        },
        has (symbol) {
            if (!symbol || typeof symbol !== 'string') {
                return false;
            }
            return tokenMap.has(normalizeSymbol(symbol));
        },
        symbols () {
            return Array.from(tokenMap.values()).map((def)=>def.symbol);
        },
        entries () {
            return Array.from(tokenMap.values());
        }
    };
}

/**
 * Define a schema for token registry interfaces.
 *
 * @remarks
 * Validate that a registry exposes the `resolve()` API used by adapters.
 *
 * @example
 * ```typescript
 * import { tokenRegistrySchema } from '@core/tokens'
 *
 * const registry = {
 *   resolve: () => ({ locator: '0x0', decimals: 6 }),
 * }
 *
 * tokenRegistrySchema.parse(registry)
 * ```
 */ zod.z.custom((value)=>{
    if (value === null || typeof value !== 'object') {
        return false;
    }
    const record = value;
    return typeof record['resolve'] === 'function' && typeof record['get'] === 'function' && typeof record['has'] === 'function' && typeof record['symbols'] === 'function' && typeof record['entries'] === 'function';
}, {
    message: 'Invalid token registry'
});

/**
 * Create a chain validation function bound to the adapter's capabilities.
 *
 * @param capabilities - The adapter capabilities containing supported chains.
 * @returns A function that throws `KitError` if the chain is not supported.
 *
 * @example
 * ```typescript
 * const validateChainSupport = createValidateChainSupport(capabilities)
 * validateChainSupport(Ethereum) // ok
 * validateChainSupport(Solana)   // throws KitError (INVALID_CHAIN)
 * ```
 */ function createValidateChainSupport(capabilities) {
    return function validateChainSupport(chain) {
        const supported = capabilities.supportedChains;
        const isSupported = supported.some((s)=>s.chain === chain.chain);
        if (!isSupported) {
            throw new KitError({
                ...InputError.INVALID_CHAIN,
                recoverability: 'FATAL',
                message: `Chain "${chain.name}" is not supported by this adapter. ` + `Supported chains: ${supported.map((c)=>c.name).join(', ')}.`
            });
        }
    };
}

/**
 * Default clock implementation.
 *
 * @packageDocumentation
 */ /**
 * Default clock implementation using `Date.now()`.
 *
 * @remarks
 * Use this in production code. For testing, inject a mock clock
 * that returns controlled timestamps.
 *
 * @example
 * ```typescript
 * import { defaultClock } from '@core/runtime'
 *
 * const start = defaultClock.now()
 * // ... do work ...
 * const elapsed = defaultClock.since(start)
 * ```
 */ const defaultClock = {
    now: ()=>Date.now(),
    since: (start)=>Date.now() - start
};

// ============================================================================
// Crypto Utilities (Internal)
// ============================================================================
/** @internal */ function hasGetRandomValues() {
    return typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function';
}
// ============================================================================
// ID Generators
// ============================================================================
/**
 * Create a unique ID with a custom prefix.
 *
 * @param prefix - ID type prefix (alphanumeric, hyphens, underscores only).
 * @returns ID in format `{prefix}-{timestamp36}-{random6}`.
 * @throws KitError if prefix is empty or contains invalid characters.
 *
 * @example
 * ```typescript
 * const opId = createId('op')   // "op-m5abc123-x7y2z1"
 * const txId = createId('tx')   // "tx-m5abc123-a8b3c2"
 * ```
 */ function createId(prefix) {
    if (!/^[\w-]+$/.test(prefix)) {
        throw createValidationFailedError('prefix', prefix, 'must be non-empty and contain only alphanumeric characters, hyphens, or underscores');
    }
    const timestamp = Date.now().toString(36);
    let random;
    if (hasGetRandomValues()) {
        const randomValues = new Uint32Array(1);
        crypto.getRandomValues(randomValues);
        // biome-ignore lint/style/noNonNullAssertion: Uint32Array(1) guarantees element at index 0
        random = randomValues[0].toString(36).padStart(6, '0').slice(0, 6);
    } else {
        // Math.random() fallback for environments without crypto
        random = Math.random().toString(36).slice(2, 8).padStart(6, '0') // NOSONAR:
        ;
    }
    return `${prefix}-${timestamp}-${random}`;
}
/**
 * Create a timestamped operation ID.
 *
 * @returns ID in format `op-{timestamp36}-{random6}`.
 *
 * @remarks
 * Convenience wrapper around {@link createId} with 'op' prefix.
 * Use when timestamp ordering is needed.
 *
 * @example
 * ```typescript
 * const opId = createOpId() // "op-m5abc123-x7y2z1"
 * ```
 */ function createOpId() {
    return createId('op');
}
/**
 * Create a W3C/OpenTelemetry-compatible trace ID.
 *
 * @returns 32-character lowercase hex string (128-bit).
 *
 * @remarks
 * **Standard function for generating `traceId` values.** Compatible with
 * OpenTelemetry, Jaeger, Zipkin, and AWS X-Ray.
 *
 * @example
 * ```typescript
 * const traceId = createTraceId() // "a1b2c3d4e5f6789012345678abcdef00"
 * ```
 */ function createTraceId() {
    const bytes = new Uint8Array(16);
    if (hasGetRandomValues()) {
        crypto.getRandomValues(bytes);
    } else {
        for(let i = 0; i < 16; i++){
            bytes[i] = Math.floor(Math.random() * 256) // NOSONAR:
            ;
        }
    }
    return Array.from(bytes, (b)=>b.toString(16).padStart(2, '0')).join('');
}

/**
 * Clean tags by removing keys with undefined values.
 *
 * @param tags - Tags object, may contain undefined values. Accepts `undefined` or `null`.
 * @returns A new object with undefined values removed, or empty object if input is nullish.
 *
 * @remarks
 * This helper ensures tags are safe for serialization and logging.
 * Similar to the internal `cleanUndefined` in the logger module, but
 * typed specifically for {@link Tags}.
 *
 * @example
 * ```typescript
 * import { cleanTags } from '@core/runtime'
 *
 * const tags = { chain: 'Ethereum', amount: 100, extra: undefined }
 * const cleaned = cleanTags(tags)
 * // { chain: 'Ethereum', amount: 100 }
 *
 * const empty = cleanTags(undefined)
 * // {}
 * ```
 */ function cleanTags(tags) {
    if (tags == null) return {};
    return Object.fromEntries(Object.entries(tags).filter(([, value])=>value !== undefined));
}

/**
 * Check if a pattern is valid.
 *
 * @remarks
 * Invalid patterns:
 * - Empty segments (e.g., `a..b`, `.a`, `a.`)
 * - `**` not at end (e.g., `a.**.b`)
 *
 * @param pattern - The pattern to validate.
 * @returns True if valid, false otherwise.
 */ function isValidPattern(pattern) {
    // Empty pattern is valid (matches empty topic)
    if (pattern === '') return true;
    const segments = pattern.split('.');
    // Check for empty segments
    if (segments.includes('')) return false;
    // Check that ** only appears at the end
    const doubleStarIndex = segments.indexOf('**');
    if (doubleStarIndex !== -1 && doubleStarIndex !== segments.length - 1) {
        return false;
    }
    return true;
}
/**
 * Convert a pattern to a regular expression.
 *
 * @param pattern - The pattern to convert.
 * @returns A RegExp that matches topics according to the pattern.
 */ function patternToRegex(pattern) {
    const segments = pattern.split('.');
    // Handle ** at end specially to match zero or more segments
    const lastSegment = segments.at(-1);
    if (lastSegment === '**') {
        // Everything before ** must match, then optionally more segments
        const prefix = segments.slice(0, -1).map((seg)=>{
            if (seg === '*') return '[^.]+';
            return seg.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);
        }).join(String.raw`\.`);
        // ** matches zero or more segments:
        // - If prefix is empty (**), match anything
        // - Otherwise, match prefix, then optionally (dot + more content)
        if (prefix === '') {
            return /^.*$/;
        }
        return new RegExp(String.raw`^${prefix}(?:\..*)?$`);
    }
    // No ** - just convert segments normally
    const escaped = segments.map((segment)=>{
        if (segment === '*') return '[^.]+';
        return segment.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);
    }).join(String.raw`\.`);
    return new RegExp(String.raw`^${escaped}$`);
}
/**
 * Execute an event handler with error isolation.
 *
 * @param handler - The handler function to execute.
 * @param event - The event to pass to the handler.
 * @param logger - Optional logger for error reporting.
 *
 * @remarks
 * - Synchronous errors are caught and logged
 * - Promise rejections are caught without awaiting
 * - Handler errors never propagate to caller
 */ function executeHandler(handler, event, logger) {
    try {
        const result = handler(event);
        // Handle promise rejection without awaiting
        if (result instanceof Promise) {
            result.catch((err)=>{
                logger?.error('Event handler promise rejected', {
                    event: event.name,
                    error: extractErrorInfo(err)
                });
            });
        }
    } catch (err) {
        // Isolate handler errors
        logger?.error('Event handler threw', {
            event: event.name,
            error: extractErrorInfo(err)
        });
    }
}
/**
 * Create an event bus.
 *
 * @param opts - Options for the event bus.
 * @returns An EventBus instance.
 *
 * @example
 * ```typescript
 * import { createEventBus } from '@core/runtime'
 *
 * const bus = createEventBus({ logger })
 *
 * // Subscribe to events
 * const unsubscribe = bus.on('tx.*', (event) => {
 *   console.log('Transaction event:', event.name)
 * })
 *
 * // Emit events
 * bus.emit({ name: 'tx.sent', data: { txHash: '0x123' } })
 *
 * // Unsubscribe
 * unsubscribe()
 * ```
 */ function createEventBus(opts) {
    const logger = opts?.logger;
    const subscriptions = new Set();
    function createBus(baseTags) {
        return {
            emit (event) {
                // Invalid topic names silently don't match any subscriptions
                if (!isValidPattern(event.name)) return;
                const mergedTags = Object.keys(baseTags).length > 0 || event.tags ? {
                    ...baseTags,
                    ...cleanTags(event.tags)
                } : undefined;
                const finalEvent = mergedTags === undefined ? event : {
                    ...event,
                    tags: mergedTags
                };
                // Notify all matching subscribers
                for (const sub of subscriptions){
                    // Match-all subscription
                    if (sub.pattern === null) {
                        executeHandler(sub.handler, finalEvent, logger);
                        continue;
                    }
                    // Patterned subscription: invalid pattern => regex=null => never match
                    if (sub.regex === null) continue;
                    if (!sub.regex.test(event.name)) continue;
                    executeHandler(sub.handler, finalEvent, logger);
                }
            },
            child (tags) {
                // Merge and clean tags, don't mutate parent
                const childTags = {
                    ...baseTags,
                    ...cleanTags(tags)
                };
                return createBus(childTags);
            },
            on (patternOrHandler, handler) {
                let sub;
                if (typeof patternOrHandler === 'function') {
                    // on(handler) - subscribe to all
                    sub = {
                        pattern: null,
                        handler: patternOrHandler,
                        regex: null
                    };
                } else {
                    // on(pattern, handler)
                    if (typeof handler !== 'function') {
                        throw new TypeError(`EventBus.on("${patternOrHandler}") expected a function handler`);
                    }
                    const regex = isValidPattern(patternOrHandler) ? patternToRegex(patternOrHandler) : null;
                    sub = {
                        pattern: patternOrHandler,
                        handler,
                        regex
                    };
                }
                subscriptions.add(sub);
                // Return unsubscribe function (idempotent)
                let unsubscribed = false;
                return ()=>{
                    if (!unsubscribed) {
                        subscriptions.delete(sub);
                        unsubscribed = true;
                    }
                };
            }
        };
    }
    return createBus({});
}

/**
 * No-op metrics implementation.
 *
 * @remarks
 * Provide a metrics implementation that silently discards all operations.
 * Useful for:
 * - Disabling metrics in certain environments
 * - Default fallback when no backend is configured
 * - Testing without metric side effects
 *
 * @see {@link noopMetrics} for the singleton instance.
 */ /** No-op counter that discards all increments. */ const noopCounter = {
    inc: ()=>{
    // Intentionally empty - discards increment
    }
};
/** No-op histogram that discards all observations. */ const noopHistogram = {
    observe: ()=>{
    // Intentionally empty - discards observation
    }
};
/** No-op timer that returns an empty stop function. */ const noopTimer = {
    start: ()=>()=>{
        // Intentionally empty - discards timing
        }
};
/**
 * Create a no-op metrics instance.
 *
 * @returns A Metrics instance that discards all operations.
 */ function createNoopMetrics() {
    // Self-referential instance - child() returns same object to avoid allocations
    const instance = {
        counter: ()=>noopCounter,
        histogram: ()=>noopHistogram,
        timer: ()=>noopTimer,
        child: ()=>instance
    };
    return instance;
}
/**
 * A no-op metrics implementation that discards all operations.
 *
 * @remarks
 * Use this when metrics collection is disabled or not configured.
 * All metric operations are safe to call and return immediately.
 * The `child()` method returns the same instance to avoid allocations.
 *
 * @example
 * ```typescript
 * import { noopMetrics } from '@core/runtime'
 *
 * // Use when metrics are disabled
 * const metrics = config.metricsEnabled
 *   ? createDatadogMetrics(config)
 *   : noopMetrics
 *
 * // All operations are safe to call
 * metrics.counter('requests').inc()
 * const stop = metrics.timer('query').start()
 * stop()
 * ```
 */ const noopMetrics = createNoopMetrics();

// Import global type declarations
/**
 * Check whether the current runtime is Node.js.
 *
 * @returns `true` when running in Node.js, `false` otherwise.
 *
 * @example
 * ```typescript
 * import { isNodeEnvironment } from '@core/utils'
 *
 * if (isNodeEnvironment()) {
 *   console.log('Running in Node.js')
 * }
 * ```
 */ const isNodeEnvironment = ()=>typeof process !== 'undefined' && typeof process.versions === 'object' && typeof process.versions.node === 'string';

/**
 * Parses and validates data against a Zod schema, returning the transformed result.
 *
 * Unlike `validate` and `validateOrThrow` which use type assertions (`asserts value is T`),
 * this function **returns the parsed data** from Zod. This is important when your schema
 * includes transformations like defaults, coercion, or custom transforms.
 *
 * @typeParam T - The expected output type (caller must specify).
 * @param value - The value to parse and validate.
 * @param schema - The Zod schema to validate against.
 * @param context - Context string to include in error messages (e.g., 'user input', 'config').
 * @returns The parsed and transformed data of type T.
 * @throws KitError with INPUT_VALIDATION_FAILED code (1098) if validation fails.
 *
 * @remarks
 * This function uses `ZodTypeAny` for the schema parameter to avoid TypeScript's
 * "excessively deep type instantiation" error in generic contexts. The caller
 * must provide the expected type `T` explicitly.
 *
 * Use this instead of `validate`/`validateOrThrow` when:
 * - Your schema has `.default()` values
 * - Your schema uses `.coerce` (e.g., `z.coerce.number()`)
 * - Your schema has `.transform()` functions
 * - You need the actual parsed output, not just type narrowing
 *
 * @example
 * ```typescript
 * import { parseOrThrow } from '@core/utils'
 * import { z } from 'zod'
 *
 * const userSchema = z.object({
 *   name: z.string().default('Anonymous'),
 *   age: z.coerce.number(),  // Transforms "25" → 25
 * })
 *
 * type User = z.infer<typeof userSchema>
 *
 * // Explicit type parameter
 * const user = parseOrThrow<User>({ age: '25' }, userSchema, 'user data')
 * console.log(user)  // { name: 'Anonymous', age: 25 }
 * ```
 *
 * @example
 * ```typescript
 * // Usage in generic adapter functions (no deep type instantiation)
 * function validateInput<TInput>(
 *   input: unknown,
 *   schema: z.ZodTypeAny,
 *   name: string,
 * ): TInput {
 *   return parseOrThrow<TInput>(input, schema, `${name} input`)
 * }
 * ```
 */ // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-parameters -- Intentional: T is caller-provided to avoid deep type instantiation from schema inference
function parseOrThrow(value, schema, context) {
    const result = schema.safeParse(value);
    if (!result.success) {
        throw createValidationErrorFromZod(result.error, context);
    }
    return result.data;
}

/**
 * Detect the format of the provided address string.
 *
 * Analyzes the address format and returns the corresponding chain type or bytes32
 * format. Supports EVM addresses (0x-prefixed 40-char hex), bytes32 addresses
 * (0x-prefixed 64-char hex), and Solana addresses (base58 encoded 32-byte keys).
 *
 * @param address - The address string to analyze.
 * @returns The detected format: 'evm', 'solana', or 'bytes32'.
 * @throws Error if the address format is unrecognized.
 *
 * @example
 * ```typescript
 * import { detectFormat } from '@core/utils'
 *
 * // EVM address
 * const evmFormat = detectFormat('0x1234567890abcdef1234567890abcdef12345678')
 * console.log(evmFormat) // 'evm'
 *
 * // Solana address
 * const solanaFormat = detectFormat('11111111111111111111111111111112')
 * console.log(solanaFormat) // 'solana'
 *
 * // Bytes32 address
 * const bytes32Format = detectFormat('0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(bytes32Format) // 'bytes32'
 * ```
 */ const detectFormat = (address)=>{
    if (/^0x[0-9a-fA-F]{40}$/.test(address)) {
        return 'evm';
    }
    if (/^0x[0-9a-fA-F]{64}$/.test(address)) {
        return 'bytes32';
    }
    const decoded = bs58__default.decode(address);
    if (decoded.length === 32) return 'solana';
    throw new Error(`Unsupported address format: ${address}`);
};
/**
 * Convert an EVM address or Solana base58 key into a 32-byte hex string.
 *
 * This function normalizes addresses from different blockchain formats into a
 * standardized 32-byte hex representation. EVM addresses are zero-padded to
 * 32 bytes, while Solana addresses are decoded from base58 format.
 *
 * @param address - The address string to convert.
 * @returns A 32-byte hex string (0x-prefixed).
 * @throws Error if the address format is unsupported.
 *
 * @example
 * ```typescript
 * import { toBytes32 } from '@core/utils'
 *
 * // Convert EVM address
 * const evmBytes32 = toBytes32('0x1234567890abcdef1234567890abcdef12345678')
 * console.log(evmBytes32) // '0x0000000000000000000000001234567890abcdef1234567890abcdef12345678'
 *
 * // Convert Solana address
 * const solanaBytes32 = toBytes32('11111111111111111111111111111112')
 * console.log(solanaBytes32) // '0x...' (32-byte hex representation)
 * ```
 */ const toBytes32 = (address)=>{
    const fmt = detectFormat(address);
    switch(fmt){
        case 'evm':
            // pad 20-byte address → 32 bytes
            return bytes.hexZeroPad(address, 32);
        case 'bytes32':
            return address;
        case 'solana':
            // base58 decode → raw 32 bytes → hex
            return bytes.hexlify(bs58__default.decode(address));
    }
    throw new Error(`Unsupported address format: ${address}`);
};
/**
 * Convert a bytes32 hex string to a checksummed EVM address.
 *
 * This function extracts the last 20 bytes from a 32-byte hex string and
 * converts it to a valid EVM address with EIP-55 checksum formatting.
 *
 * @param bytes32 - The 32-byte hex string (with or without 0x prefix).
 * @returns A checksummed EVM address (0x-prefixed).
 * @throws Error if the input is not a valid hex string.
 *
 * @example
 * ```typescript
 * import { bytes32ToEvm } from '@core/utils'
 *
 * // Convert bytes32 to EVM address
 * const evmAddress = bytes32ToEvm('0x0000000000000000000000001234567890abcdef1234567890abcdef12345678')
 * console.log(evmAddress) // '0x1234567890AbcdEF1234567890aBcdeF12345678' (checksummed)
 *
 * // Works without 0x prefix too
 * const evmAddress2 = bytes32ToEvm('0000000000000000000000001234567890abcdef1234567890abcdef12345678')
 * console.log(evmAddress2) // '0x1234567890AbcdEF1234567890aBcdeF12345678'
 * ```
 */ const bytes32ToEvm = (bytes32)=>{
    // remove 0x prefix
    const hex = bytes32.startsWith('0x') ? bytes32.slice(2) : bytes32;
    // take last 20 bytes (40 hex chars)
    const ethHex = '0x' + hex.slice(-40);
    // apply EIP-55 checksum
    return address.getAddress(ethHex);
};
/**
 * Convert a bytes32 hex string to a Solana base58 address.
 *
 * This function takes a 32-byte hex string and converts it to a Solana
 * public key address using base58 encoding.
 *
 * @param bytes32 - The 32-byte hex string (with or without 0x prefix).
 * @returns A Solana address in base58 format.
 * @throws Error if the input is not a valid hex string.
 *
 * @example
 * ```typescript
 * import { bytes32ToSolana } from '@core/utils'
 *
 * // Convert bytes32 to Solana address
 * const solanaAddress = bytes32ToSolana('0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(solanaAddress) // Base58 encoded address
 *
 * // Works without 0x prefix too
 * const solanaAddress2 = bytes32ToSolana('1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(solanaAddress2) // Base58 encoded address
 * ```
 */ function bytes32ToSolana(bytes32) {
    const hex = bytes32.startsWith('0x') ? bytes32.slice(2) : bytes32;
    const buffer = Buffer.from(hex, 'hex');
    return bs58__default.encode(new Uint8Array(buffer));
}
/**
 * Convert any supported address format into the target format.
 * @param address - input address (auto-detected)
 * @param targetFormat - one of 'evm', 'solana', or 'bytes32'
 * @returns converted address string
 */ const convertAddress = (address, targetFormat)=>{
    const current = detectFormat(address);
    if (current === targetFormat) return address;
    // first normalize to bytes32
    const asBytes32 = toBytes32(address);
    // then to target
    switch(targetFormat){
        case 'bytes32':
            return asBytes32;
        case 'evm':
            return bytes32ToEvm(asBytes32);
        case 'solana':
            return bytes32ToSolana(asBytes32);
    }
    throw new Error(`Unsupported address format: ${address}`);
};

/**
 * Assert that a value has type `never` (exhaustive switch helper).
 *
 * @remarks
 * Use in the `default` branch of a switch over a discriminated union.
 * If all union members are handled, the default is unreachable and TypeScript
 * narrows the parameter to `never`. If a member is missed, the compiler errors.
 *
 * @param _x - The value (typed as `never` when switch is exhaustive).
 * @returns Never returns; always throws.
 * @throws Error when the switch is not exhaustive.
 *
 * @example
 * ```typescript
 * type Foo = { type: 'a'; x: number } | { type: 'b'; y: string }
 *
 * function handle(foo: Foo): string {
 *   switch (foo.type) {
 *     case 'a': return String(foo.x)
 *     case 'b': return foo.y
 *     default: return assertNever(foo)
 *   }
 * }
 * ```
 */ function assertNever(x) {
    // Plain `String(x)` collapses non-primitive union members (objects, arrays)
    // to `'[object Object]'`, which is useless when triaging which discriminant
    // was missed. Attempt `JSON.stringify` first so the thrown message preserves
    // the offending shape. Fall back to a minimal `typeof`-based label if
    // serialization fails (`BigInt` member, circular references, host objects).
    //
    // `x` is statically typed as `never` (the whole point of this helper), but
    // at runtime callers may still pass an unexpected value when the switch is
    // not actually exhaustive — that's exactly the bug we want to surface. Cast
    // through `unknown` so the runtime defence is not stripped by the compiler.
    const value = x;
    let stringified;
    try {
        const json = JSON.stringify(value);
        stringified = typeof json === 'string' ? json : `<${typeof value}>`;
    } catch  {
        stringified = `<unstringifiable ${typeof value}>`;
    }
    throw new Error(`Unhandled switch case: ${stringified}`);
}

/**
 * Define a schema for runtime logger interfaces.
 *
 * @remarks
 * Validate that a runtime logger provides the minimal methods expected by the SDK.
 *
 * @example
 * ```typescript
 * import { loggerSchema } from '@core/runtime'
 *
 * const logger = {
 *   debug: () => undefined,
 *   info: () => undefined,
 *   warn: () => undefined,
 *   error: () => undefined,
 *   child: () => logger,
 * }
 *
 * loggerSchema.parse(logger)
 * ```
 */ const loggerSchema = zod.z.custom((value)=>{
    if (value === null || typeof value !== 'object') {
        return false;
    }
    const record = value;
    return typeof record['debug'] === 'function' && typeof record['info'] === 'function' && typeof record['warn'] === 'function' && typeof record['error'] === 'function' && typeof record['child'] === 'function';
}, {
    message: 'Invalid logger'
});

/**
 * Define a schema for runtime metrics interfaces.
 *
 * @remarks
 * Validate that a metrics implementation exposes the minimal API expected by the runtime.
 *
 * @example
 * ```typescript
 * import { metricsSchema } from '@core/runtime'
 *
 * const metrics = {
 *   counter: () => ({ inc: () => undefined }),
 *   histogram: () => ({ observe: () => undefined }),
 *   timer: () => ({ start: () => () => undefined }),
 *   child: () => metrics,
 * }
 *
 * metricsSchema.parse(metrics)
 * ```
 */ const metricsSchema = zod.z.custom((value)=>{
    if (value === null || typeof value !== 'object') {
        return false;
    }
    const record = value;
    return typeof record['counter'] === 'function' && typeof record['histogram'] === 'function' && typeof record['timer'] === 'function' && typeof record['child'] === 'function';
}, {
    message: 'Invalid metrics'
});

/**
 * Omit undefined values from an object.
 *
 * @param obj - The object to process.
 * @returns A new object with undefined values removed.
 *
 * @internal
 * @remarks
 * Used by both production and mock loggers to ensure consistent behavior.
 * This prevents undefined values from being serialized in log output,
 * which can cause issues with some log transports.
 */ function omitUndefined(obj) {
    const result = {};
    for (const [key, value] of Object.entries(obj)){
        if (value !== undefined) {
            result[key] = value;
        }
    }
    return result;
}

/**
 * Default redaction paths for web3/blockchain SDKs.
 *
 * @remarks
 * These paths target common sensitive fields in blockchain applications.
 * All user fields are nested under `context`, so paths start with `context.`.
 * Wildcard `*` matches any key at that level.
 */ const DEFAULT_REDACT_PATHS = [
    // Generic Credentials
    'context.password',
    'context.passphrase',
    'context.secret',
    'context.token',
    'context.*.password',
    'context.*.passphrase',
    'context.*.secret',
    'context.*.token',
    // API Keys & Auth Tokens
    'context.apiKey',
    'context.apiSecret',
    'context.accessToken',
    'context.refreshToken',
    'context.jwt',
    'context.bearerToken',
    'context.sessionId',
    'context.authorization',
    'context.cookie',
    'context.*.apiKey',
    'context.*.apiSecret',
    'context.*.accessToken',
    'context.*.refreshToken',
    'context.*.jwt',
    'context.*.bearerToken',
    'context.*.sessionId',
    'context.*.authorization',
    'context.*.cookie',
    // Web3 / Crypto Keys
    'context.privateKey',
    'context.secretKey',
    'context.signingKey',
    'context.encryptionKey',
    'context.*.privateKey',
    'context.*.secretKey',
    'context.*.signingKey',
    'context.*.encryptionKey',
    // Web3 / Crypto Mnemonics and Seeds
    'context.mnemonic',
    'context.seed',
    'context.seedPhrase',
    'context.*.mnemonic',
    'context.*.seed',
    'context.*.seedPhrase',
    // OTP / Verification Codes
    'context.otp',
    'context.verificationCode',
    'context.*.otp',
    'context.*.verificationCode',
    // Payment Information
    'context.cardNumber',
    'context.cvv',
    'context.accountNumber',
    'context.*.cardNumber',
    'context.*.cvv',
    'context.*.accountNumber'
];
/**
 * Wrap user fields under `context` to prevent collision with pino internals.
 *
 * @param fields - User-provided log fields.
 * @returns Object with fields nested under `context`, or undefined if empty.
 *
 * @remarks
 * This function handles edge cases by returning undefined for null, undefined,
 * or empty objects to avoid unnecessary wrapping in log output.
 * Undefined values are cleaned before wrapping.
 */ function wrapInContext(fields) {
    if (!fields) return undefined;
    // Clean undefined values for consistency and transport compatibility
    const cleaned = omitUndefined(fields);
    // Handle edge case: all values were undefined, resulting in empty object
    const keys = Object.keys(cleaned);
    if (keys.length === 0) return undefined;
    return {
        context: cleaned
    };
}
/**
 * Wrap a pino instance to conform to our Logger interface.
 *
 * @param pinoInstance - The pino logger instance to wrap.
 * @returns A Logger instance conforming to our stable interface.
 */ function wrapPino(pinoInstance) {
    return {
        debug (message, fields) {
            const wrapped = wrapInContext(fields);
            if (wrapped) {
                pinoInstance.debug(wrapped, message);
            } else {
                pinoInstance.debug(message);
            }
        },
        info (message, fields) {
            const wrapped = wrapInContext(fields);
            if (wrapped) {
                pinoInstance.info(wrapped, message);
            } else {
                pinoInstance.info(message);
            }
        },
        warn (message, fields) {
            const wrapped = wrapInContext(fields);
            if (wrapped) {
                pinoInstance.warn(wrapped, message);
            } else {
                pinoInstance.warn(message);
            }
        },
        error (message, fields) {
            const wrapped = wrapInContext(fields);
            if (wrapped) {
                pinoInstance.error(wrapped, message);
            } else {
                pinoInstance.error(message);
            }
        },
        child (tags) {
            // Child bindings stay flat (not wrapped) - they're part of logger's base context
            const cleaned = omitUndefined(tags);
            return wrapPino(pinoInstance.child(cleaned));
        }
    };
}
/**
 * Build pino redact configuration from our simplified options.
 *
 * @param redact - The redact configuration option.
 * @returns Pino-compatible redact configuration or undefined.
 */ function buildRedactConfig(redact) {
    // Explicitly disabled
    if (redact === false) {
        return undefined;
    }
    // Custom paths provided
    if (Array.isArray(redact)) {
        return redact.length > 0 ? {
            paths: redact,
            censor: '[REDACTED]'
        } : undefined;
    }
    // Default: use web3 sensible defaults
    return {
        paths: [
            ...DEFAULT_REDACT_PATHS
        ],
        censor: '[REDACTED]'
    };
}
/**
 * Create a logger backed by pino.
 *
 * @param options - Logger options (optional).
 * @param stream - Destination stream (optional).
 * @returns A Logger instance.
 * @throws Error if invalid pino options are provided.
 *
 * @remarks
 * This is a thin wrapper around pino that exposes our stable Logger interface.
 * Pino handles all transport concerns: JSON, pretty printing, file, remote, browser, etc.
 *
 * **Security**: By default, sensitive web3 fields (privateKey, mnemonic, apiKey, etc.)
 * are automatically redacted from log output. Use `redact: false` to disable.
 *
 * @example
 * ```typescript
 * import { createLogger } from '@core/runtime'
 *
 * // Default: web3 sensitive fields are redacted
 * const logger = createLogger({ level: 'info' })
 * logger.info('Signing', { privateKey: '0x123...' })
 * // Output: { context: { privateKey: '[REDACTED]' }, msg: 'Signing' }
 *
 * // Disable redaction (use with caution)
 * const unsafeLogger = createLogger({ level: 'debug', redact: false })
 *
 * // Custom redaction paths
 * const customLogger = createLogger({
 *   level: 'info',
 *   redact: ['context.mySecret', 'context.*.credentials']
 * })
 *
 * // Pretty output for development
 * const devLogger = createLogger({
 *   level: 'debug',
 *   transport: { target: 'pino-pretty' }
 * })
 *
 * // Browser logger
 * const browserLogger = createLogger({
 *   browser: { asObject: true }
 * })
 * ```
 */ function createLogger(options, stream) {
    const { redact, ...pinoOptions } = {};
    // Build redaction config
    const redactConfig = buildRedactConfig(redact);
    // Build final pino options, only include redact if defined
    const finalOptions = redactConfig ? {
        ...pinoOptions,
        redact: redactConfig
    } : pinoOptions;
    const pinoInstance = pino__default(finalOptions);
    return wrapPino(pinoInstance);
}

// ============================================================================
// Validation Schema
// ============================================================================
/**
 * Schema for validating {@link RuntimeOptions}.
 *
 * @remarks
 * Used internally by {@link createRuntime} to validate options from JS consumers.
 * Exported for advanced use cases where manual validation is needed.
 */ const runtimeOptionsSchema = zod.z.object({
    logger: loggerSchema.optional(),
    metrics: metricsSchema.optional()
}).passthrough();
// ============================================================================
// Factory
// ============================================================================
/**
 * Create a complete Runtime with sensible defaults.
 *
 * @param options - Optional configuration to override logger and metrics.
 * @returns A frozen, immutable Runtime with all services guaranteed present.
 * @throws KitError (INPUT_VALIDATION_FAILED) if options contain invalid services.
 *
 * @remarks
 * Creates a fully-configured runtime by merging provided options with defaults.
 * The returned runtime is frozen to enforce immutability.
 *
 * | Service | Default | Configurable |
 * |---------|---------|--------------|
 * | `logger` | pino logger (info level) | Yes |
 * | `metrics` | No-op metrics | Yes |
 * | `events` | Internal event bus | No |
 * | `clock` | `Date.now()` | No |
 *
 * **Why only logger and metrics?**
 *
 * - **Logger/Metrics**: Integration points with your infrastructure
 * - **Events**: Internal pub/sub mechanism - subscribe via `runtime.events.on()`
 * - **Clock**: Testing concern - use mock factories for tests
 *
 * @example
 * ```typescript
 * import { createRuntime, createLogger } from '@core/runtime'
 *
 * // Use all defaults
 * const runtime = createRuntime()
 *
 * // Custom logger
 * const runtime = createRuntime({
 *   logger: createLogger({ level: 'debug' }),
 * })
 *
 * // Custom metrics (e.g., Prometheus)
 * const runtime = createRuntime({
 *   metrics: myPrometheusMetrics,
 * })
 *
 * // Subscribe to events (don't replace the bus)
 * runtime.events.on('operation.*', (event) => {
 *   console.log('Event:', event.name)
 * })
 * ```
 */ function createRuntime(options) {
    // Validate options for JS consumers
    if (options != null) {
        parseOrThrow(options, runtimeOptionsSchema, 'runtime options');
    }
    // Resolve logger first (events may need it)
    const logger = options?.logger ?? createLogger();
    // Internal services - not configurable
    const events = createEventBus({
        logger
    });
    const clock = defaultClock;
    // Resolve metrics
    const metrics = options?.metrics ?? noopMetrics;
    return Object.freeze({
        logger,
        events,
        metrics,
        clock
    });
}

/**
 * Lifecycle event types and constants for pipeline phase tracking.
 *
 * @packageDocumentation
 */ /**
 * Event names for lifecycle events.
 *
 * @remarks
 * These constants provide a single source of truth for lifecycle event names,
 * used both by the middleware that emits them and consumers who subscribe.
 *
 * @example
 * ```typescript
 * import { LIFECYCLE_EVENTS, createEventBus } from '@core/runtime'
 *
 * const bus = createEventBus()
 * bus.on(LIFECYCLE_EVENTS.STARTED, handler)
 * ```
 */ const LIFECYCLE_EVENTS = {
    /** Emitted when a phase begins execution. */ STARTED: 'op.phase.started',
    /** Emitted when a phase completes successfully. */ SUCCEEDED: 'op.phase.succeeded',
    /** Emitted when a phase fails with an error. */ FAILED: 'op.phase.failed'
};

/**
 * Type-safe wrapper for the untyped EventBus.
 *
 * @remarks
 * This module provides compile-time type safety for event emission
 * and subscription while maintaining zero runtime overhead.
 */ /**
 * Wrap an untyped EventBus with type-safe interface.
 *
 * @typeParam M - The event map defining available events and their payloads.
 * @param bus - The untyped event bus to wrap.
 * @returns A type-safe event bus wrapper.
 *
 * @remarks
 * This is a zero-overhead wrapper that only adds compile-time type checking.
 * All calls are forwarded directly to the underlying bus.
 *
 * @example
 * ```typescript
 * interface MyEvents {
 *   'tx.started': { txId: string }
 *   'tx.completed': { txId: string; hash: string }
 *   'tx.failed': { txId: string; error: string }
 * }
 *
 * const bus = createEventBus({ logger })
 * const typedBus = asTypedEvents<MyEvents>(bus)
 *
 * // Emit with type safety
 * typedBus.emit({
 *   name: 'tx.started',
 *   data: { txId: 'abc-123' }
 * })
 *
 * // Subscribe with pattern matching
 * typedBus.on('tx.*', (event) => {
 *   switch (event.name) {
 *     case 'tx.started':
 *       console.log('Started:', event.data.txId)
 *       break
 *     case 'tx.completed':
 *       console.log('Completed:', event.data.hash)
 *       break
 *     case 'tx.failed':
 *       console.log('Failed:', event.data.error)
 *       break
 *   }
 * })
 * ```
 */ function asTypedEvents(bus) {
    return {
        emit (event) {
            bus.emit(event);
        },
        on (patternOrHandler, handler) {
            if (typeof patternOrHandler === 'function') {
                // on(handler) - subscribe to all
                return bus.on(patternOrHandler);
            }
            // on(pattern, handler)
            return bus.on(patternOrHandler, handler);
        },
        child (tags) {
            return asTypedEvents(bus.child(tags));
        }
    };
}

// ============================================================================
// Validation Schemas
// ============================================================================
/**
 * Schema for validating Caller.
 */ const callerSchema = zod.z.object({
    type: zod.z.string(),
    name: zod.z.string(),
    version: zod.z.string().optional()
});
/**
 * Schema for validating InvocationMeta input.
 */ const invocationMetaSchema = zod.z.object({
    traceId: zod.z.string().optional(),
    runtime: zod.z.object({}).passthrough().optional(),
    tokens: zod.z.object({}).passthrough().optional(),
    callers: zod.z.array(callerSchema).optional(),
    signal: zod.z.instanceof(AbortSignal).optional()
}).strict();
// ============================================================================
// Invocation Context Resolution
// ============================================================================
/**
 * Resolve invocation metadata to invocation context.
 *
 * @param meta - User-provided invocation metadata (**WHO/HOW**), optional.
 * @param defaults - Default runtime and tokens to use if not overridden.
 * @returns Frozen, immutable invocation context with guaranteed values.
 * @throws KitError when meta contains invalid properties.
 *
 * @remarks
 * Resolves the **WHO** called and **HOW** to observe:
 * - TraceId: Uses provided value or generates new one
 * - Runtime: Uses meta.runtime if provided, otherwise defaults.runtime
 * - Tokens: Uses meta.tokens if provided, otherwise defaults.tokens
 * - Callers: Uses provided array or empty array
 *
 * The returned context is frozen to enforce immutability.
 *
 * @example
 * ```typescript
 * import { resolveInvocationContext, createRuntime } from '@core/runtime'
 * import { createTokenRegistry } from '@core/tokens'
 *
 * const defaults = {
 *   runtime: createRuntime(),
 *   tokens: createTokenRegistry(),
 * }
 *
 * // Minimal - just using defaults
 * const ctx = resolveInvocationContext(undefined, defaults)
 *
 * // With trace ID and caller info
 * const ctx = resolveInvocationContext(
 *   {
 *     traceId: 'abc-123',
 *     callers: [{ type: 'kit', name: 'BridgeKit', version: '1.0.0' }],
 *   },
 *   defaults
 * )
 *
 * // With runtime override (complete replacement)
 * const ctx = resolveInvocationContext(
 *   { runtime: createRuntime({ logger: myLogger }) },
 *   defaults
 * )
 * ```
 */ function resolveInvocationContext(meta, defaults) {
    // Validate meta input if provided
    if (meta !== undefined) {
        const result = invocationMetaSchema.safeParse(meta);
        if (!result.success) {
            throw createValidationFailedError('invocationMeta', meta, result.error.errors.map((e)=>e.message).join(', '));
        }
    }
    // Generate trace ID if not provided
    const traceId = meta?.traceId ?? createTraceId();
    // Use meta overrides or fall back to defaults
    const runtime = meta?.runtime ?? defaults.runtime;
    const tokens = meta?.tokens ?? defaults.tokens;
    const callers = meta?.callers ?? [];
    // Omit `signal` entirely when absent so `exactOptionalPropertyTypes`
    // stays satisfied — the key is missing rather than set to `undefined`.
    return Object.freeze({
        traceId,
        runtime,
        tokens,
        callers,
        ...meta?.signal === undefined ? {} : {
            signal: meta.signal
        }
    });
}

/**
 * Create an execution context for middleware.
 *
 * @param options - Options containing name, invocation context, and optional tags/meta.
 * @returns Frozen, immutable execution context for middleware.
 *
 * @remarks
 * Creates the observability surface for middleware by combining:
 * - A unique `opId` for this specific operation invocation
 * - The operation/phase `name`
 * - `traceId` and `runtime` from the resolved invocation context
 * - Optional `tags` and `meta`
 *
 * The returned context is frozen to enforce immutability.
 *
 * @example
 * ```typescript
 * import { resolveInvocationContext, createExecutionContext, createRuntime } from '@core/runtime'
 * import { createTokenRegistry } from '@core/tokens'
 *
 * const defaults = { runtime: createRuntime(), tokens: createTokenRegistry() }
 * const invCtx = resolveInvocationContext(meta, defaults)
 *
 * const execCtx = createExecutionContext({
 *   name: 'transfer',
 *   invocation: invCtx,
 *   tags: { chain: 'Ethereum' },
 * })
 *
 * // Use with runOperation or pipeline
 * await runOperation(execCtx, middleware, async () => { ... })
 * ```
 */ function createExecutionContext(options) {
    const { name, description, invocation, tags, meta } = options;
    return Object.freeze({
        opId: createOpId(),
        name,
        ...description === undefined ? {} : {
            description
        },
        traceId: invocation.traceId,
        runtime: invocation.runtime,
        ...tags === undefined ? {} : {
            tags
        },
        ...meta === undefined ? {} : {
            meta
        }
    });
}

/**
 * Unified middleware factory and detection utilities.
 *
 * @remarks
 * Unified middleware works with both single operations (`runOperation`) and
 * multi-phase pipelines (`createPipeline`). This module provides the factory
 * function and type guard for working with unified middleware.
 *
 * @packageDocumentation
 */ // ============================================================================
// Unified Middleware Symbol
// ============================================================================
/**
 * Symbol to identify unified middleware.
 * @internal
 */ const UNIFIED_MIDDLEWARE = Symbol.for('@core/runtime/unified-middleware');
// ============================================================================
// Type Guard
// ============================================================================
/**
 * Check if a value is a unified middleware.
 *
 * @param value - The value to check.
 * @returns True if the value is a {@link UnifiedMiddleware}.
 *
 * @example
 * ```typescript
 * const mw = createUnifiedMiddleware(async ({ next, state }) => next(state))
 *
 * if (isUnifiedMiddleware(mw)) {
 *   // mw is UnifiedMiddleware<unknown>
 * }
 * ```
 */ function isUnifiedMiddleware(value) {
    return typeof value === 'object' && value !== null && UNIFIED_MIDDLEWARE in value && value[UNIFIED_MIDDLEWARE] === true;
}
// ============================================================================
// Factory
// ============================================================================
/**
 * Create a unified middleware that works with both operations and pipelines.
 *
 * @typeParam T - The return type for operations / state type for pipelines.
 * @param middleware - The middleware implementation using the unified context.
 * @returns A branded {@link UnifiedMiddleware} that both systems recognize.
 *
 * @remarks
 * This is the recommended way to write middleware that should work everywhere.
 * The unified middleware receives a {@link MiddlewareContext} with:
 *
 * - `ctx` - Full execution context with runtime services
 * - `name` - Operation name or phase name
 * - `state` - Current state (for pipelines) or `never` (for operations)
 * - `next` - Continuation function
 *
 * **For operations**: `state` is typed as `never`, call `next()` without args
 * **For pipelines**: `state` is the actual state, call `next(state)`
 *
 * Because `never` is assignable to any type, you can always write `next(state)`
 * and it will work in both contexts.
 *
 * @example
 * ```typescript
 * import { createUnifiedMiddleware } from '@core/runtime'
 *
 * // Single factory - works everywhere
 * const timingMw = createUnifiedMiddleware(async ({ ctx, name, next, state }) => {
 *   const start = ctx.runtime.clock.now()
 *   const result = await next(state) // Works for both!
 *   ctx.runtime.logger.debug(`${name}: ${ctx.runtime.clock.now() - start}ms`)
 *   return result
 * })
 *
 * // Use in operations
 * await runOperation(ctx, timingMw, async () => 'result')
 *
 * // Use in pipelines
 * pipeline.useAll(timingMw)
 * ```
 *
 * @example
 * ```typescript
 * import { extractErrorInfo } from '@core/errors'
 *
 * // Error handling middleware
 * const errorMw = createUnifiedMiddleware(async ({ ctx, name, next, state }) => {
 *   try {
 *     return await next(state)
 *   } catch (err) {
 *     ctx.runtime.logger.error(`${name} failed`, { error: extractErrorInfo(err) })
 *     throw err
 *   }
 * })
 * ```
 */ function createUnifiedMiddleware(middleware) {
    return {
        middleware,
        [UNIFIED_MIDDLEWARE]: true
    };
}

// ============================================================================
// Middleware Factory
// ============================================================================
/**
 * Create a unified error normalization middleware that works with both operations and pipelines.
 *
 * @typeParam T - The return/state type.
 * @param options - Configuration options.
 * @returns A unified middleware that normalizes errors to KitError.
 *
 * @remarks
 * This is the **recommended** way to add error normalization. The returned
 * middleware works with both `runOperation` and `createPipeline`, so you only
 * need one factory.
 *
 * @example
 * ```typescript
 * import { createErrorMiddleware, runOperation, createPipeline } from '@core/runtime'
 *
 * // Single factory - works everywhere!
 * const errorMw = createErrorMiddleware({
 *   createNormalizer: (ctx) => viemErrorNormalizer,
 * })
 *
 * // Use in operations
 * await runOperation(ctx, errorMw, async () => result)
 *
 * // Use in pipelines
 * pipeline.useAll(errorMw)
 * ```
 */ function createErrorMiddleware(options = {}) {
    return createUnifiedMiddleware(async ({ ctx, name, next, state })=>{
        try {
            return await next(state);
        } catch (err) {
            // Already a KitError - re-throw as-is
            if (isKitError(err)) {
                throw err;
            }
            // Try adapter normalizer if provided
            // Normalizers either throw KitError (handled) or return void (not handled)
            const normalizer = options.createNormalizer?.(ctx);
            // Forward `tags` as well as `meta`: the canonical `chain` dimension
            // lives in `ctx.tags` (via `buildOperationTags`), while `ctx.meta`
            // is the per-call overlay and is usually empty. Without this, every
            // normalized fallback/Zod error would report the adapter's default
            // chain instead of the real one.
            normalizer?.(err, {
                name,
                tags: ctx.tags,
                meta: ctx.meta
            });
            // If we reach here, no normalizer handled - wrap in unknown error
            ctx.runtime.logger.warn('Wrapping unhandled error as UNKNOWN', {
                tags: {
                    traceId: ctx.traceId,
                    name
                },
                error: extractErrorInfo(err)
            });
            throw createUnknownError({
                message: 'An unexpected error occurred',
                cause: err
            });
        }
    });
}

// ============================================================================
// Middleware Factory
// ============================================================================
/**
 * Create lifecycle middleware for observability.
 *
 * @returns Unified middleware that emits lifecycle events, logs, and metrics.
 *
 * @remarks
 * Works with both `runOperation` and `createPipeline`.
 *
 * **Logs emitted:**
 * - debug: `{name} started`
 * - debug: `{name} succeeded` (with durationMs)
 * - error: `{name} failed` (with durationMs and error)
 *
 * **Events emitted:** `op.phase.started`, `op.phase.succeeded`, `op.phase.failed`
 *
 * **Metrics emitted:**
 * - `operation.succeeded` / `operation.failed` (counter)
 * - `operation.duration` (histogram)
 *
 * @example
 * ```typescript
 * const lifecycle = createLifecycleMiddleware()
 *
 * // Use with operations
 * await runOperation(ctx, lifecycle, async () => result)
 *
 * // Use with pipelines
 * pipeline.useAll(lifecycle)
 * ```
 */ function createLifecycleMiddleware() {
    return createUnifiedMiddleware(async ({ ctx, name, next, state })=>{
        const { runtime } = ctx;
        const phase = name === ctx.name ? undefined : name;
        // Tags for events (includes traceId for correlation)
        const tags = cleanTags({
            traceId: ctx.traceId,
            name: ctx.name,
            ...ctx.description !== undefined && {
                description: ctx.description
            },
            ...phase !== undefined && {
                phase
            },
            ...ctx.tags
        });
        // Tags for metrics (no traceId/address — would cause cardinality explosion)
        // Cherry-pick bounded dimensions only: chain (~20 values) and chainId (same cardinality)
        const ctxTags = ctx.tags;
        const metricTags = cleanTags({
            name: ctx.name,
            ...phase !== undefined && {
                phase
            },
            chain: ctxTags?.['chain'],
            chainId: ctxTags?.['chainId']
        });
        // Start
        runtime.logger.debug(`${name} started`, {
            tags
        });
        runtime.events.emit({
            name: LIFECYCLE_EVENTS.STARTED,
            level: 'debug',
            at: runtime.clock.now(),
            tags,
            data: {
                status: 'started',
                meta: ctx.meta
            }
        });
        const startTime = runtime.clock.now();
        try {
            const result = await next(state);
            const durationMs = runtime.clock.since(startTime);
            // Success
            runtime.logger.debug(`${name} succeeded`, {
                tags,
                durationMs
            });
            runtime.events.emit({
                name: LIFECYCLE_EVENTS.SUCCEEDED,
                level: 'debug',
                at: runtime.clock.now(),
                tags,
                data: {
                    status: 'succeeded',
                    meta: ctx.meta,
                    durationMs
                }
            });
            runtime.metrics.counter('operation.succeeded').inc(metricTags);
            runtime.metrics.histogram('operation.duration').observe({
                ...metricTags,
                status: 'success'
            }, durationMs);
            return result;
        } catch (err) {
            const durationMs = runtime.clock.since(startTime);
            // Failure
            runtime.logger.error(`${name} failed`, {
                tags,
                durationMs,
                error: extractErrorInfo(err)
            });
            runtime.events.emit({
                name: LIFECYCLE_EVENTS.FAILED,
                level: 'error',
                at: runtime.clock.now(),
                tags,
                data: {
                    status: 'failed',
                    meta: ctx.meta,
                    durationMs,
                    error: extractErrorInfo(err)
                }
            });
            runtime.metrics.counter('operation.failed').inc(metricTags);
            runtime.metrics.histogram('operation.duration').observe({
                ...metricTags,
                status: 'failed'
            }, durationMs);
            throw err;
        }
    });
}

// ============================================================================
// Constants
// ============================================================================
/** Default retry configuration. */ const DEFAULTS = {
    maxAttempts: 3,
    baseDelayMs: 200,
    maxDelayMs: 10_000,
    backoff: 'exponential',
    jitter: true,
    isRetryable: isRetryableError
};
/** Event names for retry observability. */ const RETRY_EVENTS = {
    /** Emitted when a retry attempt starts. */ ATTEMPT: 'retry.attempt',
    /** Emitted when all retries are exhausted. */ EXHAUSTED: 'retry.exhausted',
    /** Emitted when an operation succeeds after retries. */ RECOVERED: 'retry.recovered'
};
/** Metric names for retry observability. */ const RETRY_METRICS = {
    /** Counter: Number of retry attempts. */ ATTEMPTS: 'retry.attempts',
    /** Counter: Operations that recovered after retries. */ RECOVERED: 'retry.recovered',
    /** Counter: Operations that failed after exhausting retries. */ EXHAUSTED: 'retry.exhausted',
    /** Histogram: Total retry duration in milliseconds. */ DURATION: 'retry.duration'
};
// ============================================================================
// Utilities
// ============================================================================
/**
 * Resolve partial retry options into complete options with defaults.
 *
 * @param options - Optional partial retry configuration.
 * @returns Complete retry options with all defaults applied.
 */ function resolveOptions(options) {
    if (options === undefined) {
        return DEFAULTS;
    }
    return {
        maxAttempts: options.maxAttempts ?? DEFAULTS.maxAttempts,
        baseDelayMs: options.baseDelayMs ?? DEFAULTS.baseDelayMs,
        maxDelayMs: options.maxDelayMs ?? DEFAULTS.maxDelayMs,
        backoff: options.backoff ?? DEFAULTS.backoff,
        jitter: options.jitter ?? DEFAULTS.jitter,
        isRetryable: options.isRetryable ?? DEFAULTS.isRetryable
    };
}
/**
 * Emit observability events when an operation recovers after retries.
 *
 * @param params - Shared observability parameters.
 * @param attempt - The attempt number that succeeded (1 = first retry).
 *
 * @remarks
 * Emits:
 * - Info log with recovery message and duration
 * - `retry.recovered` event
 * - `retry.recovered` counter metric
 * - `retry.duration` histogram with 'recovered' outcome
 */ function emitRecoveryEvents(params, attempt) {
    const { ctx, runtime, metricTags, startTime } = params;
    const { logger, events, metrics, clock } = runtime;
    const ctxTags = ctx.tags ?? {};
    const durationMs = clock.since(startTime);
    logger.info(`${ctx.name} recovered after ${String(attempt)} ${attempt === 1 ? 'retry' : 'retries'}`, {
        tags: {
            traceId: ctx.traceId,
            ...ctxTags
        },
        durationMs
    });
    events.emit({
        name: RETRY_EVENTS.RECOVERED,
        level: 'info',
        at: clock.now(),
        tags: cleanTags({
            traceId: ctx.traceId,
            name: ctx.name,
            ...ctxTags,
            attempt,
            durationMs
        })
    });
    metrics.counter(RETRY_METRICS.RECOVERED).inc(metricTags);
    metrics.histogram(RETRY_METRICS.DURATION).observe({
        ...metricTags,
        outcome: 'recovered'
    }, durationMs);
}
/**
 * Emit observability events when all retry attempts are exhausted.
 *
 * @param params - Shared observability parameters.
 * @param attempt - The final attempt number that failed.
 * @param error - The error that caused the final failure.
 *
 * @remarks
 * Emits:
 * - Warn log with exhaustion message and sanitized error
 * - `retry.exhausted` event with sanitized error data
 * - `retry.exhausted` counter metric
 * - `retry.duration` histogram with 'exhausted' outcome
 */ function emitExhaustedEvents(params, attempt, error) {
    const { ctx, runtime, metricTags, startTime } = params;
    const { logger, events, metrics, clock } = runtime;
    const ctxTags = ctx.tags ?? {};
    const durationMs = clock.since(startTime);
    logger.warn(`${ctx.name} failed after exhausting ${String(attempt)} ${attempt === 1 ? 'retry' : 'retries'}`, {
        tags: {
            traceId: ctx.traceId,
            ...ctxTags
        },
        durationMs,
        error: extractErrorInfo(error)
    });
    events.emit({
        name: RETRY_EVENTS.EXHAUSTED,
        level: 'warn',
        at: clock.now(),
        tags: cleanTags({
            traceId: ctx.traceId,
            name: ctx.name,
            ...ctxTags,
            totalAttempts: attempt + 1,
            durationMs
        }),
        data: {
            error: extractErrorInfo(error)
        }
    });
    metrics.counter(RETRY_METRICS.EXHAUSTED).inc(metricTags);
    metrics.histogram(RETRY_METRICS.DURATION).observe({
        ...metricTags,
        outcome: 'exhausted'
    }, durationMs);
}
/**
 * Emit observability events before a retry attempt.
 *
 * @param params - Shared observability parameters.
 * @param nextAttempt - The upcoming attempt number.
 * @param maxAttempts - Maximum configured retry attempts.
 * @param delayMs - Delay in milliseconds before the retry.
 * @param error - The error that triggered the retry.
 *
 * @remarks
 * Emits:
 * - Debug log with retry details and sanitized error
 * - `retry.attempt` event with sanitized error data
 * - `retry.attempts` counter metric
 */ function emitRetryAttemptEvents(params, nextAttempt, maxAttempts, delayMs, error) {
    const { ctx, runtime, metricTags } = params;
    const { logger, events, metrics, clock } = runtime;
    const ctxTags = ctx.tags ?? {};
    logger.debug(`Retrying ${ctx.name} (attempt ${String(nextAttempt)}/${String(maxAttempts)}) in ${String(delayMs)}ms`, {
        tags: {
            traceId: ctx.traceId,
            ...ctxTags
        },
        error: extractErrorInfo(error)
    });
    events.emit({
        name: RETRY_EVENTS.ATTEMPT,
        level: 'debug',
        at: clock.now(),
        tags: cleanTags({
            traceId: ctx.traceId,
            name: ctx.name,
            ...ctxTags,
            attempt: nextAttempt,
            maxAttempts,
            delayMs
        }),
        data: {
            error: extractErrorInfo(error)
        }
    });
    metrics.counter(RETRY_METRICS.ATTEMPTS).inc(metricTags);
}
// ============================================================================
// Delay Calculation
// ============================================================================
/**
 * Calculate the delay before the next retry attempt.
 *
 * @param attempt - The retry attempt number (1-indexed).
 * @param config - Resolved retry configuration.
 * @returns Delay in milliseconds before the next attempt.
 *
 * @remarks
 * Delay calculation by backoff strategy:
 * - `constant`: Always returns `baseDelayMs`
 * - `linear`: Returns `baseDelayMs * attempt`
 * - `exponential`: Returns `baseDelayMs * 2^(attempt-1)`
 *
 * The result is capped at `maxDelayMs` and optionally jittered by ±25%.
 */ function calculateDelay(attempt, config) {
    const { baseDelayMs, maxDelayMs, backoff, jitter } = config;
    let delay;
    switch(backoff){
        case 'constant':
            delay = baseDelayMs;
            break;
        case 'linear':
            delay = baseDelayMs * attempt;
            break;
        case 'exponential':
            delay = baseDelayMs * Math.pow(2, attempt - 1);
            break;
    }
    // Cap at max delay
    delay = Math.min(delay, maxDelayMs);
    // Add jitter if enabled (±25% randomness)
    if (jitter) {
        const jitterFactor = 0.75 + Math.random() * 0.5 // NOSONAR - not security-sensitive
        ;
        delay = Math.round(delay * jitterFactor);
    }
    return delay;
}
// ============================================================================
// Middleware Factory
// ============================================================================
/**
 * Create retry middleware for automatic operation retries.
 *
 * @param options - Retry configuration options.
 * @returns Unified middleware that retries failed operations.
 *
 * @remarks
 * Works with both `runOperation` and `createPipeline`.
 *
 * **Logs emitted:**
 * - debug: `Retrying {name} (attempt X/Y) in Zms`
 * - info: `{name} recovered after X retries`
 * - warn: `{name} failed after exhausting X retries`
 *
 * **Events emitted:**
 * - `retry.attempt` - When a retry is about to be attempted
 * - `retry.recovered` - When an operation succeeds after retries
 * - `retry.exhausted` - When all retries are exhausted
 *
 * **Metrics emitted:**
 * - `retry.attempts` (counter) - Number of retry attempts
 * - `retry.recovered` (counter) - Successful recoveries
 * - `retry.exhausted` (counter) - Exhausted retries
 * - `retry.duration` (histogram) - Total retry duration
 *
 * @example
 * ```typescript
 * import { createRetryMiddleware, runOperation } from '@core/runtime'
 *
 * const retry = createRetryMiddleware({
 *   maxAttempts: 3,
 *   baseDelayMs: 200,
 *   backoff: 'exponential',
 * })
 *
 * // Use with operations
 * await runOperation(ctx, retry, async () => {
 *   return await fetchData()
 * })
 *
 * // Use with pipelines
 * pipeline.useAll(retry)
 * ```
 *
 * @example
 * ```typescript
 * // Custom retry logic
 * const retry = createRetryMiddleware({
 *   maxAttempts: 5,
 *   isRetryable: (error) => {
 *     // Only retry rate limit errors
 *     return error instanceof RateLimitError
 *   },
 * })
 * ```
 */ function createRetryMiddleware(options) {
    const config = resolveOptions(options);
    return createUnifiedMiddleware(async ({ ctx, next, state })=>{
        const { runtime, tags: ctxTags = {} } = ctx;
        const startTime = runtime.clock.now();
        let lastError;
        // Shared params for observability helpers
        const obsParams = {
            ctx,
            runtime,
            metricTags: cleanTags({
                name: ctx.name,
                ...ctxTags
            }),
            startTime
        };
        // Initial attempt + retries
        for(let attempt = 0; attempt <= config.maxAttempts; attempt++){
            try {
                const result = await next(state);
                // Emit recovery events if this wasn't the first attempt
                if (attempt > 0) {
                    emitRecoveryEvents(obsParams, attempt);
                }
                return result;
            } catch (error) {
                lastError = error;
                // Check if we should retry
                const canRetry = attempt < config.maxAttempts && config.isRetryable(error);
                if (!canRetry) {
                    // Emit exhausted events if we had retried at least once
                    if (attempt > 0) {
                        emitExhaustedEvents(obsParams, attempt, error);
                    }
                    throw error;
                }
                // Calculate delay and emit retry attempt events
                const nextAttempt = attempt + 1;
                const delayMs = calculateDelay(nextAttempt, config);
                emitRetryAttemptEvents(obsParams, nextAttempt, config.maxAttempts, delayMs, error);
                // Wait before retrying
                await new Promise((resolve)=>setTimeout(resolve, delayMs));
            }
        }
        /* v8 ignore next -- unreachable safety throw for TypeScript */ throw lastError;
    });
}

// ============================================================================
// Factory
// ============================================================================
/**
 * Create a configured middleware stack for operation instrumentation.
 *
 * @typeParam T - The return type of the operation.
 * @param options - Configuration options for the middleware stack.
 * @returns Array of middleware in the correct execution order.
 *
 * @remarks
 * The middleware stack is ordered from outermost to innermost:
 *
 * 1. **Lifecycle** - Captures total duration including retries, emits events
 * 2. **Retry** - Retries on retryable errors (enabled by default, disable with `retry: false`)
 * 3. **Error normalization** - Converts raw errors to KitError
 *
 * This ordering ensures:
 * - Lifecycle captures the full operation time including all retries
 * - Error normalization is innermost so errors are normalized before retry checks
 * - Retry receives normalized KitError instances (isRetryableError works correctly)
 *
 * @example
 * ```typescript
 * import { createMiddlewareStack, runOperation } from '@core/runtime'
 *
 * const middleware = createMiddlewareStack({
 *   config: adapterContext.config,
 *   normalizeError: adapterContext.normalizeError,
 * })
 *
 * await runOperation(ctx, middleware, async () => {
 *   return execute(input)
 * })
 * ```
 */ function createMiddlewareStack(options) {
    const { config, normalizeError, retryable = true } = options ?? {};
    // Build middleware stack in execution order (outermost to innermost)
    const stack = [
        // 1. Lifecycle middleware (outermost - captures full duration)
        createLifecycleMiddleware()
    ];
    // 2. Retry middleware (middle — enabled by default; stripped entirely for
    //    non-retryable operations such as write primitives, regardless of
    //    `config.retry`. Automatic retry of a signed transaction after an
    //    ambiguous RPC failure is a double-spend risk and must be opt-in
    //    at the caller level.)
    if (retryable && config?.retry !== false) {
        const retryOpts = typeof config?.retry === 'object' ? config.retry : undefined;
        stack.push(createRetryMiddleware(retryOpts));
    }
    // 3. Error normalization middleware (innermost - normalizes before retry sees errors)
    stack.push(createErrorMiddleware(normalizeError ? {
        createNormalizer: ()=>normalizeError
    } : undefined));
    return stack;
}

// ============================================================================
// Composed Middleware
// ============================================================================
/**
 * Symbol to identify pre-composed middleware.
 * @internal
 */ const COMPOSED = Symbol.for('@core/runtime/composed');
/**
 * Check if a middleware is already composed.
 *
 * @param mw - The middleware to check.
 * @returns True if the middleware was created by {@link composeMiddleware}.
 */ function isComposed(mw) {
    return COMPOSED in mw;
}
/**
 * Adapt a unified middleware to the operation middleware signature.
 * @internal
 */ function adaptUnifiedMiddleware(unified) {
    return async (ctx, next)=>{
        const context = {
            ctx,
            name: ctx.name,
            state: undefined,
            next: next
        };
        return unified.middleware(context);
    };
}
/**
 * Normalize middleware input to native operation middleware.
 * @internal
 */ function normalizeMiddleware(mw) {
    return isUnifiedMiddleware(mw) ? adaptUnifiedMiddleware(mw) : mw;
}
// ============================================================================
// Middleware Composition
// ============================================================================
/**
 * Compose middlewares into a single pre-composed middleware.
 *
 * @typeParam T - The return type of operations using this middleware.
 * @param middlewares - A single middleware or array of middlewares to compose.
 * @returns A branded {@link ComposedMiddleware}.
 *
 * @remarks
 * Accepts flexible input:
 * - A single middleware (branded and returned)
 * - An already-composed middleware (returned as-is)
 * - An array of middlewares (composed together)
 * - Unified middleware (adapted automatically)
 *
 * @example
 * ```typescript
 * const composed = composeMiddleware([loggingMw, metricsMw])
 *
 * // Pass already-composed (returns as-is)
 * const same = composeMiddleware(composed)
 * ```
 */ function composeMiddleware(middlewares) {
    const rawArray = Array.isArray(middlewares) ? middlewares : [
        middlewares
    ];
    // Fast path: single already-composed native middleware
    if (rawArray.length === 1) {
        const single = rawArray[0];
        if (single !== undefined && !isUnifiedMiddleware(single)) {
            const nativeMw = single;
            if (isComposed(nativeMw)) {
                return nativeMw;
            }
        }
    }
    const mwArray = rawArray.map(normalizeMiddleware);
    const composed = async (ctx, next)=>{
        const chain = mwArray.reduceRight((nextFn, mw)=>async ()=>mw(ctx, nextFn), next);
        return chain();
    };
    return Object.assign(composed, {
        [COMPOSED]: true
    });
}
// ============================================================================
// Core Runner
// ============================================================================
/**
 * Run an operation wrapped with middleware.
 *
 * @typeParam T - The return type of the operation.
 * @param ctx - The execution context.
 * @param middlewares - Middleware to apply (array, single, or pre-composed).
 * @param fn - The operation function to execute.
 * @returns Promise resolving to the operation result.
 *
 * @remarks
 * For repeated operations with the same middleware stack, pre-compose with
 * {@link composeMiddleware} to avoid re-composition overhead.
 *
 * @example
 * ```typescript
 * // Pass array (composed on each call)
 * await runOperation(ctx, [loggingMw], fn)
 *
 * // Pre-compose for reuse (recommended for hot paths)
 * const composed = composeMiddleware([loggingMw, metricsMw])
 * await runOperation(ctx, composed, fn)
 * ```
 */ async function runOperation(ctx, middlewares, fn) {
    return composeMiddleware(middlewares)(ctx, fn);
}

/**
 * Runtime package providing cross-cutting infrastructure for SDK operations.
 *
 * @remarks
 * This package provides the core runtime infrastructure including:
 *
 * - **Runtime**: Complete container for logger, metrics, events, and clock
 * - **ExecutionContext**: Context for middleware with observability surface
 * - **Logger**: Isomorphic structured logging via {@link createLogger}
 * - **Events**: Type-safe event bus with {@link createEventBus}
 * - **Pipeline**: Middleware-based operation execution with {@link createPipeline}
 * - **Metrics**: Pluggable metrics collection with dimensional tags
 *
 * @example
 * ```typescript
 * import {
 *   createRuntime,
 *   createExecutionContext,
 *   createOpId,
 *   createTraceId,
 *   type Runtime,
 *   type ExecutionContext,
 * } from '@core/runtime'
 *
 * // Create a complete runtime
 * const runtime = createRuntime()
 *
 * // All services are guaranteed present
 * runtime.logger.info('Starting operation')
 * runtime.metrics.counter('requests').inc()
 * runtime.events.emit({ name: 'operation.started' })
 * ```
 *
 * @packageDocumentation
 */ // Core types
// Clock - expose defaultClock for backward compatibility
/** Clock validation schema (backward compatibility). */ zod.z.custom((val)=>val !== null && typeof val === 'object' && 'now' in val && typeof val['now'] === 'function');
/** EventBus validation schema (backward compatibility). */ zod.z.custom((val)=>val !== null && typeof val === 'object' && 'emit' in val && typeof val['emit'] === 'function');
/** Runtime validation schema (backward compatibility). */ zod.z.object({
    logger: zod.z.any().optional(),
    events: zod.z.any().optional(),
    metrics: zod.z.any().optional(),
    clock: zod.z.any().optional()
}).passthrough();

/**
 * Type guard that checks whether a value is a fully constructed `Runtime`.
 *
 * @internal
 */ function isRuntime(value) {
    return value !== null && typeof value === 'object' && 'events' in value && 'clock' in value;
}
/**
 * Resolve `Runtime | RuntimeOptions | undefined` into a concrete `Runtime`.
 *
 * @remarks
 * Adapter factories need a `Runtime` before constructing the adapter context
 * so that transport instrumentation shares the same event bus and logger.
 * This helper normalises the input so factories don't duplicate the check.
 *
 * @param input - An existing Runtime, options to create one, or undefined for defaults.
 * @returns A fully constructed Runtime instance.
 */ function resolveRuntime(input) {
    return isRuntime(input) ? input : createRuntime(input);
}

// ============================================================================
// Validation
// ============================================================================
/**
 * Validate OperationMeta input structure.
 *
 * @remarks
 * Ensures the meta object has the expected shape. Chain resolution is
 * delegated to `resolveChainIdentifier()` which provides detailed errors.
 */ function validateOperationMeta(meta) {
    if (meta === null || typeof meta !== 'object') {
        throw createValidationFailedError('operationMeta', meta, 'Expected an object with chain property');
    }
    // Chain is required
    if (!('chain' in meta) || meta.chain === undefined) {
        throw createValidationFailedError('operationMeta.chain', undefined, 'Chain is required');
    }
    // Address must be string if provided
    if ('address' in meta) {
        const address = meta.address;
        if (address !== undefined && typeof address !== 'string') {
            throw createValidationFailedError('operationMeta.address', address, 'Address must be a string');
        }
    }
}
// ============================================================================
// Operation Context Resolution
// ============================================================================
/**
 * Resolve operation metadata to operation context.
 *
 * @param meta - User-provided operation metadata (**WHAT**).
 * @param options - Resolution options with capabilities and getAddress.
 * @returns Frozen, immutable operation context with guaranteed chain and address.
 * @throws KitError when address is required but cannot be resolved.
 *
 * @remarks
 * Resolves the **WHAT** of an operation:
 * - Chain: Resolved via `resolveChainIdentifier()`
 * - Address: Resolved based on adapter capabilities
 *
 * The returned context is frozen to enforce immutability.
 *
 * @example
 * ```typescript
 * // User-controlled adapter (address resolved from wallet)
 * const ctx = await resolveOperationContext(
 *   { chain: 'Ethereum' },
 *   { capabilities, getAddress: adapter.getAddress }
 * )
 *
 * // Developer-controlled adapter (address required)
 * const ctx = await resolveOperationContext(
 *   { chain: 'Ethereum', address: '0x...' },
 *   { capabilities }
 * )
 * ```
 */ async function resolveOperationContext$1(meta, options) {
    // Validate meta input
    validateOperationMeta(meta);
    const { capabilities, getAddress, requireAddress } = options;
    // Resolve chain
    const chain = resolveChainIdentifier(meta.chain);
    // Determine if address is required (explicit override or developer-controlled adapter)
    const addressRequired = requireAddress ?? capabilities.addressContext === 'developer-controlled';
    // Resolve address
    let address;
    if (meta.address !== undefined && meta.address !== '') {
        // Address provided in input
        address = meta.address;
    } else if (capabilities.addressContext === 'user-controlled' && getAddress) {
        // User-controlled: resolve from adapter
        try {
            address = await getAddress(chain);
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            throw createValidationFailedError('address', undefined, `Failed to resolve address from adapter: ${message}`);
        }
    }
    // Check if address is required but not resolved
    if (addressRequired && address === undefined) {
        throw createValidationFailedError('address', meta.address, 'Address is required. Provide an address in the operation metadata, ' + 'or use resolveReadOnlyOperationContext() for read-only operations.');
    }
    // At this point, address is guaranteed to be defined if we haven't thrown
    if (address === undefined) {
        throw createValidationFailedError('address', undefined, 'Address could not be resolved. This operation requires an address.');
    }
    return Object.freeze({
        chain,
        address
    });
}
/**
 * Resolve operation metadata for read-only operations.
 *
 * @param meta - User-provided operation metadata.
 * @returns Frozen, immutable context with chain and optional address.
 *
 * @remarks
 * Use for operations that don't require an address (e.g., `read`, `getGasPrice`).
 * The returned context is frozen to enforce immutability.
 *
 * @example
 * ```typescript
 * const ctx = resolveReadOnlyOperationContext({ chain: 'Ethereum' })
 * console.log(ctx.chain)    // ChainDefinition
 * console.log(ctx.address)  // undefined
 * ```
 */ function resolveReadOnlyOperationContext(meta) {
    // Validate meta input
    validateOperationMeta(meta);
    return Object.freeze({
        chain: resolveChainIdentifier(meta.chain),
        address: meta.address
    });
}

/**
 * Build the typed error raised when an operation is aborted via its
 * `AbortSignal`.
 *
 * @param operation - Optional operation name to embed in the message.
 * @returns A {@link KitError} with code `NETWORK_ABORTED` (3008) and
 *   `RETRYABLE` recoverability.
 *
 * @example
 * ```typescript
 * import { createAbortError } from '@core/adapter-base'
 *
 * throw createAbortError('waitForTransaction')
 * ```
 */ function createAbortError(operation) {
    return new KitError({
        ...NetworkError.ABORTED,
        recoverability: 'RETRYABLE',
        message: operation === undefined ? 'Operation aborted via its AbortSignal.' : `Operation aborted: ${operation} was cancelled via its AbortSignal.`
    });
}
/**
 * Throw {@link createAbortError} if the signal is already aborted.
 *
 * @param signal - The cancellation signal, or `undefined` when the caller did
 *   not supply one.
 * @param operation - Optional operation name to embed in the error message.
 * @throws KitError `NETWORK_ABORTED` when `signal.aborted` is `true`.
 *
 * @example
 * ```typescript
 * import { throwIfAborted } from '@core/adapter-base'
 *
 * throwIfAborted(ctx.signal, 'execute') // throws if already cancelled
 * ```
 */ function throwIfAborted(signal, operation) {
    if (signal?.aborted === true) {
        throw createAbortError(operation);
    }
}
/**
 * Race a promise against an `AbortSignal`, rejecting with the typed abort
 * error if the signal fires first.
 *
 * @remarks
 * Use this to make an otherwise non-cancellable async API (e.g. viem's
 * `waitForTransactionReceipt`, which has no `signal` option) responsive to
 * cancellation. When the signal aborts, the returned promise rejects
 * immediately — but the underlying work is **not** torn down, so callers must
 * treat post-broadcast aborts as "stop waiting", not "undo".
 *
 * @typeParam T - The resolved value type of the wrapped promise.
 * @param promise - The work to await.
 * @param signal - The cancellation signal, or `undefined` for no cancellation.
 * @param operation - Optional operation name to embed in the error message.
 * @returns The promise's resolved value when it settles before any abort.
 * @throws KitError `NETWORK_ABORTED` when the signal aborts before `promise`
 *   settles.
 *
 * @example
 * ```typescript
 * import { raceAbort } from '@core/adapter-base'
 *
 * const receipt = await raceAbort(
 *   publicClient.waitForTransactionReceipt({ hash }),
 *   ctx.signal,
 *   'waitForTransaction',
 * )
 * ```
 */ async function raceAbort(promise, signal, operation) {
    if (signal === undefined) {
        return promise;
    }
    if (signal.aborted) {
        throw createAbortError(operation);
    }
    let onAbort;
    const abortPromise = new Promise((_resolve, reject)=>{
        onAbort = ()=>{
            reject(createAbortError(operation));
        };
        signal.addEventListener('abort', onAbort, {
            once: true
        });
    });
    try {
        return await Promise.race([
            promise,
            abortPromise
        ]);
    } finally{
        if (onAbort !== undefined) {
            signal.removeEventListener('abort', onAbort);
        }
    }
}

/**
 * Create the canonical error for an adapter authorization-review rejection.
 *
 * @param intent - What the application declined to authorize.
 * @returns A user-cancelled `KitError` detectable by `isSigningRejected`.
 *
 * @example
 * ```typescript
 * if (decision === 'reject') {
 *   throw createAuthorizationRejectedError({ action: 'earn.deposit' })
 * }
 * ```
 */ function createAuthorizationRejectedError(intent) {
    const what = intent.step === undefined ? intent.action : `${intent.action}:${intent.step}`;
    return new KitError({
        ...InputError.USER_CANCELLED,
        recoverability: 'FATAL',
        message: `The application declined the '${what}' authorization ` + '(onBeforeAuthorize hook).',
        cause: {
            trace: {
                intent,
                authorizationRejected: true,
                signingRejected: true
            }
        }
    });
}

const AUTHORIZATION_OPERATION = 'authorization review';
/**
 * Resolve the effective intent for an authorization request.
 *
 * @param descriptor - Optional request-scoped descriptor.
 * @param fallback - Adapter primitive fallback intent.
 * @returns The descriptor override when present, otherwise `fallback`.
 *
 * @example
 * ```typescript
 * const intent = resolveAuthorizationIntent(descriptor, {
 *   action: 'execute',
 * })
 * ```
 */ function resolveAuthorizationIntent(descriptor, fallback) {
    return descriptor?.intent ?? fallback;
}
/**
 * Create one shared, fail-closed authorization gate for an adapter context.
 *
 * @typeParam TPayload - The ecosystem authorization payload type.
 * @param options - Optional adapter authorization-review configuration.
 * @returns An awaited gate that resolves only after explicit approval.
 * @throws KitError when configuration is invalid, review fails, the request
 *   is aborted, or the application rejects the authorization.
 *
 * @example
 * ```typescript
 * const authorize = createAuthorizationGate({
 *   onBeforeAuthorize: async ({ payload }) =>
 *     showConfirmation(payload) ? 'approve' : 'reject',
 * })
 *
 * await authorize({
 *   payload,
 *   intent: { action: 'execute' },
 * })
 * ```
 */ function createAuthorizationGate(options) {
    const hook = options.onBeforeAuthorize;
    if (hook !== undefined && typeof hook !== 'function') {
        throw createValidationFailedError('onBeforeAuthorize', typeof hook, 'onBeforeAuthorize must be a function when provided');
    }
    return async function authorize(input) {
        if (hook === undefined) return;
        const { payload, descriptor, signal } = input;
        const intent = resolveAuthorizationIntent(descriptor, input.intent);
        throwIfAborted(signal, AUTHORIZATION_OPERATION);
        let snapshot;
        try {
            snapshot = structuredClone(payload);
        } catch (error) {
            throw createAuthorizationReviewError('payload snapshot', error);
        }
        const review = descriptor?.createReview === undefined ? undefined : await runReviewStage(async ()=>descriptor.createReview?.(snapshot), signal, 'review factory');
        const decision = await runReviewStage(async ()=>hook({
                intent,
                payload: snapshot,
                ...review === undefined ? {} : {
                    review
                },
                ...signal === undefined ? {} : {
                    signal
                }
            }), signal, 'onBeforeAuthorize hook');
        throwIfAborted(signal, AUTHORIZATION_OPERATION);
        if (decision === 'approve') return;
        if (decision === 'reject') {
            throw createAuthorizationRejectedError(intent);
        }
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: "onBeforeAuthorize must resolve to exactly 'approve' or 'reject'.",
            cause: {
                trace: {
                    decision,
                    intent
                }
            }
        });
    };
}
async function runReviewStage(stage, signal, stageName) {
    try {
        return await raceAbort(Promise.resolve().then(stage), signal, AUTHORIZATION_OPERATION);
    } catch (error) {
        if (isKitError(error)) throw error;
        throw createAuthorizationReviewError(stageName, error);
    }
}
function createAuthorizationReviewError(stage, error) {
    return new KitError({
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: `Authorization review failed during ${stage}.`,
        cause: {
            trace: {
                stage,
                rawError: error
            }
        }
    });
}

/**
 * Create an adapter context with runtime defaults and token registry support.
 *
 * @typeParam TCapabilities - Adapter capabilities type.
 * @param options - The adapter context options.
 * @returns A shallowly frozen adapter context instance.
 *
 * @remarks
 * Internal factory - upstream adapter factories are responsible for validation.
 * The returned context is shallowly frozen to enforce immutability.
 *
 * @example
 * ```typescript
 * const ctx = createAdapterContext({
 *   identity: { name: 'evm', version: '1.0.0' },
 *   capabilities: { addressContext: 'user-controlled', supportedChains: [Ethereum] },
 *   normalizeError: viemErrorNormalizer,
 *   getAddress: async (chain) => wallet.getAddress(),
 *   config: { retry: { maxAttempts: 3, backoff: 'exponential' } },
 * })
 * ```
 */ function createAdapterContext$1(options) {
    const runtime = resolveRuntime(options.runtime);
    const tokens = options.tokens ?? createTokenRegistry();
    const context = {
        identity: options.identity,
        capabilities: options.capabilities,
        runtime,
        normalizeError: options.normalizeError,
        tokens,
        getAddress: options.getAddress,
        validateChainSupport: createValidateChainSupport(options.capabilities),
        authorize: createAuthorizationGate({
            onBeforeAuthorize: options.onBeforeAuthorize
        }),
        ...options.config ? {
            config: options.config
        } : {},
        ...options.ensureChain ? {
            ensureChain: options.ensureChain
        } : {}
    };
    return Object.freeze(context);
}

/**
 * Build standard observability tags from an operation's chain and address.
 *
 * @remarks
 * Produces a consistent tag set for `createExecutionContext`. Used by both
 * `createPrimitive` and `defineAction` to avoid duplicating the logic.
 *
 * When `identity` is supplied (the normal path through `createPrimitive`
 * and `defineAction`), the resulting tags include `layer: 'adapter'`,
 * `adapter`, and `adapterVersion` dimensions on every emitted lifecycle
 * **event**. The `layer` tag is an explicit, stable discriminant so event
 * consumers (e.g. the Compass Studio) can tell which architectural layer
 * emitted the event — `'adapter'` here, with `'provider'` / `'kit'`
 * reserved for those layers to stamp when they emit. `adapter` /
 * `adapterVersion` further disambiguate which concrete adapter (viem,
 * ethers, …) in a multi-adapter process.
 *
 * Note: these tags do **not** reach the metrics backend.
 * `createLifecycleMiddleware` deliberately cherry-picks only bounded,
 * low-cardinality dimensions (`name`, `phase`, `chain`, `chainId`) into
 * `metricTags`; `layer`/`adapter`/`adapterVersion` and high-cardinality
 * fields such as `address` are intentionally excluded to avoid a metric
 * cardinality explosion.
 *
 * @param chain - The chain definition for the operation.
 * @param address - The resolved wallet address (if available).
 * @param custom - Additional tags to merge (e.g. from `ActionOptions.tags`).
 * @param identity - Adapter identity for telemetry enrichment.
 * @returns A `Tags` object with `chain`, optional `chainId`, optional
 *   `address`, optional `layer`/`adapter`/`adapterVersion`, and any custom
 *   tags.
 */ function buildOperationTags(chain, address, custom, identity) {
    return {
        chain: chain.name,
        ...'chainId' in chain ? {
            chainId: chain.chainId
        } : {},
        ...address !== undefined && address !== '' ? {
            address
        } : {},
        ...identity === undefined ? {} : {
            layer: 'adapter',
            adapter: identity.name,
            adapterVersion: identity.version
        },
        ...custom
    };
}

/**
 * Resolve ordinary runtime invocation fields while preserving adapter-only
 * authorization metadata outside the runtime schema.
 *
 * @typeParam TPayload - The ecosystem authorization payload type.
 * @param meta - Optional adapter invocation metadata.
 * @param defaults - Adapter runtime and token-registry defaults.
 * @returns A frozen resolved invocation context with request-scoped metadata.
 *
 * @example
 * ```typescript
 * const invocation = resolveAdapterInvocationContext(meta, {
 *   runtime: adapterContext.runtime,
 *   tokens: adapterContext.tokens,
 * })
 * ```
 */ function resolveAdapterInvocationContext(meta, defaults) {
    const invocation = resolveInvocationContext(meta === undefined ? undefined : {
        traceId: meta.traceId,
        runtime: meta.runtime,
        tokens: meta.tokens,
        callers: meta.callers,
        signal: meta.signal
    }, defaults);
    return Object.freeze({
        ...invocation,
        ...meta?.authorization === undefined ? {} : {
            authorization: meta.authorization
        }
    });
}

// Implementation
function createPrimitive(options) {
    const { name, adapterContext, execute, inputSchema, requireAddress = false, ensureChainBefore = false, retryable = true } = options;
    // ───────────────────────────────────────────────────────────────────────────
    // Build middleware stack once for performance (not on every call).
    // Primitives that opt out of retry (e.g. execute/batchExecute) produce a
    // stack without the retry middleware so a signed transaction is never
    // replayed automatically on an ambiguous RPC failure.
    // ───────────────────────────────────────────────────────────────────────────
    const middleware = createMiddlewareStack({
        config: adapterContext.config,
        normalizeError: adapterContext.normalizeError,
        retryable
    });
    return async function primitive(input, operation, invocation) {
        // ─────────────────────────────────────────────────────────────────────────
        // 1. Validate input (if schema provided)
        // ─────────────────────────────────────────────────────────────────────────
        let validatedInput;
        if (inputSchema === undefined) {
            validatedInput = input;
        } else {
            const result = inputSchema.safeParse(input);
            if (!result.success) {
                throw createValidationErrorFromZod(result.error, `${name} input`);
            }
            validatedInput = result.data;
        }
        // ─────────────────────────────────────────────────────────────────────────
        // 2. Resolve WHAT - Operation context (chain, address)
        //
        //    Resolve the chain BEFORE address. `resolveOperationContext`
        //    invokes `getAddress(chain)` on user-controlled adapters when
        //    no address is supplied, and on browser wallets that means
        //    popping a UI prompt. Validating chain support up-front lets us
        //    fail fast with a typed `INVALID_CHAIN` error before any
        //    side-effecting wallet interaction (or `ensureChain` switch
        //    request) runs. We do this by parsing the read-only context
        //    first — which only normalises the chain identifier and never
        //    calls the adapter — running `validateChainSupport`, then
        //    upgrading to the full operation context (which may resolve
        //    the address) only on supported chains.
        //
        //    The read-only resolver does not take capabilities, so without
        //    this explicit guard read primitives (and any write primitive
        //    whose `requireAddress` is false) would silently fan out
        //    wrong-chain RPC calls — at best returning misleading data,
        //    at worst racing against an adapter that has cached clients
        //    for an unrelated chain.
        // ─────────────────────────────────────────────────────────────────────────
        const readOnlyCtx = resolveReadOnlyOperationContext(operation);
        adapterContext.validateChainSupport(readOnlyCtx.chain);
        const operationCtx = requireAddress ? await resolveOperationContext$1(operation, {
            capabilities: adapterContext.capabilities,
            getAddress: adapterContext.getAddress,
            requireAddress: true
        }) : readOnlyCtx;
        // ─────────────────────────────────────────────────────────────────────────
        // 3. Resolve WHO/HOW - Invocation context (traceId, runtime, callers)
        // ─────────────────────────────────────────────────────────────────────────
        const invocationCtx = resolveAdapterInvocationContext(invocation, {
            runtime: adapterContext.runtime,
            tokens: adapterContext.tokens
        });
        // ─────────────────────────────────────────────────────────────────────────
        // 4. Create execution context FOR MIDDLEWARE
        // ─────────────────────────────────────────────────────────────────────────
        const chain = operationCtx.chain;
        const execCtx = createExecutionContext({
            name,
            invocation: invocationCtx,
            // `identity` flows through to the emitted lifecycle events and
            // metrics, so downstream observability pipelines can distinguish
            // adapters (viem vs ethers) and adapter versions without any
            // call-site changes.
            tags: buildOperationTags(chain, operationCtx.address, undefined, adapterContext.identity)
        });
        // ─────────────────────────────────────────────────────────────────────────
        // 5. Build execute context for business logic
        //    The cast to TChain is safe: the adapter that supplies TChain is
        //    also the one that registers chains of that type via its context.
        //
        //    `traceId` is surfaced on the execute context (and on primitive
        //    result types) so callers can correlate returned values with the
        //    lifecycle events without racing the event bus.
        // ─────────────────────────────────────────────────────────────────────────
        const executeCtx = {
            chain: operationCtx.chain,
            address: operationCtx.address,
            runtime: invocationCtx.runtime,
            tokens: invocationCtx.tokens,
            traceId: execCtx.traceId,
            // Omit `signal` entirely when absent so `exactOptionalPropertyTypes`
            // stays satisfied — the key is missing rather than set to `undefined`.
            ...invocationCtx.signal === undefined ? {} : {
                signal: invocationCtx.signal
            },
            ...invocationCtx.authorization === undefined ? {} : {
                authorization: invocationCtx.authorization
            }
        };
        // ─────────────────────────────────────────────────────────────────────────
        // 6. Execute with middleware
        //    `ensureChain` runs inside the middleware stack so chain-switch
        //    rejections surface as typed errors through the same normalization
        //    pipeline as the primitive body. Adapters that don't provide the
        //    hook (e.g. Solana) incur no cost even when primitives opt in.
        // ─────────────────────────────────────────────────────────────────────────
        return runOperation(execCtx, middleware, async ()=>{
            if (ensureChainBefore && adapterContext.ensureChain !== undefined) {
                await adapterContext.ensureChain(executeCtx.chain);
            }
            return execute(validatedInput, executeCtx);
        });
    };
}

/**
 * Create a structured error for amount operation failures.
 *
 * @remarks
 * Returns a `KitError` with `INPUT_INVALID_AMOUNT` code (1002).
 * The error trace contains the reason and context for debugging.
 *
 * @param reason - The specific error reason.
 * @param message - Human-readable error description.
 * @param context - Additional context about the error (optional).
 * @param cause - The underlying error, if any (optional).
 * @returns A KitError with INPUT type and FATAL recoverability.
 *
 * @example
 * ```typescript
 * throw createAmountError(
 *   'DECIMAL_MISMATCH',
 *   'Cannot add amounts with different decimals',
 *   { leftDecimals: 6, rightDecimals: 18 }
 * )
 * ```
 *
 * @example
 * ```typescript
 * throw createAmountError(
 *   'PARSE_ERROR',
 *   'Amount.parse: input contains non-numeric characters',
 *   { input: '12.34.56' }
 * )
 * ```
 */ function createAmountError(reason, message, context, cause) {
    const trace = {
        reason
    };
    if (context !== undefined) {
        trace.context = context;
    }
    return new KitError({
        ...InputError.INVALID_AMOUNT,
        recoverability: 'FATAL',
        message,
        cause: {
            trace
        }
    });
}

// ============================================================================
// Constants
// ============================================================================
/**
 * Maximum supported decimal precision.
 *
 * @remarks
 * Set to 77 because `10n ** 77n` is the largest power of 10 that fits within
 * a 256-bit unsigned integer (`2n ** 256n - 1n`), which is the standard word
 * size for EVM smart contracts. This is well beyond any practical token
 * decimal requirement (ETH uses 18, most stablecoins 6).
 */ const MAX_DECIMALS = 77;
/**
 * Cache for scale multipliers to avoid repeated BigInt exponentiation.
 *
 * @remarks
 * Maps decimal count → 10^decimals. Populated lazily on first access
 * for each decimal value. Thread-safe in single-threaded JS environments.
 */ const scaleCache = new Map();
// ============================================================================
// Scale Helpers
// ============================================================================
/**
 * Get the scale multiplier for a given number of decimals.
 *
 * @param decimals - The decimal precision (0 to MAX_DECIMALS).
 * @returns The scale factor (10^decimals).
 * @throws KitError If decimals is out of valid range.
 *
 * @remarks
 * Results are cached to avoid repeated BigInt exponentiation. The cache
 * is bounded by MAX_DECIMALS, so memory usage is predictable.
 *
 * @example
 * ```typescript
 * getScale(6)  // 1_000_000n
 * getScale(18) // 1_000_000_000_000_000_000n
 * ```
 */ function getScale(decimals) {
    // Validate range before cache lookup
    if (decimals < 0 || decimals > MAX_DECIMALS) {
        throw createAmountError('INVALID_DECIMALS', `Decimals must be between 0 and ${String(MAX_DECIMALS)}, got ${String(decimals)}`, {
            decimals
        });
    }
    // Check cache first
    let scale = scaleCache.get(decimals);
    if (scale === undefined) {
        // Compute and cache for future use
        scale = 10n ** BigInt(decimals);
        scaleCache.set(decimals, scale);
    }
    return scale;
}
// ============================================================================
// Validation Helpers
// ============================================================================
/**
 * Validate that decimals are within acceptable range.
 *
 * @param decimals - The decimal value to validate.
 * @param context - The calling function name for error messages.
 * @throws KitError If decimals is not a valid integer in range.
 *
 * @remarks
 * Ensures decimals is:
 * - An integer (not a float)
 * - Non-negative
 * - At most MAX_DECIMALS
 *
 * @example
 * ```typescript
 * validateDecimals(6, 'Amt.of')     // OK
 * validateDecimals(-1, 'Amt.parse') // throws INVALID_DECIMALS
 * validateDecimals(1.5, 'Amt.of')   // throws INVALID_DECIMALS
 * ```
 */ function validateDecimals(decimals, context) {
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > MAX_DECIMALS) {
        throw createAmountError('INVALID_DECIMALS', `${context}: decimals must be an integer between 0 and ${String(MAX_DECIMALS)}, got ${String(decimals)}`, {
            decimals,
            context
        });
    }
}
/**
 * Assert that two amounts have the same decimal precision.
 *
 * @param a - The first Amount.
 * @param b - The second Amount.
 * @param operation - The operation name for error messages.
 * @throws KitError If decimals differ.
 *
 * @remarks
 * Operations like add/sub/compare require matching decimals to ensure
 * meaningful results. This function provides a consistent error message
 * format across all such operations.
 *
 * @example
 * ```typescript
 * const usdc = { raw: 1_000_000n, decimals: 6 }
 * const eth = { raw: 1n, decimals: 18 }
 *
 * assertSameDecimals(usdc, usdc, 'Amt.add') // OK
 * assertSameDecimals(usdc, eth, 'Amt.add')  // throws DECIMAL_MISMATCH
 * ```
 */ function assertSameDecimals(a, b, operation) {
    if (a.decimals !== b.decimals) {
        throw createAmountError('DECIMAL_MISMATCH', `${operation}: cannot operate on amounts with different decimals ` + `(${String(a.decimals)} vs ${String(b.decimals)})`, {
            aDecimals: a.decimals,
            bDecimals: b.decimals,
            operation
        });
    }
}
/**
 * Assert that a config's decimals matches an Amount's decimals when both are provided.
 *
 * @param inputDecimals - The decimal precision of the input Amount.
 * @param configDecimals - The decimal precision specified in config (may be undefined).
 * @param context - The calling function name for error messages.
 * @throws KitError If both are defined and don't match.
 *
 * @remarks
 * Used by Amount.from to validate that when an Amount-like input is provided
 * with explicit config, the decimals are consistent.
 *
 * @example
 * ```typescript
 * assertDecimalConfig(6, 6, 'Amount.from')   // OK - matches
 * assertDecimalConfig(6, undefined, 'Amount.from') // OK - no config
 * assertDecimalConfig(6, 18, 'Amount.from')  // throws DECIMAL_MISMATCH
 * ```
 */ function assertDecimalConfig(inputDecimals, configDecimals, context) {
    if (configDecimals !== undefined && configDecimals !== inputDecimals) {
        throw createAmountError('DECIMAL_MISMATCH', `${context}: Amount has ${String(inputDecimals)} decimals but ` + `config specifies ${String(configDecimals)}`, {
            inputDecimals,
            configDecimals
        });
    }
}

/**
 * Parse a human-readable string or number into raw amount data.
 *
 * @param input - The input to parse (e.g., "100.50", ".5", "1000", or 100.5).
 * @param options - Parse options including decimals.
 * @param ctx - Context for error messages.
 * @returns Parsed amount data with raw bigint and decimals.
 * @throws KitError If input is invalid or parsing fails.
 *
 * @example
 * ```typescript
 * parse('100.50', { decimals: 6 }, 'test')
 * // { raw: 100_500_000n, decimals: 6 }
 *
 * parse('1', { decimals: 6 }, 'test')
 * // { raw: 1_000_000n, decimals: 6 }
 *
 * // Inputs starting with decimal point are supported
 * parse('.5', { decimals: 6 }, 'test')
 * // { raw: 500_000n, decimals: 6 }
 * ```
 */ function parse(input, options, ctx) {
    // Validate decimals first
    validateDecimals(options.decimals, ctx);
    const { decimals, allowNegative = false } = options;
    // Convert number to string (warning: potential precision loss)
    const str = typeof input === 'number' ? input.toString() : input;
    // Basic validation - must be non-empty string
    if (typeof str !== 'string' || str.trim() === '') {
        throw createAmountError('PARSE_ERROR', `${ctx}: input must be a non-empty string or number`, {
            input
        });
    }
    // Normalize: trim whitespace
    let normalized = str.trim();
    // Handle negative sign
    const isNegative = normalized.startsWith('-');
    if (isNegative) {
        if (!allowNegative) {
            throw createAmountError('NEGATIVE_NOT_ALLOWED', `${ctx}: negative values not allowed`, {
                input
            });
        }
        normalized = normalized.slice(1);
    }
    // Normalize leading zeros (but preserve "0" and "0.xxx")
    if (normalized.length > 1 && normalized.startsWith('0') && normalized[1] !== '.') {
        normalized = normalized.replace(/^0+/, '') || '0';
    }
    // Split into integer and decimal parts
    const parts = normalized.split('.');
    if (parts.length > 2) {
        throw createAmountError('PARSE_ERROR', `${ctx}: invalid number format (multiple decimal points)`, {
            input
        });
    }
    let integerPart = parts[0] ?? '';
    const decimalPart = parts[1] ?? '';
    // Handle inputs starting with decimal point (e.g., ".5" → "0.5")
    if (integerPart === '' && decimalPart !== '') {
        integerPart = '0';
    }
    // Validate parts contain only digits
    if (!/^\d+$/.test(integerPart) || decimalPart && !/^\d+$/.test(decimalPart)) {
        throw createAmountError('PARSE_ERROR', `${ctx}: input contains non-numeric characters`, {
            input
        });
    }
    // Truncate decimal part to allowed precision and pad if needed
    const truncatedDecimal = decimalPart.slice(0, decimals).padEnd(decimals, '0');
    // Combine and convert to bigint
    const rawString = integerPart + truncatedDecimal;
    let raw = BigInt(rawString);
    // Apply negative sign if present
    if (isNegative) {
        raw = -raw;
    }
    return {
        raw,
        decimals
    };
}

/**
 * Compare two amount values.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns -1 if a is less than b, 0 if equal, 1 if a is greater than b.
 * @throws KitError If decimals don't match.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 500_000n, decimals: 6 }
 * compare(a, b, 'test') // 1 (a > b)
 * ```
 */ function compare(a, b, ctx) {
    assertSameDecimals(a, b, ctx);
    if (a.raw < b.raw) return -1;
    if (a.raw > b.raw) return 1;
    return 0;
}
/**
 * Check if two amounts are equal.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if raw values are equal.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * eq(a, a, 'test') // true
 * ```
 */ function eq(a, b, ctx) {
    return compare(a, b, ctx) === 0;
}
/**
 * Check if a is less than b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is less than b.
 *
 * @example
 * ```typescript
 * const a = { raw: 500_000n, decimals: 6 }
 * const b = { raw: 1_000_000n, decimals: 6 }
 * lt(a, b, 'test') // true
 * ```
 */ function lt(a, b, ctx) {
    return compare(a, b, ctx) === -1;
}
/**
 * Check if a is less than or equal to b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is less than or equal to b.
 *
 * @example
 * ```typescript
 * const a = { raw: 500_000n, decimals: 6 }
 * lte(a, a, 'test') // true
 * ```
 */ function lte(a, b, ctx) {
    return compare(a, b, ctx) <= 0;
}
/**
 * Check if a is greater than b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is greater than b.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 500_000n, decimals: 6 }
 * gt(a, b, 'test') // true
 * ```
 */ function gt(a, b, ctx) {
    return compare(a, b, ctx) === 1;
}
/**
 * Check if a is greater than or equal to b.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns True if a is greater than or equal to b.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * gte(a, a, 'test') // true
 * ```
 */ function gte(a, b, ctx) {
    return compare(a, b, ctx) >= 0;
}

/**
 * Fixed-point precision for number multiplication/division.
 * Using 10^18 provides sufficient precision for most token operations.
 */ const PRECISION = 10n ** 18n;
/**
 * Add two amount values.
 *
 * @param a - The first amount.
 * @param b - The second amount.
 * @param ctx - Context for error messages.
 * @returns The sum with preserved decimals.
 * @throws KitError If decimals don't match.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 500_000n, decimals: 6 }
 * add(a, b, 'test') // { raw: 1_500_000n, decimals: 6 }
 * ```
 */ function add(a, b, ctx) {
    assertSameDecimals(a, b, ctx);
    return {
        raw: a.raw + b.raw,
        decimals: a.decimals
    };
}
/**
 * Subtract one amount from another.
 *
 * @param a - The amount to subtract from.
 * @param b - The amount to subtract.
 * @param ctx - Context for error messages.
 * @returns The difference with preserved decimals.
 * @throws KitError If decimals don't match.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * const b = { raw: 300_000n, decimals: 6 }
 * sub(a, b, 'test') // { raw: 700_000n, decimals: 6 }
 * ```
 */ function sub(a, b, ctx) {
    assertSameDecimals(a, b, ctx);
    return {
        raw: a.raw - b.raw,
        decimals: a.decimals
    };
}
/**
 * Multiply an amount by a scalar.
 *
 * @param amount - The amount to multiply.
 * @param multiplier - The scalar (bigint for exact, number for approximate).
 * @returns The product with preserved decimals.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * mul(a, 2n)   // { raw: 2_000_000n, decimals: 6 }
 * mul(a, 0.5) // { raw: 500_000n, decimals: 6 }
 * ```
 */ function mul(amount, multiplier) {
    let raw;
    if (typeof multiplier === 'bigint') {
        // Exact multiplication for bigint
        raw = amount.raw * multiplier;
    } else {
        // Fixed-point math for number multipliers.
        // Note: Precision is limited to ~15-17 significant digits (JavaScript Number limit).
        // For exact precision with large or high-precision multipliers, use bigint instead.
        // Use Math.round for better precision (avoids systematic bias from truncation).
        const multiplierBigInt = BigInt(Math.round(multiplier * Number(PRECISION)));
        raw = amount.raw * multiplierBigInt / PRECISION;
    }
    return {
        raw,
        decimals: amount.decimals
    };
}
/**
 * Divide an amount by a scalar.
 *
 * @param amount - The amount to divide.
 * @param divisor - The scalar divisor (bigint or number).
 * @param ctx - Context for error messages.
 * @returns The quotient (truncated) with preserved decimals.
 * @throws KitError If divisor is zero.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * div(a, 2n, 'test')   // { raw: 500_000n, decimals: 6 }
 * div(a, 2.5, 'test') // { raw: 400_000n, decimals: 6 }
 * ```
 */ function div(amount, divisor, ctx) {
    let raw;
    if (typeof divisor === 'bigint') {
        if (divisor === 0n) {
            throw createAmountError('INVALID_INPUT', `${ctx}: division by zero`);
        }
        raw = amount.raw / divisor;
    } else {
        if (divisor === 0) {
            throw createAmountError('INVALID_INPUT', `${ctx}: division by zero`);
        }
        // Fixed-point math for number divisors
        // Use Math.round for better precision (avoids systematic bias from truncation).
        const divisorBigInt = BigInt(Math.round(divisor * Number(PRECISION)));
        raw = amount.raw * PRECISION / divisorBigInt;
    }
    return {
        raw,
        decimals: amount.decimals
    };
}
/**
 * Get the absolute value of an amount.
 *
 * @param amount - The amount.
 * @returns The absolute value with preserved decimals.
 *
 * @example
 * ```typescript
 * const a = { raw: -1_000_000n, decimals: 6 }
 * abs(a) // { raw: 1_000_000n, decimals: 6 }
 * ```
 */ function abs(amount) {
    return {
        raw: amount.raw < 0n ? -amount.raw : amount.raw,
        decimals: amount.decimals
    };
}
/**
 * Negate an amount.
 *
 * @param amount - The amount.
 * @returns The negated value with preserved decimals.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_000_000n, decimals: 6 }
 * neg(a) // { raw: -1_000_000n, decimals: 6 }
 * ```
 */ function neg(amount) {
    return {
        raw: -amount.raw,
        decimals: amount.decimals
    };
}

/**
 * Remove trailing zeros from a decimal string, keeping at least minDigits.
 *
 * @param str - The decimal string to trim.
 * @param minDigits - Minimum digits to keep.
 * @returns The trimmed string.
 */ function trimTrailingZeros(str, minDigits) {
    let end = str.length;
    while(end > minDigits && str[end - 1] === '0'){
        end--;
    }
    return str.slice(0, end);
}
/**
 * Format an amount as a human-readable string.
 *
 * @param amount - The amount to format.
 * @param options - Formatting options.
 * @returns A human-readable string (e.g., "1,000.50").
 *
 * @example
 * ```typescript
 * const a = { raw: 1_500_000n, decimals: 6 }
 * formatted(a)                              // "1.5"
 * formatted(a, { minimumFractionDigits: 2 }) // "1.50"
 * formatted(a, { useGrouping: false })      // "1.5"
 * ```
 */ function formatted(amount, options = {}) {
    const { locale = 'en-US', minimumFractionDigits = 0, maximumFractionDigits = amount.decimals, useGrouping = true } = options;
    // Validate that minimumFractionDigits does not exceed maximumFractionDigits
    if (minimumFractionDigits > maximumFractionDigits) {
        throw new RangeError(`minimumFractionDigits (${String(minimumFractionDigits)}) cannot be ` + `greater than maximumFractionDigits (${String(maximumFractionDigits)})`);
    }
    // Get scale for splitting integer and decimal parts
    const scale = getScale(amount.decimals);
    // Handle negative values
    const isNegative = amount.raw < 0n;
    const absRaw = isNegative ? -amount.raw : amount.raw;
    // Split into integer and decimal parts using bigint division
    const integerPart = absRaw / scale;
    const decimalPart = absRaw % scale;
    // Format integer with locale grouping
    const formattedInteger = useGrouping ? integerPart.toLocaleString(locale) : integerPart.toString();
    // Format decimal part
    let formattedDecimal = '';
    if (maximumFractionDigits > 0) {
        // Pad decimal part to full precision
        const fullDecimal = decimalPart.toString().padStart(amount.decimals, '0');
        // Truncate to max digits
        let trimmed = fullDecimal.slice(0, maximumFractionDigits);
        // Trim trailing zeros (but keep minimumFractionDigits)
        if (minimumFractionDigits < trimmed.length) {
            trimmed = trimTrailingZeros(trimmed, minimumFractionDigits);
        }
        // Add decimal point if there's content
        if (trimmed.length > 0) {
            formattedDecimal = '.' + trimmed;
        }
    }
    // Note: The branch for maximumFractionDigits <= 0 && minimumFractionDigits > 0
    // is unreachable due to validation at the start of the function.
    return (isNegative ? '-' : '') + formattedInteger + formattedDecimal;
}
/**
 * Convert an amount to a human-readable string.
 *
 * @param amount - The amount to convert.
 * @returns A formatted string like "1.5".
 *
 * @remarks
 * This is equivalent to calling `formatted()` with default options.
 * For display with a token symbol, combine with the token registry:
 * ```typescript
 * `${amount.toString()} ${token.symbol}`
 * ```
 *
 * @example
 * ```typescript
 * const a = { raw: 1_500_000n, decimals: 6 }
 * toString(a) // "1.5"
 * ```
 */ // biome-ignore lint/suspicious/noShadowRestrictedNames: `toString` is an intentional public amount-formatting API in @core/amounts; renaming it would be a breaking change.
function toString(amount) {
    return formatted(amount);
}
/**
 * Convert an amount to a JSON-serializable object.
 *
 * @param amount - The amount to convert.
 * @returns An object with raw (as string), decimals, and formatted value.
 *
 * @example
 * ```typescript
 * const a = { raw: 1_500_000n, decimals: 6 }
 * toJSON(a)
 * // { raw: "1500000", decimals: 6, formatted: "1.5" }
 * ```
 */ function toJSON(amount) {
    return {
        raw: amount.raw.toString(),
        decimals: amount.decimals,
        formatted: formatted(amount)
    };
}

/**
 * Convert an amount to a different decimal precision.
 *
 * @param amount - The amount to convert.
 * @param newDecimals - The target decimal precision.
 * @param ctx - Context for error messages.
 * @returns Converted amount data with adjusted raw value and new decimals.
 * @throws KitError If newDecimals is invalid.
 *
 * @example
 * ```typescript
 * // Increase precision (6 → 18)
 * const usdc = { raw: 1_000_000n, decimals: 6 }
 * toDecimals(usdc, 18, 'test')
 * // { raw: 1_000_000_000_000_000_000n, decimals: 18 }
 *
 * // Decrease precision (18 → 6)
 * const eth = { raw: 1_000_000_000_000_000_000n, decimals: 18 }
 * toDecimals(eth, 6, 'test')
 * // { raw: 1_000_000n, decimals: 6 }
 * ```
 */ function toDecimals(amount, newDecimals, ctx) {
    validateDecimals(newDecimals, ctx);
    // Same precision - return copy with same values
    if (amount.decimals === newDecimals) {
        return {
            raw: amount.raw,
            decimals: amount.decimals
        };
    }
    let raw;
    if (newDecimals > amount.decimals) {
        // Increasing precision - multiply by scale difference
        const scaleDiff = getScale(newDecimals - amount.decimals);
        raw = amount.raw * scaleDiff;
    } else {
        // Decreasing precision - divide by scale difference (truncates)
        const scaleDiff = getScale(amount.decimals - newDecimals);
        raw = amount.raw / scaleDiff;
    }
    return {
        raw,
        decimals: newDecimals
    };
}

// ============================================================================
// Amount Class
// ============================================================================
/**
 * An immutable token amount with fluent API methods.
 *
 * @remarks
 * The `Amount` class provides a type-safe, ergonomic way to work with token
 * amounts. It combines the raw bigint value with decimal precision and
 * provides chainable methods for:
 *
 * - **Math operations**: add, sub, mul, div, abs, neg
 * - **Comparisons**: eq, lt, lte, gt, gte, cmp, min, max
 * - **Predicates**: isZero, isPositive, isNegative
 * - **Formatting**: formatted, toString, toJSON
 * - **Conversion**: toDecimals
 *
 * All operations return new Amount instances - the class is immutable.
 *
 * Token identity (symbol) is intentionally excluded. Source token metadata
 * from the token registry for display purposes.
 */ class Amount {
    /** The raw value in smallest units (e.g., wei for ETH, micro-units for USDC). */ raw;
    /** Number of decimal places for this token. */ decimals;
    // ==========================================================================
    // Constructor (private - use static factories)
    // ==========================================================================
    constructor(raw, decimals){
        this.raw = raw;
        this.decimals = decimals;
        Object.freeze(this);
    }
    // ==========================================================================
    // Static Factory Methods
    // ==========================================================================
    /**
   * Create an Amount from a raw bigint value.
   *
   * @param raw - The raw value in smallest units.
   * @param config - Configuration with decimals.
   * @returns A new immutable Amount instance.
   * @throws KitError If raw is not a bigint or decimals is invalid.
   *
   * @example
   * ```typescript
   * // Get decimals from token registry
   * const amount = Amount.of(1_000_000n, { decimals: 6 })
   * ```
   */ static of(raw, config) {
        validateDecimals(config.decimals, 'Amount.of');
        if (typeof raw !== 'bigint') {
            throw createAmountError('INVALID_INPUT', `Amount.of: expected bigint, got ${typeof raw}`, {
                input: raw
            });
        }
        return new Amount(raw, config.decimals);
    }
    /**
   * Parse a human-readable string or number into an Amount.
   *
   * @param input - The input to parse (e.g., "100.50" or 100.5).
   * @param options - Parse options including decimals.
   * @returns A new immutable Amount instance.
   * @throws KitError If input is invalid or parsing fails.
   *
   * @example
   * ```typescript
   * const amount = Amount.parse('100.50', { decimals: 6 })
   * ```
   */ static parse(input, options) {
        const result = parse(input, options, 'Amount.parse');
        return new Amount(result.raw, result.decimals);
    }
    /**
   * Convert any AmountLike value to an Amount.
   *
   * @param input - The input (bigint, string, number, or existing Amount).
   * @param config - Configuration (required for non-Amount inputs).
   * @returns A new immutable Amount instance.
   * @throws KitError If conversion fails or config is missing.
   *
   * @remarks
   * When providing a `number` input, very large or small values may be
   * converted to exponential notation (e.g., `1e21`), which is not supported.
   * For such values, provide a `string` representation instead.
   *
   * @example
   * ```typescript
   * Amount.from(1_000_000n, { decimals: 6 })  // from bigint
   * Amount.from('1.00', { decimals: 6 })      // from string
   * Amount.from(existingAmount)               // pass-through
   * ```
   */ static from(input, config) {
        // Already an Amount instance - return directly
        if (input instanceof Amount) {
            assertDecimalConfig(input.decimals, config?.decimals, 'Amount.from');
            return input;
        }
        // Plain Amount-like object (e.g., from JSON deserialization)
        if (Amount.isAmount(input)) {
            assertDecimalConfig(input.decimals, config?.decimals, 'Amount.from');
            return new Amount(input.raw, input.decimals);
        }
        // Config is required for non-Amount inputs
        if (config === undefined) {
            throw createAmountError('INVALID_INPUT', 'Amount.from: config with decimals is required for non-Amount inputs', {
                input
            });
        }
        // Route to appropriate factory
        if (typeof input === 'bigint') {
            return Amount.of(input, config);
        }
        return Amount.parse(input, config);
    }
    /**
   * Create a zero Amount with the given configuration.
   *
   * @param config - Configuration with decimals.
   * @returns A zero Amount instance.
   *
   * @example
   * ```typescript
   * const zero = Amount.zero({ decimals: 6 })
   * ```
   */ static zero(config) {
        return Amount.of(0n, config);
    }
    /**
   * Check if a value is an Amount-like object.
   *
   * @param value - The value to check.
   * @returns True if the value has Amount shape (raw: bigint, decimals: number).
   *
   * @example
   * ```typescript
   * Amount.isAmount({ raw: 1000000n, decimals: 6 }) // true
   * Amount.isAmount({ value: 100 })                 // false
   * ```
   */ static isAmount(value) {
        return typeof value === 'object' && value !== null && 'raw' in value && typeof value.raw === 'bigint' && 'decimals' in value && typeof value.decimals === 'number';
    }
    /**
   * Sum an array of Amounts.
   *
   * @param amounts - The amounts to sum (must have same decimals).
   * @returns A new Amount with the total sum.
   * @throws KitError If amounts array is empty or decimals don't match.
   *
   * @example
   * ```typescript
   * const fee1 = Amount.parse('0.10', { decimals: 6 })
   * const fee2 = Amount.parse('0.25', { decimals: 6 })
   * const fee3 = Amount.parse('0.15', { decimals: 6 })
   *
   * const total = Amount.sum([fee1, fee2, fee3])
   * total.toString() // "0.5"
   * ```
   */ static sum(amounts) {
        // Extract first element with proper type narrowing
        const first = amounts[0];
        if (first === undefined) {
            throw createAmountError('INVALID_INPUT', 'Amount.sum: cannot sum an empty array');
        }
        // Single element - return directly (preserves immutability semantics)
        if (amounts.length === 1) {
            return first;
        }
        // Sum remaining amounts using reduce, validating decimal consistency
        const totalRaw = amounts.slice(1).reduce((sum, amount, index)=>{
            if (amount.decimals !== first.decimals) {
                throw createAmountError('DECIMAL_MISMATCH', `Amount.sum: all amounts must have the same decimals ` + `(expected ${String(first.decimals)}, got ${String(amount.decimals)} at index ${String(index + 1)})`, {
                    expectedDecimals: first.decimals,
                    actualDecimals: amount.decimals
                });
            }
            return sum + amount.raw;
        }, first.raw);
        return new Amount(totalRaw, first.decimals);
    }
    /**
   * Deserialize an Amount from a JSON object.
   *
   * @param json - The JSON object (e.g., from `JSON.parse()`).
   * @returns A new Amount instance.
   * @throws KitError If the JSON structure is invalid.
   *
   * @example
   * ```typescript
   * const json = JSON.parse('{"raw":"1500000","decimals":6}')
   * const amount = Amount.fromJSON(json)
   * ```
   */ static fromJSON(json) {
        // Runtime validation since input may come from JSON.parse()
        if (typeof json !== 'object' || json === null || !('raw' in json) || typeof json.raw !== 'string' || !('decimals' in json) || typeof json.decimals !== 'number') {
            throw createAmountError('INVALID_INPUT', 'Amount.fromJSON: invalid JSON structure', {
                json
            });
        }
        const { raw, decimals } = json;
        return Amount.of(BigInt(raw), {
            decimals
        });
    }
    // ==========================================================================
    // Comparison Methods
    // ==========================================================================
    /**
   * Compare this Amount with another.
   *
   * @param other - The Amount to compare with.
   * @returns -1 if this is less than other, 0 if equal, 1 if this is greater.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * const b = Amount.parse('2.0', { decimals: 6 })
   * a.compare(b) // -1
   * ```
   */ compare(other) {
        return compare(this, other, 'Amount.compare');
    }
    /**
   * Check if this Amount equals another.
   *
   * @param other - The Amount to compare with.
   * @returns True if the raw values are equal.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * const b = Amount.parse('1.5', { decimals: 6 })
   * a.eq(b) // true
   * ```
   */ eq(other) {
        return eq(this, other, 'Amount.eq');
    }
    /**
   * Check if this Amount is less than another.
   *
   * @param other - The Amount to compare with.
   * @returns True if this.raw is less than other.raw.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.0', { decimals: 6 })
   * const b = Amount.parse('2.0', { decimals: 6 })
   * a.lt(b) // true
   * ```
   */ lt(other) {
        return lt(this, other, 'Amount.lt');
    }
    /**
   * Check if this Amount is less than or equal to another.
   *
   * @param other - The Amount to compare with.
   * @returns True if this.raw is less than or equal to other.raw.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * const b = Amount.parse('1.5', { decimals: 6 })
   * a.lte(b) // true
   * ```
   */ lte(other) {
        return lte(this, other, 'Amount.lte');
    }
    /**
   * Check if this Amount is greater than another.
   *
   * @param other - The Amount to compare with.
   * @returns True if this.raw is greater than other.raw.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('2.0', { decimals: 6 })
   * const b = Amount.parse('1.0', { decimals: 6 })
   * a.gt(b) // true
   * ```
   */ gt(other) {
        return gt(this, other, 'Amount.gt');
    }
    /**
   * Check if this Amount is greater than or equal to another.
   *
   * @param other - The Amount to compare with.
   * @returns True if this.raw is greater than or equal to other.raw.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('2.0', { decimals: 6 })
   * const b = Amount.parse('2.0', { decimals: 6 })
   * a.gte(b) // true
   * ```
   */ gte(other) {
        return gte(this, other, 'Amount.gte');
    }
    /**
   * Return the minimum of this Amount and another.
   *
   * @param other - The Amount to compare with.
   * @returns The smaller of the two amounts.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.0', { decimals: 6 })
   * const b = Amount.parse('2.0', { decimals: 6 })
   * a.min(b).toString() // "1"
   * ```
   */ min(other) {
        return this.lt(other) ? this : other;
    }
    /**
   * Return the maximum of this Amount and another.
   *
   * @param other - The Amount to compare with.
   * @returns The larger of the two amounts.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.0', { decimals: 6 })
   * const b = Amount.parse('2.0', { decimals: 6 })
   * a.max(b).toString() // "2"
   * ```
   */ max(other) {
        return this.gt(other) ? this : other;
    }
    // ==========================================================================
    // Math Methods
    // ==========================================================================
    /**
   * Add another Amount to this one.
   *
   * @param other - The Amount to add.
   * @returns A new Amount with the sum.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * const b = Amount.parse('0.5', { decimals: 6 })
   * a.add(b).toString() // "2"
   * ```
   */ add(other) {
        const result = add(this, other, 'Amount.add');
        return new Amount(result.raw, result.decimals);
    }
    /**
   * Subtract another Amount from this one.
   *
   * @param other - The Amount to subtract.
   * @returns A new Amount with the difference.
   * @throws KitError If amounts have different decimals.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('2.0', { decimals: 6 })
   * const b = Amount.parse('0.5', { decimals: 6 })
   * a.sub(b).toString() // "1.5"
   * ```
   */ sub(other) {
        const result = sub(this, other, 'Amount.sub');
        return new Amount(result.raw, result.decimals);
    }
    /**
   * Multiply this Amount by a scalar.
   *
   * @param multiplier - The scalar to multiply by (bigint or integer number).
   * @returns A new Amount with the product.
   *
   * @remarks
   * When using a `number` as a multiplier, precision is limited by standard
   * JavaScript floating-point capabilities (~15-17 significant digits). For
   * high-precision calculations, provide the multiplier as a `bigint`.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * a.mul(2n).toString() // "3"
   * a.mul(3).toString()  // "4.5"
   * ```
   */ mul(multiplier) {
        const result = mul(this, multiplier);
        return new Amount(result.raw, result.decimals);
    }
    /**
   * Divide this Amount by a scalar.
   *
   * @param divisor - The scalar to divide by (bigint or integer number).
   * @returns A new Amount with the quotient (integer division).
   * @throws KitError If divisor is zero.
   *
   * @remarks
   * When using a `number` as a divisor, precision is limited by standard
   * JavaScript floating-point capabilities (~15-17 significant digits). For
   * high-precision calculations, provide the divisor as a `bigint`.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('6.0', { decimals: 6 })
   * a.div(2n).toString() // "3"
   * a.div(4).toString()  // "1.5"
   * ```
   */ div(divisor) {
        const result = div(this, divisor, 'Amount.div');
        return new Amount(result.raw, result.decimals);
    }
    /**
   * Get the absolute value of this Amount.
   *
   * @returns A new Amount with the absolute value.
   *
   * @example
   * ```typescript
   * const a = Amount.of(-1_500_000n, { decimals: 6 })
   * a.abs().toString() // "1.5"
   * ```
   */ abs() {
        const result = abs(this);
        return new Amount(result.raw, result.decimals);
    }
    /**
   * Negate this Amount.
   *
   * @returns A new Amount with the negated value.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * a.neg().raw // -1_500_000n
   * ```
   */ neg() {
        const result = neg(this);
        return new Amount(result.raw, result.decimals);
    }
    // ==========================================================================
    // Predicate Methods
    // ==========================================================================
    /**
   * Check if this Amount is zero.
   *
   * @returns True if the raw value is 0n.
   *
   * @example
   * ```typescript
   * Amount.zero({ decimals: 6 }).isZero() // true
   * Amount.parse('0.001', { decimals: 6 }).isZero() // false
   * ```
   */ isZero() {
        return this.raw === 0n;
    }
    /**
   * Check if this Amount is positive.
   *
   * @returns True if the raw value is greater than 0n.
   *
   * @example
   * ```typescript
   * Amount.parse('1.0', { decimals: 6 }).isPositive() // true
   * Amount.zero({ decimals: 6 }).isPositive() // false
   * ```
   */ isPositive() {
        return this.raw > 0n;
    }
    /**
   * Check if this Amount is negative.
   *
   * @returns True if the raw value is less than 0n.
   *
   * @example
   * ```typescript
   * Amount.of(-1_000_000n, { decimals: 6 }).isNegative() // true
   * Amount.parse('1.0', { decimals: 6 }).isNegative() // false
   * ```
   */ isNegative() {
        return this.raw < 0n;
    }
    // ==========================================================================
    // Conversion Methods
    // ==========================================================================
    /**
   * Convert this Amount to a different decimal precision.
   *
   * @param newDecimals - The target number of decimal places.
   * @returns A new Amount with adjusted precision (or this if same precision).
   * @throws KitError If newDecimals is invalid.
   *
   * @example
   * ```typescript
   * // Scale up: 6 decimals → 18 decimals
   * const usdc = Amount.parse('1.5', { decimals: 6 })
   * const scaled = usdc.toDecimals(18)
   * scaled.raw // 1_500_000_000_000_000_000n
   *
   * // Scale down: 18 decimals → 6 decimals (truncates)
   * const eth = Amount.of(1_500_000_000_000_000_000n, { decimals: 18 })
   * eth.toDecimals(6).raw // 1_500_000n
   * ```
   */ toDecimals(newDecimals) {
        // Same precision - return this for immutability
        if (this.decimals === newDecimals) {
            return this;
        }
        const result = toDecimals(this, newDecimals, 'Amount.toDecimals');
        return new Amount(result.raw, result.decimals);
    }
    // ==========================================================================
    // Formatting Methods
    // ==========================================================================
    /**
   * Format this Amount as a human-readable string.
   *
   * @param options - Formatting options (locale, fraction digits, grouping).
   * @returns A formatted string (e.g., "1,000.50").
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1000.5', { decimals: 6 })
   * a.formatted()                              // "1,000.5"
   * a.formatted({ minimumFractionDigits: 2 }) // "1,000.50"
   * a.formatted({ useGrouping: false })       // "1000.5"
   * ```
   */ formatted(options = {}) {
        return formatted(this, options);
    }
    /**
   * Convert to a human-readable string.
   *
   * @returns A formatted string like "1.5".
   *
   * @remarks
   * For display with a token symbol, combine with the token registry:
   * ```typescript
   * `${amount.toString()} ${token.symbol}`
   * ```
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * a.toString() // "1.5"
   * ```
   */ toString() {
        return toString(this);
    }
    /**
   * Convert to a JSON-serializable object.
   *
   * @returns An object with raw (as string), decimals, and formatted value.
   *
   * @example
   * ```typescript
   * const a = Amount.parse('1.5', { decimals: 6 })
   * a.toJSON()
   * // { raw: "1500000", decimals: 6, formatted: "1.5" }
   * ```
   */ toJSON() {
        return toJSON(this);
    }
}

// ============================================================================
// Factory Options
// ============================================================================
// Static operation name for all prepare functions
const PREPARE_OPERATION_NAME = 'prepare';
/**
 * Create a PrepareResult wrapper around prepared transactions.
 *
 * @remarks
 * Types are inferred from `TPrepared`:
 * - `TInput` from `TPrepared['input']`
 * - `TBuilt` from `TPrepared['built']`
 * - `TRaw` from `TPrepared['execute']` return type
 *
 * @internal
 */ function createPrepareResult(options) {
    const { transactions, meta } = options;
    return {
        transactions,
        name: PREPARE_OPERATION_NAME,
        meta,
        single () {
            if (transactions.length !== 1) {
                throw createValidationFailedError('transactions', transactions.length, `Expected exactly 1 prepared transaction for single(), got ${String(transactions.length)}. ` + `For multiple transactions, iterate over .transactions or use execute()`);
            }
            const tx = transactions[0];
            if (tx === undefined) {
                throw createValidationFailedError('transactions', 0, 'Transaction at index 0 is undefined');
            }
            return tx;
        },
        async estimateTotal () {
            const estimates = await Promise.all(transactions.map(async (tx)=>tx.estimate()));
            const totalFee = estimates.length === 0 ? Amount.zero({
                decimals: 18
            }) : Amount.sum(estimates.map((e)=>e.fee));
            return {
                totalFee,
                count: transactions.length,
                estimates
            };
        },
        async execute (executeOptions) {
            const results = [];
            const { onTxSent } = executeOptions ?? {};
            for (const [i, tx] of transactions.entries()){
                // Execute and get wait function
                const { txId, wait } = await tx.execute();
                onTxSent?.(txId, i);
                // Wait for confirmation - cast is safe because TPrepared extends
                // PreparedTransactionBase which returns ExecuteResult<unknown>
                // and callers provide TRaw to match their custom type
                const confirmation = await wait();
                results.push(confirmation);
                // If transaction failed, stop execution
                if (!confirmation.success) {
                    return {
                        success: false,
                        results,
                        failedIndex: i
                    };
                }
            }
            return {
                success: true,
                results
            };
        }
    };
}
// ============================================================================
// Factory
// ============================================================================
/**
 * Create an observable prepare function.
 *
 * @typeParam TPrepared - The prepared transaction type. All other types are inferred.
 * @param options - Factory options.
 * @returns A prepare function that returns PrepareResult with properly typed transactions.
 *
 * @remarks
 * The returned function:
 * 1. Validates input (if inputSchema provided)
 * 2. Resolves operation context (chain, address)
 * 3. Resolves invocation context (traceId, runtime, callers)
 * 4. Wraps with observability middleware
 * 5. Calls user's prepare function
 * 6. Returns PrepareResult with helper methods
 *
 * **Type Inference:**
 * All types are inferred from `TPrepared`:
 * - `TInput` from `TPrepared['input']`
 * - `TBuilt` from `TPrepared['built']`
 * - `TRaw` from `TPrepared['execute']` return type
 *
 * **Custom Prepared Transaction Types:**
 * Pass your ecosystem-specific prepared transaction type as `TPrepared`.
 * It must extend `PreparedTransactionBase`.
 *
 * **Runtime Propagation:**
 * If `invocation.runtime` is provided, it supersedes the adapter's runtime.
 * This allows kits to pass their logger/events through the entire call chain.
 *
 * @example
 * ```typescript
 * // With custom prepared transaction type - types are inferred!
 * const prepareTransfer = createPrepare<PreparedEVMTransaction>({
 *   adapterContext,
 *   prepare: async (input, ctx) => {
 *     // Return PreparedEVMTransaction with custom estimate/simulate/execute
 *     return {
 *       input,
 *       built: rawTx,
 *       estimate: async () => estimateFn(rawTx, { chain }),
 *       simulate: async () => simulateFn(rawTx, { chain }),
 *       execute: async (overrides?) => executeFn({ raw: rawTx, overrides }, { chain }),
 *     }
 *   },
 * })
 *
 * // Usage - result.single() returns PreparedEVMTransaction
 * const result = await prepareTransfer(input, { chain, address })
 * const tx = result.single()
 * const fee = await tx.estimate()  // Properly typed!
 * ```
 */ function createPrepare(options) {
    const { adapterContext, prepare, inputSchema } = options;
    // ───────────────────────────────────────────────────────────────────────────
    // Build middleware stack once for performance (not on every call)
    // ───────────────────────────────────────────────────────────────────────────
    const middleware = createMiddlewareStack({
        config: adapterContext.config,
        normalizeError: adapterContext.normalizeError
    });
    /**
   * Validate input against the schema if provided.
   * Handles both single inputs and arrays.
   */ const validateInput = (input)=>{
        if (!inputSchema) return input;
        const inputs = Array.isArray(input) ? input : [
            input
        ];
        const validated = [];
        for(let i = 0; i < inputs.length; i++){
            const item = inputs[i];
            const parseResult = inputSchema.safeParse(item);
            if (!parseResult.success) {
                // Include index in error message for array inputs
                const context = Array.isArray(input) ? `${PREPARE_OPERATION_NAME} input[${String(i)}]` : `${PREPARE_OPERATION_NAME} input`;
                throw createValidationErrorFromZod(parseResult.error, context);
            }
            validated.push(parseResult.data);
        }
        // Return in same shape as input (single or array)
        if (Array.isArray(input)) return validated;
        const single = validated[0];
        if (single === undefined) {
            throw createValidationFailedError('input', undefined, 'Validated input is undefined');
        }
        return single;
    };
    return async (input, operation, invocation)=>{
        // ─────────────────────────────────────────────────────────────────────────
        // 1. Validate input if schema provided
        // ─────────────────────────────────────────────────────────────────────────
        const validatedInput = validateInput(input);
        // ─────────────────────────────────────────────────────────────────────────
        // 2. Resolve WHO/HOW - Invocation context (traceId, runtime, callers)
        // ─────────────────────────────────────────────────────────────────────────
        const invocationCtx = resolveAdapterInvocationContext(invocation, {
            runtime: adapterContext.runtime,
            tokens: adapterContext.tokens
        });
        // ─────────────────────────────────────────────────────────────────────────
        // 3. Resolve WHAT - Operation context (chain, address)
        //
        //    Uses the full resolveOperationContext (not read-only) because prepare
        //    is always a write operation that requires a sender address.
        //    Resolution is idempotent — if chain is already a ChainDefinition and
        //    address is already a string, they pass through unchanged.
        // ─────────────────────────────────────────────────────────────────────────
        const operationCtx = await resolveOperationContext$1(operation, {
            capabilities: adapterContext.capabilities,
            getAddress: adapterContext.getAddress,
            requireAddress: true
        });
        // The cast to TChain is safe: the adapter that supplies TChain is
        // also the one that registers chains of that type via its context.
        const resolvedCtx = {
            chain: operationCtx.chain,
            address: operationCtx.address,
            runtime: invocationCtx.runtime,
            tokens: invocationCtx.tokens,
            invocation: invocationCtx
        };
        // ─────────────────────────────────────────────────────────────────────────
        // 4. Create execution context FOR MIDDLEWARE
        // ─────────────────────────────────────────────────────────────────────────
        const execCtx = createExecutionContext({
            name: PREPARE_OPERATION_NAME,
            invocation: invocationCtx
        });
        // ─────────────────────────────────────────────────────────────────────────
        // 5. Call user's prepare function with validated input (with middleware)
        // ─────────────────────────────────────────────────────────────────────────
        const prepared = await runOperation(execCtx, middleware, async ()=>prepare(validatedInput, resolvedCtx));
        // ─────────────────────────────────────────────────────────────────────────
        // 6. Normalize to array and wrap in PrepareResult
        // ─────────────────────────────────────────────────────────────────────────
        const transactions = Array.isArray(prepared) ? prepared : [
            prepared
        ];
        return createPrepareResult({
            transactions,
            meta: invocation ?? {}
        });
    };
}

// ============================================================================
// Implementation
// ============================================================================
/**
 * Resolve all contexts needed for action execution.
 *
 * @param operation - User-provided operation metadata (chain, address).
 * @param adapterCtx - Adapter context with runtime and capabilities.
 * @param options - Optional action options (traceId, runtime override, callers).
 * @returns All resolved contexts needed for action execution.
 *
 * @remarks
 * This function performs two resolutions:
 * 1. **WHO/HOW** (invocation): traceId, runtime, callers, tokens
 * 2. **WHAT** (operation): chain, address
 *
 * It then builds derived contexts for different consumers:
 * - `actionContext`: For action handlers (has ChainDefinition)
 * - `adapterOpContext`: For adapter calls (has string/number chain ID)
 *
 * @example
 * ```typescript
 * const ctx = await resolveContexts(
 *   { chain: 'Ethereum' },
 *   adapterContext,
 *   { traceId: 'custom-trace' },
 * )
 *
 * // Use ctx.invocation for execution context
 * // Use ctx.actionContext for handlers
 * // Use ctx.adapterOpContext for adapter calls
 * ```
 */ async function resolveContexts(operation, adapterCtx, options) {
    // WHO/HOW: Resolve invocation context
    const invocation = resolveAdapterInvocationContext(options, {
        runtime: adapterCtx.runtime,
        tokens: adapterCtx.tokens
    });
    // WHAT: Resolve operation context
    const operationCtx = await resolveOperationContext$1(operation, {
        capabilities: adapterCtx.capabilities,
        getAddress: adapterCtx.getAddress
    });
    // Build derived contexts
    const actionContext = {
        chain: operationCtx.chain,
        address: operationCtx.address,
        traceId: invocation.traceId
    };
    return Object.freeze({
        invocation,
        operation: operationCtx,
        actionContext
    });
}

// ============================================================================
// No-op constants
// ============================================================================
/** Synthetic confirmation returned by noop write actions. */ const NOOP_CONFIRMATION = Object.freeze({
    success: true,
    txId: '',
    blockId: '',
    costUsed: Amount.zero({
        decimals: 0
    }),
    raw: undefined
});
/** Synthetic write result returned by the fast-path when the action is a noop. */ const NOOP_WRITE_RESULT = Object.freeze({
    txId: '',
    txIds: [],
    // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
    wait: ()=>Promise.resolve(NOOP_CONFIRMATION)
});
/**
 * Create a no-op `PreparedWriteAction` with zero transactions.
 *
 * @remarks
 * Used when a build callback calls `ctx.noop()` to signal that the action
 * has nothing to execute on this ecosystem (e.g. SPL allowance on Solana).
 */ function createNoopPreparedWriteAction(actionName, output) {
    return {
        transactions: [],
        name: actionName,
        meta: {},
        single: ()=>{
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `${actionName}: no-op action has no transactions`
            });
        },
        // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
        estimateTotal: ()=>Promise.resolve({
                totalFee: Amount.zero({
                    decimals: 0
                }),
                count: 0,
                estimates: []
            }),
        // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
        execute: ()=>Promise.resolve({
                success: true,
                results: [],
                failedIndex: undefined
            }),
        output
    };
}
// Implementation
function defineAction(options) {
    const { name, inputSchema, description } = options;
    if (!name || typeof name !== 'string') {
        throw createValidationFailedError('name', name, 'Action name must be a non-empty string');
    }
    return {
        name,
        inputSchema: inputSchema,
        description,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Concrete adapter generics are invariant; this bound preserves their inferred types.
        bind (bindOptions) {
            if ('execute' in bindOptions) {
                return createReadAction(name, inputSchema, bindOptions, description);
            }
            return createWriteAction(name, inputSchema, bindOptions, description);
        }
    };
}
// ============================================================================
// Input validation
// ============================================================================
/**
 * Validate an action's raw input against its schema.
 *
 * @remarks
 * Runs **before** {@link resolveContexts} so that malformed input fails fast
 * at the schema layer. Resolving the operation context can call
 * `adapterContext.getAddress`, which on a real wallet adapter pops a
 * connection / signing prompt and may perform a network round-trip — doing
 * that for input the SDK already knows is invalid is both wasteful and a
 * confusing UX. A `ZodError` is converted to the same
 * `INPUT_VALIDATION_FAILED` (FATAL) `KitError` the universal error
 * normalizer would have produced, with the raw error redacted onto
 * `cause.trace` for diagnostics.
 *
 * @typeParam T - The validated input type.
 * @param name - The action name (used in the error message).
 * @param schema - The action's input schema.
 * @param input - The raw, untrusted input.
 * @returns The parsed (and possibly transformed) input.
 * @throws {@link KitError} `INPUT_VALIDATION_FAILED` when validation fails.
 *
 * @internal
 */ function validateActionInput(name, schema, input) {
    const result = schema.safeParse(input);
    if (result.success) {
        return result.data;
    }
    throw new KitError({
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: `Input validation failed for ${name}.`,
        cause: {
            trace: {
                rawError: redactRawError(result.error)
            }
        }
    });
}
/** Attach the registered action name as the default authorization intent. */ function withActionAuthorizationIntent(name, options) {
    const descriptor = options?.authorization;
    return {
        ...options,
        authorization: {
            ...descriptor,
            intent: descriptor?.intent ?? {
                action: name
            }
        }
    };
}
// ============================================================================
// Read Action
// ============================================================================
function createReadAction(name, inputSchema, options, description) {
    const { adapter, execute } = options;
    const adapterContext = adapter.ctx;
    const action = async (input, operation, actionOptions)=>{
        // Validate before resolving context so garbage input never triggers a
        // wallet address prompt / network round-trip.
        const validatedInput = validateActionInput(name, inputSchema, input);
        const invocationOptions = withActionAuthorizationIntent(name, actionOptions);
        const ctx = await resolveContexts(operation, adapterContext, invocationOptions);
        const execCtx = createExecutionContext({
            name,
            description,
            invocation: ctx.invocation,
            tags: buildOperationTags(ctx.operation.chain, ctx.operation.address, actionOptions?.tags, adapterContext.identity),
            meta: actionOptions?.meta
        });
        const middleware = createMiddlewareStack({
            config: adapterContext.config,
            normalizeError: adapterContext.normalizeError
        });
        return runOperation(execCtx, middleware, async ()=>{
            // `chain` is narrowed via a two-step cast: the conditional
            // `AdapterChainOf<TAdapter>` cannot be resolved at this generic call site,
            // but adapters validate their supported chains before this point so the
            // runtime value is always correct. Every other field is still type-checked.
            const executeCtx = {
                ...ctx.actionContext,
                chain: ctx.actionContext.chain,
                adapter,
                tokens: ctx.invocation.tokens,
                invocation: ctx.invocation,
                read: async (readInput)=>adapter.read(readInput, operation, ctx.invocation)
            };
            return execute(validatedInput, executeCtx);
        });
    };
    Object.defineProperty(action, 'name', {
        value: name
    });
    Object.defineProperty(action, 'type', {
        value: 'read'
    });
    Object.defineProperty(action, 'description', {
        value: description
    });
    return action;
}
// ============================================================================
// Write Action
// ============================================================================
function createWriteAction(name, inputSchema, options, description) {
    const { adapter, build } = options;
    const adapterContext = adapter.ctx;
    /**
   * Build phase: validate input, run build callback, collect write intents.
   */ async function runBuild(input, operation, actionOptions) {
        // Validate before resolving context so garbage input never triggers a
        // wallet address prompt / network round-trip.
        const validatedInput = validateActionInput(name, inputSchema, input);
        const invocationOptions = withActionAuthorizationIntent(name, actionOptions);
        const ctx = await resolveContexts(operation, adapterContext, invocationOptions);
        const writeInputs = [];
        let isNoop = false;
        const execCtx = createExecutionContext({
            name: `${name}.prepare`,
            description,
            invocation: ctx.invocation,
            tags: buildOperationTags(ctx.operation.chain, ctx.operation.address, actionOptions?.tags, adapterContext.identity),
            meta: actionOptions?.meta
        });
        const middleware = createMiddlewareStack({
            config: adapterContext.config,
            normalizeError: adapterContext.normalizeError
        });
        const result = await runOperation(execCtx, middleware, async ()=>{
            // `chain` is cast to the narrowed type: the conditional
            // `AdapterChainOf<TAdapter>` cannot be proved at this generic call site,
            // but adapters validate their supported chains before this point so the
            // runtime value is always correct. Every other field is still type-checked.
            const buildCtx = {
                ...ctx.actionContext,
                chain: ctx.actionContext.chain,
                adapter,
                tokens: ctx.invocation.tokens,
                invocation: ctx.invocation,
                noop: ()=>{
                    isNoop = true;
                },
                write: (writeInput)=>{
                    writeInputs.push(writeInput);
                },
                read: async (readInput)=>adapter.read(readInput, operation, ctx.invocation)
            };
            const buildOutput = await build(validatedInput, buildCtx);
            return {
                output: buildOutput,
                writeInputs: [
                    ...writeInputs
                ]
            };
        });
        return {
            ...result,
            isNoop,
            ctx
        };
    }
    /**
   * Prepare: run build, then delegate to adapter.prepare().
   *
   * When the build callback called `ctx.noop()` and queued no writes,
   * a zero-cost, zero-transaction result is returned without touching
   * the adapter's prepare pipeline.
   */ const prepare = async (input, operation, actionOptions)=>{
        const { output, writeInputs, isNoop, ctx } = await runBuild(input, operation, actionOptions);
        if (isNoop && writeInputs.length === 0) {
            return createNoopPreparedWriteAction(name, output);
        }
        if (writeInputs.length === 0) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `${name}: no transactions to execute; build must call ctx.write() at least once`
            });
        }
        let prepareInput;
        if (writeInputs.length === 1) {
            const first = writeInputs[0];
            if (first === undefined) {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: `${name}: writeInputs must not contain undefined when length is 1`
                });
            }
            prepareInput = first;
        } else {
            prepareInput = writeInputs;
        }
        const prepareResult = await adapter.prepare(prepareInput, operation, ctx.invocation);
        return Object.assign(prepareResult, {
            output
        });
    };
    /**
   * Direct call (fast path): prepare, then estimate, then execute sequentially.
   */ const action = async (input, operation, actionOptions)=>{
        const prepared = await prepare(input, operation, actionOptions);
        if (actionOptions?.skipEstimate !== true) {
            await prepared.estimateTotal();
        }
        const txIds = [];
        const txs = prepared.transactions;
        // Noop actions return zero transactions — short-circuit with a synthetic result.
        if (txs.length === 0) {
            return NOOP_WRITE_RESULT;
        }
        // Execute all but the last tx fully (send + wait for confirmation)
        for(let i = 0; i < txs.length - 1; i++){
            const tx = txs[i];
            if (tx === undefined) continue;
            const { txId, wait } = await tx.execute();
            txIds.push(txId);
            const confirmation = await wait();
            if (!confirmation.success) {
                const waitFn = async ()=>{
                    return await Promise.resolve(confirmation);
                };
                return {
                    txId,
                    txIds,
                    wait: waitFn
                };
            }
        }
        // Execute the last tx — return immediately, wait is lazy
        const last = txs.at(-1);
        if (last === undefined) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `${name}: transactions array contains undefined; adapter must not return sparse arrays`
            });
        }
        const { txId, wait } = await last.execute();
        txIds.push(txId);
        return {
            txId,
            txIds,
            wait
        };
    };
    Object.defineProperty(action, 'name', {
        value: name
    });
    Object.defineProperty(action, 'type', {
        value: 'write'
    });
    Object.defineProperty(action, 'description', {
        value: description
    });
    Object.assign(action, {
        prepare
    });
    return action;
}

// ============================================================================
// Primitive Schemas
// ============================================================================
/**
 * Schema for blockchain addresses (chain-agnostic).
 *
 * @remarks
 * Accepts any non-empty string. Adapters validate chain-specific formats
 * (e.g., 0x... for EVM, base58 for Solana).
 */ const addressSchema = zod.z.string().trim().min(1, 'Address is required');
/**
 * Schema for non-negative bigint amounts.
 */ const amountSchema = zod.z.bigint().nonnegative('Amount must be non-negative');
/**
 * Schema for raw token selectors (object form with explicit locator).
 */ const rawTokenSelectorSchema = zod.z.object({
    locator: zod.z.string().min(1, 'Token locator is required'),
    decimals: zod.z.number().int().nonnegative().optional()
});
/**
 * Schema for token selectors.
 *
 * @remarks
 * Accepts either:
 * - A string (token symbol like `'USDC'` or a raw address like `'0xA0b8...'`)
 * - An object `{ locator, decimals? }` for arbitrary tokens with explicit info
 *
 * Resolution (symbol vs. address) is handled by the adapter binding layer.
 */ // Type assertion needed: Zod infers `decimals?: number | undefined` but
// RawTokenSelector uses `decimals?: number` (exactOptionalPropertyTypes).
const tokenSelectorSchema = zod.z.union([
    zod.z.string().trim().min(1, 'Token symbol or address is required'),
    rawTokenSelectorSchema
]).transform((val)=>val);
// ============================================================================
// Field Schemas (for composition)
// ============================================================================
/** Token selector field (symbol, address, or `{ locator, decimals? }`). */ const tokenField = zod.z.object({
    token: tokenSelectorSchema
});
/** Optional wallet address field. */ const walletField = zod.z.object({
    walletAddress: addressSchema.optional()
});
/** Delegate address field. */ const delegateField = zod.z.object({
    delegate: addressSchema
});
/** Recipient (to) address field. */ const recipientField = zod.z.object({
    to: addressSchema
});
/** Amount field. */ const amountField = zod.z.object({
    amount: amountSchema
});
// ============================================================================
// Composed Input Schemas
// ============================================================================
/**
 * Schema for balance queries (optional walletAddress).
 *
 * @example
 * ```typescript
 * // Used by native.balanceOf, usdc.balanceOf, usdt.balanceOf
 * inputSchema: balanceOfInputSchema
 * ```
 */ const balanceOfInputSchema = walletField;
/**
 * Schema for token balance queries (token + optional walletAddress).
 *
 * @example
 * ```typescript
 * // Used by token.balanceOf
 * inputSchema: tokenBalanceOfInputSchema
 * ```
 */ const tokenBalanceOfInputSchema = tokenField.merge(walletField);
/**
 * Schema for token metadata queries that need only the token.
 *
 * @example
 * ```typescript
 * // Used by token.name
 * inputSchema: tokenNameInputSchema
 * ```
 */ const tokenNameInputSchema = tokenField;
/**
 * Schema for allowance queries (token + optional walletAddress + delegate).
 *
 * @example
 * ```typescript
 * // Used by token.allowance
 * inputSchema: tokenAllowanceInputSchema
 * ```
 */ const tokenAllowanceInputSchema = tokenField.merge(walletField).merge(delegateField);
/**
 * Schema for approve actions (delegate + amount).
 *
 * @example
 * ```typescript
 * // Used by usdc.approve, usdt.approve
 * inputSchema: approveInputSchema
 * ```
 */ const approveInputSchema = delegateField.merge(amountField);
/**
 * Schema for token approve actions (token + delegate + amount).
 *
 * @example
 * ```typescript
 * // Used by token.approve
 * inputSchema: tokenApproveInputSchema
 * ```
 */ const tokenApproveInputSchema = tokenField.merge(approveInputSchema);
/**
 * Schema for transfer actions (to + amount).
 *
 * @example
 * ```typescript
 * // Used by usdc.transfer, usdt.transfer
 * inputSchema: transferInputSchema
 * ```
 */ const transferInputSchema = recipientField.merge(amountField);
/**
 * Schema for token transfer actions (token + to + amount).
 *
 * @example
 * ```typescript
 * // Used by token.transfer
 * inputSchema: tokenTransferInputSchema
 * ```
 */ const tokenTransferInputSchema = tokenField.merge(transferInputSchema);

const tokenBalanceOf = defineAction({
    name: 'token.balanceOf',
    description: 'Get the balance of a token for a wallet address',
    inputSchema: tokenBalanceOfInputSchema
});

// ============================================================================
// Action Definition
// ============================================================================
/**
 * Get the allowance a spender has for an owner's tokens.
 *
 * @remarks
 * EVM-specific concept. Solana uses different delegation patterns.
 */ const tokenAllowance = defineAction({
    name: 'token.allowance',
    description: "Get the allowance a spender has for an owner's tokens",
    inputSchema: tokenAllowanceInputSchema
});

// ============================================================================
// Action Definition
// ============================================================================
/**
 * Approve a spender to spend tokens on behalf of the caller.
 *
 * @remarks
 * EVM-specific concept. Solana uses different delegation patterns.
 */ const tokenApprove = defineAction({
    name: 'token.approve',
    description: 'Approve a spender to spend tokens',
    inputSchema: tokenApproveInputSchema
});

// ============================================================================
// Action Definition
// ============================================================================
/**
 * Transfer tokens from the caller to a recipient.
 */ const tokenTransfer = defineAction({
    name: 'token.transfer',
    description: 'Transfer tokens to a recipient',
    inputSchema: tokenTransferInputSchema
});

/**
 * Safely increase a spender's allowance without the approve-to-zero race condition.
 */ const tokenIncreaseAllowance = defineAction({
    name: 'token.increaseAllowance',
    description: 'Safely increase a spender allowance (ERC20 extension)',
    inputSchema: tokenApproveInputSchema
});

/**
 * Read the on-chain name of a token contract.
 *
 * @remarks
 * This is a chain-agnostic definition. The adapter provides the execute
 * function that handles chain-specific logic.
 *
 * @example
 * ```typescript
 * // EVM binding
 * const boundAction = tokenName.bind({
 *   adapter,
 *   execute: async (input, ctx) => {
 *     const name = await ctx.read<string>({
 *       address: input.token,
 *       abi: erc20Abi,
 *       functionName: 'name',
 *       args: [],
 *     })
 *     return { name }
 *   },
 * })
 * ```
 */ const tokenName = defineAction({
    name: 'token.name',
    description: 'Read the on-chain name of a token contract',
    inputSchema: tokenNameInputSchema
});

// ============================================================================
// Action Definition
// ============================================================================
/**
 * Get the native token balance for a wallet address.
 *
 * @remarks
 * Native tokens: ETH (Ethereum), SOL (Solana), SUI (Sui), etc.
 */ const nativeBalanceOf = defineAction({
    name: 'native.balanceOf',
    description: 'Get the native token balance for a wallet address',
    inputSchema: balanceOfInputSchema
});

// ============================================================================
// Action Definition
// ============================================================================
/**
 * Transfer native tokens (ETH, SOL, etc.) to a recipient.
 */ const nativeTransfer = defineAction({
    name: 'native.transfer',
    description: 'Transfer native tokens to a recipient',
    inputSchema: transferInputSchema
});

/**
 * Chain identifier field with narrowed output type.
 *
 * @remarks
 * `chainIdentifierSchema` validates correctly at runtime but Zod infers its
 * output as `string | Blockchain | ChainDefinition` because `z.string().refine()`
 * preserves the `string` base type. The `.transform()` narrows the output to
 * `ChainIdentifier` so schema-inferred input types match the declared interfaces.
 */ const chainIdentifierField = chainIdentifierSchema.transform((val)=>val);
// ============================================================================
// Schemas
// ============================================================================
const depositForBurnInputSchema = zod.z.object({
    amount: amountSchema,
    mintRecipient: addressSchema,
    destinationCaller: addressSchema.optional(),
    maxFee: amountSchema,
    minFinalityThreshold: zod.z.number().int().nonnegative(),
    toChain: chainIdentifierField
});
const receiveMessageInputSchema = zod.z.object({
    eventNonce: zod.z.string().min(1, 'Event nonce is required'),
    attestation: zod.z.string().min(1),
    message: zod.z.string().min(1),
    fromChain: chainIdentifierField,
    destinationAddress: addressSchema.optional(),
    mintRecipient: addressSchema.optional()
});
const HEX_32_BYTES$1 = /^0x[0-9a-fA-F]{64}$/;
const permitParamsSchema = zod.z.object({
    deadline: zod.z.bigint().positive('Permit deadline must be a positive timestamp'),
    v: zod.z.number().int(),
    r: zod.z.string().regex(HEX_32_BYTES$1, 'r must be a 0x-prefixed 32-byte hex string'),
    s: zod.z.string().regex(HEX_32_BYTES$1, 's must be a 0x-prefixed 32-byte hex string')
});
const customBurnBaseSchema = depositForBurnInputSchema.extend({
    protocolFee: amountSchema.optional(),
    feeRecipient: addressSchema.optional(),
    permitParams: permitParamsSchema.optional()
});
function refineFeeParams(data, ctx) {
    const fee = data.protocolFee ?? 0n;
    if (fee > 0n && data.feeRecipient === undefined) {
        ctx.addIssue({
            code: 'custom',
            path: [
                'feeRecipient'
            ],
            message: 'protocolFee requires feeRecipient. Specify where the fee should be sent.'
        });
    }
    if (data.feeRecipient !== undefined && fee === 0n) {
        ctx.addIssue({
            code: 'custom',
            path: [
                'protocolFee'
            ],
            message: 'feeRecipient requires non-zero protocolFee. Specify the fee amount to send.'
        });
    }
    if (data.protocolFee !== undefined && data.protocolFee === 0n) {
        ctx.addIssue({
            code: 'custom',
            path: [
                'protocolFee'
            ],
            message: 'protocolFee is explicitly set to 0. Omit the field if no fee is intended.'
        });
    }
}
const customBurnInputSchema = customBurnBaseSchema.superRefine(refineFeeParams);
const hookDataSchema = zod.z.string().min(4, 'hookData must contain at least one full byte (e.g. "0xAB")').regex(/^0x[0-9a-fA-F]+$/, 'hookData must be a 0x-prefixed hex string').refine((v)=>(v.length - 2) % 2 === 0, 'hookData hex payload must be an even number of characters (whole bytes)');
const depositForBurnWithHookInputSchema = depositForBurnInputSchema.extend({
    hookData: hookDataSchema
});
const customBurnWithHookInputSchema = customBurnBaseSchema.extend({
    hookData: hookDataSchema
}).superRefine(refineFeeParams);
// ============================================================================
// Action Definitions
// ============================================================================
/**
 * Burn USDC on source chain to initiate a CCTP v2 cross-chain transfer.
 */ const cctpV2DepositForBurn = defineAction({
    name: 'cctp.v2.depositForBurn',
    description: 'Burn USDC to initiate a CCTP v2 cross-chain transfer',
    inputSchema: depositForBurnInputSchema
});
/**
 * Submit a CCTP message and attestation to mint USDC on the destination chain.
 *
 * @remarks
 * The attestation must be obtained separately from Circle's attestation service.
 * This action submits both the message and attestation on-chain to trigger minting.
 */ const cctpV2ReceiveMessage = defineAction({
    name: 'cctp.v2.receiveMessage',
    description: 'Submit CCTP message and attestation to mint USDC on destination chain',
    inputSchema: receiveMessageInputSchema
});
/**
 * Burn USDC via custom bridge contract with protocol fees.
 */ const cctpV2CustomBurn = defineAction({
    name: 'cctp.v2.customBurn',
    description: 'Burn USDC via custom bridge contract with protocol fee support',
    inputSchema: customBurnInputSchema
});
/**
 * Burn USDC with hook data for automatic relay via Circle's Orbit relayer.
 *
 * @remarks
 * Calls `depositForBurnWithHook` on TokenMessengerV2, appending `hookData`
 * that signals the Orbit relayer to auto-mint on the destination chain.
 */ const cctpV2DepositForBurnWithHook = defineAction({
    name: 'cctp.v2.depositForBurnWithHook',
    description: 'Burn USDC with hook data for automatic relay via Orbit relayer',
    inputSchema: depositForBurnWithHookInputSchema
});
/**
 * Burn USDC via custom bridge contract with hook data for automatic relay.
 *
 * @remarks
 * Uses `bridgeWithPreapprovalAndHook` or `bridgeWithPermitAndHook` depending
 * on whether permit parameters are provided.
 */ const cctpV2CustomBurnWithHook = defineAction({
    name: 'cctp.v2.customBurnWithHook',
    description: 'Burn USDC via custom bridge contract with hook data for Orbit relayer',
    inputSchema: customBurnWithHookInputSchema
});

// ============================================================================
// Input Schemas
// ============================================================================
/**
 * Cross-field validator for permit / authorization signature inputs.
 *
 * @remarks
 * Permits and EIP-3009 authorizations may be supplied either as a single
 * compact `signature` string or as the split `v`/`r`/`s` triple. Mixing
 * the two forms is almost always a caller bug — exactly one shape must be
 * provided. Encoding this as a `superRefine` lets the runtime surface a
 * structured `ZodError` (and downstream `KitError`) at the schema layer
 * rather than waiting for the binding to throw a less-specific runtime
 * error during signature reconstruction.
 */ // Shared ECDSA signature-material schemas. Mirrors the constraints
// already enforced by CCTP v2's `permitParamsSchema` so Gateway permit /
// authorization inputs fail fast at the schema layer with a useful error
// instead of reverting on-chain with an opaque "invalid signature length".
const HEX_32_BYTES = /^0x[0-9a-fA-F]{64}$/;
const COMPACT_SIG_65 = /^0x[0-9a-fA-F]{130}$/;
// EIP-3009 / EIP-2612 nonces are bytes32.
const BYTES32_HEX = HEX_32_BYTES;
// Raw ECDSA recovery ids (0/1) and EIP-155 normalized ids (27/28).
const VALID_RECOVERY_IDS = new Set([
    0,
    1,
    27,
    28
]);
const compactSignatureSchema = zod.z.string().regex(COMPACT_SIG_65, 'signature must be a 0x-prefixed 65-byte hex string');
const signatureRSchema = zod.z.string().regex(HEX_32_BYTES, 'r must be a 0x-prefixed 32-byte hex string');
const signatureSSchema = zod.z.string().regex(HEX_32_BYTES, 's must be a 0x-prefixed 32-byte hex string');
const recoveryIdSchema = zod.z.number().int().refine((value)=>VALID_RECOVERY_IDS.has(value), 'v must be a valid ECDSA recovery id (0, 1, 27, or 28)');
function refineSignatureFields(data, ctx) {
    const hasCompact = data.signature !== undefined;
    const splitFields = [
        data.v,
        data.r,
        data.s
    ];
    const splitProvided = splitFields.filter((value)=>value !== undefined);
    const hasSplit = splitProvided.length > 0;
    const hasFullSplit = splitProvided.length === splitFields.length;
    if (hasCompact && hasSplit) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: 'Provide either `signature` or the `v`/`r`/`s` triple, not both.',
            path: [
                'signature'
            ]
        });
    }
    if (!hasCompact && !hasSplit) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: 'Missing signature: provide either `signature` or the `v`/`r`/`s` triple.',
            path: [
                'signature'
            ]
        });
    }
    if (!hasCompact && hasSplit && !hasFullSplit) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: 'Incomplete signature: `v`, `r`, and `s` must all be provided together.',
            path: [
                'v'
            ]
        });
    }
}
const gatewayDepositInputSchema = zod.z.object({
    token: addressSchema,
    value: amountSchema
});
const gatewayDepositForInputSchema = zod.z.object({
    token: addressSchema,
    depositor: addressSchema,
    value: amountSchema
});
const gatewayDepositWithPermitInputSchema = zod.z.object({
    token: addressSchema,
    owner: addressSchema,
    value: amountSchema,
    deadline: zod.z.bigint(),
    signature: compactSignatureSchema.optional(),
    v: recoveryIdSchema.optional(),
    r: signatureRSchema.optional(),
    s: signatureSSchema.optional()
}).superRefine(refineSignatureFields);
const gatewayDepositWithAuthorizationInputSchema = zod.z.object({
    token: addressSchema,
    from: addressSchema,
    value: amountSchema,
    validAfter: zod.z.bigint().nonnegative('validAfter must be a non-negative Unix timestamp'),
    validBefore: zod.z.bigint().nonnegative('validBefore must be a non-negative Unix timestamp'),
    nonce: zod.z.string().regex(BYTES32_HEX, 'nonce must be a 0x-prefixed 32-byte hex string'),
    signature: compactSignatureSchema.optional(),
    v: recoveryIdSchema.optional(),
    r: signatureRSchema.optional(),
    s: signatureSSchema.optional()
}).superRefine((data, ctx)=>{
    refineSignatureFields(data, ctx);
    // EIP-3009 defines a half-open validity window [validAfter, validBefore).
    // A window where `validBefore <= validAfter` can never be valid on-chain
    // — reject it here rather than letting it revert during settlement.
    if (data.validBefore <= data.validAfter) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: 'validBefore must be strictly greater than validAfter.',
            path: [
                'validBefore'
            ]
        });
    }
});
const gatewayAddDelegateInputSchema = zod.z.object({
    token: addressSchema,
    delegate: addressSchema
});
const gatewayRemoveDelegateInputSchema = zod.z.object({
    token: addressSchema,
    delegate: addressSchema
});
const gatewayIsDelegateInputSchema = zod.z.object({
    token: addressSchema,
    depositor: addressSchema,
    delegate: addressSchema
});
const gatewayInitiateWithdrawalInputSchema = zod.z.object({
    token: addressSchema,
    value: amountSchema
});
const gatewayWithdrawInputSchema = zod.z.object({
    token: addressSchema
});
const gatewayWithdrawingBalanceInputSchema = zod.z.object({
    token: addressSchema,
    depositor: addressSchema
});
const gatewayWithdrawalBlockInputSchema = zod.z.object({
    token: addressSchema,
    depositor: addressSchema
});
// Matches the `0x${string}` template literal used by GatewayBurnInput and
// GatewayMintInput. Empty body (just `0x`) is allowed because the downstream
// length checks are scheme-specific and live in the bindings.
const hexStringSchema$2 = zod.z.string().regex(/^0x[0-9a-fA-F]*$/, 'Expected a 0x-prefixed hex string');
const gatewayBurnInputSchema = zod.z.object({
    calldataBytes: hexStringSchema$2,
    signature: hexStringSchema$2
});
const gatewayMintInputSchema = zod.z.object({
    attestation: hexStringSchema$2,
    signature: hexStringSchema$2
});
const gatewaySignBurnIntentsInputSchema = zod.z.object({
    typedData: zod.z.unknown()
});
// ============================================================================
// Action Definitions
// ============================================================================
/** Deposit tokens into a Gateway Wallet account. */ const gatewayV1Deposit = defineAction({
    name: 'gateway.v1.deposit',
    description: 'Deposit tokens into a Gateway Wallet account',
    inputSchema: gatewayDepositInputSchema
});
/** Deposit tokens on behalf of another address. */ const gatewayV1DepositFor = defineAction({
    name: 'gateway.v1.depositFor',
    description: 'Deposit tokens on behalf of another address',
    inputSchema: gatewayDepositForInputSchema
});
/** Deposit with EIP-2612 permit (gasless approval). */ defineAction({
    name: 'gateway.v1.depositWithPermit',
    description: 'Deposit with EIP-2612 permit signature',
    inputSchema: gatewayDepositWithPermitInputSchema
});
/** Deposit with EIP-3009 authorization. */ defineAction({
    name: 'gateway.v1.depositWithAuthorization',
    description: 'Deposit with EIP-3009 transferWithAuthorization',
    inputSchema: gatewayDepositWithAuthorizationInputSchema
});
/** Grant delegate access on a Gateway account. */ const gatewayV1AddDelegate = defineAction({
    name: 'gateway.v1.addDelegate',
    description: 'Grant spending rights to a delegate',
    inputSchema: gatewayAddDelegateInputSchema
});
/** Revoke delegate access on a Gateway account. */ const gatewayV1RemoveDelegate = defineAction({
    name: 'gateway.v1.removeDelegate',
    description: 'Revoke spending rights from a delegate',
    inputSchema: gatewayRemoveDelegateInputSchema
});
/** Check whether an address is an authorized delegate. */ const gatewayV1IsDelegate = defineAction({
    name: 'gateway.v1.isDelegate',
    description: 'Check delegate authorization status',
    inputSchema: gatewayIsDelegateInputSchema
});
/** Initiate a delayed fund withdrawal. */ const gatewayV1InitiateWithdrawal = defineAction({
    name: 'gateway.v1.initiateWithdrawal',
    description: 'Start a delayed fund removal from a Gateway account',
    inputSchema: gatewayInitiateWithdrawalInputSchema
});
/** Complete a fund withdrawal after delay. */ const gatewayV1Withdraw = defineAction({
    name: 'gateway.v1.withdraw',
    description: 'Complete a fund removal after the withdrawal delay',
    inputSchema: gatewayWithdrawInputSchema
});
/** Read the pending withdrawal balance. */ const gatewayV1WithdrawingBalance = defineAction({
    name: 'gateway.v1.withdrawingBalance',
    description: 'Query pending withdrawal balance',
    inputSchema: gatewayWithdrawingBalanceInputSchema
});
/** Read the block number when withdrawal can be completed. */ const gatewayV1WithdrawalBlock = defineAction({
    name: 'gateway.v1.withdrawalBlock',
    description: 'Query withdrawal block number',
    inputSchema: gatewayWithdrawalBlockInputSchema
});
/** Execute a Gateway burn for cross-chain spend. */ const gatewayV1GatewayBurn = defineAction({
    name: 'gateway.v1.gatewayBurn',
    description: 'Burn tokens for a cross-chain spend',
    inputSchema: gatewayBurnInputSchema
});
/** Execute a Gateway mint on destination chain. */ const gatewayV1GatewayMint = defineAction({
    name: 'gateway.v1.gatewayMint',
    description: 'Mint tokens on destination chain',
    inputSchema: gatewayMintInputSchema
});
/**
 * Sign burn intents for the Gateway API.
 *
 * @remarks
 * Modelled as a `ReadAction` because this is an off-chain signing operation
 * that returns a signature rather than producing an on-chain transaction.
 */ const gatewayV1SignBurnIntents = defineAction({
    name: 'gateway.v1.signBurnIntents',
    description: 'Sign burn intents for Gateway transfer',
    inputSchema: gatewaySignBurnIntentsInputSchema
});

var EarnPermitType;
(function(EarnPermitType) {
    /** No permit required — tokens must be pre-approved. */ EarnPermitType[EarnPermitType["NONE"] = 0] = "NONE";
    /** EIP-2612 standard permit. */ EarnPermitType[EarnPermitType["EIP2612"] = 1] = "EIP2612";
})(EarnPermitType || (EarnPermitType = {}));
// ============================================================================
// Schemas
// ============================================================================
// EIP-712 signatures produced by Circle's proxy service are always 65 bytes
// (r=32, s=32, v=1) — 130 hex chars after the `0x` prefix.
const eip712SignatureSchema$1 = zod.z.string().regex(/^0x[0-9a-fA-F]{130}$/, 'Expected a 0x-prefixed 65-byte EIP-712 signature (130 hex chars)');
const hexAddressSchema$1 = zod.z.string().regex(/^0x[0-9a-fA-F]{40}$/, 'Expected a 0x-prefixed 20-byte EVM address (40 hex chars)');
const hexBytesSchema = zod.z.string().regex(/^0x([0-9a-fA-F]{2})*$/, 'Expected a 0x-prefixed even-length hex string');
const uint256Schema$1 = zod.z.bigint().nonnegative();
const earnTokenInputSchema = zod.z.object({
    permitType: zod.z.nativeEnum(EarnPermitType),
    token: hexAddressSchema$1,
    amount: uint256Schema$1,
    permitCalldata: hexBytesSchema
}).strict();
const earnExecuteParamsSchema = zod.z.object({}).passthrough();
const earnExecuteInputSchema = zod.z.object({
    executeParams: earnExecuteParamsSchema,
    tokenInputs: zod.z.array(earnTokenInputSchema),
    signature: eip712SignatureSchema$1
}).strict();
// ============================================================================
// Action Definitions
// ============================================================================
/**
 * `earn.deposit` action definition.
 *
 * @remarks
 * Forwards service-signed `executeParams` and `signature` to the Adapter
 * Contract's `execute` function. The earn provider issues a separate
 * token allowance before calling this action.
 *
 * @example
 * ```typescript
 * import { earnDeposit } from '@core/adapter-base'
 *
 * const action = earnDeposit.bind({ adapter, build: depositBuild })
 * const prepared = await action.prepare(input, ctx)
 * ```
 */ defineAction({
    name: 'earn.deposit',
    description: 'Deposit tokens into an earn vault',
    inputSchema: earnExecuteInputSchema
});
/**
 * `earn.withdraw` action definition.
 *
 * @remarks
 * Same wire format as `earn.deposit`. The earn provider handles any required
 * allowance or balance checks before calling this action.
 *
 * @example
 * ```typescript
 * import { earnWithdraw } from '@core/adapter-base'
 *
 * const action = earnWithdraw.bind({ adapter, build: withdrawBuild })
 * const prepared = await action.prepare(input, ctx)
 * ```
 */ defineAction({
    name: 'earn.withdraw',
    description: 'Withdraw tokens from an earn vault',
    inputSchema: earnExecuteInputSchema
});
/**
 * `earn.claimRewards` action definition.
 *
 * @remarks
 * Same wire format as `earn.deposit` / `earn.withdraw`. Claim rewards does
 * not pull user tokens, so `tokenInputs` is typically an empty array.
 *
 * @example
 * ```typescript
 * import { earnClaimRewards } from '@core/adapter-base'
 *
 * const action = earnClaimRewards.bind({ adapter, build: claimBuild })
 * const prepared = await action.prepare(input, ctx)
 * ```
 */ defineAction({
    name: 'earn.claimRewards',
    description: 'Claim accrued rewards from an earn vault',
    inputSchema: earnExecuteInputSchema
});

var SwapPermitType;
(function(SwapPermitType) {
    /** No permit required — tokens must be pre-approved. */ SwapPermitType[SwapPermitType["NONE"] = 0] = "NONE";
    /** EIP-2612 standard permit. */ SwapPermitType[SwapPermitType["EIP2612"] = 1] = "EIP2612";
})(SwapPermitType || (SwapPermitType = {}));
// ============================================================================
// Input Schema
// ============================================================================
// Matches the `0x${string}` template literal used by EVM swap inputs. Body is
// optional because metadata/permit calldata may legitimately be empty.
const hexStringSchema$1 = zod.z.string().regex(/^0x[0-9a-fA-F]*$/, 'Expected a 0x-prefixed hex string');
const hexAddressSchema = zod.z.string().regex(/^0x[0-9a-fA-F]{40}$/, 'Expected a 0x-prefixed 20-byte hex address');
// EIP-712 signatures produced by Circle's proxy service are always 65 bytes
// (r=32, s=32, v=1) — 130 hex chars after the `0x` prefix. Accepting anything
// shorter lets malformed signatures reach the contract where they fail with
// a cryptic onchain error instead of a clear input error.
const eip712SignatureSchema = zod.z.string().regex(/^0x[0-9a-fA-F]{130}$/, 'Expected a 0x-prefixed 65-byte EIP-712 signature (130 hex chars)');
// Standard base64 alphabet with optional padding. Rejects whitespace, URL-safe
// variants, and truncated payloads (non-multiple-of-4 length). The `+`
// quantifier on the leading group intentionally rejects empty strings and
// padding-only inputs like `====` — an empty serialized transaction is not
// valid input and should be caught at the schema layer rather than surfaced
// later as a cryptic deserialize failure. The Solana binding additionally
// verifies that the decoded buffer is non-empty so that
// `VersionedTransaction.deserialize` always receives valid bytes.
const base64Schema = zod.z.string().regex(/^(?:[A-Za-z0-9+/]{4})+(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/, 'Expected a non-empty base64-encoded string (length multiple of 4, optional `=` padding)');
// All swap amounts map to `uint256` fields on-chain. A negative `bigint`
// silently wraps to `2^256 - n`, so reject it at the schema layer.
const uint256Schema = zod.z.bigint().nonnegative();
const swapInstructionSchema = zod.z.object({
    target: hexAddressSchema,
    data: hexStringSchema$1,
    value: uint256Schema,
    tokenIn: hexAddressSchema,
    amountToApprove: uint256Schema,
    tokenOut: hexAddressSchema,
    minTokenOut: uint256Schema
}).strict();
const swapTokenRecipientSchema = zod.z.object({
    token: hexAddressSchema,
    beneficiary: hexAddressSchema
}).strict();
// Upper bound on instructions per swap. A payload with tens of thousands
// of instructions still satisfies `.min(1)` but burns CPU on parsing and
// simulation (gas-bomb / DoS surface). 64 comfortably exceeds any real
// stablecoin-service route while bounding the worst case.
const MAX_SWAP_INSTRUCTIONS = 64;
const swapExecuteParamsSchema = zod.z.object({
    // A swap with zero instructions is a no-op on-chain — reject early at
    // the schema layer rather than letting it surface as a confusing revert.
    instructions: zod.z.array(swapInstructionSchema).min(1).max(MAX_SWAP_INSTRUCTIONS),
    tokens: zod.z.array(swapTokenRecipientSchema),
    execId: uint256Schema,
    deadline: uint256Schema,
    metadata: hexStringSchema$1
}).strict();
const swapTokenInputSchema = zod.z.object({
    permitType: zod.z.nativeEnum(SwapPermitType),
    token: hexAddressSchema,
    amount: uint256Schema,
    permitCalldata: hexStringSchema$1
}).strict();
const executeSwapEVMInputSchema = zod.z.object({
    executeParams: swapExecuteParamsSchema,
    tokenInputs: zod.z.array(swapTokenInputSchema),
    signature: eip712SignatureSchema,
    inputAmount: uint256Schema,
    tokenInAddress: hexAddressSchema
}).strict();
const executeSwapSolanaInputSchema = zod.z.object({
    serializedTransaction: base64Schema
}).strict();
// Chain-specific inputs are structurally disjoint — the EVM shape owns
// `executeParams`/`tokenInputs`/`signature`, the Solana shape owns
// `serializedTransaction`. We can't use `z.discriminatedUnion` directly
// because there's no shared literal tag field on the wire; the wire payload
// is what the stablecoin-service returns verbatim and must stay unchanged.
//
// Instead we emulate a discriminated union: pick the correct branch based
// on the presence of a discriminating property so Zod reports errors for
// that branch only (much clearer than the generic "invalid union" message
// `z.union` emits). Unknown branches fall through to a rejection.
const executeSwapInputSchema = zod.z.unknown().superRefine((value, ctx)=>{
    if (typeof value !== 'object' || value === null) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: 'swap.execute input must be an object containing either EVM ' + '(executeParams, tokenInputs, signature, inputAmount, ' + 'tokenInAddress) or Solana (serializedTransaction) fields.'
        });
        return;
    }
    const obj = value;
    // Reject hybrid payloads that carry both ecosystems' discriminating
    // fields. Without this, `serializedTransaction` would silently win the
    // branch selection below even when EVM fields are also present, hiding
    // genuine EVM validation errors behind a Solana parse.
    const hasSolana = 'serializedTransaction' in obj;
    const hasEvm = 'executeParams' in obj;
    if (hasSolana && hasEvm) {
        ctx.addIssue({
            code: zod.z.ZodIssueCode.custom,
            message: 'swap.execute input is ambiguous: it carries both Solana ' + '(`serializedTransaction`) and EVM (`executeParams`) fields. ' + 'Provide exactly one ecosystem payload.'
        });
        return;
    }
    if (hasSolana) {
        const result = executeSwapSolanaInputSchema.safeParse(value);
        if (!result.success) {
            for (const issue of result.error.issues){
                ctx.addIssue(issue);
            }
        }
        return;
    }
    if (hasEvm) {
        const result = executeSwapEVMInputSchema.safeParse(value);
        if (!result.success) {
            for (const issue of result.error.issues){
                ctx.addIssue(issue);
            }
        }
        return;
    }
    ctx.addIssue({
        code: zod.z.ZodIssueCode.custom,
        message: 'swap.execute input is neither an EVM nor a Solana payload. Expected ' + 'either `serializedTransaction` (Solana) or `executeParams` plus ' + '`tokenInputs`, `signature`, `inputAmount`, `tokenInAddress` (EVM).'
    });
}).transform((value)=>value);
// ============================================================================
// Action Definitions
// ============================================================================
/**
 * Execute a pre-built swap transaction.
 *
 * @remarks
 * The `executeParams`, `tokenInputs` / `signature` (EVM) or
 * `serializedTransaction` (Solana) are supplied by the stablecoin-service
 * `createSwap` endpoint and must be forwarded unmodified. Ecosystem bindings
 * narrow the union input at runtime and dispatch to the appropriate transport.
 */ const swapExecute = defineAction({
    name: 'swap.execute',
    description: 'Execute a pre-built swap transaction',
    inputSchema: executeSwapInputSchema
});

/**
 * Action registry types and composition helpers.
 *
 * @remarks
 * Provides:
 * - `BaseActionRegistry` — the minimum set of actions every adapter must expose
 * - `StablecoinXxxInput` — input types for stablecoin wrappers (token omitted)
 * - `withToken` / `withTokenWrite` — compose a stablecoin action from a generic
 *   token action by pre-filling the `token` field
 *
 * Ecosystem packages (`@core/adapter-evm-base`, etc.) extend `BaseActionRegistry`
 * with chain-specific actions and use the composition helpers to create defaults.
 *
 * @packageDocumentation
 */ // ============================================================================
// Composition Helpers
// ============================================================================
/**
 * Create a stablecoin read action by pre-filling the `token` field.
 *
 * @param action - The generic token read action (e.g. bound `tokenBalanceOf`).
 * @param token - The token to inject (symbol or selector).
 * @returns A read action that accepts input without the `token` field.
 *
 * @remarks
 * Pure function composition — no context resolution, no Zod re-validation,
 * no inject chains. The generic action handles all of that.
 *
 * @example
 * ```typescript
 * const usdcBalanceOf = withToken(tokenBalanceOf, 'USDC')
 * const { amount } = await usdcBalanceOf({ walletAddress: '0x...' }, { chain: Ethereum })
 * ```
 */ function withToken(action, token) {
    // Type assertions are required: TS cannot prove Omit<T,'token'> & {token} ≡ T & {token}
    const derived = async (input, operation, options)=>action({
            ...input,
            token
        }, operation, options);
    Object.defineProperty(derived, 'name', {
        value: action.name
    });
    Object.defineProperty(derived, 'type', {
        value: 'read'
    });
    if (action.description !== undefined) {
        Object.defineProperty(derived, 'description', {
            value: action.description
        });
    }
    return derived;
}
/**
 * Create a stablecoin write action by pre-filling the `token` field.
 *
 * @param action - The generic token write action (e.g. bound `tokenApprove`).
 * @param token - The token to inject (symbol or selector).
 * @returns A write action that accepts input without the `token` field.
 *
 * @remarks
 * Forwards both the direct call and `.prepare()` to the parent action.
 *
 * @example
 * ```typescript
 * const usdcApprove = withTokenWrite(tokenApprove, 'USDC')
 * await usdcApprove({ delegate: '0x...', amount: 1000000n }, { chain, address })
 * ```
 */ function withTokenWrite(action, token) {
    // Type assertions are required: TS cannot prove Omit<T,'token'> & {token} ≡ T & {token}
    const withInjected = (input)=>({
            ...input,
            token
        });
    const derived = async (input, operation, options)=>action(withInjected(input), operation, options);
    derived.prepare = async (input, operation, options)=>action.prepare(withInjected(input), operation, options);
    Object.defineProperty(derived, 'name', {
        value: action.name
    });
    Object.defineProperty(derived, 'type', {
        value: 'write'
    });
    if (action.description !== undefined) {
        Object.defineProperty(derived, 'description', {
            value: action.description
        });
    }
    return derived;
}

// ============================================================================
// Unsupported-Action Sentinel
// ============================================================================
/**
 * Create a callback that throws `INPUT_UNSUPPORTED_ACTION` when invoked.
 * Used internally to fill binding slots that the ecosystem did not provide.
 */ function unsupported(actionName) {
    return ()=>{
        throw new KitError({
            ...InputError.UNSUPPORTED_ACTION,
            recoverability: 'FATAL',
            message: `Action "${actionName}" is not supported by this adapter.`
        });
    };
}
// ============================================================================
// usdc.name — Chain-Scoped Alias (Deliberately Not withToken)
// ============================================================================
/**
 * Compose the `usdc.name` alias from `chain.usdcAddress`, never the registry.
 *
 * @remarks
 * Every other `usdc.*` alias is `withToken(bound, 'USDC')`: it injects the
 * registry symbol `'USDC'`, which a consumer's custom `TokenRegistry` is
 * free to redirect. That is the right behavior for balance, allowance,
 * approve, and transfer — those calls only need to agree with themselves
 * about which contract to hit.
 *
 * `usdc.name` is different: its result feeds Gateway's EIP-712 domain for
 * the `permit` / `authorize` deposit strategies, and that domain's
 * `verifyingContract` is `chain.usdcAddress` — resolved independently, not
 * through this action. If a registry override pointed `'USDC'` elsewhere,
 * `usdc.name` would describe a different contract than the one the
 * signature actually authorizes. The two would disagree, and the resulting
 * signature would fail to validate on-chain with no error from the SDK. So
 * this alias reads `chain.usdcAddress` directly — the same address the
 * legacy (pre-`/next`) `usdc.name` action always read — and never
 * consults the registry. Do not change this back to
 * `withToken(boundTokenName, 'USDC')`.
 *
 * `decimals` is hardcoded to `0` on the injected token because `token.name`
 * never reads it — only `locator` reaches the on-chain `name()` call — and
 * a real value would cost an extra on-chain `decimals()` read for nothing.
 *
 * @param action - The bound `token.name` read action.
 * @returns A read action that resolves USDC from the operation's chain.
 * @throws {KitError} `INPUT_UNSUPPORTED_TOKEN` when the chain has no
 *   `usdcAddress` configured.
 */ function withChainUsdcToken(action) {
    const derived = async (input, operation, options)=>{
        const chain = resolveChainIdentifier(operation.chain);
        const usdcAddress = chain.usdcAddress;
        if (usdcAddress == null) {
            throw new KitError({
                ...InputError.UNSUPPORTED_TOKEN,
                recoverability: 'FATAL',
                message: `Chain "${chain.name}" has no usdcAddress configured.`
            });
        }
        return action({
            ...input,
            token: {
                locator: usdcAddress,
                decimals: 0
            }
        }, operation, options);
    };
    Object.defineProperty(derived, 'name', {
        value: action.name
    });
    Object.defineProperty(derived, 'type', {
        value: 'read'
    });
    if (action.description !== undefined) {
        Object.defineProperty(derived, 'description', {
            value: action.description
        });
    }
    return derived;
}
// ============================================================================
// Factory
// ============================================================================
/**
 * Create a complete {@link BaseActionRegistry} from ecosystem-specific binding
 * callbacks.
 *
 * @remarks
 * Internally calls each action definition's `.bind()` and composes USDC
 * stablecoin aliases via `withToken` / `withTokenWrite`. Omitted bindings
 * are filled with handlers that throw `INPUT_UNSUPPORTED_ACTION`.
 *
 * Ecosystem adapters that need additional actions beyond the base set
 * (e.g. CCTP bridge actions) can spread the returned registry:
 *
 * ```typescript
 * const base = createActionBindings({ adapter, bindings: { ... } })
 * const full: MyActionRegistry = {
 *   ...base,
 *   'bridge.send': bindBridgeSend(adapter),
 * }
 * ```
 *
 * @typeParam TAdapter - The concrete adapter type.
 * @param config - Adapter instance and per-action callbacks.
 * @returns A fully wired `BaseActionRegistry` including `usdc.*` aliases.
 */ function createActionBindings(config) {
    const { adapter, bindings } = config;
    // Read bindings (execute callbacks)
    const boundTokenBalanceOf = tokenBalanceOf.bind({
        adapter,
        execute: bindings['token.balanceOf'] ?? unsupported('token.balanceOf')
    });
    const boundTokenAllowance = tokenAllowance.bind({
        adapter,
        execute: bindings['token.allowance'] ?? unsupported('token.allowance')
    });
    const boundNativeBalanceOf = nativeBalanceOf.bind({
        adapter,
        execute: bindings['native.balanceOf'] ?? unsupported('native.balanceOf')
    });
    const boundTokenName = tokenName.bind({
        adapter,
        execute: bindings['token.name'] ?? unsupported('token.name')
    });
    // Write bindings (build callbacks)
    const boundTokenApprove = tokenApprove.bind({
        adapter,
        build: bindings['token.approve'] ?? unsupported('token.approve')
    });
    const boundTokenTransfer = tokenTransfer.bind({
        adapter,
        build: bindings['token.transfer'] ?? unsupported('token.transfer')
    });
    const boundTokenIncreaseAllowance = tokenIncreaseAllowance.bind({
        adapter,
        build: bindings['token.increaseAllowance'] ?? unsupported('token.increaseAllowance')
    });
    const boundNativeTransfer = nativeTransfer.bind({
        adapter,
        build: bindings['native.transfer'] ?? unsupported('native.transfer')
    });
    return {
        // Generic token actions
        'token.balanceOf': boundTokenBalanceOf,
        'token.allowance': boundTokenAllowance,
        'token.approve': boundTokenApprove,
        'token.transfer': boundTokenTransfer,
        'token.increaseAllowance': boundTokenIncreaseAllowance,
        'token.name': boundTokenName,
        // Native actions
        'native.balanceOf': boundNativeBalanceOf,
        'native.transfer': boundNativeTransfer,
        // USDC stablecoin aliases (auto-composed)
        'usdc.balanceOf': withToken(boundTokenBalanceOf, 'USDC'),
        'usdc.allowance': withToken(boundTokenAllowance, 'USDC'),
        'usdc.approve': withTokenWrite(boundTokenApprove, 'USDC'),
        'usdc.transfer': withTokenWrite(boundTokenTransfer, 'USDC'),
        'usdc.increaseAllowance': withTokenWrite(boundTokenIncreaseAllowance, 'USDC'),
        'usdc.name': withChainUsdcToken(boundTokenName)
    };
}

/**
 * No-op binding callbacks for ecosystems that do not support certain actions.
 *
 * @remarks
 * Some ecosystems lack concepts that exist on others. For example, Solana has
 * no ERC-20-style `approve` / `allowance` mechanism. Rather than leaving
 * those action slots empty (which would break orchestration code), ecosystem
 * adapters can fill them with no-op callbacks:
 *
 * ```typescript
 * import { createActionBindings, noopBuild, noopWith } from '@core/adapter-base'
 * import { Amount } from '@core/amounts'
 *
 * const MAX_U64 = 2n ** 64n - 1n
 *
 * const actions = createActionBindings({
 *   adapter,
 *   bindings: {
 *     'token.balanceOf':          solanaTokenBalanceOfExecute,
 *     'token.allowance':          noopWith({ amount: Amount.from(MAX_U64, { decimals: 6 }) }),
 *     'token.approve':            noopWith({ amount: Amount.from(0n, { decimals: 0 }) }),
 *     'token.transfer':           solanaTokenTransferBuild,
 *     'token.increaseAllowance':  noopBuild,
 *     'native.balanceOf':         solanaNativeBalanceOfExecute,
 *     'native.transfer':          solanaNativeTransferBuild,
 *   },
 * })
 * ```
 *
 * @packageDocumentation
 */ /**
 * Check whether a value has a callable `noop` method.
 *
 * @param ctx - The value to check (typically a `BuildContext`).
 * @returns `true` if `ctx` is an object with a `noop` function.
 */ function hasNoop(ctx) {
    return ctx !== null && typeof ctx === 'object' && 'noop' in ctx && typeof ctx['noop'] === 'function';
}
/**
 * A no-op build callback that signals "this action has no work to do."
 *
 * @remarks
 * Use for write actions whose concept does not exist on the target ecosystem
 * (e.g. `token.increaseAllowance` on Solana). Calls `ctx.noop()` to
 * short-circuit the prepare/estimate/execute flow, producing a zero-cost,
 * zero-transaction result.
 *
 * Both parameters are typed as `unknown` so the callback is structurally
 * assignable to any binding callback signature via TypeScript's function
 * parameter contravariance (`T` is always assignable to `unknown`).
 *
 * @param _input - Action input (ignored).
 * @param ctx - Build or execute context; only `BuildContext.noop()` is called.
 */ const noopBuild = (_input, ctx)=>{
    if (hasNoop(ctx)) {
        ctx.noop();
    }
};
/**
 * Create a no-op callback that returns a fixed output value.
 *
 * @remarks
 * Works for both read and write action bindings:
 *
 * - **Read actions** — the second argument is an `ExecuteContext` (no `noop`
 *   method); the callback simply returns the fixed output.
 * - **Write actions** — the second argument is a `BuildContext` with a
 *   `noop()` method; the callback calls `ctx.noop()` to short-circuit the
 *   prepare/estimate/execute flow, then returns the fixed output.
 *
 * Both parameters are typed as `unknown` so the callback is structurally
 * assignable to any binding callback signature via TypeScript's function
 * parameter contravariance.
 *
 * @typeParam TOutput - The output type the callback must return.
 * @param output - The fixed value to return on every invocation.
 * @returns A callback suitable for `createActionBindings` bindings.
 */ function noopWith(output) {
    // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
    return (_input, ctx)=>{
        if (hasNoop(ctx)) {
            ctx.noop();
        }
        return Promise.resolve(output);
    };
}

/**
 * Create a type-safe action dispatch function from an action registry.
 *
 * @remarks
 * Accepts any object whose string-keyed values are callable. TypeScript
 * interfaces lack implicit index signatures, so the function parameter
 * uses `{ [K in keyof T]: T[K] }` to structurally map the registry
 * instead of requiring `Record<string, ...>` directly.
 *
 * @typeParam TRegistry - The action registry type.
 * @param actions - The action registry.
 * @returns An overloaded dispatch function.
 */ function createActionDispatch$1(actions) {
    // The internal dispatch narrows via `keyof` at the call site. The
    // overload signatures on `ActionDispatch` guarantee type safety for
    // callers. Inside the implementation we must use a widened record
    // because `(...args: never[]) => unknown` is not directly callable.
    // Required: TS interfaces lack implicit index signatures; the generic
    // constraint ensures only valid registries are accepted at call sites.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const registry = actions;
    function dispatch(key, ...args) {
        const fn = registry[key];
        if (fn === undefined) {
            throw new KitError({
                ...InputError.UNSUPPORTED_ACTION,
                recoverability: 'FATAL',
                message: `Action "${key}" is not registered in this adapter.`
            });
        }
        if (args.length === 0) return fn;
        return fn(...args);
    }
    return dispatch;
}

/**
 * Helper for resolving the chain name from an error context.
 *
 * @packageDocumentation
 */ /**
 * Extract the chain name from an error context.
 *
 * @remarks
 * Shared across all ecosystems. Resolution is **tags-first**: the
 * canonical `chain` dimension is written to `ctx.tags.chain` by
 * `buildOperationTags` on the execution context, and the error
 * middleware forwards it here. `ctx.meta.chain` is consulted only as a
 * fallback (it is the per-call overlay and is usually empty), so reading
 * meta-first would make every fallback/Zod-normalized error report the
 * generic default (e.g. `"EVM"`) instead of the real chain.
 *
 * @param ctx - Optional error context from the middleware stack.
 * @param defaultChain - Fallback chain name.
 * @returns The resolved chain name.
 *
 * @example
 * ```typescript
 * import { getChainName } from '@core/adapter-base'
 *
 * getChainName({ name: 'op', tags: { chain: 'Ethereum' } }, 'EVM')
 * // => 'Ethereum'
 *
 * getChainName(undefined, 'EVM')
 * // => 'EVM'
 * ```
 */ function getChainName(ctx, defaultChain) {
    const fromTags = ctx?.tags?.['chain'];
    if (typeof fromTags === 'string') return fromTags;
    const fromMeta = ctx?.meta?.['chain'];
    if (typeof fromMeta === 'string') return fromMeta;
    return defaultChain;
}

/**
 * Detect a Zod validation error without depending on a single `zod`
 * instance.
 *
 * @remarks
 * Each `dist/*` adapter bundle can ship its own copy of `zod`, so
 * `error instanceof ZodError` against any one import will return
 * `false` for ZodErrors thrown across the package boundary (the same
 * cross-bundle identity problem that affects {@link KitError} itself).
 * Use the public shape — `name === 'ZodError'` and `Array.isArray(issues)`
 * — which is stable across all `zod@3.x` releases.
 *
 * @internal
 */ function isZodError(error) {
    if (!(error instanceof Error)) return false;
    if (error.name !== 'ZodError') return false;
    const issues = error.issues;
    // A bare `{ name: 'ZodError', issues: [] }` (or one whose entries are
    // not ZodIssue-shaped) is not a real validation failure. Accepting it
    // would let any unrelated error spoof its way into
    // INPUT_VALIDATION_FAILED (FATAL), bypassing the framework / pattern
    // stages and flipping retry semantics for genuine RPC errors. Require
    // a non-empty array of ZodIssue-shaped entries (`code: string`,
    // `path: unknown[]`) — stable across all `zod@3.x` releases.
    return Array.isArray(issues) && issues.length > 0 && issues.every(isZodIssueLike);
}
/**
 * Narrow an unknown value to the public `ZodIssue` shape.
 *
 * @internal
 */ function isZodIssueLike(value) {
    if (typeof value !== 'object' || value === null) return false;
    const candidate = value;
    return typeof candidate.code === 'string' && Array.isArray(candidate.path);
}
/**
 * Create an error normalizer from ecosystem-specific callbacks.
 *
 * @remarks
 * The returned normalizer executes in this order:
 *
 * 1. **Re-throw `KitError`** — already normalized, pass through.
 * 2. **ZodError short-circuit** — input-schema validation failures
 *    cannot be helped by a chain-specific framework handler or by
 *    a pattern match against an RPC error message; surface them as
 *    `INPUT_VALIDATION_FAILED` (FATAL) directly so the action retry
 *    middleware bypasses them and observability does not chase a
 *    phantom RPC issue.
 * 3. **Framework handler** — match library-specific error types
 *    (e.g., viem `ContractFunctionExecutionError`, ethers `CALL_EXCEPTION`).
 * 4. **Extract message** — get a human-readable string from the raw error.
 * 5. **Pattern matching** — match the message against known error patterns
 *    (e.g., "insufficient funds", "out of gas", "revert").
 * 6. **Fallback** — throw a generic `RPC_ENDPOINT_ERROR`.
 *
 * @param options - Ecosystem-specific callbacks.
 * @returns An error normalizer function that throws normalized KitError instances.
 *
 * @example
 * ```typescript
 * import { createErrorNormalizer } from '@core/adapter-base'
 * import { getErrorMessage } from '@core/errors'
 *
 * const normalizeError = createErrorNormalizer({
 *   defaultChain: 'Aptos',
 *   handleFrameworkError: (error, chain) => {
 *     // Handle Aptos SDK-specific error types
 *   },
 *   extractMessage: getErrorMessage,
 *   matchPatterns: (message, chain, details) => {
 *     if (message.includes('INSUFFICIENT_BALANCE')) {
 *       throw createInsufficientGasError(chain, undefined, details)
 *     }
 *   },
 * })
 * ```
 */ function createErrorNormalizer(options) {
    const { defaultChain, handleFrameworkError, extractMessage, matchPatterns } = options;
    return (error, ctx)=>{
        const chain = getChainName(ctx, defaultChain);
        if (error instanceof KitError) {
            throw error;
        }
        // ZodError short-circuit. A deterministic input-schema failure
        // (e.g. a missing required field on `prepareAction(...)`) is an
        // INPUT error, not a network error, and it is FATAL — re-running
        // the call with the same input produces the same ZodError. Empirical
        // review against live RPC observed these flowing all the way to the
        // generic fallback as `RPC_ENDPOINT_ERROR (4001)` and being retried
        // 3× by the action middleware before bubbling up. Catch them here,
        // before the framework handler / pattern matching, so:
        //
        //   - operators see the right error type for alerting + dashboards
        //   - the retry loop's `recoverability !== 'FATAL'` gate skips
        //     pointless re-validation
        //   - chain-specific framework handlers don't have to special-case
        //     a non-RPC error shape they can't help with anyway
        //
        // Detection is deliberately duck-typed (`isZodError`) rather than
        // `instanceof ZodError` so it survives across `dist/*` bundles
        // shipping their own `zod` copy — the same cross-bundle identity
        // hazard that affects `instanceof KitError` itself.
        if (isZodError(error)) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `Input validation failed for ${chain} operation.`,
                cause: {
                    trace: {
                        rawError: redactRawError(error),
                        chain
                    }
                }
            });
        }
        handleFrameworkError(error, chain);
        // Redaction parity with the Zod and fallback stages. The EVM/Solana
        // matchers spread both `details` and the matched message into the
        // resulting `KitError` (`cause.trace` / `KitError.message`), so the
        // raw values must be scrubbed BEFORE they reach the matchers:
        //
        //   - `extractMessage(error)` ⇒ `redactErrorMessage(...)` — provider
        //     text (ethers/viem) interpolates RPC URLs with API keys into the
        //     message string; the defaults-on redactor scrubs well-known
        //     providers so a matched revert reason never carries a secret.
        //   - `rawError` ⇒ `redactRawError(error)` — keeps only
        //     `{ name, message }` for `Error` instances so the matchers can't
        //     splice the full provider object graph into `cause.trace`.
        const message = redactErrorMessage(extractMessage(error));
        matchPatterns(message, chain, {
            rawError: redactRawError(error)
        });
        // Generic fallback. Two redaction concerns at this site:
        //
        //   1. Do NOT splice the raw provider message into the top-level
        //      `KitError.message` — provider/RPC error strings can carry
        //      user-controlled or sensitive content (URLs, addresses,
        //      payload fragments) that downstream logs may not redact.
        //      Keep the redacted form on `cause.trace` so opt-in trace
        //      handlers still have it for debugging while the user-visible
        //      surface stays chain-only.
        //
        //   2. Pass `rawError` through `redactRawError` so we don't embed
        //      the full provider object graph (RPC URLs, API keys,
        //      request/response payloads, internal state) in
        //      `cause.trace.rawError`. The previous shape leaked the entire
        //      object on every unmatched error — `redactRawError` keeps
        //      only `{ name, message }` for `Error` instances and falls
        //      back to `String(error)` otherwise. Note: this strips the
        //      *object graph* only; secrets that providers have already
        //      interpolated into the message string itself (e.g.
        //      ethers v6's `makeError()` formatting `requestUrl="…/KEY"`
        //      into the message) still ride on the redacted message and
        //      must be scrubbed by the telemetry pipeline. See the
        //      `redactRawError` JSDoc for the boundary discussion.
        //
        // `rawMessage` is intentionally dropped from the trace — it was a
        // verbatim copy of `redactRawError(error).message` for `Error`
        // instances, so keeping both fields would produce two parallel
        // copies of the same potentially-sensitive string for every
        // unmatched error.
        throw new KitError({
            ...RpcError.ENDPOINT_ERROR,
            recoverability: 'RETRYABLE',
            message: `RPC endpoint error on ${chain}.`,
            cause: {
                trace: {
                    rawError: redactRawError(error),
                    chain
                }
            }
        });
    };
}

/**
 * Create an event subscription mixin from a runtime instance.
 *
 * @remarks
 * Wraps the runtime's untyped `EventBus` with a `TypedEventBus<KitEventMap>`
 * and provides `on` / `off` methods that track handler → unsubscribe mappings.
 *
 * @param runtime - The runtime containing the event bus.
 * @returns An {@link AdapterEventSubscription} with `on` and `off` methods.
 *
 * @example
 * ```typescript
 * import { createAdapterEvents } from '@core/adapter-base'
 *
 * const events = createAdapterEvents(ctx.runtime)
 * const adapter = { ...corePrimitives, ...events }
 * ```
 */ function createAdapterEvents(runtime) {
    const typedBus = asTypedEvents(runtime.events);
    const subscriptions = new Map();
    function on(...args) {
        const handler = args.length === 1 ? args[0] : args[1];
        const unsubscribe = args.length === 1 ? typedBus.on(args[0]) : typedBus.on(args[0], args[1]);
        const existing = subscriptions.get(handler);
        if (existing === undefined) {
            subscriptions.set(handler, [
                unsubscribe
            ]);
        } else {
            existing.push(unsubscribe);
        }
        return ()=>{
            unsubscribe();
            const subs = subscriptions.get(handler);
            if (subs !== undefined) {
                const idx = subs.indexOf(unsubscribe);
                if (idx !== -1) subs.splice(idx, 1);
                if (subs.length === 0) subscriptions.delete(handler);
            }
        };
    }
    function off(...args) {
        const handler = args.length === 1 ? args[0] : args[1];
        const subs = subscriptions.get(handler);
        if (subs !== undefined) {
            for (const unsubscribe of subs){
                unsubscribe();
            }
            subscriptions.delete(handler);
        }
    }
    return {
        on: on,
        off: off
    };
}

// ============================================================================
// Implementation
// ============================================================================
function assembleAdapter(options) {
    const { ctx, chainType, primitives, actions, extras } = options;
    const { read, prepare, waitForTransaction } = primitives;
    // Snapshot the action registry. `createActionDispatch` otherwise aliases
    // the caller's object by reference, so a post-assembly mutation of
    // `actions` would silently change what the (frozen) adapter dispatches —
    // defeating the freeze for the one field that routes user calls.
    const action = createActionDispatch$1({
        ...actions
    });
    const core = {
        ctx,
        capabilities: ctx.capabilities,
        chainType,
        read,
        prepare,
        getAddress: ctx.getAddress,
        action,
        waitForTransaction,
        validateChainSupport: ctx.validateChainSupport,
        ...createAdapterEvents(ctx.runtime)
    };
    const result = extras === undefined ? core : Object.assign(core, extras);
    // Why freeze:
    //   The assembled adapter is treated as a stable handle by all kits and
    //   end-user code. Without `Object.freeze`, a misbehaving consumer could
    //   monkey-patch `prepare`, `read`, `waitForTransaction`, `getAddress`,
    //   or — most dangerously — `validateChainSupport` and silently
    //   compromise every other consumer holding the same reference. We've
    //   already had at least one regression where a kit accidentally
    //   reassigned `ctx` mid-lifecycle, so the freeze is load-bearing.
    //
    // Why shallow:
    //   `ctx` itself is already shallow-frozen at the `createAdapterContext`
    //   boundary, and `ctx.runtime` / `ctx.tokens` deliberately remain
    //   mutable so consumers can swap event-bus subscribers, register new
    //   tokens, etc. A deep freeze here would either break those sites or
    //   require us to copy the world; the shallow freeze is the right
    //   trade-off.
    return Object.freeze(result);
}

/**
 * Assert that a chain supports CCTP v2, narrowing the type accordingly.
 *
 * @param chain - The chain definition to validate.
 * @throws KitError with `InputError.UNSUPPORTED_ROUTE` if the chain lacks CCTP v2 config.
 *
 * @example
 * ```typescript
 * import { assertCCTPV2Supported } from '@core/adapter-base'
 * import type { ChainDefinition } from '@core/chains'
 *
 * function prepareBurn(chain: ChainDefinition) {
 *   assertCCTPV2Supported(chain)
 *   // chain is now narrowed to ChainDefinitionWithCCTPv2
 *   const domain = chain.cctp.domain
 * }
 * ```
 */ function assertCCTPV2Supported(chain) {
    if (!isCCTPV2Supported(chain)) {
        throw new KitError({
            ...InputError.UNSUPPORTED_ROUTE,
            recoverability: 'FATAL',
            message: `Chain "${chain.name}" does not support CCTP v2. ` + 'Ensure the chain has CCTP v2 contract configuration.'
        });
    }
}

/**
 * Type-safe registry for managing and executing blockchain action handlers.
 *
 * Provides a centralized system for registering action handlers with full
 * TypeScript type safety, ensuring that handlers can only be registered
 * with compatible action keys and payload types. Supports both individual
 * handler registration and batch registration operations.
 *
 * @remarks
 * The registry uses a Map internally for O(1) lookups and maintains type
 * safety through generic constraints and careful type assertions. All
 * type assertions are validated at registration time to ensure runtime
 * type safety matches compile-time guarantees.
 */ class ActionRegistry {
    actionHandlers = new Map();
    /**
   * Register a type-safe action handler for a specific action key.
   *
   * Associates an action handler function with its corresponding action key,
   * ensuring compile-time type safety between the action and its expected
   * payload structure. The handler will be available for execution via
   * {@link executeAction}.
   *
   * @typeParam TActionKey - The specific action key being registered.
   * @param action - The action key to register the handler for.
   * @param handler - The handler function for processing this action type.
   * @returns Void.
   *
   * @throws Error When action parameter is not a valid string.
   * @throws TypeError When handler parameter is not a function.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   * import type { ActionHandler } from '@core/adapter'
   *
   * const registry = new ActionRegistry()
   *
   * // Register a CCTP deposit handler
   * const depositHandler: ActionHandler<'cctp.v2.depositForBurn'> = async (params, resolved) => {
   *   console.log('Processing deposit:', params.amount)
   *   return {
   *     chainId: params.chainId,
   *     data: '0x...',
   *     to: '0x...',
   *     value: '0'
   *   }
   * }
   *
   * registry.registerHandler('cctp.v2.depositForBurn', depositHandler)
   * ```
   */ registerHandler(action, handler) {
        // Runtime validation for JavaScript consumers
        if (typeof action !== 'string' || action.length === 0) {
            throw new TypeError(`Action must be a non-empty string, received: ${typeof action}`);
        }
        if (typeof handler !== 'function') {
            throw new TypeError(`Handler must be a function, received: ${typeof handler}`);
        }
        // The handler is upcast to ActionHandler<ActionKeys> for storage,
        // but type safety is maintained at the call site through the generic constraint
        this.actionHandlers.set(action, handler);
    }
    /**
   * Register multiple action handlers in a single operation.
   *
   * Efficiently register multiple handlers from a record object, where keys
   * are action identifiers and values are their corresponding handler
   * functions. Provides a convenient way to bulk-register handlers while
   * maintaining type safety.
   *
   * @param handlers - A record mapping action keys to their handler functions.
   * @returns Void.
   *
   * @throws {Error} When handlers parameter is not a valid object.
   * @throws {Error} When any individual handler registration fails.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   * import type { ActionHandler, ActionHandlers } from '@core/adapter'
   *
   * const registry = new ActionRegistry()
   *
   * // Register multiple handlers at once
   * const tokenHandlers: ActionHandlers = {
   *   'token.approve': async (params, resolved) => ({
   *     chainId: resolved.chain,
   *     data: '0x095ea7b3...',
   *     to: params.tokenAddress,
   *     value: '0'
   *   }),
   *   'token.transfer': async (params, resolved) => ({
   *     chainId: resolved.chain,
   *     data: '0xa9059cbb...',
   *     to: params.tokenAddress,
   *     value: '0'
   *   })
   * }
   *
   * registry.registerHandlers(tokenHandlers)
   * console.log('Registered multiple token handlers')
   * ```
   */ registerHandlers(handlers) {
        // Runtime validation for JavaScript consumers
        if (typeof handlers !== 'object' || handlers === null) {
            throw new Error(`Handlers must be a non-null object, received: ${typeof handlers}`);
        }
        // Register each handler individually to benefit from per-handler validation
        for (const [action, handler] of Object.entries(handlers)){
            this.registerHandler(action, handler);
        }
    }
    /**
   * Check whether a specific action is supported by this registry.
   *
   * Determine if a handler has been registered for the given action key.
   * Use this method to conditionally execute actions or provide appropriate
   * error messages when actions are not available.
   *
   * @param action - The action key to check for support.
   * @returns True if the action is supported, false otherwise.
   *
   * @throws {Error} When action parameter is not a valid string.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   *
   * const registry = new ActionRegistry()
   *
   * // Check if actions are supported before attempting to use them
   * if (registry.supportsAction('token.approve')) {
   *   console.log('Token approval is supported')
   * } else {
   *   console.log('Token approval not available')
   * }
   *
   * // Conditional logic based on support
   * const action = 'cctp.v2.depositForBurn'
   * if (registry.supportsAction(action)) {
   *   // Safe to execute
   *   console.log(`${action} is available`)
   * } else {
   *   console.warn(`${action} is not registered`)
   * }
   * ```
   */ supportsAction(action) {
        // Runtime validation for JavaScript consumers
        if (typeof action !== 'string' || action.length === 0) {
            throw new TypeError(`Action must be a non-empty string, received: ${typeof action}`);
        }
        return this.actionHandlers.has(action);
    }
    /**
   * Execute a registered action handler with type-safe parameters.
   *
   * Look up and execute the handler associated with the given action key,
   * passing the provided parameters and context, returning the resulting prepared
   * chain request. TypeScript ensures the parameters match the expected
   * structure for the specified action.
   *
   * @typeParam TActionKey - The specific action key being executed.
   * @param action - The action key identifying which handler to execute.
   * @param params - The parameters to pass to the action handler.
   * @param context - The resolved operation context with concrete chain and address values.
   * @returns A promise resolving to the prepared chain request.
   * @throws {KitError} When the handler execution fails with a structured error.
   * @throws {Error} When no handler is registered for the specified action.
   * @throws {Error} When the handler execution fails with an unstructured error.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   * import type { ChainEnum } from '@core/chains'
   *
   * const registry = new ActionRegistry()
   *
   * // First register a handler
   * registry.registerHandler('token.approve', async (params, context) => ({
   *   chainId: context.chain, // Always defined
   *   data: '0x095ea7b3...',
   *   to: params.tokenAddress,
   *   value: '0'
   * }))
   *
   * // Execute the action with resolved context (typically called from adapter.prepareAction)
   * const resolvedContext = { chain: 'Base', address: '0x123...' }
   * const result = await registry.executeAction('token.approve', {
   *   chainId: ChainEnum.Ethereum,
   *   tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
   *   delegate: '0x1234567890123456789012345678901234567890',
   *   amount: '1000000'
   * }, resolvedContext)
   *
   * console.log('Transaction prepared:', result.data)
   * ```
   */ async executeAction(action, params, context) {
        // Runtime validation for JavaScript consumers
        if (typeof action !== 'string' || action.length === 0) {
            throw new TypeError(`Action must be a non-empty string, received: ${typeof action}`);
        }
        const handler = this.actionHandlers.get(action);
        if (!handler) {
            throw new Error(`Action ${action} is not supported`);
        }
        try {
            // Type safety is guaranteed by the registration process
            return await handler(params, context);
        } catch (error) {
            // If it's already a KitError with structured information, re-throw as-is
            // to preserve error code, name, type, recoverability, and cause
            if (error instanceof KitError) {
                throw error;
            }
            // For other errors, re-throw with context for better debugging
            const message = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to execute action ${action}: ${message}`);
        }
    }
}

/**
 * Canonical list of actions that do not prepare or submit transactions.
 *
 * @internal
 */ const READ_ACTION_KEYS = [
    'token.allowance',
    'token.balanceOf',
    'token.name',
    'native.balanceOf',
    'usdc.allowance',
    'usdc.balanceOf',
    'usdc.name',
    'gateway.v1.isDelegate',
    'gateway.v1.withdrawingBalance',
    'gateway.v1.withdrawalBlock',
    'gateway.v1.signBurnIntents'
];
const READ_ACTION_KEY_SET = new Set(READ_ACTION_KEYS);
/**
 * Check whether a runtime value identifies a read action.
 *
 * @param action - The value to classify.
 * @returns Whether the value is a registered read-action key.
 *
 * @example
 * ```typescript
 * import { isReadActionKey } from '@core/adapter'
 *
 * if (isReadActionKey(value)) {
 *   await adapter.readAction(value, params, context)
 * }
 * ```
 *
 * @internal
 */ function isReadActionKey(action) {
    return typeof action === 'string' && READ_ACTION_KEY_SET.has(action);
}

/**
 * Resolves an operation context into concrete chain and address values.
 *
 * This function ensures that action handlers always receive defined chain and address
 * values by applying validation and resolution logic based on the adapter's capabilities.
 * It enforces compile-time and runtime address requirements based on the adapter's
 * address control model.
 *
 * **Resolution logic**:
 * - **Chain**: Uses provided chain identifier and resolves to ChainDefinition
 * - **Address**:
 *   - For user-controlled adapters: Retrieves current address from adapter (context address ignored)
 *   - For developer-controlled adapters: Uses address provided in context (required)
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type for compile-time validation
 * @param adapter - The typed adapter instance with capabilities defined
 * @param ctx - Operation context with compile-time validated address requirements
 * @returns Promise resolving to concrete chain and address values
 * @throws Error when adapter capabilities are not defined
 * @throws Error when operation context is not provided
 * @throws Error when address is required but not provided (developer-controlled)
 * @throws Error when adapter.getAddress() fails (user-controlled)
 *
 * @example
 * ```typescript
 * import { resolveOperationContext } from '@core/adapter'
 *
 * // User-controlled adapter - address forbidden in context
 * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
 * const resolved = await resolveOperationContext(userAdapter, {
 *   chain: 'Base' // address will be resolved from wallet
 * })
 * console.log(resolved.chain)   // ChainDefinition - always defined
 * console.log(resolved.address) // string - resolved from adapter
 *
 * // Developer-controlled adapter - address required in context
 * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
 * const resolved = await resolveOperationContext(devAdapter, {
 *   chain: 'Base',
 *   address: '0x123...' // Required and enforced at compile time
 * })
 * console.log(resolved.address) // '0x123...' - from context
 * ```
 */ async function resolveOperationContext(adapter, ctx) {
    // Adapter must have capabilities defined
    if (adapter.capabilities === undefined) {
        throw new Error('Adapter capabilities must be defined. Please ensure the adapter implements the capabilities property.');
    }
    // Operation context is required for new typed adapters
    if (ctx === undefined) {
        throw new Error('Operation context is required. Please provide a context with the required chain and address information.');
    }
    // Resolve chain from context (required)
    const resolvedChain = resolveChainIdentifier(ctx.chain);
    // Resolve address based on adapter capabilities
    let resolvedAddress;
    if (adapter.capabilities.addressContext === 'developer-controlled') {
        // Developer-controlled: address must be explicitly provided
        if (!ctx.address) {
            throw new Error('Address is required for developer-controlled adapters. Please provide an address in the operation context.');
        }
        resolvedAddress = ctx.address;
    } else {
        // User-controlled: get current address from adapter
        try {
            // Pass resolved chain to getAddress for adapters that support it (like ViemAdapter)
            // The chain parameter is optional in implementations, so this is safe
            resolvedAddress = await adapter.getAddress(resolvedChain);
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to resolve address from user-controlled adapter: ${message}`);
        }
    }
    return {
        chain: resolvedChain,
        address: resolvedAddress
    };
}

/**
 * Create the standard error for a missing or non-read action.
 *
 * @param action - The unsupported action value.
 * @returns A fatal unsupported-action error.
 *
 * @internal
 */ function createUnsupportedReadActionError(action) {
    return new KitError({
        ...InputError.UNSUPPORTED_ACTION,
        recoverability: 'FATAL',
        message: `Read action "${String(action)}" is not registered in this adapter.`
    });
}
/**
 * Execute a read through the adapter's dedicated read seam when available.
 *
 * @remarks
 * Fall back to the legacy `prepareAction().execute()` contract so providers
 * remain runtime-compatible with adapter versions released before `readAction`.
 * Consumers must upgrade their adapter package for reads to bypass custom
 * `prepareAction` wrappers.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type.
 * @typeParam TActionKey - The read action key.
 * @param adapter - The adapter that owns the read action.
 * @param action - The read action to execute.
 * @param params - The parameters for the read action.
 * @param ctx - The operation context.
 * @returns The raw read-action result.
 * @throws {KitError} When `action` is not a supported read-action key.
 *
 * @example
 * ```typescript
 * import { executeAdapterReadAction } from '@core/adapter'
 * import { Ethereum } from '@core/chains'
 *
 * const allowance = await executeAdapterReadAction(
 *   adapter,
 *   'token.allowance',
 *   { tokenAddress, delegate },
 *   { chain: Ethereum },
 * )
 * ```
 *
 * @internal
 */ async function executeAdapterReadAction(adapter, action, params, ctx) {
    if (!isReadActionKey(action)) {
        throw createUnsupportedReadActionError(action);
    }
    const runtimeAdapter = adapter;
    if (typeof runtimeAdapter.readAction === 'function') {
        return runtimeAdapter.readAction(action, params, ctx);
    }
    let request;
    try {
        request = await adapter.prepareAction(action, params, ctx);
    } catch (error) {
        if (error instanceof Error && error.message === `Action ${action} is not supported`) {
            throw createUnsupportedReadActionError(action);
        }
        throw error;
    }
    return request.execute();
}
/**
 * Read and parse a token allowance while supporting older adapter versions.
 *
 * @remarks
 * Prefer the adapter's dedicated read seam and fall back to the legacy
 * `prepareAction().execute()` contract when the runtime adapter predates it.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type.
 * @param adapter - The adapter that owns the allowance action.
 * @param params - The token and delegate whose allowance is being read.
 * @param ctx - The operation context.
 * @returns The non-negative allowance in token base units.
 * @throws {KitError} When the action is unsupported or its response is malformed.
 *
 * @example
 * ```typescript
 * import { readTokenAllowance } from '@core/adapter'
 * import { Ethereum } from '@core/chains'
 *
 * const allowance = await readTokenAllowance(
 *   adapter,
 *   { tokenAddress, delegate },
 *   { chain: Ethereum },
 * )
 * ```
 *
 * @internal
 */ async function readTokenAllowance(adapter, params, ctx) {
    return parseAllowanceResponse(await executeAdapterReadAction(adapter, 'token.allowance', params, ctx));
}
/**
 * Parse a raw token allowance response into base units.
 *
 * @param allowanceRaw - The adapter response, optionally wrapped as an Amount output.
 * @returns The non-negative allowance as a bigint, or zero for a missing value.
 * @throws {KitError} When the response cannot represent a non-negative bigint.
 *
 * @example
 * ```typescript
 * import { parseAllowanceResponse } from '@core/adapter'
 *
 * const allowance = parseAllowanceResponse({ amount: { raw: 1000000n } })
 * ```
 */ function parseAllowanceResponse(allowanceRaw) {
    let value = allowanceRaw;
    if (typeof value === 'object' && value !== null && 'amount' in value) {
        const amount = value.amount;
        if (typeof amount === 'object' && amount !== null && 'raw' in amount) {
            value = amount.raw;
        }
    }
    if (value === undefined || value === null) {
        return 0n;
    }
    let allowance;
    if (typeof value === 'bigint') {
        allowance = value;
    } else if (typeof value === 'string') {
        try {
            allowance = BigInt(value);
        } catch  {
            allowance = undefined;
        }
    }
    if (allowance === undefined || allowance < 0n) {
        throw createValidationFailedError('token.allowance', value, 'token.allowance response must be a non-negative bigint-compatible string or bigint');
    }
    return allowance;
}

/**
 * Abstract class defining the standard interface for an adapter that interacts with a specific blockchain.
 *
 * An `Adapter` is responsible for encapsulating chain-specific logic necessary to
 * perform operations like sending transactions, querying balances, or interacting with smart contracts.
 * Implementations of this class will provide concrete logic for a particular blockchain protocol.
 *
 * This abstraction allows the App Kit to work with multiple blockchains in a uniform way.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type for compile-time address validation.
 * When provided, enables strict typing of operation context based on the adapter's address control model.
 */ class Adapter {
    /**
   * Capabilities of this adapter, defining address control model and supported chains.
   *
   * This property determines how the adapter behaves, especially for address selection
   * and bridge API requirements. The `addressContext` must match the adapter's type parameter.
   *
   * @remarks
   * The `addressContext` value must align with the adapter's generic type parameter for proper
   * type safety in bridge operations.
   *
   * @example
   * ```typescript
   * // User-controlled adapter (private key, browser wallet)
   * capabilities = {
   *   addressContext: 'user-controlled', // Address implicit in bridge operations
   *   supportedChains: [Ethereum, Base, Polygon]
   * }
   *
   * // Developer-controlled adapter (enterprise provider)
   * capabilities = {
   *   addressContext: 'developer-controlled', // Address required in bridge operations
   *   supportedChains: [Ethereum, Base, Solana]
   * }
   * ```
   */ capabilities;
    /**
   * Registry of available actions for this adapter.
   *
   * The {@link ActionRegistry} provides a catalog of supported operations
   * (such as token transfers, approvals, etc.) that can be performed by this adapter
   * on the connected blockchain. This enables dynamic discovery and invocation
   * of chain-specific or cross-chain actions in a type-safe manner.
   *
   * @readonly
   */ actionRegistry = new ActionRegistry();
    /**
   * Prepares (but does not execute) an action for the connected blockchain.
   *
   * This method looks up the appropriate action handler for the given action key
   * and prepares the transaction request using the provided parameters. The returned
   * {@link PreparedChainRequest} allows developers to estimate gas costs and execute
   * the transaction at a later time, enabling pre-flight simulation and deferred execution.
   *
   * **Compile-time Address Validation**: When used with typed adapters that have capabilities,
   * this method enforces address requirements at compile time:
   * - **User-controlled adapters**: The `address` field is forbidden in the context
   * - **Developer-controlled adapters**: The `address` field is required in the context
   * - **Legacy adapters**: The `address` field remains optional for backward compatibility
   *
   * @remarks
   * This method does not send any transaction to the network. Instead, it returns a
   * prepared request object with `estimate()` and `execute()` methods, allowing
   * developers to inspect, simulate, or submit the transaction as needed.
   *
   * @param action - The action key identifying which handler to use for preparation.
   * @param params - The parameters to pass to the action handler.
   * @param ctx - Operation context with compile-time validated address requirements based on adapter capabilities.
   * @returns A promise that resolves to a {@link PreparedChainRequest} for estimation and execution.
   * @throws Error If the specified action key does not correspond to a registered handler.
   * @throws Error If the provided parameters are invalid for the action.
   * @throws Error If the operation context cannot be resolved.
   *
   * @example
   * ```typescript
   * // User-controlled adapter (address forbidden)
   * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
   * await userAdapter.prepareAction('token.approve', params, {
   *   chain: 'Ethereum'
   *   // address: '0x123...' // ❌ TypeScript error: address not allowed
   * })
   *
   * // Developer-controlled adapter (address required)
   * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
   * await devAdapter.prepareAction('token.approve', params, {
   *   chain: 'Ethereum',
   *   address: '0x123...' // ✅ Required for developer-controlled
   * })
   * ```
   */ async prepareAction(action, params, ctx) {
        // Only prepares the action; does not execute it.
        // The returned PreparedChainRequest allows for estimation and execution.
        // Resolve the operation context to ensure handlers receive concrete values
        const resolvedContext = await resolveOperationContext(this, ctx);
        return this.actionRegistry.executeAction(action, params, resolvedContext);
    }
    /**
   * Execute a non-transaction action without routing through transaction preparation.
   *
   * @remarks
   * Use this seam for balance, allowance, contract-state, and other actions
   * classified as reads. It never calls {@link Adapter.prepareAction}, so
   * transaction authorization wrappers only observe actions that can produce a
   * signable chain request.
   *
   * @typeParam TActionKey - The read action key.
   * @param action - The read action to execute.
   * @param params - The parameters for the read action.
   * @param ctx - The operation context.
   * @returns The raw action response.
   * @throws {KitError} When the key is not a read action or no handler is registered.
   * @throws Error When the operation context or action handler fails.
   *
   * @example
   * ```typescript
   * import { Ethereum } from '@core/chains'
   *
   * const balance = await adapter.readAction(
   *   'token.balanceOf',
   *   { tokenAddress, walletAddress },
   *   { chain: Ethereum },
   * )
   * ```
   *
   * @internal
   */ async readAction(action, params, ctx) {
        if (!isReadActionKey(action) || !this.actionRegistry.supportsAction(action)) {
            throw createUnsupportedReadActionError(action);
        }
        const resolvedContext = await resolveOperationContext(this, ctx);
        const request = await this.actionRegistry.executeAction(action, params, resolvedContext);
        return request.execute();
    }
    /**
   * Read the current token allowance a delegate holds over an owner's tokens.
   *
   * @remarks
   * Perform a network read through {@link Adapter.readAction}. This method
   * never routes through {@link Adapter.prepareAction}. On chains without an
   * allowance model, such as Solana, return the maximum uint256 value.
   *
   * @param params - The token to query and the delegate whose allowance is being read.
   * @param ctx - Operation context with compile-time validated address requirements.
   * @returns A promise resolving to the current allowance in the token's base units.
   * @throws {KitError} When the adapter does not register a `token.allowance` handler.
   * @throws Error When the operation context or action handler fails.
   *
   * @example
   * ```typescript
   * import type { Adapter } from '@core/adapter'
   * import { Ethereum } from '@core/chains'
   *
   * declare const adapter: Adapter
   *
   * const allowance = await adapter.getTokenAllowance(
   *   {
   *     tokenAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
   *     delegate: '0x1111111111111111111111111111111111111111',
   *   },
   *   { chain: Ethereum },
   * )
   * console.log(allowance) // 1000000n
   * ```
   */ async getTokenAllowance(params, ctx) {
        return readTokenAllowance(this, params, ctx);
    }
    /**
   * Ensures the adapter is operating on the specified chain, switching if necessary.
   *
   * This method provides a unified interface for establishing chain preconditions across different adapter types.
   * The behavior varies based on the adapter's capabilities:
   * - **Private key adapters**: Recreate clients with new RPC endpoints
   * - **Browser wallet adapters**: Request chain switch via EIP-1193 or equivalent
   * - **Multi-entity adapters**: Validate chain support (operations are contextual)
   *
   * @param chain - The target chain for operations.
   * @returns A promise that resolves when the adapter is operating on the specified chain.
   * @throws When the target chain is not supported or chain switching fails.
   *
   * @remarks
   * This method always calls `switchToChain()` to ensure consistency across all adapter types.
   * The underlying implementations handle idempotent switching efficiently (e.g., browser wallets
   * gracefully handle switching to the current chain, private key adapters recreate lightweight clients).
   *
   * @example
   * ```typescript
   * // Private key adapter - switches chains seamlessly
   * await privateKeyAdapter.ensureChain(Base)
   *
   * // Browser wallet - requests user to switch chains
   * await metamaskAdapter.ensureChain(Polygon)
   *
   * // Multi-entity adapter - validates chain is supported
   * await circleWalletsAdapter.ensureChain(Ethereum)
   * ```
   */ async ensureChain(targetChain) {
        this.validateChainSupport(targetChain);
        // Always delegate to switchToChain - implementations handle idempotent switching
        try {
            await this.switchToChain(targetChain);
        } catch (error) {
            throw new Error(`Failed to switch to chain ${targetChain.name}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    /**
   * Validate that the target chain is supported by this adapter.
   *
   * @param targetChain - The chain to validate.
   * @throws KitError with INVALID_CHAIN code if the chain is not supported by this adapter.
   */ validateChainSupport(targetChain) {
        if (this.capabilities?.supportedChains) {
            const isSupported = this.capabilities.supportedChains.some((supportedChain)=>supportedChain.chain === targetChain.chain);
            if (!isSupported) {
                const supportedCount = this.capabilities.supportedChains.length;
                // List supported chain names for better user experience
                const supportedChainNames = this.capabilities.supportedChains.map((chainDef)=>chainDef.name).join(', ');
                const reason = `Not supported by this adapter. It supports ${supportedCount.toString()} ${supportedCount === 1 ? 'chain' : 'chains'}: ${supportedChainNames}`;
                throw createInvalidChainError(targetChain.name, reason);
            }
        } else if (this.chainType && targetChain.type !== this.chainType) {
            const reason = `Chain type mismatch: adapter supports ${this.chainType} chains, but received ${targetChain.type ?? 'unknown'} chain`;
            throw createInvalidChainError(targetChain.name, reason);
        }
    }
}

/**
 * Schema for validating hexadecimal strings with '0x' prefix.
 *
 * This schema validates that a string:
 * - Is a string type
 * - Is not empty after trimming
 * - Starts with '0x'
 * - Contains only valid hexadecimal characters (0-9, a-f, A-F) after '0x'
 *
 * @remarks
 * This schema does not validate length, making it suitable for various hex string types
 * like addresses, transaction hashes, and other hex-encoded data.
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { hexStringSchema } from '@core/adapter'
 *
 * const validAddress = '0x1234567890123456789012345678901234567890'
 * const validTxHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const addressResult = hexStringSchema.safeParse(validAddress)
 * const txHashResult = hexStringSchema.safeParse(validTxHash)
 * console.log(addressResult.success) // true
 * console.log(txHashResult.success) // true
 * ```
 */ const hexStringSchema = zod.z.string().min(1, 'Hex string is required').refine((value)=>value.trim().length > 0, 'Hex string cannot be empty').refine((value)=>value.startsWith('0x'), 'Hex string must start with 0x prefix').refine((value)=>{
    const hexPattern = /^0x[0-9a-fA-F]+$/;
    return hexPattern.test(value);
}, 'Hex string contains invalid characters. Only hexadecimal characters (0-9, a-f, A-F) are allowed after 0x');
/**
 * Schema for validating EVM addresses.
 *
 * This schema validates that a string is a properly formatted EVM address:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 42 characters long (0x + 40 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmAddressSchema } from '@core/adapter'
 *
 * const validAddress = '0x1234567890123456789012345678901234567890'
 *
 * const result = evmAddressSchema.safeParse(validAddress)
 * console.log(result.success) // true
 * ```
 */ hexStringSchema.refine((value)=>value.length === 42, 'EVM address must be exactly 42 characters long (0x + 40 hex characters)').transform((value)=>value);
/**
 * Schema for validating transaction hashes.
 *
 * This schema validates that a string is a properly formatted transaction hash:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 66 characters long (0x + 64 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmTransactionHashSchema } from '@core/adapter'
 *
 * const validTxHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const result = evmTransactionHashSchema.safeParse(validTxHash)
 * console.log(result.success) // true
 * ```
 */ hexStringSchema.refine((value)=>value.length === 66, 'Transaction hash must be exactly 66 characters long (0x + 64 hex characters)');
/**
 * Schema for validating EVM signatures.
 *
 * This schema validates that a string is a properly formatted 65-byte EVM
 * signature:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 132 characters long (0x + 130 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmSignatureSchema } from '@core/adapter'
 *
 * const validSignature = `0x${'ab'.repeat(65)}`
 *
 * const result = evmSignatureSchema.safeParse(validSignature)
 * console.log(result.success) // true
 * ```
 */ hexStringSchema.refine((value)=>value.length === 132, 'EVM signature must be exactly 132 characters long (0x + 130 hex characters)').transform((value)=>value);
/**
 * Schema for validating base58-encoded strings.
 *
 * This schema validates that a string:
 * - Is a string type
 * - Is not empty after trimming
 * - Contains only valid base58 characters (1-9, A-H, J-N, P-Z, a-k, m-z)
 * - Does not contain commonly confused characters (0, O, I, l)
 *
 * @remarks
 * This schema does not validate length, making it suitable for various base58-encoded data
 * like Solana addresses, transaction signatures, and other base58-encoded data.
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { base58StringSchema } from '@core/adapter'
 *
 * const validAddress = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 * const validTxHash = '3Jf8k2L5mN9pQ7rS1tV4wX6yZ8aB2cD4eF5gH7iJ9kL1mN3oP5qR7sT9uV1wX3yZ5'
 *
 * const addressResult = base58StringSchema.safeParse(validAddress)
 * const txHashResult = base58StringSchema.safeParse(validTxHash)
 * console.log(addressResult.success) // true
 * console.log(txHashResult.success) // true
 * ```
 */ const base58StringSchema = zod.z.string().min(1, 'Base58 string is required').refine((value)=>value.trim().length > 0, 'Base58 string cannot be empty').refine((value)=>{
    // Base58 alphabet: 123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz
    // Excludes: 0, O, I, l to avoid confusion
    const base58Pattern = /^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/;
    return base58Pattern.test(value);
}, 'Base58 string contains invalid characters. Only base58 characters (1-9, A-H, J-N, P-Z, a-k, m-z) are allowed');
/**
 * Schema for validating Solana addresses.
 *
 * This schema validates that a string is a properly formatted Solana address:
 * - Must be a valid base58-encoded string
 * - Must be between 32-44 characters long (typical length for base58-encoded 32-byte addresses)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { solanaAddressSchema } from '@core/adapter'
 *
 * const validAddress = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 *
 * const result = solanaAddressSchema.safeParse(validAddress)
 * console.log(result.success) // true
 * ```
 */ base58StringSchema.refine((value)=>value.length >= 32 && value.length <= 44, 'Solana address must be between 32-44 characters long (base58-encoded 32-byte address)');
/**
 * Schema for validating Solana transaction hashes.
 *
 * This schema validates that a string is a properly formatted Solana transaction hash:
 * - Must be a valid base58-encoded string
 * - Must be between 86-88 characters long (typical length for base58-encoded 64-byte signatures)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { solanaTransactionHashSchema } from '@core/adapter'
 *
 * const validTxHash = '5VfYmGBjvQKe3xgLtTQPSMEUdpEVHrJwLK7pKBJWKzYpNBE2g3kJrq7RSe9M8DqzQJ5J2aZPTjHLvd4WgxPpJKS'
 *
 * const result = solanaTransactionHashSchema.safeParse(validTxHash)
 * console.log(result.success) // true
 * ```
 */ base58StringSchema.refine((value)=>value.length >= 86 && value.length <= 88, 'Solana transaction hash must be between 86-88 characters long (base58-encoded 64-byte signature)');
/**
 * Schema for validating Adapter objects.
 * Checks for the required methods that define an Adapter.
 */ zod.z.object({
    prepare: zod.z.function(),
    waitForTransaction: zod.z.function(),
    getAddress: zod.z.function()
});

/**
 * Permit signature standards for gasless token approvals.
 *
 * Defines the permit types that can be used to approve token spending
 * without requiring a separate approval transaction.
 *
 * @remarks
 * - NONE: No permit, tokens must be pre-approved via separate transaction
 * - EIP2612: Standard ERC-20 permit (USDC, DAI v2, and most modern tokens)
 */ var PermitType;
(function(PermitType) {
    /** No permit required - tokens must be pre-approved */ PermitType[PermitType["NONE"] = 0] = "NONE";
    /** EIP-2612 standard permit */ PermitType[PermitType["EIP2612"] = 1] = "EIP2612";
})(PermitType || (PermitType = {}));

/**
 * Type guard to check if a signer is provider-based.
 *
 * @param signer - The signer to check
 * @returns True if the signer is provider-based
 */ function isProviderSigner(signer) {
    return signer.isProviderSigner;
}

/**
 * Parses a private key string into raw bytes.
 *
 * This shared utility supports multiple Solana private key formats:
 * - Base58 encoded strings (most common)
 * - Base64 encoded strings
 * - JSON array format (e.g., "[1,2,3,...]")
 *
 * @param privateKey - The private key string in any supported format
 * @returns Raw key bytes as Uint8Array
 * @throws Error when the private key format is invalid or unsupported
 *
 * @remarks
 * This function extracts the common private key parsing logic shared between
 * all Solana adapters. It handles format detection, decoding, and validation,
 * but does not create adapter-specific key objects (Keypair vs KitSigner).
 *
 * @example
 * ```typescript
 * import { parsePrivateKeyToBytes } from '@core/adapter-solana'
 *
 * // Base58 format (most common)
 * const keyBytes = parsePrivateKeyToBytes('5Kk7...')
 *
 * // Base64 format
 * const keyBytes2 = parsePrivateKeyToBytes('base64string==')
 *
 * // JSON array format
 * const keyBytes3 = parsePrivateKeyToBytes('[1,2,3,4,...]')
 * ```
 */ function parsePrivateKeyToBytes(privateKey) {
    // Define decoding strategies in priority order
    const decoders = [
        /**
     * Base58 decoder (most common format for Solana private keys)
     */ (key)=>bs58__default.decode(key),
        /**
     * Base64 decoder with whitespace handling
     */ (key)=>{
            // Remove any whitespace and padding issues
            const cleanedKey = key.replace(/\s+/g, '');
            return Buffer.from(cleanedKey, 'base64');
        },
        /**
     * JSON array decoder for array format like "[1,2,3,...]"
     */ (key)=>{
            const parsed = JSON.parse(key);
            if (!Array.isArray(parsed) || !parsed.every((n)=>typeof n === 'number')) {
                throw new Error('JSON format must be an array of numbers');
            }
            return new Uint8Array(parsed);
        }
    ];
    let secretKey;
    // Try each decoder until one succeeds
    for (const decoder of decoders){
        try {
            secretKey = decoder(privateKey);
            // Validate key length (Solana secret keys are typically 32 or 64 bytes)
            if (secretKey.length === 32 || secretKey.length === 64) {
                return secretKey;
            }
        } catch  {
        // Continue to next decoder - we expect some decoders to fail
        }
    }
    // If no decoder succeeded, throw a descriptive error
    throw new Error(`Invalid private key format. Please provide a valid Base58, base64, or array format private key.`);
}

/**
 * Default transaction confirmation timeout in milliseconds.
 *
 * @constant
 * @remarks
 * This 60-second timeout provides sufficient time for transaction
 * confirmation while preventing indefinite waiting in failure scenarios.
 */ const DEFAULT_TX_TIMEOUT = 60000;
/**
 * Gets the standard connection configuration for @solana/web3.js adapters.
 *
 * This shared utility eliminates duplicate connection configuration across
 * Solana adapters and ensures consistent behavior for timeouts, retries,
 * commitment levels, and HTTP headers.
 *
 * @param userAgent - Optional custom user agent string. Defaults to 'app-kit/1.0.0'
 * @returns Standard connection configuration object
 *
 * @remarks
 * These settings are optimized for production use and provide:
 * - Consistent 'confirmed' commitment level
 * - 60-second transaction confirmation timeout
 * - Rate limiting retry enabled for better reliability
 * - Proper User-Agent identification for RPC providers
 *
 * @example
 * ```typescript
 * import { getStandardConnectionConfig } from '@core/adapter-solana'
 * import { Connection } from '@solana/web3.js'
 *
 * const config = getStandardConnectionConfig()
 * const connection = new Connection(rpcUrl, config)
 * ```
 */ function getStandardConnectionConfig(userAgent = 'app-kit/1.0.0') {
    return {
        commitment: 'confirmed',
        confirmTransactionInitialTimeout: DEFAULT_TX_TIMEOUT,
        disableRetryOnRateLimit: false,
        // A raw `User-Agent` request header is forbidden in browsers, so only set
        // it in Node. Browser RPC requests simply omit it.
        httpHeaders: isNodeEnvironment() ? {
            'User-Agent': userAgent
        } : {}
    };
}

/**
 * SPL Token program ID (standard, non-2022).
 *
 * @remarks
 * Address: TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA
 */ new web3_js.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
/**
 * SPL Associated Token Account program ID.
 *
 * @remarks
 * Address: ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL
 */ new web3_js.PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');
/**
 * SPL Token-2022 (Token Extensions) program ID.
 *
 * @remarks
 * Address: TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb
 */ new web3_js.PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb');

const enc = new TextEncoder();
enc.encode('gateway_minter');
enc.encode('gateway_minter_custody');
enc.encode('used_transfer_spec_hash');

/**
 * Zod schema for the numeric parameters of customBurn.
 * Matches existing error messages used in tests.
 */ zod.z.object({
    amount: zod.z.bigint({
        required_error: 'amount is required for customBurn'
    }).refine((v)=>v > 0n, 'amount must be greater than zero'),
    maxFee: zod.z.bigint({
        required_error: 'maxFee is required for customBurn'
    }).refine((v)=>v >= 0n, 'maxFee cannot be negative'),
    minFinalityThreshold: zod.z.number({
        required_error: 'minFinalityThreshold is required for customBurn',
        invalid_type_error: 'minFinalityThreshold is required for customBurn'
    }).refine((v)=>Number.isFinite(v), 'minFinalityThreshold is required for customBurn').refine((v)=>v >= 0, 'minFinalityThreshold cannot be negative'),
    protocolFee: zod.z.bigint().optional().refine((v)=>v === undefined || v >= 0n, 'protocolFee cannot be negative')
});
// Chain params are validated via explicit checks below to preserve exact error messages
/**
 * Zod schema for the address parameters of customBurn.
 * Enforces presence; format is verified by PublicKey conversion below.
 */ zod.z.object({
    mintRecipient: zod.z.string({
        required_error: 'mintRecipient is required for customBurn'
    }).min(1, 'mintRecipient is required for customBurn'),
    feeRecipient: zod.z.string().optional(),
    destinationCaller: zod.z.string().optional()
});

/**
 * Schema for validating private keys in multiple supported formats.
 *
 * Supports Base58, Base64, and JSON array formats for maximum compatibility
 * with different private key sources and developer preferences.
 *
 * @example
 * ```typescript
 * import { privateKeySchema } from '@core/adapter-solana'
 *
 * // Valid formats:
 * privateKeySchema.parse('5KkQMKuKpKU...') // Base58
 * privateKeySchema.parse('[1,2,3,...]')     // JSON array string
 * privateKeySchema.parse('base64string==')   // Base64
 * ```
 */ const privateKeySchema = zod.z.string({
    required_error: 'Private key is required. Please provide a valid private key (Base58, Base64, or JSON array format).',
    invalid_type_error: 'Private key must be a string. Please provide a valid private key (Base58, Base64, or JSON array format).'
}).min(10, {
    message: 'Private key is too short. Please provide a valid private key.'
}).max(1000, {
    message: 'Private key is too long. Please provide a valid private key.'
});
/**
 * Schema for validating Solana chain identifiers.
 *
 * Accepts multiple formats for developer convenience:
 * - String literals ('Solana', 'Solana_Devnet')
 * - Blockchain enum values (Blockchain.Solana, Blockchain.Solana_Devnet)
 * - ChainDefinition objects with type 'solana'
 *
 * @example
 * ```typescript
 * import { solanaChainIdentifierSchema } from '@core/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 *
 * // Valid formats:
 * solanaChainIdentifierSchema.parse('Solana')              // String literal
 * solanaChainIdentifierSchema.parse(Blockchain.Solana)     // Enum value
 * solanaChainIdentifierSchema.parse(Solana)                // ChainDefinition
 * ```
 */ const solanaChainIdentifierSchema = zod.z.union([
    zod.z.literal('Solana'),
    zod.z.literal('Solana_Devnet'),
    zod.z.nativeEnum(Blockchain).refine((val)=>val === Blockchain.Solana || val === Blockchain.Solana_Devnet, 'Must be a Solana blockchain enum value (Blockchain.Solana or Blockchain.Solana_Devnet)'),
    zod.z.object({
        type: zod.z.literal('solana'),
        chain: zod.z.nativeEnum(Blockchain),
        name: zod.z.string()
    }).passthrough()
]);
/**
 * Schema for validating Solana wallet provider objects.
 *
 * Ensures the provider has all required methods for wallet operations
 * including connection, signing, and optional message signing capabilities.
 *
 * @example
 * ```typescript
 * import { solanaWalletProviderSchema } from '@core/adapter-solana'
 *
 * // Validates wallet providers like Phantom, Solflare, etc.
 * const provider = window.solana
 * solanaWalletProviderSchema.parse(provider)
 * ```
 */ const solanaWalletProviderSchema = zod.z.object({
    connect: zod.z.function().returns(zod.z.promise(zod.z.object({
        publicKey: zod.z.object({
            toString: zod.z.function().returns(zod.z.string())
        })
    }))),
    disconnect: zod.z.function().returns(zod.z.promise(zod.z.void())),
    isConnected: zod.z.boolean(),
    publicKey: zod.z.union([
        zod.z.object({
            toString: zod.z.function().returns(zod.z.string())
        }),
        zod.z.null()
    ]),
    signTransaction: zod.z.function().returns(zod.z.promise(zod.z.unknown())),
    signAllTransactions: zod.z.function().returns(zod.z.promise(zod.z.array(zod.z.unknown()))).optional(),
    signMessage: zod.z.function().returns(zod.z.promise(zod.z.object({
        signature: zod.z.instanceof(Uint8Array)
    }))).optional()
}).passthrough() // Allow additional provider-specific properties
;
/**
 * Schema for validating RPC URL strings.
 *
 * Ensures the URL is properly formatted and can be used for
 * Solana RPC connections.
 *
 * @example
 * ```typescript
 * import { rpcUrlSchema } from '@core/adapter-solana'
 *
 * // Valid URLs:
 * rpcUrlSchema.parse('https://api.mainnet-beta.solana.com')
 * rpcUrlSchema.parse('https://api.devnet.solana.com')
 * rpcUrlSchema.parse('https://rpc.helius.xyz/?api-key=...')
 * ```
 */ zod.z.string({
    invalid_type_error: 'RPC URL must be a string'
}).url({
    message: 'RPC URL must be a valid URL'
});
/**
 * Schema for validating connection configuration options.
 *
 * Provides flexible validation for connection options that work
 * with both @solana/web3.js and @solana/kit adapters.
 *
 * @example
 * ```typescript
 * import { connectionOptionsSchema } from '@core/adapter-solana'
 *
 * const options = {
 *   commitment: 'confirmed',
 *   timeout: 30000,
 *   maxRetries: 3
 * }
 * connectionOptionsSchema.parse(options)
 * ```
 */ zod.z.record(zod.z.unknown()).optional();
/**
 * Base schema for validating adapter creation parameters.
 *
 * Contains common fields used by all Solana adapter factory methods.
 * Extended by transport-specific schemas in individual adapter packages.
 */ zod.z.object({
    privateKey: privateKeySchema.optional(),
    chain: solanaChainIdentifierSchema,
    provider: solanaWalletProviderSchema.optional()
});
/**
 * Schema for validating private key adapter creation parameters.
 *
 * Used by factory methods that create adapters from private keys
 * across both @solana/web3.js and @solana/kit implementations.
 *
 * @example
 * ```typescript
 * import { privateKeyAdapterParamsSchema } from '@core/adapter-solana'
 *
 * const params = {
 *   privateKey: 'your-base58-key',
 *   chain: 'Solana'
 * }
 * privateKeyAdapterParamsSchema.parse(params)
 * ```
 */ const privateKeyAdapterParamsSchema = zod.z.object({
    privateKey: privateKeySchema,
    chain: solanaChainIdentifierSchema
});
/**
 * Schema for validating provider-based adapter creation parameters.
 *
 * Used by factory methods that create adapters from wallet providers
 * across both @solana/web3.js and @solana/kit implementations.
 *
 * @example
 * ```typescript
 * import { providerAdapterParamsSchema } from '@core/adapter-solana'
 *
 * const params = {
 *   provider: window.solana,
 *   chain: 'Solana'
 * }
 * providerAdapterParamsSchema.parse(params)
 * ```
 */ const providerAdapterParamsSchema = zod.z.object({
    provider: solanaWalletProviderSchema,
    chain: solanaChainIdentifierSchema
});

/**
 * Creates a Solana Connection using default configuration.
 *
 * This utility handles the common connection creation logic shared between factory methods.
 * It automatically determines the appropriate RPC endpoint based on the chain definition
 * and applies consistent connection configuration.
 *
 * @param resolvedChain - The resolved chain definition
 * @returns A configured Solana Connection instance
 *
 * @example
 * ```typescript
 * import { createConnection } from './createConnection'
 * import { Solana } from '@core/chains'
 * import { resolveSolanaChainIdentifier } from '../../validation'
 *
 * // Using default configuration
 * const resolvedChain = resolveSolanaChainIdentifier('Solana')
 * const connection = createConnection(resolvedChain)
 * ```
 */ function createConnection(resolvedChain) {
    const rpcUrl = getDefaultRpcEndpoint(resolvedChain);
    const connectionConfig = getStandardConnectionConfig();
    return new web3_js.Connection(rpcUrl, connectionConfig);
}

/**
 * Schema for validating Connection instances.
 * This validates that the passed object is a valid Solana Connection.
 */ const connectionSchema = zod.z.custom((val)=>val != null && typeof val === 'object' && 'getLatestBlockhash' in val, 'Expected valid Solana Connection object');
/**
 * Zod schema for validating CreateAdapterFromPrivateKeyParams for web3.js.
 * This extends the shared schema with web3.js-specific Connection support.
 *
 * @example
 * ```typescript
 * import { createAdapterFromPrivateKeyParamsSchema } from '@circle-fin/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 * import { Connection } from '@solana/web3.js'
 *
 * const params = {
 *   privateKey: 'your-base58-private-key',
 *   chain: Solana, // or Blockchain.Solana or 'Solana'
 *   connection: new Connection('https://api.mainnet-beta.solana.com') // optional
 * }
 *
 * const result = createAdapterFromPrivateKeyParamsSchema.safeParse(params)
 * if (result.success) {
 *   console.log('Parameters are valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */ privateKeyAdapterParamsSchema.extend({
    connection: connectionSchema.optional()
});
/**
 * Zod schema for validating CreateAdapterFromProviderParams for web3.js.
 * This extends the shared schema with web3.js-specific Connection support.
 *
 * @example
 * ```typescript
 * import { createAdapterFromProviderParamsSchema } from '@circle-fin/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 * import { Connection } from '@solana/web3.js'
 *
 * const params = {
 *   provider: window.solana,
 *   chain: Solana, // or Blockchain.Solana or 'Solana'
 *   connection: new Connection('https://api.mainnet-beta.solana.com') // optional
 * }
 *
 * const result = createAdapterFromProviderParamsSchema.safeParse(params)
 * if (result.success) {
 *   console.log('Parameters are valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */ providerAdapterParamsSchema.extend({
    connection: connectionSchema.optional()
});
/**
 * Schema for validating Solana adapter capabilities (OperationContext-based).
 *
 * @remarks
 * - Enforces explicit address context: 'user-controlled' or 'developer-controlled'.
 * - Requires supportedChains to include Solana chain definitions only.
 */ zod.z.object({
    /**
     * Defines who controls the address used in operations.
     * Must be either 'user-controlled' or 'developer-controlled'.
     */ addressContext: zod.z.enum([
        'user-controlled',
        'developer-controlled'
    ], {
        errorMap: ()=>({
                message: "addressContext must be either 'user-controlled' or 'developer-controlled'. " + "Use 'user-controlled' for browser wallets, private keys, or hardware wallets. " + "Use 'developer-controlled' for enterprise custody solutions or multi-entity adapters."
            })
    }),
    /**
     * Array of supported chains. Must contain Solana chains only.
     * All chains must be Solana type for this adapter.
     */ supportedChains: zod.z.array(zod.z.object({
        type: zod.z.literal('solana', {
            errorMap: ()=>({
                    message: 'Solana adapter only supports Solana chains'
                })
        }),
        name: zod.z.string(),
        // Chain identifier (enum or string); kept flexible for core ChainDefinition compatibility
        chain: zod.z.unknown(),
        // Solana uses non-numeric identifiers (e.g., 'mainnet'); allow either form and optionality
        chainId: zod.z.union([
            zod.z.string(),
            zod.z.number()
        ]).optional()
    }), {
        errorMap: ()=>({
                message: 'supportedChains must be an array of ChainDefinition objects'
            })
    })
}).strict();
/**
 * Zod schema for validating SolanaAdapterOptions used by the Solana adapter constructor.
 *
 * @remarks
 * - `connection` must be a valid `@solana/web3.js` Connection.
 * - `signer` can be either a Signer-like object (has `publicKey`) or a function returning a Promise of a signer.
 */ zod.z.object({
    connection: connectionSchema.optional(),
    // Optional lazy connection factory; typed as unknown here and validated at use-site
    getConnection: zod.z.function().args(zod.z.object({
        chain: zod.z.unknown()
    })).returns(zod.z.unknown()).optional(),
    signer: zod.z.union([
        // Lazy initialization function returning a signer (Promise)
        zod.z.function().args().returns(zod.z.promise(zod.z.unknown())),
        // Direct Signer-like object (must expose publicKey)
        zod.z.object({
            publicKey: zod.z.unknown()
        }).passthrough()
    ])
}).refine((v)=>v.connection !== undefined || v.getConnection !== undefined, {
    message: 'Either `connection` or `getConnection` must be provided to initialize a Solana connection.'
});

/**
 * Simple wallet wrapper that works with AnchorProvider in all environments.
 *
 * This class provides a unified interface for both provider-based signers (e.g., browser wallets)
 * and keypair-based signers, making it compatible with AnchorProvider without requiring
 * the payer: Keypair constraint that would be incompatible with provider-based signers.
 *
 * @remarks
 * This wallet is used for Anchor instruction building, which does not require signing
 * at this stage. Actual signing is deferred to the adapter's `execute` method, which
 * uses the real signer. This design aligns with the `solana-kit` adapter's behavior
 * and avoids unnecessary signing during the instruction building phase.
 *
 * @example
 * ```typescript
 * import { Keypair } from '@solana/web3.js';
 * import { SimpleWallet } from './adapter';
 *
 * const keypair = Keypair.generate();
 * const wallet = new SimpleWallet(keypair);
 * console.log('Wallet address:', wallet.publicKey.toBase58());
 * ```
 */ class SimpleWallet {
    signer;
    /**
   * Create a new SimpleWallet instance.
   *
   * @param signer - The Solana signer (Keypair or provider-based signer).
   */ constructor(signer){
        this.signer = signer;
    }
    /**
   * The public key of the wallet.
   *
   * @returns The PublicKey associated with this wallet's signer.
   */ get publicKey() {
        return this.signer.publicKey;
    }
    /**
   * The fee payer public key for transactions.
   *
   * @returns The PublicKey that will pay for transaction fees.
   */ get payer() {
        return this.signer.publicKey;
    }
    /**
   * Sign a transaction (no-op for Anchor instruction building).
   *
   * @typeParam T - The transaction type (Transaction or VersionedTransaction).
   * @param tx - The transaction to sign.
   * @returns A Promise resolving to the unsigned transaction.
   *
   * @remarks
   * This wallet is used for Anchor instruction building, which does not require signing
   * at this stage. Actual signing is deferred to the adapter's `execute` method, which
   * uses the real signer. This design aligns with the `solana-kit` adapter's behavior
   * and avoids unnecessary signing during the instruction building phase.
   */ async signTransaction(tx) {
        // No-op: Return unsigned transaction
        // Actual signing happens in adapter.execute() using the real signer
        return Promise.resolve(tx);
    }
    /**
   * Sign multiple transactions (no-op for Anchor instruction building).
   *
   * @typeParam T - The transaction type (Transaction or VersionedTransaction).
   * @param txs - An array of transactions to sign.
   * @returns A Promise resolving to an array of unsigned transactions.
   *
   * @remarks
   * This wallet is used for Anchor instruction building, which does not require signing
   * at this stage. See `signTransaction` for details.
   */ async signAllTransactions(txs) {
        // No-op: Return unsigned transactions
        // Actual signing happens in adapter.execute() using the real signer
        return Promise.resolve(txs);
    }
}

/**
 * Create a `getAddress` function for the Solana adapter context.
 *
 * @remarks
 * For Solana, the address is always derived from the signer's public key.
 *
 * @param options - The options containing the signer accessor.
 * @returns An async function that returns the wallet's base58 public key.
 *
 * @example
 * ```typescript
 * import { createGetAddress } from '@circle-fin/adapter-solana/next/context/getAddress'
 * import { Keypair } from '@solana/web3.js'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const keypair = Keypair.generate()
 * const getAddress = createGetAddress({
 *   getSigner: async () => keypair,
 * })
 * const address = await getAddress(Solana)
 * console.log(address) // base58 public key
 * ```
 */ function createGetAddress(options) {
    return async ()=>{
        if (options.addressContext === 'developer-controlled') {
            throw new KitError({
                ...InputError.INVALID_ADDRESS,
                recoverability: 'FATAL',
                message: 'getAddress() is not supported for developer-controlled adapters. ' + 'Address management is handled programmatically; use the ' + 'configured key or address directly.'
            });
        }
        const signer = await options.getSigner();
        return signer.publicKey.toBase58();
    };
}

// ============================================================================
// Solana Address Helpers
// ============================================================================
/**
 * Zod type for a Solana base58 public key string (32-44 characters).
 *
 * @example
 * ```typescript
 * import { solanaAddress } from '@core/adapter-solana-base'
 *
 * solanaAddress.parse('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v') // ok
 * solanaAddress.parse('0xdeadbeef') // throws ZodError
 * ```
 */ const solanaAddress = zod.z.string().regex(/^[1-9A-HJ-NP-Za-km-z]{32,44}$/, 'Invalid Solana address (expected 32-44 base58 characters)');
// ============================================================================
// Solana Read Input Schemas
// ============================================================================
const tokenBalanceReadSchema = zod.z.object({
    type: zod.z.literal('tokenBalance'),
    mint: solanaAddress,
    owner: solanaAddress
});
const nativeBalanceReadSchema = zod.z.object({
    type: zod.z.literal('nativeBalance'),
    address: solanaAddress
});
const accountExistsReadSchema = zod.z.object({
    type: zod.z.literal('accountExists'),
    address: solanaAddress
});
const associatedTokenAccountReadSchema = zod.z.object({
    type: zod.z.literal('associatedTokenAccount'),
    mint: solanaAddress,
    owner: solanaAddress
});
const tokenProgramReadSchema = zod.z.object({
    type: zod.z.literal('tokenProgram'),
    mint: solanaAddress
});
/**
 * Zod schema for {@link SolanaReadInput}.
 *
 * @example
 * ```typescript
 * import { solanaReadInputSchema } from '@core/adapter-solana-base'
 *
 * solanaReadInputSchema.parse({
 *   type: 'tokenBalance',
 *   mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *   owner: '7UX2i7SucgLMQcfZ75s3VXmZZY4YRUyJN9X1RgfMoDUi',
 * })
 * ```
 */ const solanaReadInputSchema = zod.z.discriminatedUnion('type', [
    tokenBalanceReadSchema,
    nativeBalanceReadSchema,
    accountExistsReadSchema,
    associatedTokenAccountReadSchema,
    tokenProgramReadSchema
]);
// ============================================================================
// Solana Write Input Schemas
// ============================================================================
const instructionWriteSchema = zod.z.object({
    type: zod.z.literal('instructions'),
    instructions: zod.z.array(zod.z.unknown()).min(1),
    computeUnitLimit: zod.z.number().int().positive().optional(),
    signers: zod.z.array(zod.z.unknown()).optional(),
    addressLookupTableAccounts: zod.z.array(zod.z.unknown()).optional()
});
const serializedWriteSchema = zod.z.object({
    type: zod.z.literal('serializedTransaction'),
    // Reject zero-byte payloads at the boundary: an empty Uint8Array would
    // otherwise reach `VersionedTransaction.deserialize` and surface as an
    // opaque web3.js decode error rather than a clear validation failure.
    serializedTransaction: zod.z.instanceof(Uint8Array).refine((bytes)=>bytes.length > 0, {
        message: 'serializedTransaction must not be empty.'
    })
});
/**
 * Zod schema for {@link SolanaWriteInput}.
 *
 * @example
 * ```typescript
 * import { solanaWriteInputSchema } from '@core/adapter-solana-base'
 * import { SystemProgram } from '@solana/web3.js'
 *
 * const ix = SystemProgram.transfer({ fromPubkey: payer.publicKey, toPubkey: recipient, lamports: 1000 })
 *
 * solanaWriteInputSchema.parse({
 *   type: 'instructions',
 *   instructions: [ix],
 * })
 *
 * solanaWriteInputSchema.parse({
 *   type: 'serializedTransaction',
 *   serializedTransaction: new Uint8Array([1, 2, 3]),
 * })
 * ```
 */ const solanaWriteInputSchema = zod.z.discriminatedUnion('type', [
    instructionWriteSchema,
    serializedWriteSchema
]);

/**
 * All known Solana chain definitions.
 *
 * @remarks
 * Used as the default `supportedChains` when none are provided.
 */ const ALL_SOLANA_CHAINS = [
    Solana,
    SolanaDevnet
];
/**
 * Resolve partial capability overrides into a complete `AdapterCapabilities`.
 *
 * @remarks
 * Defaults:
 * - `addressContext` \> `'user-controlled'`
 * - `supportedChains` \> all known Solana chains (mainnet + devnet)
 *
 * @param overrides - Partial capabilities to merge with defaults.
 * @returns A fully resolved `AdapterCapabilities` object.
 *
 * @example
 * ```typescript
 * import { resolveSolanaCapabilities } from '@core/adapter-solana-base'
 * import { Solana } from '@core/chains'
 *
 * const capabilities = resolveSolanaCapabilities({
 *   supportedChains: [Solana],
 * })
 * ```
 */ function resolveSolanaCapabilities(overrides) {
    return {
        addressContext: overrides?.addressContext ?? 'user-controlled',
        supportedChains: overrides?.supportedChains && overrides.supportedChains.length > 0 ? overrides.supportedChains : [
            ...ALL_SOLANA_CHAINS
        ]
    };
}

/**
 * Token balance read binding for Solana.
 *
 * @remarks
 * Dispatches to the adapter's `read` primitive with a `tokenBalance` input.
 * The read primitive implementation (in each concrete adapter) calls the
 * appropriate RPC method to fetch the balance.
 *
 * @param input - The token balance input containing token selector and optional wallet address.
 * @param ctx - The execution context with adapter access.
 * @returns The token balance as an `Amount`.
 *
 * @example
 * ```typescript
 * import { tokenBalanceOfExecute } from '@core/adapter-solana-base'
 *
 * // Used as an execute binding in the action registry:
 * // { 'token.balanceOf': { execute: tokenBalanceOfExecute } }
 * const output = await tokenBalanceOfExecute(
 *   {
 *     token: { locator: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', decimals: 6 },
 *     walletAddress: '7xKX...',
 *   },
 *   executeCtx,
 * )
 * ```
 */ async function tokenBalanceOfExecute(input, ctx) {
    const chain = ctx.chain;
    const wallet = input.walletAddress ?? await ctx.adapter.getAddress(chain);
    const tokenInfo = ctx.tokens.resolve(input.token, chain.chain);
    const balance = await ctx.read({
        type: 'tokenBalance',
        mint: tokenInfo.locator,
        owner: wallet
    });
    return {
        amount: Amount.from(balance, {
            decimals: tokenInfo.decimals
        })
    };
}

/**
 * SPL Token program ID (standard, non-2022).
 *
 * @remarks
 * Address: TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA
 */ const TOKEN_PROGRAM_ID = new web3_js.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
/**
 * SPL Token-2022 (Token Extensions) program ID.
 *
 * @remarks
 * Address: TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb
 */ const TOKEN_2022_PROGRAM_ID = new web3_js.PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb');
/**
 * SPL Associated Token Account program ID.
 *
 * @remarks
 * Address: ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL
 */ const ASSOCIATED_TOKEN_PROGRAM_ID = new web3_js.PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');
/**
 * Derive the Associated Token Account address for a given mint and owner.
 *
 * Equivalent to \@solana/spl-token's `getAssociatedTokenAddressSync`.
 *
 * @param mint - The token mint public key.
 * @param owner - The wallet owner public key.
 * @param allowOwnerOffCurve - Allow the owner to be off the ed25519 curve
 *   (e.g. PDA owners). Defaults to `false`.
 * @param programId - The token program owning the account.
 *   Defaults to the standard SPL Token program.
 * @param associatedTokenProgramId - The ATA program.
 *   Defaults to the standard ATA program.
 * @returns The derived ATA public key.
 *
 * @throws `KitError` with code `INPUT_INVALID_ADDRESS` when the owner is off the
 *   ed25519 curve and `allowOwnerOffCurve` is `false`.
 *
 * @example
 * ```typescript
 * import { getAssociatedTokenAddressSync } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const ata = getAssociatedTokenAddressSync(
 *   new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'),
 *   new PublicKey('DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'),
 * )
 * ```
 */ const getAssociatedTokenAddressSync = (mint, owner, allowOwnerOffCurve = false, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>{
    if (!allowOwnerOffCurve && !web3_js.PublicKey.isOnCurve(owner.toBuffer())) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Owner ${owner.toBase58()} is off the ed25519 curve`,
            cause: {
                trace: {
                    reason: 'Owner is off the ed25519 curve',
                    owner: owner.toBase58()
                }
            }
        });
    }
    const [address] = web3_js.PublicKey.findProgramAddressSync([
        owner.toBuffer(),
        programId.toBuffer(),
        mint.toBuffer()
    ], associatedTokenProgramId);
    return address;
};
/**
 * Build an ATA instruction with the given accounts and data.
 * @internal
 */ const buildAssociatedTokenAccountInstruction = (payer, associatedToken, owner, mint, instructionData, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>new web3_js.TransactionInstruction({
        keys: [
            {
                pubkey: payer,
                isSigner: true,
                isWritable: true
            },
            {
                pubkey: associatedToken,
                isSigner: false,
                isWritable: true
            },
            {
                pubkey: owner,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: mint,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: web3_js.SystemProgram.programId,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: programId,
                isSigner: false,
                isWritable: false
            }
        ],
        programId: associatedTokenProgramId,
        data: instructionData
    });
/**
 * Create an idempotent instruction to create an Associated Token Account.
 *
 * Unlike {@link createAssociatedTokenAccountInstruction}, this variant
 * succeeds even if the ATA already exists (uses discriminator `1`).
 *
 * Equivalent to \@solana/spl-token's
 * `createAssociatedTokenAccountIdempotentInstruction`.
 *
 * @param payer - The account paying for the creation (writable signer).
 * @param associatedToken - The ATA address to create (writable).
 * @param owner - The wallet that will own the ATA.
 * @param mint - The token mint.
 * @param programId - The token program. Defaults to SPL Token.
 * @param associatedTokenProgramId - The ATA program.
 * @returns A transaction instruction.
 */ const createAssociatedTokenAccountIdempotentInstruction = (payer, associatedToken, owner, mint, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>buildAssociatedTokenAccountInstruction(payer, associatedToken, owner, mint, Buffer.from([
        1
    ]), programId, associatedTokenProgramId);
/**
 * Detect whether a mint account is owned by the standard SPL Token Program
 * or by Token-2022.
 *
 * Fetches the mint account info and inspects its `owner` field. Falls back to
 * `TOKEN_PROGRAM_ID` when the account does not exist on-chain. Transient RPC
 * errors (timeouts, rate limits) are re-thrown so callers can handle them
 * explicitly rather than silently deriving an ATA against the wrong program.
 *
 * @param connection - The active Solana RPC connection.
 * @param mintKey - The public key of the mint account to inspect.
 * @returns `TOKEN_2022_PROGRAM_ID` when the mint is owned by Token-2022,
 *   otherwise `TOKEN_PROGRAM_ID`.
 */ const detectTokenProgram = async (connection, mintKey)=>{
    try {
        const accountInfo = await connection.getAccountInfo(mintKey, 'confirmed');
        if (accountInfo?.owner.equals(TOKEN_2022_PROGRAM_ID) === true) {
            return TOKEN_2022_PROGRAM_ID;
        }
        return TOKEN_PROGRAM_ID;
    } catch (error) {
        if (error instanceof Error && /could not find account/i.test(error.message)) {
            return TOKEN_PROGRAM_ID;
        }
        throw error;
    }
};
/**
 * Resolve a base58 token-program id (e.g. the value returned by
 * `ctx.read({ type: 'tokenProgram', mint })`) to a known Solana token
 * program public key.
 *
 * @remarks
 * The on-chain owner of a mint account is, in principle, arbitrary. Anything
 * other than the canonical SPL Token / Token-2022 program ids is either a
 * misconfigured mint or an attempt to inject a custom CPI target through
 * token resolution. Every call site that derives ATAs or builds token
 * instructions from a resolved program id MUST refuse the unknown case
 * rather than forwarding an attacker-controlled program into a CPI. Shared
 * here so the CCTP, Gateway and transfer paths apply the identical guard.
 *
 * @param programIdBase58 - The base58-encoded token program id to validate.
 * @returns The canonical {@link TOKEN_PROGRAM_ID} or
 *   {@link TOKEN_2022_PROGRAM_ID}.
 * @throws `KitError` with {@link InputError.VALIDATION_FAILED} when the id is
 *   neither the SPL Token nor the Token-2022 program.
 *
 * @example
 * ```typescript
 * import { asKnownTokenProgramId } from '@core/adapter-solana-base'
 *
 * const programId = asKnownTokenProgramId(
 *   await ctx.read({ type: 'tokenProgram', mint }),
 * )
 * ```
 */ const asKnownTokenProgramId = (programIdBase58)=>{
    if (programIdBase58 === TOKEN_PROGRAM_ID.toBase58()) {
        return TOKEN_PROGRAM_ID;
    }
    if (programIdBase58 === TOKEN_2022_PROGRAM_ID.toBase58()) {
        return TOKEN_2022_PROGRAM_ID;
    }
    throw new KitError({
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: 'Unsupported tokenProgram: mint is not owned by the SPL Token or Token-2022 program.',
        cause: {
            trace: {
                tokenProgram: programIdBase58
            }
        }
    });
};
/**
 * Create a TransferChecked instruction for an SPL token.
 *
 * Token-2022 mints reject the basic `Transfer` instruction and require
 * `TransferChecked`, which includes the mint address and expected decimals.
 * This variant is safe for both standard Token and Token-2022 programs.
 *
 * Unlike \@solana/spl-token's reference implementation (which appends
 * `multiSigners` and `programId` as positional parameters), this helper
 * collapses both into a single trailing `options` object. Positional
 * overload drift across Token/Token-2022 call sites is a common source
 * of silent bugs, and the options bag also keeps us comfortably under
 * lint thresholds on function parameter counts.
 *
 * @param source - The source token account (writable).
 * @param mint - The token mint (read-only, used for decimal verification).
 * @param destination - The destination token account (writable).
 * @param owner - The owner/authority of the source account (signer when
 *   `options.multiSigners` is empty).
 * @param amount - The number of tokens to transfer (in smallest units).
 * @param decimals - The expected number of decimals for the mint.
 * @param options - Optional extras:
 *   - `multiSigners`: extra signers for multisig owners. When non-empty,
 *     `owner` is not marked as a signer and each entry is added as a
 *     signer key.
 *   - `programId`: the token program. Defaults to SPL Token.
 * @returns A transaction instruction.
 */ const createTransferCheckedInstruction = (source, mint, destination, owner, amount, decimals, options = {})=>{
    const multiSigners = options.multiSigners ?? [];
    const programId = options.programId ?? TOKEN_PROGRAM_ID;
    const data = Buffer.alloc(10);
    data.writeUInt8(12, 0) // TransferChecked discriminator
    ;
    data.writeBigUInt64LE(BigInt(amount), 1);
    data.writeUInt8(decimals, 9);
    const ownerIsSigner = multiSigners.length === 0;
    const keys = [
        {
            pubkey: source,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: mint,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: destination,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: owner,
            isSigner: ownerIsSigner,
            isWritable: false
        },
        ...multiSigners.map((signer)=>({
                pubkey: signer,
                isSigner: true,
                isWritable: false
            }))
    ];
    return new web3_js.TransactionInstruction({
        keys,
        programId,
        data
    });
};

/**
 * Byte offset of the `decimals` field inside an SPL Token mint account.
 *
 * @remarks
 * The mint layout starts with a 36-byte `COption<Pubkey>` mint authority and
 * an 8-byte supply, so `decimals` is the 45th byte. Token-2022 keeps the same
 * base layout and appends its extensions after it, so the offset holds for
 * both programs.
 * @internal
 */ const SOLANA_MINT_DECIMALS_OFFSET = 44;
/**
 * Byte offset of the `isInitialized` flag inside an SPL Token mint account.
 *
 * @remarks
 * `0` before `InitializeMint` runs, `1` after. An uninitialized mint has no
 * meaningful `decimals` value, so a reader must check this before trusting
 * the byte at {@link SOLANA_MINT_DECIMALS_OFFSET}.
 * @internal
 */ const SOLANA_MINT_IS_INITIALIZED_OFFSET = 45;
/**
 * Exact byte length of a base SPL Token mint account.
 *
 * @remarks
 * A 4-byte mint-authority option tag, a 32-byte mint authority, an 8-byte
 * supply, a 1-byte decimals field, a 1-byte `isInitialized` flag, a 4-byte
 * freeze-authority option tag, and a 32-byte freeze authority add up to 82
 * bytes. Account sizes are exact here: a mint with no extensions is this
 * length under both token programs, and only Token-2022 extends it.
 * @internal
 */ const SOLANA_MINT_ACCOUNT_LENGTH = 82;
/**
 * Byte offset of the Token-2022 account-type discriminator.
 *
 * @remarks
 * A Token-2022 account that carries extensions pads the base layout to the
 * 165-byte token-account size, then writes an account type at this offset.
 * The padding exists precisely so a mint and a token account cannot be
 * confused by length alone.
 */ const SOLANA_TOKEN_2022_ACCOUNT_TYPE_OFFSET = 165;
/** `AccountType::Mint` in the Token-2022 extension layout. */ const SOLANA_TOKEN_2022_ACCOUNT_TYPE_MINT = 1;
/**
 * Programs allowed to own a genuine SPL mint account.
 *
 * @remarks
 * A token account is owned by this same set of programs, so this check
 * cannot tell a mint from a token account — it only rules out an account
 * owned by something else entirely. {@link isMintLayout} draws that second
 * distinction.
 */ const TOKEN_PROGRAM_OWNERS = new Set([
    TOKEN_PROGRAM_ID.toBase58(),
    TOKEN_2022_PROGRAM_ID.toBase58()
]);
/**
 * Report whether an account owned by a token program holds a mint.
 *
 * @remarks
 * Length alone cannot answer this, and neither can the `isInitialized` byte:
 * a 165-byte token account is owned by the same program, and offset 45 falls
 * inside its owner pubkey, so roughly one such account in 256 carries a `1`
 * there and reads as an initialized mint. Matching the layout exactly rules
 * every token account out, along with the 355-byte multisig account.
 *
 * @param account - The account bytes and its owning program.
 * @returns `true` when the bytes are laid out as a mint.
 */ function isMintLayout(account) {
    // A mint with no extensions is exactly 82 bytes under both programs.
    if (account.data.length === SOLANA_MINT_ACCOUNT_LENGTH) return true;
    // Only Token-2022 extends a mint. It pads the base to the token-account
    // size, then writes AccountType at that offset: 1 = Mint, 2 = Account.
    if (account.owner !== TOKEN_2022_PROGRAM_ID.toBase58()) return false;
    return account.data.length > SOLANA_TOKEN_2022_ACCOUNT_TYPE_OFFSET && account.data[SOLANA_TOKEN_2022_ACCOUNT_TYPE_OFFSET] === SOLANA_TOKEN_2022_ACCOUNT_TYPE_MINT;
}
/**
 * Maximum number of entries retained in the mint-decimals cache.
 *
 * @remarks
 * Bound the cache so a long-running, multi-tenant process that touches many
 * unique mints cannot grow it without limit. On overflow, evict the oldest
 * entry by insertion order.
 * @internal
 */ const SOLANA_DECIMALS_CACHE_MAX = 1024;
/**
 * Mint-decimals cache keyed by blockchain and mint address.
 *
 * @remarks
 * SPL mint decimal precision is immutable after the mint is initialized. The
 * bounded cache avoids repeated account reads while preventing unbounded
 * growth in long-running processes.
 */ const decimalsCache = new Map();
/** Cache a validated decimals value with FIFO eviction. */ function cacheDecimals(key, decimals) {
    if (decimalsCache.size >= SOLANA_DECIMALS_CACHE_MAX && !decimalsCache.has(key)) {
        const oldest = decimalsCache.keys().next().value;
        if (oldest !== undefined) decimalsCache.delete(oldest);
    }
    decimalsCache.set(key, decimals);
}
/**
 * Read and validate an SPL token's decimal precision from its mint account.
 *
 * @param readMintAccount - Adapter-specific mint account reader.
 * @param mintAddress - Base58 SPL mint address.
 * @param chain - Solana chain that holds the mint account.
 * @returns The decimal precision stored in the mint account.
 * @throws `KitError` with `INPUT_INVALID_CHAIN` when `chain` is not a Solana
 * chain, before address validation or any account read.
 * @throws `KitError` with `INPUT_INVALID_ADDRESS` when `mintAddress` does not
 * decode as a base58 Solana public key, before any account read.
 * @throws A reader-provided `KitError` when the reader rejects with one;
 * otherwise use `INPUT_VALIDATION_FAILED` for read failures, with provider
 * credentials redacted.
 * @throws `KitError` with `INPUT_VALIDATION_FAILED` when no account exists at
 * the address; when the account is not owned by the SPL Token or Token-2022
 * program; when the account bytes are not laid out as a mint (see
 * {@link isMintLayout}); or when the account's `isInitialized` flag is not set.
 * @example
 * ```typescript
 * import { Solana } from '@core/chains'
 * import {
 *   resolveSolanaTokenDecimalsFromMint,
 *   type SolanaMintAccountReader,
 * } from '@core/adapter-solana-base'
 *
 * declare const readMintAccount: SolanaMintAccountReader
 *
 * const decimals = await resolveSolanaTokenDecimalsFromMint(
 *   readMintAccount,
 *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *   Solana,
 * )
 * ```
 */ async function resolveSolanaTokenDecimalsFromMint(readMintAccount, mintAddress, chain) {
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `SPL mint decimals can only be read on a Solana chain, but the chain type is '${chain.type}'`);
    }
    try {
        // Decoding validates both the base58 alphabet and the 32-byte length.
        // `solanaAddress` (a regex on character count alone) let a string like
        // `'2'.repeat(43)` through, and this same decode inside the reader threw
        // an unhandled error after an RPC round trip had already started.
        new web3_js.PublicKey(mintAddress);
    } catch  {
        throw createInvalidAddressError(mintAddress, chain.name, 'a base58-encoded 32-byte mint address');
    }
    // Base58 is case sensitive, so the address is used as-is in the key.
    const cacheKey = `${chain.chain}:${mintAddress}`;
    const cached = decimalsCache.get(cacheKey);
    if (cached !== undefined) return cached;
    let account;
    try {
        account = await readMintAccount(mintAddress);
    } catch (error) {
        if (error instanceof KitError) throw error;
        throw createValidationFailedError('mintAddress', mintAddress, `Failed to fetch decimals for SPL token on ${chain.name}: ${redactErrorMessage(getErrorMessage(error))}`);
    }
    if (account === null) {
        throw createValidationFailedError('mintAddress', mintAddress, `Mint account does not exist on ${chain.name}`);
    }
    // Order matters: only a Token / Token-2022 account uses this layout at
    // all, so the owner decides whether the byte offsets below mean anything.
    if (!TOKEN_PROGRAM_OWNERS.has(account.owner)) {
        throw createValidationFailedError('mintAddress', mintAddress, `Account is not owned by the SPL Token or Token-2022 program on ${chain.name}`);
    }
    if (!isMintLayout(account)) {
        throw createValidationFailedError('mintAddress', mintAddress, `Account is not laid out as an SPL token mint on ${chain.name}`);
    }
    // A mint that exists but never ran `InitializeMint` holds a zero decimals
    // byte, which would otherwise read as a valid zero-decimal token.
    if (account.data[SOLANA_MINT_IS_INITIALIZED_OFFSET] !== 1) {
        throw createValidationFailedError('mintAddress', mintAddress, `Mint account is not initialized on ${chain.name}`);
    }
    // Every layout `isMintLayout` accepts is at least 82 bytes long, so
    // `SOLANA_MINT_DECIMALS_OFFSET` (44) is always a valid index here.
    // biome-ignore lint/style/noNonNullAssertion: the layout check above guarantees the index exists
    const decimals = account.data[SOLANA_MINT_DECIMALS_OFFSET];
    // Cache only after validation so a malformed account cannot poison later
    // lookups of this immutable value.
    cacheDecimals(cacheKey, decimals);
    return decimals;
}

/**
 * Token transfer write binding for Solana.
 *
 * @remarks
 * Builds an SPL token transfer instruction and emits it via `ctx.write()`.
 *
 * Detects whether the mint is owned by the standard Token Program or by
 * Token-2022 (via `ctx.read({ type: 'tokenProgram' })`) so the correct
 * program id is used when deriving associated token accounts and building
 * the transfer instruction. Uses `createTransferCheckedInstruction`
 * (rather than the unchecked `transfer`) because Token-2022 mints reject
 * the unchecked variant; the checked variant is also safe for standard
 * SPL Token mints.
 *
 * @param input - The transfer input containing token, recipient, and amount.
 * @param ctx - The build context with write capability.
 *
 * @example
 * ```typescript
 * import { tokenTransferBuild } from '@core/adapter-solana-base'
 *
 * // Used as a build binding in the action registry:
 * // { 'token.transfer': { build: tokenTransferBuild } }
 * await tokenTransferBuild(
 *   {
 *     token: { locator: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', decimals: 6 },
 *     to: '7xKX...',
 *     amount: 1000000n,
 *   },
 *   buildCtx,
 * )
 * ```
 */ async function tokenTransferBuild(input, ctx) {
    const chain = ctx.chain;
    const wallet = await ctx.adapter.getAddress(chain);
    const tokenInfo = ctx.tokens.resolve(input.token, chain.chain);
    const mint = new web3_js.PublicKey(tokenInfo.locator);
    const owner = new web3_js.PublicKey(wallet);
    const recipient = new web3_js.PublicKey(input.to);
    const programIdBase58 = await ctx.read({
        type: 'tokenProgram',
        mint: tokenInfo.locator
    });
    const tokenProgramId = asKnownTokenProgramId(programIdBase58);
    const fromAta = getAssociatedTokenAddressSync(mint, owner, false, tokenProgramId);
    const toAta = getAssociatedTokenAddressSync(mint, recipient, false, tokenProgramId);
    const ensureAtaIx = createAssociatedTokenAccountIdempotentInstruction(owner, toAta, recipient, mint, tokenProgramId);
    const transferIx = createTransferCheckedInstruction(fromAta, mint, toAta, owner, input.amount, tokenInfo.decimals, {
        programId: tokenProgramId
    });
    ctx.write({
        type: 'instructions',
        instructions: [
            ensureAtaIx,
            transferIx
        ]
    });
}

/**
 * Create a native balance read binding for Solana.
 *
 * @param getNativeBalance - Platform-specific native balance fetcher.
 * @returns An execute callback for the `native.balanceOf` action.
 *
 * @example
 * ```typescript
 * import { createNativeBalanceOfExecute } from '@core/adapter-solana-base'
 * import { SolanaMainnet } from '@core/chains'
 *
 * const execute = createNativeBalanceOfExecute(async (chain, wallet) => {
 *   const { Connection, PublicKey } = await import('@solana/web3.js')
 *   const connection = new Connection(chain.rpcUrl)
 *   return BigInt(await connection.getBalance(new PublicKey(wallet)))
 * })
 * ```
 */ function createNativeBalanceOfExecute(getNativeBalance) {
    return async (input, ctx)=>{
        const wallet = input.walletAddress ?? await ctx.adapter.getAddress(ctx.chain);
        const balance = await getNativeBalance(ctx.chain, wallet);
        return {
            amount: Amount.from(balance, {
                decimals: ctx.chain.nativeCurrency.decimals
            })
        };
    };
}

/**
 * Native SOL transfer write binding.
 *
 * @remarks
 * Builds a System Program transfer instruction and emits it via `ctx.write()`.
 *
 * @param input - The transfer input containing recipient and amount in lamports.
 * @param ctx - The build context with write capability.
 *
 * @example
 * ```typescript
 * import { nativeTransferBuild } from '@core/adapter-solana-base'
 *
 * // Used as a build binding in the action registry:
 * // { 'native.transfer': { build: nativeTransferBuild } }
 * await nativeTransferBuild(
 *   { to: '7xKX...', amount: 1000000n },
 *   buildCtx,
 * )
 * ```
 */ async function nativeTransferBuild(input, ctx) {
    // Validate the recipient before any wallet call: a bad address would
    // otherwise throw a raw `PublicKey` Error that normalises to
    // RPC_ENDPOINT_ERROR (RETRYABLE) instead of a clear, FATAL input error.
    const parsedTo = solanaAddress.safeParse(input.to);
    if (!parsedTo.success) {
        throw createValidationFailedError('to', input.to, 'Invalid Solana recipient address (expected 32-44 base58 characters)');
    }
    const wallet = await ctx.adapter.getAddress(ctx.chain);
    const ix = web3_js.SystemProgram.transfer({
        fromPubkey: new web3_js.PublicKey(wallet),
        toPubkey: new web3_js.PublicKey(input.to),
        lamports: input.amount
    });
    ctx.write({
        type: 'instructions',
        instructions: [
            ix
        ]
    });
}

/**
 * Create a bound CCTP depositForBurn write action for Solana.
 *
 * @param adapter - The Solana adapter.
 * @param buildCCTPInstructions - Platform-specific instruction builder.
 * @returns A bound write action.
 *
 * @example
 * ```typescript
 * import { bindDepositForBurn } from '@core/adapter-solana-base'
 *
 * const depositForBurn = bindDepositForBurn(adapter, async (input, ctx) => {
 *   return buildSolanaDepositForBurnInstructions(input, ctx)
 * })
 * ```
 */ function bindDepositForBurn(adapter, buildCCTPInstructions) {
    return cctpV2DepositForBurn.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await buildCCTPInstructions(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/**
 * Create a bound CCTP depositForBurnWithHook write action for Solana.
 *
 * @param adapter - The Solana adapter.
 * @param buildCCTPInstructions - Platform-specific instruction builder.
 * @returns A bound write action.
 *
 * @see {@link bindDepositForBurn} for the non-hook variant.
 *
 * @example
 * ```typescript
 * import { bindDepositForBurnWithHook } from '@core/adapter-solana-base'
 *
 * const depositForBurnWithHook = bindDepositForBurnWithHook(adapter, async (input, ctx) => {
 *   return buildSolanaDepositForBurnInstructions(input, ctx)
 * })
 * ```
 */ function bindDepositForBurnWithHook(adapter, buildCCTPInstructions) {
    return cctpV2DepositForBurnWithHook.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await buildCCTPInstructions(input, ctx);
            ctx.write(writeInput);
        }
    });
}

/**
 * Create a bound CCTP receiveMessage write action for Solana.
 *
 * @param adapter - The Solana adapter.
 * @param buildCCTPInstructions - Platform-specific instruction builder.
 * @returns A bound write action.
 *
 * @example
 * ```typescript
 * import { bindReceiveMessage } from '@core/adapter-solana-base'
 * import type { CCTPReceiveMessageBuilder } from '@core/adapter-solana-base'
 *
 * const builder: CCTPReceiveMessageBuilder = async (input, ctx) => {
 *   // Load programs, derive PDAs, build instructions
 *   return { type: 'instructions', instructions: [], signers: [] }
 * }
 *
 * const action = bindReceiveMessage(adapter, builder)
 * ```
 */ function bindReceiveMessage(adapter, buildCCTPInstructions) {
    return cctpV2ReceiveMessage.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await buildCCTPInstructions(input, ctx);
            ctx.write(writeInput);
        }
    });
}

/**
 * Create a bound CCTP customBurn write action for Solana.
 *
 * @param adapter - The Solana adapter.
 * @param buildCCTPInstructions - Platform-specific instruction builder.
 * @returns A bound write action.
 *
 * @example
 * ```typescript
 * import { bindCustomBurn } from '@core/adapter-solana-base'
 *
 * const customBurn = bindCustomBurn(adapter, async (input, ctx) => {
 *   return buildSolanaCustomBurnInstructions(input, ctx)
 * })
 * ```
 */ function bindCustomBurn(adapter, buildCCTPInstructions) {
    return cctpV2CustomBurn.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await buildCCTPInstructions(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/**
 * Create a bound CCTP customBurnWithHook write action for Solana.
 *
 * @param adapter - The Solana adapter.
 * @param buildCCTPInstructions - Platform-specific instruction builder.
 * @returns A bound write action.
 *
 * @see {@link bindCustomBurn} for the non-hook variant.
 *
 * @example
 * ```typescript
 * import { bindCustomBurnWithHook } from '@core/adapter-solana-base'
 *
 * const customBurnWithHook = bindCustomBurnWithHook(adapter, async (input, ctx) => {
 *   return buildSolanaCustomBurnInstructions(input, ctx)
 * })
 * ```
 */ function bindCustomBurnWithHook(adapter, buildCCTPInstructions) {
    return cctpV2CustomBurnWithHook.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await buildCCTPInstructions(input, ctx);
            ctx.write(writeInput);
        }
    });
}

/**
 * CCTP constants for Solana.
 *
 * @packageDocumentation
 */ /**
 * Compute unit limits for CCTP operations on Solana.
 *
 * @remarks
 * Based on observed compute unit consumption in production transactions.
 * Each limit includes headroom above typical observed usage.
 */ const CCTP_COMPUTE_UNITS = {
    receiveMessage: 350_000,
    depositForBurn: 200_000
};
/**
 * CCTP Address Lookup Table address for Solana mainnet.
 */ const CCTP_ALT_ADDRESS_MAINNET = 'qj4EYgsGpnRdt9rvQW3wWZR8JVaKPg9rG9EB8DNgfz8';
/**
 * CCTP Address Lookup Table address for Solana devnet.
 */ const CCTP_ALT_ADDRESS_DEVNET = '29VCJ73d5aR5dE6oxaUkipntw1tFzDDKNLqrXE2ujWHW';
/**
 * Lamports required for CCTP message account rent exemption.
 *
 * @remarks
 * ~3.87M lamports (≈ 0.00387 SOL). This is a refundable rent deposit.
 */ const MESSAGE_ACCOUNT_RENT_LAMPORTS = 3_900_000;

/**
 * Resolve the CCTP Address Lookup Table address for a Solana chain.
 *
 * @remarks
 * CCTP v2 `receiveMessage` transactions on Solana reference ~24 accounts
 * and exceed the 1232-byte raw transaction size limit. The CCTP ALT
 * contains the stable, high-frequency accounts (program IDs, static PDAs,
 * sysvars) so they can be referenced by 1-byte indices in a versioned
 * transaction. Without the ALT, `receiveMessage` simulation fails with
 * `VersionedTransaction too large`.
 *
 * @param chain - The chain definition.
 * @returns The ALT address (base58) or `null` when the chain is not Solana.
 */ function getCctpAltAddress(chain) {
    if (chain.type !== 'solana') {
        return null;
    }
    return chain.isTestnet ? CCTP_ALT_ADDRESS_DEVNET : CCTP_ALT_ADDRESS_MAINNET;
}
/**
 * Format the human-readable warning message for an ALT resolution failure.
 *
 * @internal
 */ function formatAltFailureMessage(failure) {
    const reason = failure.missing ? 'ALT account returned null from RPC (not deployed / not extended)' : `ALT fetch threw: ${String(failure.error?.message ?? failure.error)}`;
    return `[cctp] CCTP Address Lookup Table unavailable for chain "${failure.chain.name}" ` + `(alt=${failure.altAddress}). Transactions that exceed the 1232-byte ` + `raw size limit will fail with "VersionedTransaction too large". Reason: ${reason}`;
}
/**
 * Build a {@link CctpAltResolutionReporter} that routes failures through a
 * structured {@link Logger}.
 *
 * @remarks
 * Prefer this over the `console.warn` fallback in production adapters so the
 * diagnostic participates in the adapter's structured logging / events
 * stream (including trace correlation).
 *
 * @param logger - The runtime logger (typically `ctx.adapter.ctx.runtime.logger`).
 * @returns A reporter that emits a `logger.warn` with structured fields.
 *
 * @example
 * ```typescript
 * const accounts = await getCctpAddressLookupTableAccounts(
 *   provider.connection,
 *   chain,
 *   { onResolutionFailure: createLoggerAltReporter(runtime.logger) },
 * )
 * ```
 */ function createLoggerAltReporter(logger) {
    return (failure)=>{
        logger.warn(formatAltFailureMessage(failure), {
            chain: failure.chain.name,
            altAddress: failure.altAddress,
            missing: failure.missing,
            error: failure.error
        });
    };
}
/**
 * Default reporter: emit a structured `console.warn` so the silent-failure
 * footgun of the original implementation becomes diagnosable without any
 * caller changes.
 */ function defaultAltReporter(failure) {
    console.warn(formatAltFailureMessage(failure));
}
/**
 * Fetch the CCTP Address Lookup Table accounts for a Solana chain.
 *
 * @remarks
 * Returns an empty array when no ALT is configured, when the fetch fails,
 * or when the chain is not Solana. Returning an empty array (instead of
 * throwing) lets the caller fall back to legacy transaction encoding; it
 * will surface as a `VersionedTransaction too large` error downstream if
 * the instruction set truly requires the ALT — which is why we **always
 * emit a diagnostic** before swallowing the failure.
 *
 * Callers can pass a structured logger via `options.onResolutionFailure`
 * to route the warning through the adapter's runtime events; otherwise a
 * `console.warn` is emitted so the failure is never fully silent.
 *
 * @param connection - A Solana RPC connection.
 * @param chain - The chain definition for which to resolve the ALT.
 * @param options - Optional reporter for structured observability.
 * @returns Resolved `AddressLookupTableAccount` objects (empty array when unavailable).
 */ async function getCctpAddressLookupTableAccounts(connection, chain, options = {}) {
    const altAddress = getCctpAltAddress(chain);
    if (altAddress === null) {
        return [];
    }
    const reporter = options.onResolutionFailure ?? defaultAltReporter;
    try {
        const altPubkey = new web3_js.PublicKey(altAddress);
        const response = await connection.getAddressLookupTable(altPubkey);
        if (response.value) {
            return [
                response.value
            ];
        }
        reporter({
            chain,
            altAddress,
            missing: true,
            error: undefined
        });
        return [];
    } catch (error) {
        reporter({
            chain,
            altAddress,
            missing: false,
            error
        });
        return [];
    }
}

/**
 * Assert that a chain's CCTP v2 contract configuration is the "split" type
 * required by Solana programs.
 *
 * @param chain - A chain that already passed the CCTP v2 guard.
 * @throws {@link KitError} with `InputError.UNSUPPORTED_ROUTE` if the config is not "split".
 *
 * @example
 * ```typescript
 * import { assertCCTPV2Supported, assertSolanaSplitConfig } from '@core/adapter-solana-base'
 * import type { ChainDefinition } from '@core/chains'
 *
 * const chain: ChainDefinition = getChain()
 * assertCCTPV2Supported(chain)
 * assertSolanaSplitConfig(chain)
 * // chain.cctp.contracts.v2.type is now 'split' with tokenMessenger/messageTransmitter
 * ```
 */ function assertSolanaSplitConfig(chain) {
    if (chain.cctp.contracts.v2.type !== 'split') {
        throw new KitError({
            ...InputError.UNSUPPORTED_ROUTE,
            recoverability: 'FATAL',
            message: `Unsupported CCTP v2 contract configuration for chain "${chain.name}". ` + 'Solana requires the "split" contract type (separate tokenMessenger and messageTransmitter programs).'
        });
    }
}

/**
 * Build a composite cache key from programId and RPC endpoint.
 *
 * @remarks
 * Prevents cross-network cache poisoning: a program fetched from devnet
 * must not be reused when the same programId is requested on mainnet.
 */ function cacheKey(programId, provider) {
    return `${programId}@${provider.connection.rpcEndpoint}`;
}
/**
 * Create an instance-scoped program loader with its own cache.
 *
 * @remarks
 * Each call returns a fresh loader with an empty cache. Intended to be
 * created once per adapter instance (inside {@link createCCTPBuilders})
 * so that the cache lifetime matches the adapter lifetime.
 *
 * @returns A {@link ProgramLoader} function with an internal cache.
 *
 * @example
 * ```typescript
 * import { createProgramLoader } from '@core/adapter-solana-base'
 * import type { AnchorProvider } from '@coral-xyz/anchor'
 *
 * const loadProgram = createProgramLoader()
 * // provider is your Anchor provider instance
 * const program = await loadProgram(provider as AnchorProvider, 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe')
 * ```
 */ function createProgramLoader() {
    // Cache the Promise, not the resolved value, so concurrent calls for the
    // same key share a single in-flight RPC fetch rather than racing and
    // issuing duplicate Program.at requests.
    const cache = new Map();
    return async (provider, programId)=>{
        const key = cacheKey(programId, provider);
        const hit = cache.get(key);
        if (hit) return hit;
        const programKey = new web3_js.PublicKey(programId);
        const promise = anchor.Program.at(programKey, provider).catch((err)=>{
            cache.delete(key);
            throw err;
        });
        cache.set(key, promise);
        return promise;
    };
}

/**
 * Browser-safe byte encoding utilities for Solana PDA derivation and hex
 * conversion.
 *
 * @remarks
 * All helpers in this module use only Web-standard APIs (`TextEncoder`,
 * `DataView`, `Uint8Array`) so they work in both Node.js and browser
 * environments without a `Buffer` polyfill.
 *
 * The one exception is {@link hexToAnchorBuffer}, which imports `Buffer`
 * from the `buffer` npm package. This is required because Anchor's IDL
 * serializer (`buffer-layout`) calls `Buffer.isBuffer()` and rejects plain
 * `Uint8Array` inputs. The `buffer` package is a transitive dependency of
 * Anchor itself, so any bundle that ships Anchor already ships this shim.
 *
 * @packageDocumentation
 */ // Importing from the `buffer` npm package (not `node:buffer`) is intentional:
// this adapter must also run in browsers, where bundlers resolve `buffer` to
// a `Uint8Array`-backed polyfill. `node:buffer` would force a Node-only build.
const encoder = new TextEncoder();
/**
 * Encode an ASCII seed string into a `Uint8Array` for PDA derivation.
 *
 * @remarks
 * Wraps the standard {@link https://developer.mozilla.org/en-US/docs/Web/API/TextEncoder/encode | TextEncoder.encode}
 * method. The shared encoder instance avoids repeated allocations.
 *
 * @param value - An ASCII-only seed string (e.g. `'sender_authority'`).
 * @returns UTF-8 encoded bytes matching the on-chain PDA seed expectation.
 *
 * @example
 * ```typescript
 * import { seed } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const [pda] = PublicKey.findProgramAddressSync(
 *   [seed('token_messenger')],
 *   programId,
 * )
 * ```
 */ function seed(value) {
    return encoder.encode(value);
}
/**
 * Encode a CCTP domain number as its UTF-8 decimal string representation.
 *
 * @remarks
 * The CCTP v2 Solana programs derive PDAs using the ASCII string of the
 * domain number (e.g. `"0"`, `"3"`, `"13"`), **not** a fixed-width binary
 * encoding.  Domain 0 produces `[0x30]` (one byte, ASCII `'0'`), domain 13
 * produces `[0x31, 0x33]` (two bytes, ASCII `'13'`), and so on.
 *
 * **On-chain reference.** The Anchor program seeds the
 * `remote_token_messenger` PDA with `&remote_domain.to_string().as_bytes()`
 * — i.e. the decimal string of the `u32` domain, not the four little-endian
 * bytes a casual reader might expect. See:
 * - `evm-cctp-contracts/solana/programs/token-messenger-minter-v2/src/token_messenger_v2/instructions/add_remote_token_messenger.rs`
 *   (the `seeds = [b"remote_token_messenger", remote_domain.to_string().as_bytes()]`
 *   constraint).
 * - `evm-cctp-contracts/solana/programs/message-transmitter-v2/src/message_transmitter_v2/state.rs`
 *   for the same convention on the v2 message-transmitter program.
 *
 * If Circle ever changes the PDA seeding convention this helper must be
 * updated in lock-step or every PDA derivation site will silently break.
 *
 * @param domain - A CCTP domain number (e.g. 0 for Ethereum, 5 for Solana).
 * @returns UTF-8 encoded decimal string as a `Uint8Array`.
 *
 * @example
 * ```typescript
 * import { seed, domainToBytes } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const [remoteMessenger] = PublicKey.findProgramAddressSync(
 *   [seed('remote_token_messenger'), domainToBytes(0)],
 *   programId,
 * )
 * ```
 */ function domainToBytes(domain) {
    // A CCTP domain is a `u32` in the protocol but, in practice, a small
    // non-negative integer. A negative or fractional value would silently
    // encode the wrong seed string ("-1" → "-1", 1.5 → "1.5"), producing a
    // wrong PDA and an opaque on-chain `ConstraintSeeds` failure. Reject at
    // the boundary so callers get a clear `VALIDATION_FAILED` instead.
    if (!Number.isInteger(domain) || domain < 0 || domain > 0xffff) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid CCTP domain: expected an integer in [0, 65535], got ${String(domain)}.`,
            cause: {
                trace: {
                    domain
                }
            }
        });
    }
    return encoder.encode(domain.toString());
}
const HEX_PATTERN = /^[0-9a-fA-F]*$/;
/**
 * Default upper bound (in decoded bytes) for {@link hexToBytes} and
 * {@link hexToAnchorBuffer}: 1 MiB.
 *
 * @remarks
 * CCTP messages and attestations are a few hundred bytes at most. The cap
 * exists purely to stop an untrusted, oversized hex blob from forcing a
 * multi-megabyte allocation before any parsed-field length check runs.
 * Callers that genuinely need a different ceiling pass an explicit
 * `maxBytes` argument.
 *
 * @public
 */ const DEFAULT_MAX_HEX_BYTES = 1024 * 1024;
/**
 * Decode a hex string into a `Uint8Array`. Accepts an optional `0x` prefix.
 *
 * @remarks
 * Validates the input and throws a `KitError` when it is not a well-formed
 * hex string. A consumer calling from plain JS (no TypeScript narrowing) is
 * therefore guaranteed to get a clear error instead of silently-corrupted
 * bytes that surface as cryptic Anchor deserialization failures downstream.
 *
 * Accepted input is either `"0x" + hexPayload` or `hexPayload` directly,
 * where `hexPayload` must contain only characters `0-9`, `a-f`, `A-F` and
 * have an even length.
 *
 * @param hex - A hex string, with or without a `0x` prefix.
 * @param maxBytes - Maximum decoded byte length to accept before
 *   allocating. Defaults to {@link DEFAULT_MAX_HEX_BYTES} (1 MiB).
 * @returns The decoded byte array of length `hex.length / 2` (after prefix
 *   removal).
 * @throws `KitError` (FATAL) If `hex` has an odd number of digits, contains
 *   non-hex characters, or decodes to more than `maxBytes` bytes.
 *
 * @example
 * ```typescript
 * import { hexToBytes } from '@core/adapter-solana-base'
 *
 * const message = hexToBytes('0xdeadbeef')
 * // Uint8Array [ 0xDE, 0xAD, 0xBE, 0xEF ]
 *
 * const attestation = hexToBytes('cafebabe')
 * // Uint8Array [ 0xCA, 0xFE, 0xBA, 0xBE ]
 * ```
 */ function hexToBytes(hex, maxBytes = DEFAULT_MAX_HEX_BYTES) {
    const clean = hex.startsWith('0x') ? hex.slice(2) : hex;
    // Length cap FIRST — before allocation — so an untrusted multi-MB blob
    // fails fast instead of forcing a large buffer allocation.
    if (clean.length / 2 > maxBytes) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid hex string: decoded length exceeds the maximum of ${String(maxBytes)} bytes.`,
            cause: {
                trace: {
                    maxBytes,
                    decodedBytes: Math.floor(clean.length / 2)
                }
            }
        });
    }
    if (clean.length % 2 !== 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid hex string: expected an even number of digits, got ${String(clean.length)}.`
        });
    }
    if (!HEX_PATTERN.test(clean)) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid hex string: contains non-hex characters (expected [0-9a-fA-F]).`
        });
    }
    const bytes = new Uint8Array(clean.length / 2);
    for(let i = 0; i < bytes.length; i++){
        bytes[i] = Number.parseInt(clean.substring(i * 2, i * 2 + 2), 16);
    }
    return bytes;
}
/**
 * Decode a hex string into a `Buffer` suitable for Anchor IDL method arguments.
 *
 * @remarks
 * Anchor's IDL serializer (`@solana/buffer-layout`) validates variable-length
 * byte arguments via `Buffer.isBuffer(src)` and rejects plain `Uint8Array`
 * inputs with a `Blob.encode requires (length N) Buffer as src` error.
 * This helper is the browser-safe way to satisfy that check: it imports
 * `Buffer` from the `buffer` npm package (resolved via bundler polyfill in
 * browsers, via the Node built-in in Node.js) and wraps the decoded bytes.
 *
 * Use this for any `program.methods.foo({ bytesArg: hexToAnchorBuffer(hex) })`
 * call site where the IDL declares `bytesArg` as variable-length bytes.
 *
 * @param hex - A hex string, with or without a `0x` prefix. Must contain
 *   an even number of hex digits.
 * @param maxBytes - Maximum decoded byte length to accept before
 *   allocating. Defaults to {@link DEFAULT_MAX_HEX_BYTES} (1 MiB).
 * @returns A `Buffer` that passes `Buffer.isBuffer()` in all environments.
 *
 * @example
 * ```typescript
 * import { hexToAnchorBuffer } from '@core/adapter-solana-base'
 *
 * await program.methods
 *   .receiveMessage({
 *     message: hexToAnchorBuffer(messageHex),
 *     attestation: hexToAnchorBuffer(attestationHex),
 *   })
 *   .instruction()
 * ```
 */ function hexToAnchorBuffer(hex, maxBytes = DEFAULT_MAX_HEX_BYTES) {
    return buffer.Buffer.from(hexToBytes(hex, maxBytes));
}

/**
 * Derive all PDAs for CCTP depositForBurn.
 *
 * @param tokenMessengerProgramId - Token messenger program ID.
 * @param messageTransmitterProgramId - Message transmitter program ID.
 * @param usdcMint - The USDC mint on the source chain.
 * @param destinationDomain - The CCTP domain of the destination chain.
 * @returns All PDAs needed for the burn operation.
 *
 * @example
 * ```typescript
 * import { deriveDepositForBurnPdas } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const tokenMessengerProgramId = new PublicKey('CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe')
 * const messageTransmitterProgramId = new PublicKey('CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC')
 * const usdcMint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 *
 * const pdas = deriveDepositForBurnPdas(
 *   tokenMessengerProgramId,
 *   messageTransmitterProgramId,
 *   usdcMint,
 *   0, // Ethereum CCTP domain
 * )
 * ```
 */ function deriveDepositForBurnPdas(tokenMessengerProgramId, messageTransmitterProgramId, usdcMint, destinationDomain) {
    const [senderAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('sender_authority')
    ], tokenMessengerProgramId);
    const [tokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_messenger')
    ], tokenMessengerProgramId);
    const [tokenMinterPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_minter')
    ], tokenMessengerProgramId);
    const [localTokenPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('local_token'),
        usdcMint.toBytes()
    ], tokenMessengerProgramId);
    const [messageTransmitterPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('message_transmitter')
    ], messageTransmitterProgramId);
    const [remoteTokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('remote_token_messenger'),
        domainToBytes(destinationDomain)
    ], tokenMessengerProgramId);
    return {
        senderAuthorityPda,
        tokenMessengerPda,
        tokenMinterPda,
        localTokenPda,
        messageTransmitterPda,
        remoteTokenMessengerPda
    };
}

/**
 * Parse an address that may be hex-encoded (0x-prefixed, 32-byte EVM-padded)
 * or a base58 Solana public key.
 *
 * @remarks
 * CCTP cross-chain recipients are represented as 32-byte hex strings on EVM
 * chains. This helper transparently accepts both formats so callers don't need
 * to branch on encoding.
 *
 * @param address - A 0x-prefixed hex string or base58-encoded public key.
 * @returns The corresponding Solana {@link PublicKey}.
 * @throws `KitError` with {@link InputError.VALIDATION_FAILED} when the input
 *   is empty, not a string, or cannot be parsed as a valid Solana public key.
 *
 * @example
 * ```typescript
 * import { parseAddress } from '@core/adapter-solana-base'
 *
 * const keyFromHex = parseAddress(
 *   '0x0000000000000000000000001111111111111111111111111111111111111111',
 * )
 * const keyFromBase58 = parseAddress(
 *   'So11111111111111111111111111111111111111112',
 * )
 * ```
 */ function parseAddress(address) {
    // Reject non-strings, empty strings, AND whitespace-only strings up front.
    // Whitespace inputs (e.g. `'  '`, `'\n'`) used to slip past the previous
    // `length === 0` check and surface as a generic `PublicKey` parse error,
    // which obscured the real cause for callers passing un-trimmed user input.
    if (typeof address !== 'string' || address.trim().length === 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Invalid address: expected a non-empty string.'
        });
    }
    try {
        if (address.startsWith('0x')) {
            // CCTP encodes cross-chain recipients as 32-byte hex strings (the
            // public-key/word size on Solana). Anything shorter — like a 20-byte
            // EVM address — would silently succeed in `hexToBytes` and then
            // crash deep inside `new PublicKey()` with an opaque error. Catch
            // the size mismatch up-front so the failure is actionable.
            const HEX_PREFIX_LENGTH = 2;
            const EXPECTED_HEX_CHARS = 64 // 32 bytes
            ;
            if (address.length - HEX_PREFIX_LENGTH !== EXPECTED_HEX_CHARS) {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: 'Invalid address: hex-encoded Solana addresses must be 32 bytes ' + '(66 characters including the 0x prefix). If you are passing a ' + '20-byte EVM address, left-pad it with 12 zero bytes to 32 bytes.',
                    cause: {
                        trace: {
                            length: address.length
                        }
                    }
                });
            }
            return new web3_js.PublicKey(hexToBytes(address));
        }
        return new web3_js.PublicKey(address);
    } catch (error) {
        // Re-throw `KitError`s untouched so the structured details (code, trace)
        // produced by the size check above are not flattened into the generic
        // "could not parse" branch below.
        if (error instanceof KitError) {
            throw error;
        }
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Invalid address: could not parse as a Solana public key.',
            cause: {
                trace: {
                    rawError: error
                }
            }
        });
    }
}

/**
 * Build the depositForBurn transaction instructions.
 *
 * @param params - The burn parameters.
 * @param programs - Loaded Anchor programs.
 * @param pdas - Derived PDAs.
 * @param userUsdcAta - The user's USDC ATA.
 * @param user - The user's public key.
 * @returns Transaction instructions and the message account signer.
 *
 * @example
 * ```typescript
 * import { buildDepositForBurnInstructions } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 * import type { Program } from '@coral-xyz/anchor'
 *
 * const usdcMint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 * const user = new PublicKey('7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU')
 * const userUsdcAta = new PublicKey('11111111111111111111111111111111')
 *
 * const { instructions, signer } = await buildDepositForBurnInstructions(
 *   {
 *     amount: 1000000n,
 *     destinationDomain: 0,
 *     mintRecipient: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *     maxFee: 0n,
 *     minFinalityThreshold: 1000,
 *     usdcMint,
 *   },
 *   { tokenMessenger, messageTransmitter },
 *   pdas,
 *   userUsdcAta,
 *   user,
 * )
 * ```
 */ async function buildDepositForBurnInstructions(params, programs, pdas, userUsdcAta, user) {
    const messageAccount = web3_js.Keypair.generate();
    const fundMessageAccountIx = web3_js.SystemProgram.transfer({
        fromPubkey: user,
        toPubkey: messageAccount.publicKey,
        lamports: MESSAGE_ACCOUNT_RENT_LAMPORTS
    });
    const mintRecipientKey = parseAddress(params.mintRecipient);
    // Route the destination caller through `parseAddress` so callers can pass
    // either a base58 Solana key or a 32-byte hex CCTP recipient — matching the
    // shape we accept for `mintRecipient` — and so malformed values raise a
    // structured `KitError` (`VALIDATION_FAILED`) instead of an opaque
    // `PublicKey` constructor error.
    const callerKey = params.destinationCaller === undefined || params.destinationCaller === '' ? web3_js.PublicKey.default : parseAddress(params.destinationCaller);
    // Treat empty string the same as absent: both collapse to undefined so the
    // no-hook code path is taken. TypeScript narrows hookData to string below.
    const hookData = params.hookData !== undefined && params.hookData !== '' ? params.hookData : undefined;
    const methodName = hookData === undefined ? 'depositForBurn' : 'depositForBurnWithHook';
    if (!(methodName in programs.tokenMessenger.methods)) {
        throw new KitError({
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'FATAL',
            message: `${methodName} method not found on the CCTP tokenMessenger program. ` + 'The on-chain program may be outdated or incorrectly configured.'
        });
    }
    const baseArgs = {
        amount: new bn_js.BN(params.amount.toString()),
        destinationDomain: params.destinationDomain,
        mintRecipient: mintRecipientKey,
        destinationCaller: callerKey,
        maxFee: new bn_js.BN(params.maxFee.toString()),
        minFinalityThreshold: params.minFinalityThreshold
    };
    if (hookData !== undefined) {
        const hex = hookData.startsWith('0x') ? hookData.slice(2) : hookData;
        if (!/^[0-9a-fA-F]*$/.test(hex) || hex.length % 2 !== 0) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: 'hookData must be a valid hex string (with optional 0x prefix) of even length.'
            });
        }
        baseArgs['hookData'] = hexToAnchorBuffer(hex);
    }
    const method = programs.tokenMessenger.methods[methodName];
    if (method === undefined) {
        throw new KitError({
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'FATAL',
            message: `${methodName} method not found on the CCTP tokenMessenger program. ` + 'The on-chain program may be outdated or incorrectly configured.'
        });
    }
    const instruction = await method(baseArgs).accounts({
        owner: user,
        senderAuthorityPda: pdas.senderAuthorityPda,
        burnTokenAccount: userUsdcAta,
        burnTokenMint: params.usdcMint,
        tokenMessenger: pdas.tokenMessengerPda,
        tokenMinter: pdas.tokenMinterPda,
        localToken: pdas.localTokenPda,
        remoteTokenMessenger: pdas.remoteTokenMessengerPda,
        messageTransmitter: pdas.messageTransmitterPda,
        messageSentEventData: messageAccount.publicKey,
        eventRentPayer: user,
        messageTransmitterProgram: programs.messageTransmitter.programId,
        tokenMessengerMinterProgram: programs.tokenMessenger.programId,
        tokenProgram: params.tokenProgramId ?? TOKEN_PROGRAM_ID,
        systemProgram: web3_js.SystemProgram.programId
    }).signers([
        messageAccount
    ]).instruction();
    return {
        instructions: [
            fundMessageAccountIx,
            instruction
        ],
        signer: messageAccount
    };
}

/**
 * Generate complete depositForBurn transaction instructions.
 *
 * @remarks
 * Loads CCTP programs, derives PDAs, verifies ATA exists, and builds
 * the instruction set for a cross-chain USDC burn.
 *
 * @param params - The burn parameters including provider and chain config.
 * @returns Transaction instructions and required signers.
 * @throws {@link KitError} with `InputError.UNSUPPORTED_ROUTE` if CCTP v2 config is not "split" type.
 *
 * @example
 * ```typescript
 * import { getDepositForBurnInstructions, createProgramLoader } from '@core/adapter-solana-base'
 * import { SolanaMainnet, Ethereum } from '@core/chains'
 *
 * const loadProgram = createProgramLoader()
 * const result = await getDepositForBurnInstructions({
 *   provider,
 *   loadProgram,
 *   fromChain: SolanaMainnet,
 *   toChain: Ethereum,
 *   amount: 1000000n,
 *   mintRecipient: '0x1234567890123456789012345678901234567890',
 *   maxFee: 0n,
 *   minFinalityThreshold: 1000,
 * })
 * ```
 */ async function getDepositForBurnInstructions(params) {
    const { provider, loadProgram, fromChain, toChain } = params;
    assertSolanaSplitConfig(fromChain);
    const v2config = fromChain.cctp.contracts.v2;
    const [tokenMessengerProgram, messageTransmitterProgram] = await Promise.all([
        loadProgram(provider, v2config.tokenMessenger),
        loadProgram(provider, v2config.messageTransmitter)
    ]);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(fromChain.usdcAddress);
    const pdas = deriveDepositForBurnPdas(tokenMessengerProgram.programId, messageTransmitterProgram.programId, usdcMint, toChain.cctp.domain);
    const tokenProgramId = params.tokenProgramId ?? TOKEN_PROGRAM_ID;
    const userUsdcAta = getAssociatedTokenAddressSync(usdcMint, user, true, tokenProgramId);
    const { instructions, signer } = await buildDepositForBurnInstructions({
        amount: params.amount,
        destinationDomain: toChain.cctp.domain,
        mintRecipient: params.mintRecipient,
        destinationCaller: params.destinationCaller,
        maxFee: params.maxFee,
        minFinalityThreshold: params.minFinalityThreshold,
        usdcMint,
        hookData: params.hookData,
        tokenProgramId
    }, {
        tokenMessenger: tokenMessengerProgram,
        messageTransmitter: messageTransmitterProgram
    }, pdas, userUsdcAta, user);
    return {
        instructions,
        signers: [
            signer
        ]
    };
}

/**
 * Derive all PDAs for CCTP receiveMessage.
 *
 * @param sourceChain - The source chain (where the burn happened).
 * @param destinationChain - The destination chain (Solana, where the mint happens).
 * @param messageTransmitterProgramId - Message transmitter program ID.
 * @param tokenMessengerProgramId - Token messenger program ID.
 * @returns All PDAs needed for the receive/mint operation.
 *
 * @example
 * ```typescript
 * import { deriveReceiveMessagePdas } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 * import { Ethereum, SolanaMainnet } from '@core/chains'
 *
 * const pdas = deriveReceiveMessagePdas(
 *   Ethereum,
 *   SolanaMainnet,
 *   new PublicKey('CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC'),
 *   new PublicKey('CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe'),
 * )
 * ```
 */ function deriveReceiveMessagePdas(sourceChain, destinationChain, messageTransmitterProgramId, tokenMessengerProgramId) {
    const remoteMintKey = new web3_js.PublicKey(convertAddress(sourceChain.usdcAddress, 'solana'));
    const destinationUsdcMint = new web3_js.PublicKey(destinationChain.usdcAddress);
    const [tokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_messenger')
    ], tokenMessengerProgramId);
    const [messageTransmitterPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('message_transmitter')
    ], messageTransmitterProgramId);
    const [tokenMinterPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_minter')
    ], tokenMessengerProgramId);
    const [localTokenPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('local_token'),
        destinationUsdcMint.toBytes()
    ], tokenMessengerProgramId);
    const domainSeed = domainToBytes(sourceChain.cctp.domain);
    const [remoteTokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('remote_token_messenger'),
        domainSeed
    ], tokenMessengerProgramId);
    const [tokenPairPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_pair'),
        domainSeed,
        remoteMintKey.toBytes()
    ], tokenMessengerProgramId);
    const [custodyPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('custody'),
        destinationUsdcMint.toBytes()
    ], tokenMessengerProgramId);
    const [messageTransmitterAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('message_transmitter_authority'),
        tokenMessengerProgramId.toBytes()
    ], messageTransmitterProgramId);
    return {
        tokenMessengerPda,
        messageTransmitterPda,
        tokenMinterPda,
        localTokenPda,
        remoteTokenMessengerPda,
        remoteMintKey,
        tokenPairPda,
        custodyPda,
        messageTransmitterAuthorityPda
    };
}

/**
 * Build the receiveMessage transaction instruction.
 *
 * @param params - Receive parameters.
 * @param programs - Loaded Anchor programs.
 * @param pdas - Derived PDAs.
 * @param feeRecipientAta - Fee recipient's USDC ATA.
 * @param userUsdcAta - The recipient's USDC ATA.
 * @param user - The user's public key (payer/caller).
 * @returns Transaction instructions.
 *
 * @example
 * ```typescript
 * import { buildReceiveMessageInstructions, deriveReceiveMessagePdas } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 * import { getAssociatedTokenAddressSync } from '@core/adapter-solana-base'
 * import { Ethereum, SolanaMainnet } from '@core/chains'
 *
 * const usdcMint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 * const user = new PublicKey('11111111111111111111111111111111')
 * const feeRecipient = new PublicKey('11111111111111111111111111111111')
 * const messageTransmitterProgramId = new PublicKey('CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC')
 * const tokenMessengerProgramId = new PublicKey('CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe')
 * const pdas = deriveReceiveMessagePdas(Ethereum, SolanaMainnet, messageTransmitterProgramId, tokenMessengerProgramId)
 * const feeRecipientAta = getAssociatedTokenAddressSync(usdcMint, feeRecipient, true)
 * const userUsdcAta = getAssociatedTokenAddressSync(usdcMint, user, true)
 *
 * const { instructions } = await buildReceiveMessageInstructions(
 *   { message: '0xabc', attestation: '0xdef', eventNonce: '0x' + '00'.repeat(32), usdcMint },
 *   { tokenMessenger, messageTransmitter },
 *   pdas,
 *   feeRecipientAta,
 *   userUsdcAta,
 *   user,
 * )
 * ```
 */ async function buildReceiveMessageInstructions(params, programs, pdas, feeRecipientAta, userUsdcAta, user) {
    const { message, attestation, eventNonce } = params;
    const nonceHex = eventNonce.replace(/^0x/, '');
    if (nonceHex.length !== 64) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid eventNonce: expected 64 hex chars, got ${String(nonceHex.length)}.`
        });
    }
    const nonceBytes = hexToBytes(nonceHex);
    const [usedNoncePda] = web3_js.PublicKey.findProgramAddressSync([
        seed('used_nonce'),
        nonceBytes
    ], programs.messageTransmitter.programId);
    if (!('receiveMessage' in programs.messageTransmitter.methods)) {
        throw new KitError({
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'FATAL',
            message: 'receiveMessage method not found on the CCTP messageTransmitter program. ' + 'The on-chain program may be outdated or incorrectly configured.'
        });
    }
    const instruction = await programs.messageTransmitter.methods['receiveMessage']({
        message: hexToAnchorBuffer(message),
        attestation: hexToAnchorBuffer(attestation)
    }).accounts({
        payer: user,
        caller: user,
        authorityPda: pdas.messageTransmitterAuthorityPda,
        messageTransmitter: pdas.messageTransmitterPda,
        usedNonce: usedNoncePda,
        receiver: programs.tokenMessenger.programId,
        systemProgram: web3_js.SystemProgram.programId
    }).remainingAccounts([
        {
            pubkey: pdas.tokenMessengerPda,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: pdas.remoteTokenMessengerPda,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: pdas.tokenMinterPda,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: pdas.localTokenPda,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: pdas.tokenPairPda,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: feeRecipientAta,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: userUsdcAta,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: pdas.custodyPda,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: params.tokenProgramId ?? TOKEN_PROGRAM_ID,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: web3_js.PublicKey.findProgramAddressSync([
                seed('__event_authority')
            ], programs.tokenMessenger.programId)[0],
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: programs.tokenMessenger.programId,
            isSigner: false,
            isWritable: false
        }
    ]).instruction();
    return {
        instructions: [
            instruction
        ]
    };
}

/**
 * Generate complete receiveMessage transaction instructions.
 *
 * @remarks
 * Loads CCTP programs, derives PDAs, resolves fee recipient,
 * ensures the recipient ATA exists, and builds the instruction set.
 *
 * @param params - The receive parameters.
 * @returns Transaction instructions (no additional signers needed).
 * @throws {@link KitError} with `InputError.UNSUPPORTED_ROUTE` if CCTP v2 config is not "split" type.
 * @throws {@link KitError} with `OnchainError.TRANSACTION_REVERTED` if on-chain state fetch fails.
 *
 * @example
 * ```typescript
 * import { getReceiveMessageInstructions, createProgramLoader } from '@core/adapter-solana-base'
 * import { Ethereum, SolanaMainnet } from '@core/chains'
 *
 * const loadProgram = createProgramLoader()
 * const result = await getReceiveMessageInstructions({
 *   provider,
 *   loadProgram,
 *   fromChain: Ethereum,
 *   toChain: SolanaMainnet,
 *   message: '0x' + '00'.repeat(32),
 *   attestation: '0x' + '00'.repeat(65),
 *   eventNonce: '0x' + '00'.repeat(32),
 * })
 * ```
 */ async function getReceiveMessageInstructions(params) {
    const { provider, loadProgram, fromChain, toChain } = params;
    assertSolanaSplitConfig(toChain);
    const v2config = toChain.cctp.contracts.v2;
    const [tokenMessengerProgram, messageTransmitterProgram] = await Promise.all([
        loadProgram(provider, v2config.tokenMessenger),
        loadProgram(provider, v2config.messageTransmitter)
    ]);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(toChain.usdcAddress);
    const pdas = deriveReceiveMessagePdas(fromChain, toChain, messageTransmitterProgram.programId, tokenMessengerProgram.programId);
    if ('tokenMessenger' in tokenMessengerProgram.account) {
        const tokenMessengerState = await tokenMessengerProgram.account.tokenMessenger.fetch(pdas.tokenMessengerPda);
        const feeRecipient = tokenMessengerState['feeRecipient'];
        if (!(feeRecipient instanceof web3_js.PublicKey)) {
            throw new KitError({
                ...OnchainError.TRANSACTION_REVERTED,
                recoverability: 'FATAL',
                message: 'TokenMessenger state does not contain a valid feeRecipient PublicKey. ' + 'The on-chain program may be outdated or incorrectly configured.'
            });
        }
        const tokenProgramId = params.tokenProgramId ?? TOKEN_PROGRAM_ID;
        const feeRecipientAta = getAssociatedTokenAddressSync(usdcMint, feeRecipient, true, tokenProgramId);
        // Route through the shared `parseAddress` so `destinationAddress` has
        // the same hex/base58 parity as `mintRecipient` / `destinationCaller`:
        // a 32-byte EVM-padded hex recipient is accepted, and invalid input
        // yields the canonical VALIDATION_FAILED error shape.
        const mintRecipientOwner = params.destinationAddress === undefined ? user : parseAddress(params.destinationAddress);
        const userUsdcAta = getAssociatedTokenAddressSync(usdcMint, mintRecipientOwner, true, tokenProgramId);
        const { instructions: mintIxs } = await buildReceiveMessageInstructions({
            message: params.message,
            attestation: params.attestation,
            eventNonce: params.eventNonce,
            tokenProgramId
        }, {
            tokenMessenger: tokenMessengerProgram,
            messageTransmitter: messageTransmitterProgram
        }, pdas, feeRecipientAta, userUsdcAta, user);
        // Ensure recipient ATA exists (prepend creation instruction if needed)
        const ataInfo = await provider.connection.getAccountInfo(userUsdcAta);
        const instructions = [];
        if (ataInfo === null) {
            instructions.push(createAssociatedTokenAccountIdempotentInstruction(user, userUsdcAta, mintRecipientOwner, usdcMint, tokenProgramId));
        }
        instructions.push(...mintIxs);
        return {
            instructions,
            signers: []
        };
    }
    throw new KitError({
        ...OnchainError.TRANSACTION_REVERTED,
        recoverability: 'FATAL',
        message: 'TokenMessenger account not found on the CCTP tokenMessenger program. ' + 'The on-chain program may be outdated or incorrectly configured.'
    });
}

/**
 * Derive all PDAs for CCTP customBurn.
 *
 * @param tokenMessengerProgramId - Token messenger program ID.
 * @param messageTransmitterProgramId - Message transmitter program ID.
 * @param bridgeKitProgramId - Bridge kit program ID.
 * @param usdcMint - The USDC mint.
 * @param userPublicKey - The user's public key.
 * @param destinationDomain - The destination CCTP domain.
 * @returns All PDAs for the custom burn operation.
 *
 * @example
 * ```typescript
 * import { deriveCustomBurnPdas } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const tokenMessengerProgramId = new PublicKey('CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe')
 * const messageTransmitterProgramId = new PublicKey('CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC')
 * const bridgeKitProgramId = new PublicKey('11111111111111111111111111111111')
 * const usdcMint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 * const userPublicKey = new PublicKey('7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU')
 *
 * const pdas = deriveCustomBurnPdas(
 *   tokenMessengerProgramId,
 *   messageTransmitterProgramId,
 *   bridgeKitProgramId,
 *   usdcMint,
 *   userPublicKey,
 *   0, // Ethereum CCTP domain
 * )
 * ```
 */ function deriveCustomBurnPdas(tokenMessengerProgramId, messageTransmitterProgramId, bridgeKitProgramId, usdcMint, userPublicKey, destinationDomain) {
    const [senderAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('sender_authority')
    ], tokenMessengerProgramId);
    const [tokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_messenger')
    ], tokenMessengerProgramId);
    const [tokenMinterPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('token_minter')
    ], tokenMessengerProgramId);
    const [localTokenPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('local_token'),
        usdcMint.toBytes()
    ], tokenMessengerProgramId);
    const [messageTransmitterPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('message_transmitter')
    ], messageTransmitterProgramId);
    const [statePda] = web3_js.PublicKey.findProgramAddressSync([
        seed('state')
    ], bridgeKitProgramId);
    // Denylist is owned by the TokenMessenger program (NOT MessageTransmitter
    // and NOT the bridge-kit program). See `cctp_v2/programs/token-messenger-
    // minter-v2/src/token_messenger_v2/instructions/deposit_for_burn.rs` —
    // the `denylist_account` constraint is `seeds = [b"denylist_account",
    // depositor.key().as_ref()], bump = ..., owner = token_messenger_minter
    // program`. Deriving from any other program id makes the on-chain
    // constraint check fail with `ConstraintSeeds`.
    const [denylistPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('denylist_account'),
        userPublicKey.toBytes()
    ], tokenMessengerProgramId);
    const [eventAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('__event_authority')
    ], tokenMessengerProgramId);
    const [bridgeKitEventAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('__event_authority')
    ], bridgeKitProgramId);
    const [remoteTokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        seed('remote_token_messenger'),
        domainToBytes(destinationDomain)
    ], tokenMessengerProgramId);
    return {
        senderAuthorityPda,
        tokenMessengerPda,
        tokenMinterPda,
        localTokenPda,
        messageTransmitterPda,
        statePda,
        denylistPda,
        eventAuthorityPda,
        remoteTokenMessengerPda,
        bridgeKitEventAuthorityPda
    };
}

/**
 * Fetch and validate the bridge-kit on-chain state account.
 * Wraps the Anchor RPC call in a uniform KitError so callers stay flat.
 *
 * @remarks
 * **Side effects.** Performs a single network I/O call via
 * `bridgeKit.account.state.fetch(statePda)` against the Anchor provider's
 * underlying Solana RPC endpoint. No state is mutated on-chain.
 *
 * **Preconditions.**
 * - `bridgeKit` must be a loaded Anchor `Program` whose IDL exposes a
 *   `state` account of type {@link BridgeKitState}.
 * - `statePda` must be the PDA of an existing bridge-kit state account on
 *   the cluster that `bridgeKit.provider` is connected to.
 *
 * **Postconditions.**
 * - On success, the returned state is guaranteed to have
 *   `protocolFeeWallet` set (the return type is narrowed via
 *   {@link ResolvedBridgeKitState}), so callers can dereference it
 *   without an additional `undefined` check.
 *
 * **Error taxonomy and retry behavior.**
 * - `RETRYABLE` — raised when the RPC call itself fails (timeout, network
 *   error, rate limit, etc.). Callers should retry with exponential
 *   backoff and consider switching RPC endpoints on repeated failure.
 *   The original error is attached via `cause.trace.rawError`.
 * - `FATAL` — raised when the fetched state account exists but has no
 *   `protocolFeeWallet`. This indicates the bridge-kit program was
 *   deployed with an uninitialized state or a schema mismatch; retrying
 *   will not help and callers should surface the error to the operator.
 *
 * @param bridgeKit - The loaded Anchor program for the bridge-kit.
 * @param statePda - The PDA of the bridge-kit state account to fetch.
 * @returns The resolved state, guaranteed to include `protocolFeeWallet`.
 * @throws `KitError` (RETRYABLE) When the RPC call itself fails.
 * @throws `KitError` (FATAL) When the state account lacks a `protocolFeeWallet`.
 */ async function fetchBridgeKitState(bridgeKit, statePda) {
    let state;
    try {
        state = await bridgeKit.account.state.fetch(statePda);
    } catch (error) {
        throw new KitError({
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'RETRYABLE',
            message: `Failed to fetch bridge kit state from ${statePda.toBase58()}.`,
            cause: {
                trace: {
                    rawError: error
                }
            }
        });
    }
    if (state.protocolFeeWallet === undefined) {
        throw new KitError({
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'FATAL',
            message: `protocolFeeWallet missing in bridge kit state account ${statePda.toBase58()}.`
        });
    }
    return state;
}
/**
 * Return idempotent create-ATA instructions for each target whose account
 * does not yet exist on-chain.
 *
 * All existence checks are issued in parallel via `Promise.all` to minimise
 * round-trips. Only the accounts whose `getAccountInfo` response is `null`
 * receive a create instruction.
 *
 * @param connection - The Solana RPC connection used for account lookups.
 * @param payer - The wallet that pays the rent-exempt deposit.
 * @param usdcMint - The USDC mint address used to derive the ATAs.
 * @param targets - ATAs to check, each paired with the owning wallet address.
 * @param tokenProgramId - The token program that owns the mint. MUST match
 *   the program the `ata` addresses were derived under (Token-2022 vs the
 *   legacy SPL Token program); creating an ATA under the wrong program
 *   yields an account at a different address than the CPI expects.
 * @returns Zero or more idempotent
 *   {@link https://spl.solana.com/associated-token-account | create-ATA}
 *   instructions, one per missing account.
 */ async function buildMissingAtaInstructions(connection, payer, usdcMint, targets, tokenProgramId) {
    const checks = await Promise.all(targets.map(async ({ ata })=>connection.getAccountInfo(ata)));
    return targets.flatMap(({ ata, owner }, i)=>checks[i] === null ? [
            createAssociatedTokenAccountIdempotentInstruction(payer, ata, owner, usdcMint, tokenProgramId)
        ] : []);
}
/**
 * Validate a raw hookData string and return it as a `Uint8Array`.
 * Accepts an optional `0x` prefix; the hex digit count must be even (whole
 * bytes only).
 *
 * @param hookData - The raw hook-data string, with or without a `0x` prefix.
 * @returns A `Buffer` containing the decoded bytes, ready to pass to the
 *   on-chain program via an Anchor IDL method.
 * @throws `KitError` (FATAL) When `hookData` contains non-hex characters or
 *   has an odd number of hex digits.
 */ function encodeHookData(hookData) {
    const hex = hookData.startsWith('0x') ? hookData.slice(2) : hookData;
    if (!/^[0-9a-fA-F]*$/.test(hex) || hex.length % 2 !== 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'hookData must be a valid hex string (with optional 0x prefix) of even length.'
        });
    }
    return hexToAnchorBuffer(hex);
}
/**
 * Build the customBurn (bridge-kit) transaction instructions.
 *
 * Selects the `bridge` or `bridgeWithHook` on-chain method based on whether
 * `params.hookData` is present and non-empty. ATAs for the protocol fee wallet
 * and developer fee recipient are created automatically when they do not yet
 * exist on-chain.
 *
 * @param params - The burn parameters including amount, destination, and fees.
 * @param programs - Loaded Anchor programs: `bridgeKit`, `tokenMessenger`, and
 *   `messageTransmitter`.
 * @param pdas - Pre-derived PDAs for the bridgeKit and CCTP programs.
 * @param userUsdcAta - The user's USDC associated token account.
 * @param user - The user's wallet public key (payer and authority).
 * @param usdcMint - The USDC mint address on this chain.
 * @param connection - Solana RPC connection used for ATA existence checks.
 * @returns An object containing the ordered `instructions` to include in the
 *   transaction and the ephemeral `signer` (message-account keypair) that must
 *   be added as a transaction signer.
 * @throws `KitError` (FATAL) When the selected bridge method is absent from
 *   the on-chain program.
 * @throws `KitError` When fetching the bridge-kit state fails or the state is
 *   missing required fields — see {@link fetchBridgeKitState}.
 * @throws `KitError` (FATAL) When `params.hookData` is not valid hex or has an
 *   odd byte count.
 *
 * @example
 * ```typescript
 * import { buildCustomBurnInstructions } from '@core/adapter-solana-base'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const user = new PublicKey('7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU')
 * const usdcMint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 * const mintRecipient = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 * const feeRecipient = new PublicKey('So11111111111111111111111111111111111111112')
 * const userUsdcAta = new PublicKey('11111111111111111111111111111111')
 *
 * // `programs`, `pdas`, and `connection` are obtained from your adapter setup.
 * const { instructions, signer } = await buildCustomBurnInstructions(
 *   {
 *     amount: 1_000_000n,
 *     destinationDomain: 0,
 *     mintRecipient,
 *     destinationCaller: PublicKey.default,
 *     maxFee: 0n,
 *     minFinalityThreshold: 1_000,
 *     protocolFee: 0n,
 *     feeRecipient,
 *   },
 *   { bridgeKit, tokenMessenger, messageTransmitter },
 *   pdas,
 *   userUsdcAta,
 *   user,
 *   usdcMint,
 *   connection,
 * )
 * ```
 */ async function buildCustomBurnInstructions(params, programs, pdas, userUsdcAta, user, usdcMint, connection) {
    const { bridgeKit, tokenMessenger, messageTransmitter } = programs;
    // Treat empty string as absent so the no-hook path is taken.
    const hookData = params.hookData !== undefined && params.hookData !== '' ? params.hookData : undefined;
    const methodName = hookData === undefined ? 'bridge' : 'bridgeWithHook';
    const method = bridgeKit.methods[methodName];
    if (method === undefined) {
        throw new KitError({
            ...OnchainError.TRANSACTION_REVERTED,
            recoverability: 'FATAL',
            message: `${methodName} method not found on the bridgeKit program. ` + 'The on-chain program may be outdated or incorrectly configured.'
        });
    }
    const messageSender = web3_js.Keypair.generate();
    const fundMessageSenderIx = web3_js.SystemProgram.transfer({
        fromPubkey: user,
        toPubkey: messageSender.publicKey,
        lamports: MESSAGE_ACCOUNT_RENT_LAMPORTS
    });
    const state = await fetchBridgeKitState(bridgeKit, pdas.statePda);
    const tokenProgramId = params.tokenProgramId ?? TOKEN_PROGRAM_ID;
    const protocolFeeWalletAta = getAssociatedTokenAddressSync(usdcMint, new web3_js.PublicKey(state.protocolFeeWallet), true, tokenProgramId);
    const developerFeeRecipientAta = getAssociatedTokenAddressSync(usdcMint, params.feeRecipient, true, tokenProgramId);
    const createAtaIxs = await buildMissingAtaInstructions(connection, user, usdcMint, [
        {
            ata: protocolFeeWalletAta,
            owner: state.protocolFeeWallet
        },
        {
            ata: developerFeeRecipientAta,
            owner: params.feeRecipient
        }
    ], tokenProgramId);
    const bridgeParams = {
        amount: new bn_js.BN(params.amount.toString()),
        destinationDomain: params.destinationDomain,
        mintRecipient: params.mintRecipient,
        destinationCaller: params.destinationCaller,
        maxFee: new bn_js.BN(params.maxFee.toString()),
        minFinalityThreshold: params.minFinalityThreshold,
        bridgingKitFee: new bn_js.BN(params.protocolFee.toString()),
        ...hookData === undefined ? {} : {
            hookData: encodeHookData(hookData)
        }
    };
    const bridgeAccounts = {
        state: pdas.statePda,
        authority: user,
        eventRentPayer: user,
        burnTokenAccount: userUsdcAta,
        protocolFeeWalletTokenAccount: protocolFeeWalletAta,
        developerFeeRecipientTokenAccount: developerFeeRecipientAta,
        senderAuthorityPda: pdas.senderAuthorityPda,
        denylistAccount: pdas.denylistPda,
        messageTransmitter: pdas.messageTransmitterPda,
        tokenMessenger: pdas.tokenMessengerPda,
        remoteTokenMessenger: pdas.remoteTokenMessengerPda,
        tokenMinter: pdas.tokenMinterPda,
        localToken: pdas.localTokenPda,
        burnTokenMint: usdcMint,
        messageSentEventData: messageSender.publicKey,
        messageTransmitterProgram: messageTransmitter.programId,
        tokenMessengerMinterProgram: tokenMessenger.programId,
        tokenProgram: tokenProgramId,
        systemProgram: web3_js.SystemProgram.programId,
        eventAuthority: pdas.bridgeKitEventAuthorityPda,
        program: bridgeKit.programId,
        cctpEventAuthority: pdas.eventAuthorityPda,
        cctpProgram: tokenMessenger.programId
    };
    const bridgeIx = await method(bridgeParams).accountsPartial(bridgeAccounts).signers([
        messageSender
    ]).instruction();
    return {
        instructions: [
            fundMessageSenderIx,
            ...createAtaIxs,
            bridgeIx
        ],
        signer: messageSender
    };
}

/**
 * Generate complete customBurn transaction instructions.
 *
 * @param params - The custom burn parameters.
 * @returns Transaction instructions and required signers.
 * @throws {@link KitError} with `InputError.UNSUPPORTED_ROUTE` if CCTP v2 config is not "split" or bridge kit address is missing.
 *
 * @example
 * ```typescript
 * import { getCustomBurnInstructions, createProgramLoader } from '@core/adapter-solana-base'
 * import { SolanaMainnet, Ethereum } from '@core/chains'
 *
 * const loadProgram = createProgramLoader()
 * const result = await getCustomBurnInstructions({
 *   provider,
 *   loadProgram,
 *   fromChain: SolanaMainnet,
 *   toChain: Ethereum,
 *   amount: 1000000n,
 *   mintRecipient: '0x1234567890123456789012345678901234567890',
 *   maxFee: 0n,
 *   minFinalityThreshold: 1000,
 *   protocolFee: 0n,
 *   feeRecipient: '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
 * })
 * ```
 */ async function getCustomBurnInstructions(params) {
    const { provider, loadProgram, fromChain, toChain } = params;
    assertSolanaSplitConfig(fromChain);
    const v2config = fromChain.cctp.contracts.v2;
    const bridgeKitAddress = fromChain.kitContracts?.bridge;
    if (bridgeKitAddress === undefined) {
        throw new KitError({
            ...InputError.UNSUPPORTED_ROUTE,
            recoverability: 'FATAL',
            message: `Chain "${fromChain.name}" has no bridge kit contract address configured. ` + "Use 'cctp.v2.depositForBurn' instead of 'cctp.v2.customBurn'."
        });
    }
    const [tokenMessengerProgram, messageTransmitterProgram, bridgeKitProgram] = await Promise.all([
        loadProgram(provider, v2config.tokenMessenger),
        loadProgram(provider, v2config.messageTransmitter),
        loadProgram(provider, bridgeKitAddress)
    ]);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(fromChain.usdcAddress);
    const tokenProgramId = params.tokenProgramId ?? TOKEN_PROGRAM_ID;
    const userUsdcAta = getAssociatedTokenAddressSync(usdcMint, user, true, tokenProgramId);
    const pdas = deriveCustomBurnPdas(tokenMessengerProgram.programId, messageTransmitterProgram.programId, bridgeKitProgram.programId, usdcMint, user, toChain.cctp.domain);
    const mintRecipientKey = parseAddress(params.mintRecipient);
    // Route the destination caller through `parseAddress` so callers may
    // pass either a base58 Solana key or a 32-byte hex CCTP recipient
    // (consistent with `mintRecipient`) and so malformed values surface
    // as a structured `KitError` rather than an opaque `PublicKey`
    // constructor error.
    const callerKey = params.destinationCaller === undefined || params.destinationCaller === '' ? web3_js.PublicKey.default : parseAddress(params.destinationCaller);
    // `feeRecipient` is user input. `new PublicKey()` throws an opaque
    // base58 / length error; wrap it so the caller sees the same
    // structured `VALIDATION_FAILED` shape used everywhere else for
    // address-shaped inputs.
    const feeRecipientKey = parseFeeRecipient(params.feeRecipient);
    const { instructions, signer } = await buildCustomBurnInstructions({
        amount: params.amount,
        destinationDomain: toChain.cctp.domain,
        mintRecipient: mintRecipientKey,
        destinationCaller: callerKey,
        maxFee: params.maxFee,
        minFinalityThreshold: params.minFinalityThreshold,
        protocolFee: params.protocolFee,
        feeRecipient: feeRecipientKey,
        hookData: params.hookData,
        tokenProgramId
    }, {
        bridgeKit: bridgeKitProgram,
        tokenMessenger: tokenMessengerProgram,
        messageTransmitter: messageTransmitterProgram
    }, pdas, userUsdcAta, user, usdcMint, provider.connection);
    return {
        instructions,
        signers: [
            signer
        ]
    };
}
function parseFeeRecipient(feeRecipient) {
    try {
        return new web3_js.PublicKey(feeRecipient);
    } catch (error) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Invalid feeRecipient: could not parse as a Solana public key.',
            cause: {
                trace: {
                    rawError: error,
                    value: feeRecipient
                }
            }
        });
    }
}

/**
 * Create CCTP builder callbacks from an AnchorProvider source.
 *
 * @remarks
 * Both Solana adapters (web3.js and Kit) need identical CCTP instruction
 * building logic. This factory eliminates that duplication by accepting
 * the single adapter-specific dependency (`getAnchorProvider`) and
 * returning all three builder callbacks ready to pass to
 * {@link createSolanaActions}.
 *
 * @param getAnchorProvider - Adapter-specific callback to obtain an
 *   Anchor provider for a given chain.
 * @returns The three CCTP builder callbacks.
 *
 * @example
 * ```typescript
 * import { createCCTPBuilders } from '@core/adapter-solana-base'
 * import type { AnchorProvider } from '@coral-xyz/anchor'
 * import type { ChainDefinition } from '@core/chains'
 *
 * async function getAnchorProvider(chain: ChainDefinition): Promise<AnchorProvider> {
 *   // Your adapter-specific implementation
 *   return provider
 * }
 *
 * const cctpBuilders = createCCTPBuilders(getAnchorProvider)
 * // createSolanaActions uses createCCTPBuilders internally when given getAnchorProvider
 * ```
 */ function createCCTPBuilders(getAnchorProvider) {
    const loadProgram = createProgramLoader();
    return {
        buildDepositForBurn: async (input, ctx)=>{
            const provider = await getAnchorProvider(ctx.chain);
            const fromChain = ctx.chain;
            assertCCTPV2Supported(fromChain);
            assertSolanaSplitConfig(fromChain);
            const toChain = resolveChainIdentifier(input.toChain);
            assertCCTPV2Supported(toChain);
            const hookData = 'hookData' in input ? input.hookData : undefined;
            const result = await getDepositForBurnInstructions({
                provider,
                loadProgram,
                fromChain,
                toChain,
                amount: input.amount,
                mintRecipient: input.mintRecipient,
                destinationCaller: input.destinationCaller,
                maxFee: input.maxFee,
                minFinalityThreshold: input.minFinalityThreshold,
                hookData
            });
            return {
                type: 'instructions',
                instructions: result.instructions,
                signers: result.signers,
                // Without an explicit limit, Solana execute leaves the cluster
                // default (200k) in place. depositForBurn needs the full budget.
                computeUnitLimit: CCTP_COMPUTE_UNITS.depositForBurn
            };
        },
        buildReceiveMessage: async (input, ctx)=>{
            const provider = await getAnchorProvider(ctx.chain);
            const fromChain = resolveChainIdentifier(input.fromChain);
            assertCCTPV2Supported(fromChain);
            const toChain = ctx.chain;
            assertCCTPV2Supported(toChain);
            assertSolanaSplitConfig(toChain);
            const result = await getReceiveMessageInstructions({
                provider,
                loadProgram,
                fromChain,
                toChain,
                eventNonce: input.eventNonce,
                attestation: input.attestation,
                message: input.message,
                destinationAddress: input.destinationAddress
            });
            // CCTP v2 receiveMessage references ~24 accounts and exceeds the 1232-byte
            // raw transaction limit without an Address Lookup Table. Fetch the ALT
            // eagerly here so the transaction can be compiled as a VersionedTransaction.
            // Route ALT resolution failures through the adapter's structured logger
            // (rather than the console.warn fallback) so the diagnostic participates
            // in the runtime's events / trace correlation.
            const addressLookupTableAccounts = await getCctpAddressLookupTableAccounts(provider.connection, toChain, {
                onResolutionFailure: createLoggerAltReporter(ctx.adapter.ctx.runtime.logger)
            });
            return {
                type: 'instructions',
                instructions: result.instructions,
                addressLookupTableAccounts,
                // receiveMessage references ~24 accounts and exceeds the 200k cluster
                // default; it fails with "Computational budget exceeded" unless we
                // raise the limit explicitly.
                computeUnitLimit: CCTP_COMPUTE_UNITS.receiveMessage
            };
        },
        buildCustomBurn: async (input, ctx)=>{
            const provider = await getAnchorProvider(ctx.chain);
            const fromChain = ctx.chain;
            assertCCTPV2Supported(fromChain);
            assertSolanaSplitConfig(fromChain);
            const toChain = resolveChainIdentifier(input.toChain);
            assertCCTPV2Supported(toChain);
            const feeRecipient = input.feeRecipient ?? provider.wallet.publicKey.toBase58();
            const customHookData = 'hookData' in input ? input.hookData : undefined;
            const result = await getCustomBurnInstructions({
                provider,
                loadProgram,
                fromChain,
                toChain,
                amount: input.amount,
                mintRecipient: input.mintRecipient,
                destinationCaller: input.destinationCaller,
                maxFee: input.maxFee,
                minFinalityThreshold: input.minFinalityThreshold,
                protocolFee: input.protocolFee ?? 0n,
                feeRecipient,
                hookData: customHookData
            });
            return {
                type: 'instructions',
                instructions: result.instructions,
                signers: result.signers
            };
        }
    };
}

// ============================================================================
// Write Action Bindings
// ============================================================================
/** Create a bound `gateway.v1.deposit` write action for Solana. */ function bindGatewayDeposit(adapter, builder) {
    return gatewayV1Deposit.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.depositFor` write action for Solana. */ function bindGatewayDepositFor(adapter, builder) {
    return gatewayV1DepositFor.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.addDelegate` write action for Solana. */ function bindGatewayAddDelegate(adapter, builder) {
    return gatewayV1AddDelegate.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.removeDelegate` write action for Solana. */ function bindGatewayRemoveDelegate(adapter, builder) {
    return gatewayV1RemoveDelegate.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.initiateWithdrawal` write action for Solana. */ function bindGatewayInitiateWithdrawal(adapter, builder) {
    return gatewayV1InitiateWithdrawal.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.withdraw` write action for Solana. */ function bindGatewayWithdraw(adapter, builder) {
    return gatewayV1Withdraw.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.gatewayBurn` write action for Solana. */ function bindGatewayBurn(adapter, builder) {
    return gatewayV1GatewayBurn.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.gatewayMint` write action for Solana. */ function bindGatewayMint(adapter, builder) {
    return gatewayV1GatewayMint.bind({
        adapter,
        build: async (input, ctx)=>{
            const writeInput = await builder(input, ctx);
            ctx.write(writeInput);
        }
    });
}
/** Create a bound `gateway.v1.signBurnIntents` read action for Solana. */ function bindGatewaySignBurnIntents(adapter, executor) {
    return gatewayV1SignBurnIntents.bind({
        adapter,
        execute: executor
    });
}
// ============================================================================
// Read Action Bindings
// ============================================================================
/** Create a bound `gateway.v1.isDelegate` read action for Solana. */ function bindGatewayIsDelegate(adapter, executor) {
    return gatewayV1IsDelegate.bind({
        adapter,
        execute: executor
    });
}
/** Create a bound `gateway.v1.withdrawingBalance` read action for Solana. */ function bindGatewayWithdrawingBalance(adapter, executor) {
    return gatewayV1WithdrawingBalance.bind({
        adapter,
        execute: executor
    });
}
/** Create a bound `gateway.v1.withdrawalBlock` read action for Solana. */ function bindGatewayWithdrawalBlock(adapter, executor) {
    return gatewayV1WithdrawalBlock.bind({
        adapter,
        execute: executor
    });
}

/**
 * Derive PDAs for Gateway Wallet `deposit` / `deposit_for` instructions.
 *
 * @param programId - Gateway Wallet program ID.
 * @param depositor - The depositor whose balance is credited.
 * @param tokenMint - The token mint (e.g. USDC).
 * @param sender - The transaction signer. Equals depositor for `deposit`.
 */ function deriveGatewayDepositPdas(programId, depositor, tokenMint, sender) {
    const [gatewayWallet] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('gateway_wallet')
    ], programId);
    const [deposit] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('gateway_deposit'),
        tokenMint.toBuffer(),
        depositor.toBuffer()
    ], programId);
    const [custodyTokenAccount] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('gateway_wallet_custody'),
        tokenMint.toBuffer()
    ], programId);
    const [senderDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('denylist'),
        sender.toBuffer()
    ], programId);
    const [depositorDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('denylist'),
        depositor.toBuffer()
    ], programId);
    return {
        gatewayWallet,
        deposit,
        custodyTokenAccount,
        senderDenylist,
        depositorDenylist
    };
}
/**
 * Derive PDAs for Gateway Wallet `add_delegate` / `remove_delegate` instructions.
 *
 * @param programId - Gateway Wallet program ID.
 * @param depositor - The depositor granting/revoking delegation.
 * @param delegate - The delegate being authorized/revoked.
 * @param tokenMint - The token mint (e.g. USDC).
 */ function deriveGatewayDelegatePdas(programId, depositor, delegate, tokenMint) {
    const [gatewayWallet] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('gateway_wallet')
    ], programId);
    const [delegateAccount] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('gateway_delegate'),
        tokenMint.toBuffer(),
        depositor.toBuffer(),
        delegate.toBuffer()
    ], programId);
    const [depositorDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('denylist'),
        depositor.toBuffer()
    ], programId);
    const [delegateDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('denylist'),
        delegate.toBuffer()
    ], programId);
    return {
        gatewayWallet,
        delegateAccount,
        depositorDenylist,
        delegateDenylist
    };
}
// GatewayDeposit PDA layout (custom 2-byte discriminator [21, 1]):
//   2  bytes  discriminator
//   1  byte   bump
//  32  bytes  depositor
//  32  bytes  token_mint
//   8  bytes  available_amount   (u64 LE)  offset 67
//   8  bytes  withdrawing_amount (u64 LE)  offset 75
//   8  bytes  withdrawal_block   (u64 LE)  offset 83
const LAYOUT_BASE = 2 + 1 + 32 + 32;
/** Byte offsets for u64 fields in the GatewayDeposit PDA. */ const GatewayDepositOffset = {
    withdrawingBalance: LAYOUT_BASE + 8,
    withdrawalBlock: LAYOUT_BASE + 8 + 8
};

// ============================================================================
// Helpers
// ============================================================================
function getGatewayWalletProgramId(chain) {
    if (!isGatewayV1Supported(chain)) {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `Gateway Wallet program ID not found: chain "${chain.name}" does not have Gateway v1 contracts configured.`,
            cause: {
                trace: {
                    chain: chain.name
                }
            }
        });
    }
    return chain.gateway.contracts.v1.wallet;
}
function getGatewayMinterProgramId(chain) {
    if (!isGatewayV1Supported(chain)) {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `Gateway Minter program ID not found: chain "${chain.name}" does not have Gateway v1 contracts configured.`,
            cause: {
                trace: {
                    chain: chain.name
                }
            }
        });
    }
    return chain.gateway.contracts.v1.minter;
}
function assertSolanaChain(chain) {
    if (chain.type !== 'solana') {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `Expected Solana chain definition, but received chain type: ${chain.type}`,
            cause: {
                trace: {
                    chain: chain.name,
                    type: chain.type
                }
            }
        });
    }
}
/**
 * Decode a hex string (with or without `0x` prefix) into a Buffer.
 *
 * Strict validation: rejects odd-length payloads (would silently truncate the
 * trailing nibble in `Buffer.from('…', 'hex')`) and any non-hex characters.
 * Both leak through as `KitError(InputError.VALIDATION_FAILED)` so a bad
 * burn-signature / calldata blob fails fast at the adapter boundary instead
 * of producing a malformed on-chain instruction.
 */ function hexToBuffer(hex, fieldName) {
    const stripped = hex.startsWith('0x') ? hex.slice(2) : hex;
    if (stripped.length === 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid ${fieldName}: hex payload is empty.`,
            cause: {
                trace: {
                    fieldName
                }
            }
        });
    }
    if (stripped.length % 2 !== 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid ${fieldName}: hex payload must have an even number of characters (got length ${String(stripped.length)}).`,
            cause: {
                trace: {
                    fieldName,
                    length: stripped.length
                }
            }
        });
    }
    if (!/^[0-9a-fA-F]+$/.test(stripped)) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid ${fieldName}: hex payload contains non-hex characters.`,
            cause: {
                trace: {
                    fieldName
                }
            }
        });
    }
    return Buffer.from(stripped, 'hex');
}
async function getOwnerAta(provider, tokenMint) {
    const owner = provider.wallet.publicKey;
    // Resolve the mint's owning token program (SPL Token vs Token-2022) and
    // derive the ATA under it. Anchor's `utils.token.associatedAddress` is
    // hardcoded to the classic SPL Token program, so a Token-2022 deposit /
    // withdrawal would otherwise compute the wrong ATA and fail preflight.
    const tokenProgramId = await detectTokenProgram(provider.connection, tokenMint);
    const ata = getAssociatedTokenAddressSync(tokenMint, owner, false, tokenProgramId);
    const info = await provider.connection.getAccountInfo(ata);
    if (!info) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Missing token account for mint ${tokenMint.toBase58()} and owner ${owner.toBase58()}. Create the associated token account first.`,
            cause: {
                trace: {
                    owner: owner.toBase58(),
                    tokenMint: tokenMint.toBase58(),
                    ata: ata.toBase58()
                }
            }
        });
    }
    return ata;
}
/**
 * Parse attestation binary for `gatewayMint` remaining accounts.
 *
 * Attestation layout (big-endian, byte offsets):
 * ```
 * 0..84    : header (magic, version, source domain, …) - opaque to us
 * 84..88   : numAttestations (uint32 BE)
 * 88..end  : per-attestation records, repeated `numAttestations` times:
 *              0..32   : destination_token (Pubkey)
 *              32..64  : destination_recipient (Pubkey)
 *              64..72  : reserved / source_token tail (skipped)
 *              72..104 : transfer_spec_hash (32 bytes)
 *              104..108: hook_data_len (uint32 BE)
 *              108..108+hook_data_len: hook_data
 * ```
 *
 * Strict bounds checks: untrusted blobs that declare more attestations
 * than the buffer can hold (or whose declared `hookDataLen` runs off the
 * end) MUST be rejected here rather than silently producing
 * truncated/empty `PublicKey`s downstream — Solana would otherwise consume
 * a zeroed `PublicKey` as a real account, which an attacker could use to
 * redirect mint output to a chosen account.
 */ const ATTESTATION_HEADER_SIZE = 88;
const ATTESTATION_RECORD_HEADER = 108 // up through hookDataLen
;
const ATTESTATION_NUM_OFFSET = 84;
// Hard cap: any sane Gateway attestation fits in well under 1 MiB. This is
// purely a defence-in-depth guard against a malicious / malformed
// `numAttestations` field forcing a multi-million-iteration loop.
const ATTESTATION_MAX_NUM = 1024;
const ATTESTATION_MAX_HOOK_DATA_LEN = 1 << 20 // 1 MiB
;
function parseAttestationElements(attestation) {
    if (attestation.length < ATTESTATION_HEADER_SIZE) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid attestation: payload too short (${String(attestation.length)} bytes, expected at least ${String(ATTESTATION_HEADER_SIZE)}).`,
            cause: {
                trace: {
                    length: attestation.length
                }
            }
        });
    }
    const numAttestations = attestation.readUInt32BE(ATTESTATION_NUM_OFFSET);
    if (numAttestations > ATTESTATION_MAX_NUM) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `Invalid attestation: declared ${String(numAttestations)} attestations exceeds maximum of ${String(ATTESTATION_MAX_NUM)}.`,
            cause: {
                trace: {
                    numAttestations
                }
            }
        });
    }
    const elements = [];
    let offset = ATTESTATION_HEADER_SIZE;
    for(let i = 0; i < numAttestations; i++){
        if (offset + ATTESTATION_RECORD_HEADER > attestation.length) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `Invalid attestation: record ${String(i)} header runs past end of buffer.`,
                cause: {
                    trace: {
                        offset,
                        length: attestation.length,
                        numAttestations
                    }
                }
            });
        }
        const destToken = new web3_js.PublicKey(attestation.subarray(offset, offset + 32));
        const destRecipient = new web3_js.PublicKey(attestation.subarray(offset + 32, offset + 64));
        const transferSpecHash = Buffer.from(attestation.subarray(offset + 72, offset + 104));
        elements.push({
            destinationToken: destToken,
            destinationRecipient: destRecipient,
            transferSpecHash
        });
        const hookDataLen = attestation.readUInt32BE(offset + 104);
        if (hookDataLen > ATTESTATION_MAX_HOOK_DATA_LEN) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `Invalid attestation: record ${String(i)} hookDataLen ${String(hookDataLen)} exceeds maximum of ${String(ATTESTATION_MAX_HOOK_DATA_LEN)}.`,
                cause: {
                    trace: {
                        hookDataLen
                    }
                }
            });
        }
        offset += ATTESTATION_RECORD_HEADER + hookDataLen;
        if (offset > attestation.length) {
            throw new KitError({
                ...InputError.VALIDATION_FAILED,
                recoverability: 'FATAL',
                message: `Invalid attestation: record ${String(i)} hookData runs past end of buffer.`,
                cause: {
                    trace: {
                        offset,
                        length: attestation.length,
                        hookDataLen
                    }
                }
            });
        }
    }
    return elements;
}
/**
 * Read a u64 LE field from a GatewayDeposit PDA at a given offset.
 *
 * @remarks
 * Returns the raw `bigint` value. Callers wrap the value into the
 * appropriate output shape ({@link GatewayWithdrawingBalanceOutput} for
 * balance fields, {@link GatewayWithdrawalBlockOutput} for block-number
 * fields). Missing or too-short account data yields `0n`, matching the
 * semantics of the on-chain u64 defaulting to zero.
 */ async function readDepositPdaU64(provider, chain, token, depositor, offset) {
    assertSolanaChain(chain);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const connection = provider.connection;
    const tokenMint = new web3_js.PublicKey(token);
    const depositorKey = new web3_js.PublicKey(depositor);
    const programId = new web3_js.PublicKey(walletProgramId);
    const pdas = deriveGatewayDepositPdas(programId, depositorKey, tokenMint, depositorKey);
    const accountInfo = await connection.getAccountInfo(pdas.deposit, 'confirmed');
    if (!accountInfo || accountInfo.data.length < offset + 8) {
        return 0n;
    }
    return accountInfo.data.readBigUInt64LE(offset);
}
// ============================================================================
// Factory
// ============================================================================
/**
 * Create Gateway v1 builder callbacks from an AnchorProvider source.
 *
 * @param options - Adapter-specific callbacks.
 * @returns The gateway builder callbacks.
 */ function createGatewayBuilders(options) {
    const { getAnchorProvider, getSigner } = options;
    const loadProgram = createProgramLoader();
    const builders = {
        buildDeposit: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const tokenMint = new web3_js.PublicKey(input.token);
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const ownerTokenAccount = await getOwnerAta(provider, tokenMint);
            const pdas = deriveGatewayDepositPdas(program.programId, user, tokenMint, user);
            if (!('deposit' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'deposit method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['deposit'](new bn_js.BN(input.value.toString())).accounts({
                payer: user,
                owner: user,
                gatewayWallet: pdas.gatewayWallet,
                ownerTokenAccount,
                custodyTokenAccount: pdas.custodyTokenAccount,
                deposit: pdas.deposit,
                depositorDenylist: pdas.depositorDenylist
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildDepositFor: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const tokenMint = new web3_js.PublicKey(input.token);
            const depositor = new web3_js.PublicKey(input.depositor);
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const ownerTokenAccount = await getOwnerAta(provider, tokenMint);
            const pdas = deriveGatewayDepositPdas(program.programId, depositor, tokenMint, user);
            if (!('depositFor' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'depositFor method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['depositFor'](new bn_js.BN(input.value.toString()), depositor).accounts({
                payer: user,
                owner: user,
                gatewayWallet: pdas.gatewayWallet,
                ownerTokenAccount,
                custodyTokenAccount: pdas.custodyTokenAccount,
                deposit: pdas.deposit,
                senderDenylist: pdas.senderDenylist,
                depositorDenylist: pdas.depositorDenylist
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildAddDelegate: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const tokenMint = new web3_js.PublicKey(input.token);
            const delegate = new web3_js.PublicKey(input.delegate);
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const pdas = deriveGatewayDelegatePdas(program.programId, user, delegate, tokenMint);
            if (!('addDelegate' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'addDelegate method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['addDelegate'](delegate).accountsPartial({
                payer: user,
                depositor: user,
                gatewayWallet: pdas.gatewayWallet,
                tokenMint,
                delegateAccount: pdas.delegateAccount,
                depositorDenylist: pdas.depositorDenylist,
                delegateDenylist: pdas.delegateDenylist
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildRemoveDelegate: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const tokenMint = new web3_js.PublicKey(input.token);
            const delegate = new web3_js.PublicKey(input.delegate);
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const pdas = deriveGatewayDelegatePdas(program.programId, user, delegate, tokenMint);
            if (!('removeDelegate' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'removeDelegate method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['removeDelegate'](delegate).accountsPartial({
                payer: user,
                depositor: user,
                gatewayWallet: pdas.gatewayWallet,
                tokenMint,
                delegateAccount: pdas.delegateAccount,
                depositorDenylist: pdas.depositorDenylist,
                delegateDenylist: pdas.delegateDenylist
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildInitiateWithdrawal: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const tokenMint = new web3_js.PublicKey(input.token);
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const pdas = deriveGatewayDepositPdas(program.programId, user, tokenMint, user);
            if (!('initiateWithdrawal' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'initiateWithdrawal method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['initiateWithdrawal'](new bn_js.BN(input.value.toString())).accountsPartial({
                depositor: user,
                gatewayWallet: pdas.gatewayWallet,
                deposit: pdas.deposit
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildWithdraw: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const tokenMint = new web3_js.PublicKey(input.token);
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const ownerTokenAccount = await getOwnerAta(provider, tokenMint);
            const pdas = deriveGatewayDepositPdas(program.programId, user, tokenMint, user);
            if (!('withdraw' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'withdraw method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['withdraw']().accountsPartial({
                depositor: user,
                gatewayWallet: pdas.gatewayWallet,
                depositorTokenAccount: ownerTokenAccount,
                custodyTokenAccount: pdas.custodyTokenAccount,
                deposit: pdas.deposit
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildGatewayBurn: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            // Validate untrusted hex payloads BEFORE we hit the network to load
            // the on-chain IDL — fail fast on malformed inputs and avoid wasting
            // an RPC round-trip / surfacing IDL fetch failures for what is
            // really a caller-side bug.
            const calldataBytes = hexToBuffer(input.calldataBytes, 'calldataBytes');
            const signature = hexToBuffer(input.signature, 'signature');
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const program = await loadProgram(provider, walletProgramId);
            const [gatewayWallet] = web3_js.PublicKey.findProgramAddressSync([
                Buffer.from('gateway_wallet')
            ], program.programId);
            if (!('gatewayBurn' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'gatewayBurn method not found in Gateway Wallet program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['gatewayBurn']({
                encodedBurnData: calldataBytes,
                burnSignature: signature
            }).accounts({
                payer: user,
                signer: user,
                gatewayWallet
            }).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        buildGatewayMint: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            // Validate hex payloads + attestation layout before any network
            // I/O. See note in `buildGatewayBurn`.
            const attestation = hexToBuffer(input.attestation, 'attestation');
            const signature = hexToBuffer(input.signature, 'signature');
            const elements = parseAttestationElements(attestation);
            const provider = await getAnchorProvider(ctx.chain);
            const user = provider.wallet.publicKey;
            // Gateway Solana mint targets the classic SPL Token program only (the
            // `tokenProgram` account below is fixed). Assert each destination
            // token is actually owned by the classic program so a Token-2022 mint
            // fails fast with a clear error here — before the IDL fetch — rather
            // than as an opaque CPI revert at simulation. Threading Token-2022
            // through gatewayMint is a protocol-level change (the on-chain program
            // does not yet support it) and is intentionally out of scope.
            for (const el of elements){
                const tokenProgramId = await detectTokenProgram(provider.connection, el.destinationToken);
                if (!tokenProgramId.equals(TOKEN_PROGRAM_ID)) {
                    throw new KitError({
                        ...InputError.VALIDATION_FAILED,
                        recoverability: 'FATAL',
                        message: 'Gateway mint on Solana supports classic SPL Token mints only; ' + `destination token ${el.destinationToken.toBase58()} is not owned by the SPL Token program.`,
                        cause: {
                            trace: {
                                destinationToken: el.destinationToken.toBase58()
                            }
                        }
                    });
                }
            }
            const minterProgramId = getGatewayMinterProgramId(ctx.chain);
            const program = await loadProgram(provider, minterProgramId);
            const [gatewayMinterState] = web3_js.PublicKey.findProgramAddressSync([
                Buffer.from('gateway_minter')
            ], program.programId);
            const remainingAccounts = [];
            for (const el of elements){
                const [custodyPda] = web3_js.PublicKey.findProgramAddressSync([
                    Buffer.from('gateway_minter_custody'),
                    el.destinationToken.toBuffer()
                ], program.programId);
                const [usedHashPda] = web3_js.PublicKey.findProgramAddressSync([
                    Buffer.from('used_transfer_spec_hash'),
                    el.transferSpecHash
                ], program.programId);
                remainingAccounts.push({
                    pubkey: custodyPda,
                    isSigner: false,
                    isWritable: true
                }, {
                    pubkey: el.destinationRecipient,
                    isSigner: false,
                    isWritable: true
                }, {
                    pubkey: usedHashPda,
                    isSigner: false,
                    isWritable: true
                });
            }
            if (!('gatewayMint' in program.methods)) {
                throw new KitError({
                    ...InputError.INVALID_CHAIN,
                    recoverability: 'FATAL',
                    message: 'gatewayMint method not found in Gateway Minter program.',
                    cause: {
                        trace: {
                            programId: program.programId.toBase58()
                        }
                    }
                });
            }
            const instruction = await program.methods['gatewayMint']({
                attestation,
                signature
            }).accounts({
                payer: user,
                destinationCaller: user,
                gatewayMinter: gatewayMinterState,
                systemProgram: web3_js.SystemProgram.programId,
                tokenProgram: TOKEN_PROGRAM_ID
            }).remainingAccounts(remainingAccounts).instruction();
            return {
                type: 'instructions',
                instructions: [
                    instruction
                ]
            };
        },
        executeIsDelegate: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const connection = provider.connection;
            const walletProgramId = getGatewayWalletProgramId(ctx.chain);
            const programId = new web3_js.PublicKey(walletProgramId);
            const tokenMint = new web3_js.PublicKey(input.token);
            const depositor = new web3_js.PublicKey(input.depositor);
            const delegate = new web3_js.PublicKey(input.delegate);
            const pdas = deriveGatewayDelegatePdas(programId, depositor, delegate, tokenMint);
            // Delegate PDA status byte: offset 3, 0x01 = active, 0x02 = removed
            const accountInfo = await connection.getAccountInfo(pdas.delegateAccount, 'confirmed');
            if (!accountInfo || accountInfo.data.length <= 3) {
                return {
                    isDelegate: false
                };
            }
            return {
                isDelegate: accountInfo.data[3] === 0x01
            };
        },
        executeWithdrawingBalance: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const value = await readDepositPdaU64(provider, ctx.chain, input.token, input.depositor, GatewayDepositOffset.withdrawingBalance);
            return {
                balance: value.toString()
            };
        },
        executeWithdrawalBlock: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const value = await readDepositPdaU64(provider, ctx.chain, input.token, input.depositor, GatewayDepositOffset.withdrawalBlock);
            return {
                blockNumber: value
            };
        },
        executeSignBurnIntents: async (input, ctx)=>{
            assertSolanaChain(ctx.chain);
            const provider = await getAnchorProvider(ctx.chain);
            const raw = input.typedData;
            let encodedData;
            if (raw instanceof Uint8Array) {
                encodedData = raw;
            } else if (typeof ArrayBuffer !== 'undefined' && ArrayBuffer.isView(raw)) {
                const view = raw;
                encodedData = new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
            } else {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: 'signBurnIntents: typedData must be a Uint8Array or ArrayBufferView',
                    cause: {
                        trace: {
                            typeOf: typeof raw
                        }
                    }
                });
            }
            const wallet = provider.wallet;
            let sigBytes;
            if (wallet.signMessage) {
                sigBytes = await wallet.signMessage(encodedData);
            } else if (getSigner) {
                // Provider wallets wrapped from a raw Keypair (private-key factories)
                // do not surface `signMessage`; mirror the legacy adapter's
                // `signBurnIntent` action by signing directly with the underlying
                // secretKey via Ed25519. Provider-backed signers (browser wallets)
                // already hit the `wallet.signMessage` branch above.
                const signer = await getSigner(ctx.chain);
                const secretKey = signer.secretKey;
                if (!secretKey) {
                    throw new KitError({
                        ...InputError.VALIDATION_FAILED,
                        recoverability: 'FATAL',
                        message: 'signBurnIntents requires a wallet that supports signMessage or a signer with a secretKey',
                        cause: {
                            trace: {
                                walletType: provider.wallet.constructor?.name ?? 'unknown'
                            }
                        }
                    });
                }
                const skLen = secretKey.length;
                if (skLen !== 32 && skLen !== 64) {
                    throw new KitError({
                        ...InputError.VALIDATION_FAILED,
                        recoverability: 'FATAL',
                        message: 'signBurnIntents: signer.secretKey must be 32 or 64 bytes',
                        cause: {
                            trace: {
                                secretKeyLength: skLen
                            }
                        }
                    });
                }
                const privKey = skLen === 64 ? secretKey.slice(0, 32) : secretKey;
                sigBytes = ed25519.ed25519.sign(encodedData, privKey);
            } else {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: 'signBurnIntents requires a wallet that supports signMessage',
                    cause: {
                        trace: {
                            walletType: provider.wallet.constructor?.name ?? 'unknown'
                        }
                    }
                });
            }
            return {
                signature: '0x' + Buffer.from(sigBytes).toString('hex')
            };
        }
    };
    return builders;
}

/**
 * Property-based type guard that narrows to Solana swap inputs.
 *
 * @remarks
 * The `swap.execute` action accepts a union of EVM and Solana inputs; each
 * ecosystem binding narrows at runtime. Solana inputs carry a non-empty
 * `serializedTransaction` string.
 */ function isSolanaSwapInput(input) {
    return 'serializedTransaction' in input && typeof input.serializedTransaction === 'string' && input.serializedTransaction.trim() !== '';
}
/**
 * Strict base64 regex (standard alphabet, optional padding).
 *
 * @remarks
 * `Buffer.from(value, 'base64')` is intentionally lenient — it silently
 * drops invalid characters instead of rejecting them. That masks upstream
 * bugs (truncated payloads, wrong encoding, wire-level corruption) until
 * `VersionedTransaction.deserialize` throws a cryptic Solana error later
 * in the pipeline. Validating the string here surfaces the real cause of
 * the problem as a FATAL input error with actionable diagnostics.
 */ const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
/**
 * Decode a base64-encoded Solana transaction to a `Uint8Array`.
 *
 * @remarks
 * Throws a FATAL `INPUT` error when the string contains characters outside
 * the standard base64 alphabet, when its length is not a multiple of four,
 * or when decoding yields an empty buffer (a common symptom of an empty
 * payload or pure-whitespace input).
 *
 * Uses `Buffer` so this works in Node environments used by the kits; the
 * resulting `Uint8Array` is what the Solana adapter's `prepare` primitive
 * expects for `serializedTransaction` writes.
 */ function base64Decode(value) {
    if (value.length % 4 !== 0 || !BASE64_REGEX.test(value)) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'swap.execute on Solana received a malformed base64 ' + 'serializedTransaction. Expected a string containing only A–Z, a–z, ' + '0–9, `+`, `/`, with optional `=` padding and length divisible by 4.',
            cause: {
                trace: {
                    length: value.length
                }
            }
        });
    }
    const decoded = Buffer.from(value, 'base64');
    if (decoded.length === 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'swap.execute on Solana received a base64 serializedTransaction ' + 'that decoded to zero bytes. The payload is empty.'
        });
    }
    return Uint8Array.from(decoded);
}
/**
 * Create a bound `swap.execute` write action for Solana.
 *
 * @remarks
 * Throws a FATAL `INPUT` error if the payload doesn't look like a Solana swap
 * (missing or empty `serializedTransaction`). The Solana adapter handles
 * deserialisation, signing, fee estimation and submission.
 */ function bindSwapExecute(adapter) {
    return swapExecute.bind({
        adapter,
        build: (input, ctx)=>{
            if (!isSolanaSwapInput(input)) {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: 'swap.execute on Solana requires a non-empty ' + 'serializedTransaction (base64-encoded).'
                });
            }
            ctx.write({
                type: 'serializedTransaction',
                serializedTransaction: base64Decode(input.serializedTransaction)
            });
        }
    });
}

/**
 * Max u64 value used for Solana's "unlimited allowance" semantics.
 *
 * @remarks
 * Solana SPL tokens have no approval concept. We return max to signal
 * "no approval needed" to orchestration code.
 */ const MAX_U64 = 2n ** 64n - 1n;
// ============================================================================
// Solana usdt.transfer binding
// ============================================================================
const solanaUsdtTransferInputSchema = zod.z.object({
    to: zod.z.string(),
    amount: zod.z.bigint().nonnegative()
}).strict();
const solanaUsdtTransferAction = defineAction({
    name: 'usdt.transfer',
    description: 'Transfer USDT to a recipient on Solana',
    inputSchema: solanaUsdtTransferInputSchema
});
function bindSolanaUsdtTransfer(adapter) {
    return solanaUsdtTransferAction.bind({
        adapter,
        async build (input, ctx) {
            const { usdtAddress } = ctx.chain;
            if (usdtAddress === null) {
                throw new KitError({
                    ...InputError.UNSUPPORTED_TOKEN,
                    recoverability: 'FATAL',
                    message: `USDT is not supported on chain "${ctx.chain.name}". ` + 'The chain has no usdtAddress configured.'
                });
            }
            await tokenTransferBuild({
                token: usdtAddress,
                to: input.to,
                amount: input.amount
            }, ctx);
        }
    });
}
// ============================================================================
// Factory
// ============================================================================
/**
 * Create a complete Solana action registry from an adapter.
 *
 * @remarks
 * Uses `createActionBindings` for base token/native actions and USDC aliases,
 * then adds Solana-specific CCTP v2 bridge actions. Solana has no ERC-20-style
 * allowance/approve, so those actions are no-ops returning appropriate defaults.
 *
 * @param adapter - Any Solana adapter (web3.js, kit, etc.).
 * @param options - Platform-specific callbacks for native and CCTP operations.
 * @returns A fully-typed action registry.
 *
 * @example
 * ```typescript
 * import { createSolanaActions } from '@core/adapter-solana-base'
 * import { SolanaMainnet } from '@core/chains'
 *
 * const actions = createSolanaActions(adapter, {
 *   getNativeBalance: async (chain, wallet) => {
 *     const connection = await getConnection(chain)
 *     return BigInt(await connection.getBalance(new PublicKey(wallet)))
 *   },
 *   getAnchorProvider: async (chain) => getAnchorProvider(chain),
 * })
 *
 * const balance = await actions['usdc.balanceOf']({ walletAddress: '7xKX...' }, { chain: SolanaMainnet })
 * ```
 */ function createSolanaActions(adapter, options) {
    const baseActions = createActionBindings({
        adapter,
        bindings: {
            'token.balanceOf': tokenBalanceOfExecute,
            'token.allowance': noopWith({
                amount: Amount.from(MAX_U64, {
                    decimals: 6
                })
            }),
            'token.approve': noopWith({
                amount: Amount.from(0n, {
                    decimals: 0
                })
            }),
            'token.transfer': tokenTransferBuild,
            'token.increaseAllowance': noopBuild,
            'native.balanceOf': createNativeBalanceOfExecute(options.getNativeBalance),
            'native.transfer': nativeTransferBuild
        }
    });
    const cctpBuilders = createCCTPBuilders(options.getAnchorProvider);
    const gatewayBuilders = createGatewayBuilders({
        getAnchorProvider: options.getAnchorProvider,
        ...options.getSigner === undefined ? {} : {
            getSigner: options.getSigner
        }
    });
    return {
        ...baseActions,
        'cctp.v2.depositForBurn': bindDepositForBurn(adapter, cctpBuilders.buildDepositForBurn),
        'cctp.v2.receiveMessage': bindReceiveMessage(adapter, cctpBuilders.buildReceiveMessage),
        'cctp.v2.customBurn': bindCustomBurn(adapter, cctpBuilders.buildCustomBurn),
        'cctp.v2.depositForBurnWithHook': bindDepositForBurnWithHook(adapter, cctpBuilders.buildDepositForBurn),
        'cctp.v2.customBurnWithHook': bindCustomBurnWithHook(adapter, cctpBuilders.buildCustomBurn),
        'gateway.v1.deposit': bindGatewayDeposit(adapter, gatewayBuilders.buildDeposit),
        'gateway.v1.depositFor': bindGatewayDepositFor(adapter, gatewayBuilders.buildDepositFor),
        'gateway.v1.addDelegate': bindGatewayAddDelegate(adapter, gatewayBuilders.buildAddDelegate),
        'gateway.v1.removeDelegate': bindGatewayRemoveDelegate(adapter, gatewayBuilders.buildRemoveDelegate),
        'gateway.v1.isDelegate': bindGatewayIsDelegate(adapter, gatewayBuilders.executeIsDelegate),
        'gateway.v1.initiateWithdrawal': bindGatewayInitiateWithdrawal(adapter, gatewayBuilders.buildInitiateWithdrawal),
        'gateway.v1.withdraw': bindGatewayWithdraw(adapter, gatewayBuilders.buildWithdraw),
        'gateway.v1.withdrawingBalance': bindGatewayWithdrawingBalance(adapter, gatewayBuilders.executeWithdrawingBalance),
        'gateway.v1.withdrawalBlock': bindGatewayWithdrawalBlock(adapter, gatewayBuilders.executeWithdrawalBlock),
        'gateway.v1.gatewayBurn': bindGatewayBurn(adapter, gatewayBuilders.buildGatewayBurn),
        'gateway.v1.gatewayMint': bindGatewayMint(adapter, gatewayBuilders.buildGatewayMint),
        'gateway.v1.signBurnIntents': bindGatewaySignBurnIntents(adapter, gatewayBuilders.executeSignBurnIntents),
        'swap.execute': bindSwapExecute(adapter),
        'usdt.transfer': bindSolanaUsdtTransfer(adapter)
    };
}

/**
 * Solana-specific legacy compatibility configuration.
 *
 * @remarks
 * Provides `createSolanaLegacyConfig` which returns a `LegacyCompatConfig`
 * with Solana-specific implementations for:
 * - `mapWaitResult`: maps `WaitResult` → `WaitForTransactionResponse`
 * - `calculateTransactionFee`: wraps the new `calculateFee` primitive
 *
 * @packageDocumentation
 */ // ============================================================================
// Wait Result Mapper
// ============================================================================
/** Type guard for raw wait result containing a transaction with meta. */ function hasTransaction(raw) {
    return raw !== null && typeof raw === 'object' && 'transaction' in raw && raw['transaction'] !== null && typeof raw['transaction'] === 'object';
}
/**
 * Map a `WaitResult` (from the new adapter) to the legacy `WaitForTransactionResponse`.
 *
 * @remarks
 * Solana's `blockId` (the slot number) maps to `blockNumber`. The legacy
 * `executePreparedChainRequest` checks `blockNumber` to determine success,
 * so this field must be populated.
 *
 * Fee info from `costUsed` maps to `effectiveGasPrice` (total fee in
 * lamports); Solana has no per-unit gas price concept so `gasUsed` holds
 * the compute units consumed from `raw.transaction`.
 */ function mapSolanaWaitResult(result) {
    const response = {
        txHash: result.txId,
        status: result.success ? 'success' : 'reverted',
        blockNumber: typeof result.blockId === 'bigint' ? result.blockId : BigInt(result.blockId),
        effectiveGasPrice: result.costUsed.raw
    };
    // Compute units consumed from the raw Solana transaction
    const computeUnits = hasTransaction(result.raw) ? result.raw.transaction.meta?.computeUnitsConsumed : undefined;
    if (computeUnits !== undefined) {
        response.gasUsed = BigInt(computeUnits);
    }
    return response;
}
// ============================================================================
// Factory
// ============================================================================
/**
 * Create a Solana-specific `LegacyCompatConfig` for `withLegacyCompat`.
 *
 * @param options - The new `calculateFee` primitive.
 * @returns A `LegacyCompatConfig` with Solana-specific wait result mapping and fee calculation.
 *
 * @example
 * ```typescript
 * import { withLegacyCompat } from '@core/adapter-compat'
 * import { createSolanaLegacyConfig } from '@core/adapter-solana-base'
 *
 * const calculateFee = async (input, meta) => ({
 *   fee: { raw: 5000n },
 *   units: 200_000n,
 *   unitPrice: 25n,
 * })
 * const legacyConfig = createSolanaLegacyConfig({ calculateFee })
 * const compatible = withLegacyCompat(adapter, legacyConfig)
 * ```
 */ function createSolanaLegacyConfig(options) {
    const { calculateFee } = options;
    return {
        mapWaitResult: mapSolanaWaitResult,
        async calculateTransactionFee (baseComputeUnits, bufferBasisPoints, chain) {
            const result = await calculateFee({
                computeUnits: baseComputeUnits,
                bufferBasisPoints
            }, {
                chain
            });
            return {
                gas: result.units,
                gasPrice: result.unitPrice,
                fee: String(result.fee.raw)
            };
        }
    };
}

/**
 * Extract a human-readable message from any error type.
 *
 * Handle Solana-specific error shapes (transaction logs, context objects)
 * before falling back to standard `Error.message` extraction.
 *
 * @param error - The raw error to extract a message from.
 * @returns A human-readable error message string.
 *
 * @example
 * ```typescript
 * import { extractErrorMessage } from '@core/adapter-solana-base'
 *
 * extractErrorMessage(new Error('test'))
 * // => 'test'
 * ```
 */ function extractErrorMessage(error) {
    if (hasSolanaLogs(error)) {
        const anchorLog = error.context.logs.find((log)=>log.includes('AnchorError') || log.includes('Error Message'));
        if (anchorLog !== undefined) {
            return anchorLog;
        }
    }
    if (hasTransactionLogs(error)) {
        const anchorLog = error.logs?.find((log)=>log.includes('AnchorError') || log.includes('Error Message'));
        if (anchorLog !== undefined) {
            return anchorLog;
        }
    }
    if (error instanceof Error) return error.message;
    if (typeof error === 'string') return error;
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message);
    }
    return 'Unknown error';
}
/**
 * Attempt to match an error message against common Solana error patterns.
 *
 * @remarks
 * If a pattern matches, this function **throws** the corresponding
 * `KitError`.  If no pattern matches it returns normally (void).
 *
 * @param message - The error message to match.
 * @param chain - The chain name for the error context.
 * @param details - Additional details to attach to the error.
 * @param logs - Optional transaction logs for richer context.
 * @throws {@link KitError} Various error types including insufficient token balance,
 *   insufficient gas, out of gas, simulation failed, transaction reverted,
 *   RPC endpoint error, or network connection failed depending on the matched pattern.
 *
 * @example
 * ```typescript
 * import { matchSolanaMessagePatterns } from '@core/adapter-solana-base'
 *
 * const originalError = new Error('Transaction simulation failed')
 * matchSolanaMessagePatterns(
 *   'Transaction simulation failed: Insufficient funds',
 *   'Solana',
 *   { rawError: originalError },
 * )
 * ```
 */ function matchSolanaMessagePatterns(message, chain, details, logs) {
    const msg = message.toLowerCase();
    // Insufficient token balance (SPL token errors)
    if (msg.includes('transfer amount exceeds balance') || msg.includes('burn amount exceeded') || msg.includes('insufficient token balance')) {
        throw createInsufficientTokenBalanceError(chain, 'token', details);
    }
    // Insufficient SOL for fees / rent
    if (msg.includes('insufficient funds') || msg.includes('insufficient lamports') || msg.includes('insufficient balance')) {
        throw createInsufficientGasError(chain, undefined, details);
    }
    // Compute budget exceeded (Solana's equivalent of "out of gas")
    if (msg.includes('computational budget exceeded') || msg.includes('exceeded CUs meter') || msg.includes('exceeded maximum number of instructions')) {
        throw createOutOfGasError(chain, details);
    }
    // Transaction too large — commonly surfaced from VersionedTransaction
    // compilation when the Address Lookup Table (ALT) is unavailable. Match
    // both the raw web3.js message and the wrapping layers' phrasing.
    if (msg.includes('versionedtransaction too large') || msg.includes('transaction too large') || msg.includes('transaction is too large') || msg.includes('encoded/raw') || msg.includes('exceeds the maximum transaction size') || msg.includes('transaction size exceeds')) {
        throw createTransactionTooLargeError(chain, details['rawError']);
    }
    // Missing/invalid signatures — surfaced when the SDK or RPC complains
    // that a required signer didn't sign the message. Treat as simulation
    // failure with a precise reason so callers can prompt the user to
    // re-sign rather than retry the same payload.
    if (msg.includes('missing signature') || msg.includes('signature verification failed') || msg.includes('signature failed verification') || msg.includes('signature is invalid') || msg.includes('missing required signature')) {
        throw createSimulationFailedError(chain, 'Transaction is missing a required signature.', details);
    }
    // Wrong program owner — Anchor's `AccountOwnedByWrongProgram` /
    // `IncorrectProgramId`, plus the runtime's "incorrect program id for
    // instruction". This is almost always a mis-routed CPI (e.g. SPL Token
    // vs Token-2022 mismatch) and should NOT be retried blindly.
    if (msg.includes('account owned by wrong program') || msg.includes('owned by the wrong program') || msg.includes('incorrect program id for instruction') || msg.includes('accountownedbywrongprogram') || msg.includes('incorrectprogramid')) {
        throw createTransactionRevertedError(chain, 'Account is owned by an unexpected program (likely SPL Token / Token-2022 mismatch).', details);
    }
    // Slippage — DEX/aggregator programs (Jupiter, Raydium, …) surface
    // their own "slippage exceeded" / "minimum amount out" errors through
    // the Anchor log channel. Tag them as reverts with a clean reason so
    // upstream UIs can offer a "increase slippage" affordance.
    if (msg.includes('slippage tolerance') || msg.includes('slippage exceeded') || msg.includes('exceeded slippage') || msg.includes('minimum amount out') || msg.includes('exceededslippage') || msg.includes('slippagetoleranceexceeded')) {
        throw createTransactionRevertedError(chain, 'Slippage tolerance exceeded.', details);
    }
    // ORDERING NOTE
    //
    // Execution reverts / program errors are checked BEFORE the broader
    // simulation-failure heuristic. RPC and wallet messages routinely carry
    // BOTH substrings, e.g. `"Transaction failed: custom program error:
    // 0x1"`. The simulation branch keys off the very broad `transaction
    // failed` substring, so if it ran first a deterministic program revert
    // (FATAL) would be mis-classified as a simulation failure (a softer
    // failure) — masking the on-chain revert reason. Match the specific
    // revert / program-error keywords first; only fall through to the
    // simulation branch when none are present. This mirrors the EVM
    // normalizer's revert-first ordering.
    // Execution reverts / program errors
    if (msg.includes('transaction reverted') || msg.includes('program failed') || msg.includes('anchorerror') || msg.includes('error message:') || msg.includes('custom program error')) {
        const reason = extractRevertReason(msg, logs) ?? message;
        throw createTransactionRevertedError(chain, reason, details);
    }
    // Transaction simulation failures
    if (msg.includes('simulation failed') || msg.includes('preflight') || msg.includes('transaction failed')) {
        const reason = extractRevertReason(msg, logs) ?? message;
        throw createSimulationFailedError(chain, reason, details);
    }
    // Blockhash / nonce expiry
    if (msg.includes('blockhash not found') || msg.includes('block height exceeded') || msg.includes('blockhash expired')) {
        throw createRpcEndpointError(chain, {
            ...details,
            reason: 'Blockhash expired or not found'
        });
    }
    // Network / connectivity errors
    if (msg.includes('connection refused') || msg.includes('connection failed') || msg.includes('timeout') || msg.includes('enotfound') || msg.includes('econnrefused') || msg.includes('fetch failed')) {
        throw createNetworkConnectionError(chain, details);
    }
    // RPC-level errors — patterns are intentionally specific to avoid false
    // positives from substrings like "rpc" appearing in token names or addresses.
    if (msg.includes('rpc error') || msg.includes('rpc request') || msg.includes('rate limit') || msg.includes('too many requests') || msg.includes('node is unhealthy') || msg.includes('server error')) {
        throw createRpcEndpointError(chain, details);
    }
    // Wallet user-rejection. Phantom, Solflare and Backpack surface a
    // declined signature/transaction as a plain string ("User rejected the
    // request", "User denied transaction signature", …) rather than a typed
    // error, so the framework handler never catches it. Map these to
    // USER_CANCELLED (FATAL) so the middleware does not retry and re-prompt
    // a user who explicitly declined. Kept last: a rejection message carries
    // none of the gas/revert/network keywords above, and matching earlier
    // would risk masking a more specific on-chain failure.
    if (msg.includes('user rejected') || msg.includes('user denied') || msg.includes('rejected by user') || msg.includes('request rejected') || msg.includes('transaction rejected') || msg.includes('rejected the request')) {
        throw createUserRejectedError(chain, details);
    }
}
/**
 * Create a Solana error normalizer that composes framework-specific handling
 * with shared Solana message pattern matching.
 *
 * @remarks
 * Delegates to `createErrorNormalizer` from `@core/adapter-base` for the
 * shared pipeline (KitError re-throw, fallback RPC error). Provides
 * Solana-specific message extraction (with log parsing) and pattern matching.
 *
 * The normalizer runs in this order:
 * 1. Re-throw existing `KitError` instances
 * 2. Run framework-specific handler (e.g., `SendTransactionError`,
 *    `SolanaJSONRPCError` for web3.js; `SolanaError` for Kit)
 * 3. Run shared Solana message pattern matching
 * 4. Throw a generic RPC endpoint error as fallback
 *
 * @param options - Framework-specific error handling configuration.
 * @returns An `ErrorNormalizer` function.
 *
 * @example
 * ```typescript
 * import { createSolanaErrorNormalizer } from '@core/adapter-solana-base'
 * import { SendTransactionError } from '@solana/web3.js'
 *
 * const normalizer = createSolanaErrorNormalizer({
 *   handleFrameworkError: (error, chain) => {
 *     if (error instanceof SendTransactionError) {
 *       // handle...
 *     }
 *   },
 * })
 * ```
 */ function createSolanaErrorNormalizer(options) {
    return createErrorNormalizer({
        defaultChain: 'Solana',
        handleFrameworkError: options.handleFrameworkError,
        extractMessage: extractErrorMessage,
        matchPatterns: (message, chain, details)=>{
            const logs = extractLogs(details['rawError']);
            matchSolanaMessagePatterns(message, chain, details, logs);
        }
    });
}
// ============================================================================
// Internal Helpers
// ============================================================================
function hasSolanaLogs(error) {
    return error !== null && typeof error === 'object' && 'context' in error && error.context !== null && typeof error.context === 'object' && 'logs' in error.context && Array.isArray(error.context.logs);
}
function hasTransactionLogs(error) {
    return error !== null && typeof error === 'object' && 'logs' in error && (Array.isArray(error.logs) || error.logs === undefined);
}
function extractLogs(error) {
    if (hasSolanaLogs(error)) {
        return error.context.logs;
    }
    if (hasTransactionLogs(error) && Array.isArray(error.logs)) {
        return error.logs;
    }
    return undefined;
}
/**
 * Extract a human-readable error reason from Solana transaction logs.
 *
 * @remarks
 * Scan log lines for `"Error Message:"` or `"AnchorError"` patterns
 * emitted by Anchor programs and the Solana runtime.
 *
 * @param logs - Transaction log lines to inspect.
 * @returns The extracted reason string, or `undefined` if none found.
 *
 * @example
 * ```typescript
 * import { extractReasonFromLogs } from '@core/adapter-solana-base'
 *
 * extractReasonFromLogs([
 *   'Program log: Error Message: Burn amount exceeded',
 * ])
 * // => 'Burn amount exceeded'
 * ```
 */ function extractReasonFromLogs(logs) {
    for (const log of logs){
        if (log.includes('Error Message:')) {
            const parts = log.split('Error Message:');
            const reason = parts[1]?.trim();
            if (reason !== undefined && reason.length > 0) return reason;
        }
        if (log.includes('AnchorError')) {
            return log.trim();
        }
    }
    return undefined;
}
function extractAfterKeyword(msg, keyword) {
    const idx = msg.indexOf(keyword);
    if (idx === -1) return undefined;
    const afterKeyword = msg.slice(idx + keyword.length);
    const colonIdx = afterKeyword.indexOf(':');
    if (colonIdx === -1) return undefined;
    const reason = afterKeyword.slice(colonIdx + 1).trim();
    return reason.length > 0 ? reason : undefined;
}
function extractReasonFromMessage(msg) {
    const lower = msg.toLowerCase();
    const keywords = [
        'error message',
        'anchorerror',
        'custom program error',
        'program failed'
    ];
    for (const keyword of keywords){
        const reason = extractAfterKeyword(lower, keyword);
        if (reason !== undefined) return reason;
    }
    return undefined;
}
function extractRevertReason(msg, logs) {
    if (logs !== undefined) {
        const logReason = extractReasonFromLogs(logs);
        if (logReason !== undefined) return logReason;
    }
    return extractReasonFromMessage(msg);
}

// ============================================================================
// Utility Functions
// ============================================================================
function extractSendTxDetails(error) {
    return {
        // Redact the raw error object so the RPC URL (and any embedded key)
        // does not leak through `cause.trace.rawError` into telemetry pipelines.
        rawError: redactRawError(error),
        transactionMessage: error.transactionError.message,
        logs: error.transactionError.logs
    };
}
function extractRpcDetails(error) {
    return {
        // Same redaction as extractSendTxDetails — mirrors viem/ethers.
        rawError: redactRawError(error),
        code: error.code,
        data: error.data
    };
}
// ============================================================================
// @solana/web3.js Error Handlers
// ============================================================================
const handleBlockheightExceeded = (error, chain)=>{
    if (error instanceof web3_js.TransactionExpiredBlockheightExceededError) {
        throw createNetworkTimeoutError(chain, 'Transaction expired: block height exceeded', {
            rawError: redactRawError(error),
            signature: error.signature
        });
    }
};
const handleNonceInvalid = (error, chain)=>{
    if (error instanceof web3_js.TransactionExpiredNonceInvalidError) {
        throw createRpcNonceError(chain, 'Transaction expired: nonce invalid', {
            rawError: redactRawError(error),
            signature: error.signature
        });
    }
};
const handleTransactionTimeout = (error, chain)=>{
    if (error instanceof web3_js.TransactionExpiredTimeoutError) {
        throw createNetworkTimeoutError(chain, 'Transaction confirmation timed out', {
            rawError: redactRawError(error),
            signature: error.signature
        });
    }
};
const handleSendTransactionError = (error, chain)=>{
    if (error instanceof web3_js.SendTransactionError) {
        const details = extractSendTxDetails(error);
        const txMessage = error.transactionError.message;
        const logs = error.transactionError.logs;
        const msg = txMessage.toLowerCase();
        if (msg.includes('insufficient funds') || msg.includes('insufficient lamports')) {
            throw createInsufficientGasError(chain, undefined, details);
        }
        if (msg.includes('simulation failed') || msg.includes('preflight')) {
            const reason = (logs === undefined ? undefined : extractReasonFromLogs(logs)) ?? txMessage;
            throw createSimulationFailedError(chain, reason, details);
        }
        if (msg.includes('program failed') || msg.includes('custom program error') || msg.includes('anchorerror')) {
            const reason = (logs === undefined ? undefined : extractReasonFromLogs(logs)) ?? txMessage;
            throw createTransactionRevertedError(chain, reason, details);
        }
        matchSolanaMessagePatterns(error.message, chain, details, logs);
    }
};
const PREFLIGHT_ERROR_CODE = -32002;
const NODE_UNHEALTHY_CODE = -32005;
const BLOCK_NOT_AVAILABLE_CODE = -32004;
const INVALID_REQUEST_CODE = -32600;
const METHOD_NOT_FOUND_CODE = -32601;
const INVALID_PARAMS_CODE = -32602;
const INTERNAL_ERROR_CODE = -32603;
const handleSolanaJSONRPCError = (error, chain)=>{
    if (error instanceof web3_js.SolanaJSONRPCError) {
        const details = extractRpcDetails(error);
        const code = typeof error.code === 'number' ? error.code : undefined;
        if (code === PREFLIGHT_ERROR_CODE) {
            const reason = error.message;
            throw createSimulationFailedError(chain, reason, details);
        }
        if (code === NODE_UNHEALTHY_CODE || code === BLOCK_NOT_AVAILABLE_CODE || code === INVALID_REQUEST_CODE || code === METHOD_NOT_FOUND_CODE || code === INVALID_PARAMS_CODE || code === INTERNAL_ERROR_CODE) {
            throw createRpcEndpointError(chain, {
                ...details,
                reason: error.message
            });
        }
        matchSolanaMessagePatterns(error.message, chain, details);
    }
};
const web3ErrorHandlers = [
    // Phase 1 — Transaction expiry (most specific, check first)
    handleBlockheightExceeded,
    handleNonceInvalid,
    handleTransactionTimeout,
    // Phase 2 — Transaction execution (SendTransactionError sub-matching)
    handleSendTransactionError,
    // Phase 3 — RPC protocol (JSON-RPC error codes)
    handleSolanaJSONRPCError
];
// ============================================================================
// Main Error Normalizer
// ============================================================================
/**
 * Error normalizer for `@solana/web3.js` adapter errors.
 *
 * @remarks
 * Compose web3.js-specific error class handling with shared Solana message
 * pattern matching from `@core/adapter-solana-base`.
 *
 * | web3.js Error | KitError |
 * |---------------|----------|
 * | `TransactionExpiredBlockheightExceededError` | `NETWORK_TIMEOUT` |
 * | `TransactionExpiredNonceInvalidError` | `RPC_NONCE_ERROR` |
 * | `TransactionExpiredTimeoutError` | `NETWORK_TIMEOUT` |
 * | `SendTransactionError` (insufficient funds) | `BALANCE_INSUFFICIENT_GAS` |
 * | `SendTransactionError` (simulation failed) | `ONCHAIN_SIMULATION_FAILED` |
 * | `SendTransactionError` (program failed) | `ONCHAIN_TRANSACTION_REVERTED` |
 * | `SolanaJSONRPCError` (-32002 preflight) | `ONCHAIN_SIMULATION_FAILED` |
 * | `SolanaJSONRPCError` (-32005/-32004 unhealthy) | `RPC_ENDPOINT_ERROR` |
 * | `SolanaJSONRPCError` (-32600/-32601/-32602/-32603) | `RPC_ENDPOINT_ERROR` |
 * | Other web3.js errors | Pattern-matched or `RPC_ENDPOINT_ERROR` |
 */ const errorNormalizer = createSolanaErrorNormalizer({
    handleFrameworkError: (error, chain)=>{
        for (const handler of web3ErrorHandlers){
            handler(error, chain);
        }
    }
});

const ADAPTER_NAME = 'solana-web3';
const ADAPTER_VERSION = '2.0.0';
/**
 * Create a Solana web3.js adapter context.
 *
 * @typeParam TCapabilities - The adapter capabilities type.
 * @param options - Configuration options for the context.
 * @returns An AdapterContext instance.
 *
 * @remarks
 * This factory creates an adapter context that:
 * - Caches Connections per chain
 * - Provides signer access
 * - Creates AnchorProviders on demand for CCTP operations
 * - Integrates with `@core/adapter-base` infrastructure
 *
 * @example
 * ```typescript
 * import { createAdapterContext } from '@circle-fin/adapter-solana/next'
 * import { Connection } from '@solana/web3.js'
 * import { SolanaMainnet } from '@circle-fin/bridge-kit/chains'
 *
 * const ctx = createAdapterContext({
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaMainnet],
 *   },
 *   getConnection: ({ chain }) =>
 *     new Connection(chain.rpcUrls.default.http[0]),
 *   getSigner: () => mySigner,
 * })
 * ```
 */ function createAdapterContext(options) {
    const connectionCache = new Map();
    async function getConnection(chain) {
        const cached = connectionCache.get(chain.name);
        if (cached) return cached // Reuse connection per chain
        ;
        const conn = await options.getConnection(chain);
        connectionCache.set(chain.name, conn);
        return conn;
    }
    async function getSigner() {
        return options.getSigner();
    }
    async function getAnchorProvider(chain) {
        const connection = await getConnection(chain);
        const signer = await getSigner();
        const wallet = new SimpleWallet(signer) // Wraps Signer for AnchorProvider compatibility
        ;
        return new anchor.AnchorProvider(connection, wallet, {
            commitment: 'confirmed'
        });
    }
    const getAddress = createGetAddress({
        getSigner,
        addressContext: options.capabilities.addressContext
    });
    const baseContext = createAdapterContext$1({
        identity: {
            name: ADAPTER_NAME,
            version: ADAPTER_VERSION
        },
        capabilities: options.capabilities,
        normalizeError: errorNormalizer,
        getAddress,
        runtime: options.runtime,
        tokens: options.tokens,
        config: options.config
    });
    return {
        ...baseContext,
        getConnection,
        getSigner,
        getAnchorProvider
    };
}

// ============================================================================
// Legacy Compatible Adapter Base (extends Adapter)
// ============================================================================
/**
 * Concrete `Adapter` subclass used by the `withLegacyCompat` HOC.
 *
 * @remarks
 * This class provides the **`extends Adapter`** relationship that makes the
 * compat layer work across bundled `.d.ts` files. When the DTS bundler inlines
 * `Adapter` into each package bundle, an intersection type like `T & Adapter`
 * creates two nominally distinct `Adapter` copies that TypeScript can't reconcile.
 * A real `extends` chain avoids this — the same pattern all existing adapters use.
 *
 * The abstract methods are implemented with placeholder stubs. At runtime,
 * `withLegacyCompat` uses `Object.assign` to overwrite them with real
 * delegating implementations.
 */ /* eslint-disable @typescript-eslint/no-unused-vars -- Stub params required for override signatures. */ /* eslint-disable @typescript-eslint/promise-function-async -- Stubs use Promise.reject/resolve; async/await is unnecessary. */ class LegacyCompatibleAdapterBase extends Adapter {
    chainType = '';
    /* v8 ignore start -- stubs overwritten by Object.assign at runtime */ prepare(_params, _ctx) {
        return Promise.reject(new Error('Legacy prepare() is not supported. Use the action-based API instead.'));
    }
    getAddress(_chain) {
        return Promise.reject(new Error('getAddress() not configured. This is a stub.'));
    }
    switchToChain(_chain) {
        return Promise.resolve();
    }
    waitForTransaction(_txHash, _config, _chain) {
        return Promise.reject(new Error('waitForTransaction() not configured. This is a stub.'));
    }
    calculateTransactionFee(_baseComputeUnits, _bufferBasisPoints, _chain) {
        return Promise.reject(new Error('calculateTransactionFee() not configured. This is a stub.'));
    }
    /* v8 ignore stop */ /**
   * Reject because the wrapped adapter supplies no `getTokenDecimals`.
   *
   * @remarks
   * Unlike the stubs above, `withLegacyCompat` never replaces this method.
   * The wrapped adapter must expose `getTokenDecimals` as an extra of
   * `assembleAdapter`, otherwise this stub reaches production and every token
   * outside the registry fails. The rejection is a `KitError` so the failure
   * stays inside the SDK error contract instead of escaping it as a plain
   * `Error`.
   *
   * The error message only tells the caller that the lookup is unavailable.
   * It does not name `assembleAdapter`, `extra`, or `withLegacyCompat` — this
   * stub can surface through App Kit or Swap Kit, and those internal wiring
   * names mean nothing to a consumer of the adapter. Adapter authors: supply
   * a `getTokenDecimals` extra to `assembleAdapter` before you wrap the
   * adapter with `withLegacyCompat`, so production code never reaches this
   * stub in the first place.
   *
   * @param _tokenAddress - The token address, ignored by the stub.
   * @param _chain - The chain definition, ignored by the stub.
   * @returns A promise that always rejects.
   * @throws `KitError` with `INPUT_UNSUPPORTED_ACTION` on every call.
   *
   * @example
   * ```typescript
   * import { LegacyCompatibleAdapterBase } from '@core/adapter-compat'
   * import { Solana } from '@core/chains'
   *
   * const stub = new LegacyCompatibleAdapterBase()
   * await stub
   *   .getTokenDecimals('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', Solana)
   *   .catch((error: unknown) => console.error(error))
   * ```
   */ getTokenDecimals(_tokenAddress, _chain) {
        return Promise.reject(new KitError({
            ...InputError.UNSUPPORTED_ACTION,
            recoverability: 'FATAL',
            message: 'getTokenDecimals() is not available on this adapter. This ' + 'adapter cannot look up token decimals on-chain.',
            cause: {
                trace: {
                    method: 'getTokenDecimals'
                }
            }
        }));
    }
}

// ============================================================================
// Default Field Rename Map
// ============================================================================
/**
 * Declarative mapping from legacy field names to new action input field names.
 * Fields not listed here pass through unchanged (e.g. `walletAddress`, `amount`).
 *
 * @remarks
 * Only action keys with known renames are listed. Actions without renames
 * (e.g. CCTP v2 actions, `usdc.*`) let their params pass through as-is.
 *
 * @example
 * ```typescript
 * import { DEFAULT_FIELD_RENAMES } from '@core/adapter-compat'
 *
 * const tokenApproveRenames = DEFAULT_FIELD_RENAMES['token.approve']
 * // => { tokenAddress: 'token', spenderAddress: 'delegate' }
 * ```
 */ const DEFAULT_FIELD_RENAMES = {
    'token.balanceOf': {
        tokenAddress: 'token'
    },
    'token.name': {
        tokenAddress: 'token'
    },
    'token.allowance': {
        tokenAddress: 'token',
        ownerAddress: 'walletAddress',
        spenderAddress: 'delegate'
    },
    'token.approve': {
        tokenAddress: 'token',
        spenderAddress: 'delegate'
    },
    'token.transfer': {
        tokenAddress: 'token',
        toAddress: 'to'
    },
    'native.balanceOf': {},
    'usdc.balanceOf': {}
};
/**
 * Set of action keys that are write actions (require `.prepare()` path).
 *
 * @example
 * ```typescript
 * import { WRITE_ACTIONS } from '@core/adapter-compat'
 *
 * const isWriteAction = WRITE_ACTIONS.has('token.approve')
 * // => true
 *
 * const isReadAction = WRITE_ACTIONS.has('token.balanceOf')
 * // => false
 * ```
 */ const WRITE_ACTIONS = new Set([
    'token.approve',
    'token.transfer',
    'token.increaseAllowance',
    'native.transfer',
    'usdc.approve',
    'usdc.transfer',
    'usdc.increaseAllowance',
    'cctp.v2.depositForBurn',
    'cctp.v2.receiveMessage',
    'cctp.v2.customBurn',
    'cctp.v2.depositForBurnWithHook',
    'cctp.v2.customBurnWithHook',
    'gateway.v1.deposit',
    'gateway.v1.depositFor',
    'gateway.v1.depositWithPermit',
    'gateway.v1.depositWithAuthorization',
    'gateway.v1.addDelegate',
    'gateway.v1.removeDelegate',
    'gateway.v1.initiateWithdrawal',
    'gateway.v1.withdraw',
    'gateway.v1.gatewayBurn',
    'gateway.v1.gatewayMint',
    'swap.execute',
    'earn.deposit',
    'earn.withdraw',
    'earn.claimRewards',
    'usdt.transfer'
]);
// ============================================================================
// Parameter Mapping
// ============================================================================
/**
 * Map legacy parameter names to new action input names.
 *
 * @param actionKey - The action key being invoked.
 * @param params - The legacy parameters from the provider.
 * @param fieldRenames - Override rename map (defaults to `DEFAULT_FIELD_RENAMES`).
 * @returns Mapped parameters with renamed fields and `amount` coerced to bigint.
 *
 * @example
 * ```typescript
 * import { mapParams } from '@core/adapter-compat'
 *
 * const mapped = mapParams('token.approve', {
 *   tokenAddress: '0xA0b...',
 *   spenderAddress: '0x123...',
 *   amount: '1000',
 * })
 * // => { token: '0xA0b...', delegate: '0x123...', amount: 1000n }
 * ```
 */ function mapParams(actionKey, params, fieldRenames = DEFAULT_FIELD_RENAMES) {
    const renames = fieldRenames[actionKey];
    if (!renames) return params;
    const mapped = {};
    for (const [field, value] of Object.entries(params)){
        const newField = renames[field] ?? field;
        if (field === 'amount' && typeof value === 'string') {
            // `BigInt('')` and `BigInt(' ')` both return `0n` in V8 and
            // do NOT throw, so the legacy `try/catch` wrap missed two
            // real footguns: a UI defaulting an `<input>` value to `''`,
            // and an operator-formatted whitespace-padded amount, both
            // silently became zero-amount transactions. Reject these
            // explicitly *before* `BigInt(value)` so the user sees a
            // VALIDATION_FAILED error (FATAL) instead of an apparently-
            // successful tx that did nothing.
            if (value.trim() === '') {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: 'Invalid amount: expected a non-empty numeric string, got an empty / whitespace-only value.'
                });
            }
            try {
                mapped[newField] = BigInt(value);
            } catch  {
                throw new KitError({
                    ...InputError.VALIDATION_FAILED,
                    recoverability: 'FATAL',
                    message: `Invalid amount: expected a numeric string, got "${value}".`
                });
            }
        } else {
            mapped[newField] = value;
        }
    }
    return mapped;
}

// This module intentionally references deprecated types to bridge them to
// the new action-based API.
/* eslint-disable @typescript-eslint/no-deprecated */ /**
 * Shared action adapters for the legacy `prepareAction` API.
 *
 * @remarks
 * These functions bridge from the old `prepareAction` return shape
 * (`{ estimate(), execute() }`) to the new action system. They accept
 * a resolved action (obtained via `adapter.action(key)`) and are shared
 * across all adapter ecosystems.
 *
 * @deprecated The entire prepareAction API is deprecated.
 * @packageDocumentation
 */ const ZERO_ESTIMATE = {
    gas: 0n,
    gasPrice: 0n,
    fee: '0'
};
/**
 * Map a legacy execute override object onto the new ecosystem-specific
 * override shape that `tx.execute(overrides)` consumes.
 *
 * @remarks
 * The legacy AppKit/swap contract uses `gasLimit` (number) on EVM, but
 * the new EVM adapter (and viem itself) uses `gas` (bigint). We translate
 * here so swap callers passing `prepared.execute({ gasLimit })` continue
 * to land a gas-limit override on the transaction. Other override fields
 * (`gasPrice`, `maxFeePerGas`, `maxPriorityFeePerGas`, `nonce`, `value`,
 * Solana's `computeUnitLimit`, etc.) flow through unchanged so the inner
 * primitive can validate them via its own schema.
 *
 * Internal — exported only for unit testing the compat layer.
 *
 * @internal
 */ function normalizeLegacyExecuteOverrides(overrides) {
    if (!('gasLimit' in overrides)) return overrides;
    const { gasLimit, ...rest } = overrides;
    if (gasLimit === undefined) return rest;
    // Accept `number | bigint | string` for gasLimit; coerce to bigint
    // because the new EVM `GasOverrides` schema requires `gas: bigint`.
    let gas;
    if (typeof gasLimit === 'bigint') {
        gas = gasLimit;
    } else if (typeof gasLimit === 'number' || typeof gasLimit === 'string') {
        gas = BigInt(gasLimit);
    } else {
        // Unknown shape — drop the field rather than throw, mirroring viem's
        // permissive override handling. The downstream schema will reject if
        // it disagrees.
        return rest;
    }
    return {
        ...rest,
        gas
    };
}
// ============================================================================
// Read Action Adapter
// ============================================================================
/**
 * Wrap a resolved read action in the legacy `PreparedChainRequest` shape.
 *
 * @remarks
 * Read actions don't have real gas costs, so `estimate()` returns zeroes.
 * `execute()` calls the action and unwraps `amount.raw` for legacy callers.
 *
 * @param action - The resolved read action function.
 * @param input - The mapped action input.
 * @param opCtx - The operation metadata (chain, etc.).
 * @returns A legacy prepared chain request shape.
 *
 * @example
 * ```typescript
 * import { adaptReadAction } from '@core/adapter-compat'
 * import { Ethereum } from '@core/chains'
 *
 * const prepared = adaptReadAction(readAction, { walletAddress: '0x...' }, { chain: Ethereum })
 * const balance = await prepared.execute()
 * ```
 */ function adaptReadAction(action, input, opCtx) {
    return {
        // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
        estimate: ()=>Promise.resolve(ZERO_ESTIMATE),
        async execute () {
            const result = await action(input, opCtx);
            const amount = result['amount'];
            if (amount?.raw !== undefined) return amount.raw;
            // Legacy callers expect read actions to return the primitive value
            // rather than the full `{ key: value }` object. Gateway v1 read
            // actions today return single-value shapes such as
            // `{ balance: string }`, `{ blockNumber: bigint }`, and
            // `{ isDelegate: boolean }`. To stay extensible as new read actions
            // are added, generically unwrap any result whose only own enumerable
            // key holds a defined value. Results with multiple keys (or `undefined`
            // singletons) fall through so future multi-field reads do not silently
            // lose fields.
            const keys = Object.keys(result);
            if (keys.length === 1) {
                const [onlyKey] = keys;
                if (onlyKey !== undefined) {
                    const value = result[onlyKey];
                    if (value !== undefined) return value;
                }
            }
            return result;
        }
    };
}
// ============================================================================
// Write Action Adapter
// ============================================================================
/**
 * Wrap a resolved write action in the legacy `PreparedChainRequest` shape.
 *
 * @remarks
 * Uses the write action's `.prepare()` path, then wraps the underlying
 * per-transaction `estimate()` / `execute()` so the result matches the
 * legacy contract that AppKit and the swap provider rely on:
 *
 * - `estimate()` returns `{ gas, gasPrice, fee }` where `gas` is gas
 *   units, `gasPrice` is the price per unit, and `fee` is the total fee.
 *   Values are derived from the per-transaction `FeeEstimate.units`,
 *   `FeeEstimate.unitPrice`, and `FeeEstimate.fee.raw`. Multi-transaction
 *   write actions sum the units and total fee, and surface a
 *   blended `gasPrice = totalFee / totalUnits` so callers using `gas` as a
 *   limit always see a positive, ratio-correct unit price.
 * - `execute(overrides?)` submits the transaction and returns the txId
 *   **without waiting for confirmation**. AppKit performs the wait
 *   itself via `adapter.waitForTransaction(...)`. Multi-transaction
 *   actions execute sequentially and only await intermediate
 *   confirmations (the legacy contract returns the final txId only).
 *   Legacy overrides (e.g. EVM `{ gasLimit }`) are normalized to the
 *   ecosystem-specific shape — `gasLimit` becomes `{ gas: BigInt(gasLimit) }`
 *   so swap callers that pass a gas limit through the compat layer
 *   keep their override on the wire.
 *
 * When the prepared result has zero transactions (noop action via
 * `ctx.noop()`), returns a noop `LegacyPreparedChainRequest` with
 * `type: 'noop'` so that downstream consumers (e.g.
 * `executePreparedChainRequest`) can skip execution.
 *
 * @param action - The resolved write action (must have a `.prepare()` method).
 * @param input - The mapped action input.
 * @param opCtx - The operation metadata (chain, etc.).
 * @returns A legacy prepared chain request shape.
 *
 * @example
 * ```typescript
 * import { adaptWriteAction } from '@core/adapter-compat'
 * import { Ethereum } from '@core/chains'
 *
 * const prepared = await adaptWriteAction(writeAction, { to: '0x...', amount: 1000n }, { chain: Ethereum })
 * const { gas, gasPrice, fee } = await prepared.estimate()
 * const txId = await prepared.execute({ gasLimit: 100_000 })
 * ```
 */ async function adaptWriteAction(action, input, opCtx, invocation, enrich) {
    const prepared = invocation === undefined ? await action.prepare(input, opCtx) : await action.prepare(input, opCtx, invocation);
    if (prepared.transactions.length === 0) {
        return {
            type: 'noop',
            // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
            estimate: ()=>Promise.resolve(ZERO_ESTIMATE),
            // eslint-disable-next-line @typescript-eslint/promise-function-async -- Fixed value; async/await is unnecessary.
            execute: ()=>Promise.resolve(undefined)
        };
    }
    const base = {
        async estimate () {
            const estimates = await Promise.all(prepared.transactions.map(async (tx)=>tx.estimate()));
            // Single-transaction write actions are the dominant case (and the
            // only shape the legacy AppKit/swap contract was ever exercised
            // against). Pass the underlying `units` and `unitPrice` straight
            // through so callers see exact gas-unit / unit-price values rather
            // than a blended ratio.
            if (estimates.length === 1) {
                const only = estimates[0];
                if (only !== undefined) {
                    return {
                        gas: only.units,
                        gasPrice: only.unitPrice,
                        fee: String(only.fee.raw)
                    };
                }
            }
            // Multi-transaction (e.g. USDT approve-reset → set): sum units and
            // fee, derive a blended `gasPrice = totalFee / totalUnits` so the
            // legacy `{ gas, gasPrice, fee }` invariant `gas * gasPrice ≈ fee`
            // holds and callers using `gas` as a limit see a positive unit price.
            let totalUnits = 0n;
            let totalFee = 0n;
            for (const e of estimates){
                totalUnits += e.units;
                totalFee += e.fee.raw;
            }
            const gasPrice = totalUnits > 0n ? totalFee / totalUnits : 0n;
            return {
                gas: totalUnits,
                gasPrice,
                fee: String(totalFee)
            };
        },
        async execute (overrides) {
            // The legacy `prepared.execute(overrides)` contract only ever
            // shipped object-shaped overrides (e.g. `{ gasLimit }`,
            // `{ value }`). Treat anything else — `undefined`, `null`,
            // numbers, strings — as "no overrides" so we don't forward
            // garbage values into the typed inner `tx.execute(...)` schema.
            // Forwarding `null` or a primitive previously turned a no-op
            // call into a downstream `INVALID_INPUT` error.
            const normalizedOverrides = overrides !== null && overrides !== undefined && typeof overrides === 'object' && !Array.isArray(overrides) ? normalizeLegacyExecuteOverrides(overrides) : undefined;
            const txs = prepared.transactions;
            // Single-transaction case: submit, return txId IMMEDIATELY.
            // The legacy AppKit/swap contract does the confirmation wait at
            // the kit/provider layer (`adapter.waitForTransaction(...)`), so
            // calling `wait()` here would double-wait and double-charge any
            // RPC poll budget configured at that layer.
            if (txs.length === 1) {
                const only = txs[0];
                if (only === undefined) return undefined;
                const result = normalizedOverrides === undefined ? await only.execute() : await only.execute(normalizedOverrides);
                return result.txId;
            }
            // Multi-transaction case: execute sequentially. Inner `wait()` is
            // required between dependent transactions (e.g. USDT
            // approve-reset → set) so the second tx isn't built against stale
            // state. Only the *last* txId is returned to match the legacy
            // single-string return contract; intermediate failures bubble up
            // as thrown errors via the inner `wait()`.
            let lastTxId;
            for(let i = 0; i < txs.length; i++){
                const tx = txs[i];
                if (tx === undefined) continue;
                const isLast = i === txs.length - 1;
                // Apply overrides only to the final transaction. Legacy callers
                // that pass `{ gasLimit }` are sizing the user-facing transaction,
                // not internal approve-resets.
                const result = isLast && normalizedOverrides !== undefined ? await tx.execute(normalizedOverrides) : await tx.execute();
                lastTxId = result.txId;
                if (!isLast) {
                    await result.wait();
                }
            }
            return lastTxId;
        }
    };
    return enrich ? enrich(base, prepared) : base;
}

// ============================================================================
// Higher-Order Function
// ============================================================================
/**
 * Wrap a standard adapter with legacy compatibility methods.
 *
 * @param adapter - A new-style adapter conforming to `StandardAdapter`.
 * @param config - Ecosystem-specific legacy compatibility configuration.
 * @returns The adapter as a concrete `Adapter` subclass, with all new methods
 * preserved via `Object.assign`. Consumers can pass it directly to `BridgeKit`
 * and providers without any cast.
 *
 * @example
 * ```typescript
 * import { withLegacyCompat } from '@core/adapter-compat'
 * import { createEVMLegacyConfig } from '@core/adapter-evm-base'
 *
 * const legacyAdapter = withLegacyCompat(
 *   newStyleAdapter,
 *   createEVMLegacyConfig({ calculateFee }),
 * )
 * // Legacy method available:
 * const result = await legacyAdapter.prepareAction('token.approve', params, opCtx)
 * ```
 */ function withLegacyCompat(adapter, config) {
    const fieldRenames = config.fieldRenames ?? DEFAULT_FIELD_RENAMES;
    const writeActions = config.writeActions ?? WRITE_ACTIONS;
    const switchToChainFn = config.switchToChain ?? (async ()=>{
    /* no-op */ });
    const originalWait = adapter.waitForTransaction;
    // Create a real Adapter subclass instance that TypeScript recognises
    // via the `extends Adapter` chain in the bundled `.d.ts`.
    const instance = new LegacyCompatibleAdapterBase();
    // Configure the instance with the adapter's concrete values
    instance.chainType = adapter.chainType;
    // The new AdapterCapabilities uses `readonly` arrays while the legacy
    // Adapter class uses mutable arrays. This assertion bridges that gap.
    instance.capabilities = adapter.capabilities;
    // Override stubs with real implementations that delegate to the new adapter
    const legacyMethods = {
        actionRegistry: new ActionRegistry(),
        async prepareAction (action, params, ctx, invocation) {
            const mapped = mapParams(action, params, fieldRenames);
            const resolved = adapter.action(action);
            if (resolved === undefined) {
                throw new KitError({
                    ...InputError.UNSUPPORTED_ACTION,
                    recoverability: 'FATAL',
                    message: `Action "${action}" is not registered in this adapter.`
                });
            }
            if (writeActions.has(action)) {
                return adaptWriteAction(resolved, mapped, ctx, invocation, config.enrichWriteRequest);
            }
            return adaptReadAction(resolved, mapped, ctx);
        },
        async readAction (action, params, ctx) {
            if (!isReadActionKey(action)) {
                throw createUnsupportedReadActionError(action);
            }
            const mapped = mapParams(action, params, fieldRenames);
            const resolved = adapter.action(action);
            if (resolved === undefined) {
                throw createUnsupportedReadActionError(action);
            }
            const prepared = adaptReadAction(resolved, mapped, ctx);
            return prepared.execute();
        },
        async switchToChain (chain) {
            await switchToChainFn(chain);
        },
        async waitForTransaction (txHash, txConfig, chain) {
            const meta = {
                chain
            };
            const waitInput = {
                txId: txHash,
                ...txConfig?.confirmations !== undefined && {
                    finality: txConfig.confirmations
                },
                ...txConfig?.timeout !== undefined && {
                    timeout: txConfig.timeout
                }
            };
            const result = await originalWait(waitInput, meta);
            return config.mapWaitResult(result);
        },
        async calculateTransactionFee (baseComputeUnits, bufferBasisPoints, chain) {
            return config.calculateTransactionFee(baseComputeUnits, bufferBasisPoints, chain);
        },
        async getAddress (chain) {
            // `StandardAdapter` omits getAddress; concrete adapters always provide it.
            // The assertion narrows from TAdapter to include the getAddress signature.
            const adapterWithGetAddress = adapter;
            return adapterWithGetAddress.getAddress(chain);
        }
    };
    // Merge everything onto the Adapter subclass instance:
    // 1. All new adapter methods (ctx, read, signTypedData, action, etc.)
    // 2. Legacy method implementations
    // At runtime this gives a single object with both old and new APIs.
    // The double-cast is required because `LegacyCompatibleAdapter` exposes
    // `prepare` as an *overloaded* intersection of the new
    // `TAdapter['prepare']` shape and the legacy `Adapter.prepare` stub,
    // while `Object.assign(instance, adapter, ...)` materialises only one
    // function at a time. At runtime the new shape always wins (adapter
    // overwrites the stub), so the assertion is sound.
    return Object.assign(instance, adapter, legacyMethods);
}

/**
 * Match the RPC error shapes Solana returns when a token account (ATA) has
 * not been initialised on-chain.
 *
 * @remarks
 * `getTokenAccountBalance` against an un-initialised ATA rejects with
 * messages such as `Invalid param: could not find account` (and some
 * wallets/RPCs surface `account not found`). Those cases legitimately mean
 * "zero balance". Every other rejection (timeouts, 5xx, rate limits) is a
 * transient infra failure that must propagate — swallowing it as `0n` makes
 * an outage look like an empty wallet and lets bridge/transfer flows proceed
 * with wrong data.
 *
 * @internal
 */ const ACCOUNT_NOT_FOUND_PATTERN = /could not find account|account ?not ?found|invalid param/i;
function isAccountNotFoundError(error) {
    return error instanceof Error && ACCOUNT_NOT_FOUND_PATTERN.test(error.message);
}
/**
 * Create a read primitive for the Solana web3.js adapter.
 *
 * @remarks
 * Dispatches based on the `type` field of the `SolanaReadInput`:
 * - `tokenBalance` → detect token program, derive ATA, `getTokenAccountBalance`
 * - `nativeBalance` → `getBalance`
 * - `accountExists` → `getAccountInfo` (returns boolean)
 * - `associatedTokenAccount` → detect token program, derive ATA (program-aware)
 * - `tokenProgram` → inspect mint owner, return Token vs Token-2022 program id
 *
 * All token-account paths detect the owning program (standard SPL Token
 * vs Token-2022) before deriving the ATA address, since the two programs
 * produce different ATAs for the same mint/owner pair.
 *
 * @param ctx - The adapter context with connection access.
 * @returns A read primitive function.
 *
 * @example
 * ```typescript
 * import { createRead } from '@circle-fin/adapter-solana/next'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const read = createRead(ctx)
 * const balance = await read<bigint>(
 *   {
 *     type: 'tokenBalance',
 *     mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *     owner: '...',
 *   },
 *   { chain: Solana }
 * )
 * console.log(balance) // e.g., 1000000n
 * ```
 */ function createRead(ctx) {
    const primitive = createPrimitive({
        name: 'read',
        adapterContext: ctx,
        execute: async (input, executeCtx)=>{
            const connection = await ctx.getConnection(executeCtx.chain);
            switch(input.type){
                case 'tokenBalance':
                    {
                        const mint = new web3_js.PublicKey(input.mint);
                        const owner = new web3_js.PublicKey(input.owner);
                        const programId = await detectTokenProgram(connection, mint);
                        const ata = getAssociatedTokenAddressSync(mint, owner, false, programId);
                        try {
                            const result = await connection.getTokenAccountBalance(ata);
                            return BigInt(result.value.amount);
                        } catch (error) {
                            // Only an un-initialised ATA means "zero balance". Transient RPC
                            // failures must propagate so callers never treat an outage as an
                            // empty wallet.
                            if (isAccountNotFoundError(error)) {
                                return 0n;
                            }
                            throw error;
                        }
                    }
                case 'nativeBalance':
                    {
                        const balance = await connection.getBalance(new web3_js.PublicKey(input.address));
                        return BigInt(balance);
                    }
                case 'accountExists':
                    {
                        const info = await connection.getAccountInfo(new web3_js.PublicKey(input.address));
                        return info !== null;
                    }
                case 'associatedTokenAccount':
                    {
                        const mint = new web3_js.PublicKey(input.mint);
                        const owner = new web3_js.PublicKey(input.owner);
                        const programId = await detectTokenProgram(connection, mint);
                        return getAssociatedTokenAddressSync(mint, owner, false, programId).toBase58();
                    }
                case 'tokenProgram':
                    {
                        const mint = new web3_js.PublicKey(input.mint);
                        const programId = await detectTokenProgram(connection, mint);
                        return programId.toBase58();
                    }
                default:
                    return assertNever(input);
            }
        }
    });
    return primitive;
}

/**
 * Bounded retry budget for the post-confirmation `getTransaction` lookup.
 * Mirrors the legacy `adapter-solana` poll loop and the `/next`
 * `adapter-solana-kit` fix shipped in #940: Solana's `confirmed`-commitment
 * indexer can briefly lag the signature being marked confirmed, so a single
 * `getTransaction` call races and returns `null` on otherwise-finalized
 * transactions. 10 attempts × 500 ms (~5 s) covers virtually every observed
 * race window without meaningfully extending the happy path latency.
 */ const FETCH_DETAILS_MAX_ATTEMPTS = 10;
const FETCH_DETAILS_RETRY_INTERVAL_MS = 500;
/**
 * Single `getTransaction` call lifted into a helper so the caller's retry
 * loop can keep its types simple and so the deprecation warning attached
 * to the broader `Connection.getTransaction` overload is suppressed in
 * exactly one place. The `versioned`-aware overload is the variant we
 * intentionally rely on: `maxSupportedTransactionVersion: 0` is required
 * for v0 transactions, otherwise the RPC returns `null` even on success.
 */ async function fetchOnce(// eslint-disable-next-line @typescript-eslint/no-explicit-any -- intentionally untyped to side-step web3.js' overload deprecation that is unrelated to this fix.
connection, txId) {
    const result = await connection.getTransaction(txId, {
        commitment: 'confirmed',
        maxSupportedTransactionVersion: 0
    });
    return result;
}
/**
 * Create a waitForTransaction primitive for the Solana web3.js adapter.
 *
 * @param ctx - The adapter context.
 * @returns A waitForTransaction primitive function.
 *
 * @example
 * ```typescript
 * import { createWaitForTransaction } from '@circle-fin/adapter-solana/next'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const wait = createWaitForTransaction(ctx)
 * const result = await wait(
 *   { txId: '5J8...' },
 *   { chain: Solana, address: '...' }
 * )
 * console.log(result.success) // true or false
 * console.log(result.costUsed?.raw) // e.g., 5000n
 * ```
 */ function createWaitForTransaction(ctx) {
    return createPrimitive({
        name: 'waitForTransaction',
        adapterContext: ctx,
        // `confirmTransaction` is itself a poll loop that already iterates
        // signature statuses internally, and the validator's
        // `(blockhash, lastValidBlockHeight)` strategy bounds the wait on
        // the on-chain side. Adding middleware retry on top of that:
        //
        //   1. Doubles the effective wait window — a "transient RPC blip"
        //      retry would re-poll from scratch, cumulatively breaching
        //      any caller-imposed `input.timeout`.
        //   2. Defeats the timeout race below: a `NetworkError.TIMEOUT`
        //      raised by the race lives in `DEFAULT_RETRYABLE_ERROR_CODES`,
        //      so the middleware would silently retry past the deadline
        //      the caller asked for.
        //
        // Keep the primitive single-shot. Transient confirm errors propagate
        // to the caller, who can decide whether to retry at the kit/UX layer
        // (where retries cost a fresh `input.timeout` budget).
        retryable: false,
        execute: async (input, executeCtx)=>{
            const { signal } = executeCtx;
            // Cooperative cancellation (A4): bail before any RPC work if already
            // aborted; the confirm race and the detail-fetch loop below also honor
            // the signal so a cancel stops the local wait promptly. The transaction
            // itself keeps settling on-chain — abort only ends the wait.
            throwIfAborted(signal, 'waitForTransaction');
            const connection = await ctx.getConnection(executeCtx.chain);
            // Honour the ORIGINAL signing-time blockhash when the caller
            // (typically `execute()`) plumbed it through; otherwise fall
            // back to fetching a fresh blockhash. The fallback path is for
            // external callers waiting on a signature they didn't produce
            // here — they cannot retrieve the original pair, so the best
            // they can do is wait against the latest blockhash and accept
            // that the expiry window is approximate.
            let blockhash;
            let lastValidBlockHeight;
            if (input.blockhash !== undefined && input.lastValidBlockHeight !== undefined) {
                blockhash = input.blockhash;
                lastValidBlockHeight = input.lastValidBlockHeight;
            } else {
                const latest = await connection.getLatestBlockhash();
                blockhash = latest.blockhash;
                lastValidBlockHeight = latest.lastValidBlockHeight;
            }
            // ─────────────────────────────────────────────────────────────────
            // Race `confirmTransaction` against the caller-supplied timeout.
            //
            // `connection.confirmTransaction` honours the validator's
            // blockhash-expiry horizon (`lastValidBlockHeight`) but does NOT
            // surface the kit-level `input.timeout`. Without this race a slow
            // RPC could hold the promise pending well past the caller's
            // deadline — kits that need a hard wait budget (UX progress
            // indicators, finality SLAs, fork-test harnesses) silently lose
            // the contract they asked for. The race produces a typed
            // `NetworkError.TIMEOUT` so callers can branch on it the same way
            // they do for HTTP-level timeouts elsewhere in the SDK.
            //
            // Known trade-off: on timeout the in-flight `confirmTransaction`
            // subscription keeps running until it resolves or the blockhash
            // expires. The late rejection is swallowed. For long-running
            // services this means a small tail of accumulated RPC subscriptions
            // (one per timed-out call). Acceptable for the current use-case:
            // the blockhash expiry bounds the tail to ~60 s, and replacing
            // `confirmTransaction` with a `getSignatureStatuses` polling loop
            // is the right follow-up to make cancellation fully clean.
            //
            // The setTimeout handle is cleared on the success path so we don't
            // leak a pending handle into the event loop after a fast confirm.
            // ─────────────────────────────────────────────────────────────────
            const confirmPromise = connection.confirmTransaction({
                signature: input.txId,
                blockhash,
                lastValidBlockHeight
            }, 'confirmed');
            if (input.timeout !== undefined && input.timeout > 0) {
                let timeoutHandle;
                const timeoutPromise = new Promise((_resolve, reject)=>{
                    timeoutHandle = setTimeout(()=>{
                        reject(new KitError({
                            ...NetworkError.TIMEOUT,
                            // FATAL, not RETRYABLE: the transaction has already been
                            // submitted to the cluster. Retrying the whole execute
                            // would risk duplicate confirmation. Callers should poll
                            // `getTransaction(txId)` to discover the outcome instead
                            // of re-submitting.
                            recoverability: 'FATAL',
                            message: `Solana transaction confirmation exceeded the caller's ` + `${String(input.timeout)} ms timeout (txId: ${input.txId}). ` + `The transaction was already submitted — check its status ` + `via getTransaction rather than re-submitting.`,
                            cause: {
                                trace: {
                                    txId: input.txId,
                                    timeoutMs: input.timeout
                                }
                            }
                        }));
                    }, input.timeout);
                });
                try {
                    await raceAbort(Promise.race([
                        confirmPromise,
                        timeoutPromise
                    ]), signal, 'waitForTransaction');
                } finally{
                    if (timeoutHandle !== undefined) clearTimeout(timeoutHandle);
                }
            } else {
                await raceAbort(confirmPromise, signal, 'waitForTransaction');
            }
            // ─────────────────────────────────────────────────────────────────
            // Retry `getTransaction` up to FETCH_DETAILS_MAX_ATTEMPTS times.
            // `confirmTransaction` told us the signature is on chain, but the
            // `confirmed`-commitment index can lag by hundreds of milliseconds,
            // so a single lookup races and returns `null` on a freshly-finalized
            // transaction. Returning `success: false, blockId: 0n` here would
            // surface to the bridge kit as a `chain_revert` and orphan an
            // already-burned transfer (PR-940). Retrying mirrors the proven
            // legacy `adapter-solana` poll loop and the `/next adapter-solana-kit`
            // fix; if every attempt still returns `null` we throw a typed
            // `RpcError.ENDPOINT_ERROR` so the caller sees an explicit RPC
            // problem rather than a fabricated success/failure.
            // ─────────────────────────────────────────────────────────────────
            let txResponse = null;
            let lastError;
            for(let attempt = 0; attempt < FETCH_DETAILS_MAX_ATTEMPTS; attempt++){
                // Honor cancellation between detail-fetch retries so an aborted
                // caller does not keep polling for the full ~5 s budget.
                throwIfAborted(signal, 'waitForTransaction');
                try {
                    txResponse = await fetchOnce(connection, input.txId);
                    if (txResponse !== null) break;
                } catch (error) {
                    lastError = error;
                }
                await new Promise((resolve)=>setTimeout(resolve, FETCH_DETAILS_RETRY_INTERVAL_MS));
            }
            if (txResponse === null) {
                throw new KitError({
                    ...RpcError.ENDPOINT_ERROR,
                    recoverability: 'RETRYABLE',
                    message: `Transaction ${input.txId} was confirmed by ` + `getSignatureStatuses but its details did not appear at ` + `'confirmed' commitment within ` + `${String(FETCH_DETAILS_MAX_ATTEMPTS * FETCH_DETAILS_RETRY_INTERVAL_MS)}ms.`,
                    ...lastError !== undefined && {
                        cause: {
                            trace: {
                                lastError
                            }
                        }
                    }
                });
            }
            const success = txResponse.meta?.err === null // null err = success
            ;
            const fee = BigInt(txResponse.meta?.fee ?? 0);
            return {
                success,
                txId: input.txId,
                blockId: BigInt(txResponse.slot ?? 0),
                costUsed: Amount.of(fee, {
                    decimals: executeCtx.chain.nativeCurrency.decimals
                }),
                raw: {
                    transaction: txResponse
                }
            };
        }
    });
}

/**
 * Compare two bigints for sort order.
 *
 * @param a - First bigint to compare.
 * @param b - Second bigint to compare.
 * @returns -1 if a < b, 1 if a > b, 0 if equal.
 */ function compareBigInt(a, b) {
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
}
/**
 * Percentile index used for sampling `getRecentPrioritizationFees`.
 *
 * @remarks
 * Solana mainnet typically returns a 150-slot window where many slots
 * have `prioritizationFee: 0` because there was no contention. Picking
 * the median (50th percentile) collapses to `0` in those windows,
 * which on mainnet means "no priority bid" and predictably gets
 * transactions stuck. We instead filter the zeros and sample the 75th
 * percentile of the remaining (non-zero) fees, so a small contention
 * signal still drives the bid away from 0 while heavy contention
 * tracks the upper tail. See PR #853 round-2 review (finding N10).
 *
 * @internal
 */ const PRIORITY_FEE_PERCENTILE = 0.75;
/**
 * Sample a priority-fee rate from a window of recent prioritization
 * fees.
 *
 * @remarks
 * Filters zero-fee entries (idle slots), then returns the 75th
 * percentile of the remaining values. Returns `0n` when every slot in
 * the window is genuinely idle — the primitive must still let
 * `getRecentPrioritizationFees`'s "no contention" signal pass through
 * so callers don't fabricate a bid out of thin air. See
 * {@link PRIORITY_FEE_PERCENTILE} for the rationale on the percentile
 * choice.
 *
 * @param fees - Raw priority-fee window from `getRecentPrioritizationFees`.
 * @returns The selected rate in micro-lamports per CU.
 *
 * @internal
 */ function selectPriorityFeeRate(fees) {
    const nonZero = fees.map((f)=>BigInt(f.prioritizationFee)).filter((v)=>v > 0n).sort(compareBigInt);
    if (nonZero.length === 0) return 0n;
    // ceil(p * n) - 1, clamped to 0 — gives the upper-percentile element
    // (e.g. with p=0.75 and n=4 we pick index 2, the third-largest).
    const idx = Math.max(0, Math.ceil(PRIORITY_FEE_PERCENTILE * nonZero.length) - 1);
    return nonZero[idx] ?? 0n;
}
/**
 * Create a calculateFee primitive for the Solana adapter.
 *
 * @remarks
 * Estimates the fee based on the current priority fee market and compute units.
 *
 * Fee formula:
 *
 * ```
 *   fee = computeUnits * microLamportsPerCU / 1_000_000 + 5000
 *         └──────────── priority fee (lamports) ────────┘ └─┬─┘
 *                                                        base fee per signature
 * ```
 *
 * **Important — the universal `units * unitPrice` shorthand does NOT
 * apply on Solana.** The returned `unitPrice` is in *micro*-lamports
 * per CU (the same unit Solana's `setComputeUnitPrice` instruction
 * accepts), so:
 *
 *   - `units * unitPrice` is in micro-lamports, not lamports — you
 *     need a `/ 1_000_000` divisor to compare it to a balance.
 *   - The 5 000-lamport base-fee-per-signature is added on top of the
 *     priority fee, so even after the divisor the product is short
 *     of the actual fee by exactly 5 000 lamports.
 *
 * Use `result.fee` / `result.fee.raw` when you need a number you can
 * compare against a wallet balance — that is the single value the
 * primitive has done all the unit-conversion work for. `units` and
 * `unitPrice` are exposed for callers that already understand the
 * Solana fee formula (auction-style priority bumping,
 * observability dashboards) and want to drive
 * `ComputeBudgetProgram.setComputeUnitPrice` directly.
 *
 * @param ctx - The adapter context.
 * @returns A calculateFee primitive function.
 *
 * @example
 * ```typescript
 * import { createCalculateFee } from '@circle-fin/adapter-solana/next'
 * import { createAdapterContext } from '@circle-fin/adapter-solana/next/context'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const ctx = createAdapterContext({ getConnection, getSigner, capabilities, runtime })
 * const calculateFee = createCalculateFee(ctx)
 * const result = await calculateFee(
 *   { computeUnits: 200_000n, bufferBasisPoints: 100n },
 *   { chain: Solana, address: '...' }
 * )
 * console.log(result.fee.raw) // e.g., 5000n
 * ```
 */ function createCalculateFee(ctx) {
    return createPrimitive({
        name: 'calculateFee',
        adapterContext: ctx,
        execute: async (input, executeCtx)=>{
            const connection = await ctx.getConnection(executeCtx.chain);
            const recentFees = await connection.getRecentPrioritizationFees();
            // 75th percentile of the non-zero recent priority fees — see
            // `selectPriorityFeeRate` for the mainnet idle-window rationale.
            const priorityFeeRate = selectPriorityFeeRate(recentFees);
            let computeUnits = input.computeUnits;
            // Buffer formula: add (bufferBasisPoints/10000) * computeUnits to absorb fee spikes
            if (input.bufferBasisPoints !== undefined && input.bufferBasisPoints > 0n) {
                computeUnits = computeUnits + computeUnits * input.bufferBasisPoints / 10000n;
            }
            const baseFee = 5000n // Solana base fee per signature (lamports)
            ;
            const priorityFee = computeUnits * priorityFeeRate / 1_000_000n;
            const totalFee = baseFee + priorityFee;
            return {
                fee: Amount.of(totalFee, {
                    decimals: executeCtx.chain.nativeCurrency.decimals
                }),
                units: computeUnits,
                unitPrice: priorityFeeRate,
                raw: {
                    baseFee,
                    priorityFee,
                    // Kept under the legacy `medianPriorityFee` key for
                    // backward-compat with adopters that destructure `raw`.
                    // The value is now the 75th-percentile of non-zero fees;
                    // `priorityFeeRate` is the canonical name going forward
                    // (PR #853 N10).
                    medianPriorityFee: priorityFeeRate,
                    priorityFeeRate
                }
            };
        }
    });
}

/**
 * Structural bridge helpers between `@core/adapter-solana-base` types
 * and `@solana/web3.js` types.
 *
 * @remarks
 * The shared Solana types (`SolanaTransactionInstruction`, etc.) are
 * runtime-compatible with their web3.js counterparts but differ in
 * variance (readonly vs mutable) and buffer types (Uint8Array vs Buffer).
 * These helpers encapsulate the casts in one place with documentation.
 *
 * @packageDocumentation
 */ /**
 * Bridge SolanaTransactionInstruction to web3.js TransactionInstruction.
 * Types are structurally compatible at runtime (readonly-\>mutable, Uint8Array-\>Buffer).
 *
 * @param instructions - Readonly array of structural Solana instructions.
 * @returns Mutable array of web3.js TransactionInstruction.
 *
 * @example
 * ```typescript
 * import { toWeb3Instructions } from '@circle-fin/adapter-solana/next'
 * import type { SolanaTransactionInstruction } from '@core/adapter-solana-base'
 *
 * const solanaInstructions: SolanaTransactionInstruction[] = [...]
 * const web3Instructions = toWeb3Instructions(solanaInstructions)
 * ```
 */ function toWeb3Instructions(instructions) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Structural bridge requires double cast: SolanaTransactionInstruction uses readonly arrays/Uint8Array while TransactionInstruction uses mutable arrays/Buffer. A direct cast is rejected by TypeScript's variance checks despite full runtime compatibility.
    return instructions;
}
/**
 * Bridge SolanaSignerKeypair to web3.js Signer.
 *
 * @param signers - Readonly array of structural Solana signer keypairs.
 * @returns Mutable array of web3.js Signer.
 *
 * @example
 * ```typescript
 * import { toWeb3Signers } from '@circle-fin/adapter-solana/next'
 * import type { SolanaSignerKeypair } from '@core/adapter-solana-base'
 *
 * const solanaSigners: SolanaSignerKeypair[] = [...]
 * const web3Signers = toWeb3Signers(solanaSigners)
 * ```
 */ function toWeb3Signers(signers) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Structural bridge requires double cast: SolanaSignerKeypair uses readonly properties while Signer expects mutable ones. Direct cast rejected by TypeScript despite identical runtime layout.
    return signers;
}
/**
 * Bridge SolanaAddressLookupTable to web3.js AddressLookupTableAccount.
 *
 * @param alts - Optional readonly array of structural lookup tables.
 * @returns Mutable array of web3.js AddressLookupTableAccount, or undefined.
 *
 * @example
 * ```typescript
 * import { toWeb3ALTs } from '@circle-fin/adapter-solana/next'
 * import type { SolanaAddressLookupTable } from '@core/adapter-solana-base'
 *
 * const solanaALTs: SolanaAddressLookupTable[] | undefined = [...]
 * const web3ALTs = toWeb3ALTs(solanaALTs)
 * ```
 */ function toWeb3ALTs(alts) {
    if (alts === undefined) return undefined;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Structural bridge requires double cast: SolanaAddressLookupTable uses readonly properties while AddressLookupTableAccount expects mutable ones. Direct cast rejected by TypeScript despite identical runtime layout.
    return alts;
}

const DEFAULT_COMPUTE_UNITS = 200_000;
/**
 * Create an estimate primitive for the Solana web3.js adapter.
 *
 * @remarks
 * For instruction-based inputs, builds a `VersionedTransaction` and calls
 * `getFeeForMessage` to get the exact transaction fee.
 * For serialized transactions, deserializes and calls `getFeeForMessage`.
 *
 * @param ctx - The adapter context.
 * @returns An estimate primitive function.
 *
 * @example
 * ```typescript
 * import { createEstimate } from '@circle-fin/adapter-solana/next'
 * import { SystemProgram, PublicKey } from '@solana/web3.js'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const estimate = createEstimate(ctx)
 * const result = await estimate(
 *   {
 *     type: 'instructions',
 *     instructions: [
 *       SystemProgram.transfer({
 *         fromPubkey: new PublicKey('...'),
 *         toPubkey: new PublicKey('...'),
 *         lamports: 1000,
 *       }),
 *     ],
 *   },
 *   { chain: Solana, address: '...' }
 * )
 * console.log(result.fee.raw) // e.g., 5000n
 * ```
 */ function createEstimate(ctx) {
    return createPrimitive({
        name: 'estimate',
        adapterContext: ctx,
        inputSchema: solanaWriteInputSchema,
        execute: async (input, executeCtx)=>{
            const connection = await ctx.getConnection(executeCtx.chain);
            const signer = await ctx.getSigner();
            const { blockhash } = await connection.getLatestBlockhash();
            let versionedTx;
            // Instruction-based: build VersionedTransaction from instructions.
            // Prepend the ComputeBudget ix (when requested) so that
            // getFeeForMessage sees the same message the cluster will receive.
            // Omitting it under-quotes the fee by the ix's marginal byte cost.
            if (input.type === 'instructions') {
                const instructions = toWeb3Instructions(input.instructions);
                const allInstructions = [
                    ...instructions
                ];
                if (input.computeUnitLimit !== undefined) {
                    allInstructions.unshift(web3_js.ComputeBudgetProgram.setComputeUnitLimit({
                        units: input.computeUnitLimit
                    }));
                }
                const alts = toWeb3ALTs(input.addressLookupTableAccounts);
                const message = new web3_js.TransactionMessage({
                    payerKey: signer.publicKey,
                    recentBlockhash: blockhash,
                    instructions: allInstructions
                }).compileToV0Message(alts ? [
                    ...alts
                ] : []);
                versionedTx = new web3_js.VersionedTransaction(message);
            } else {
                // Serialized: deserialize and pass message to getFeeForMessage
                versionedTx = web3_js.VersionedTransaction.deserialize(input.serializedTransaction);
            }
            const fee = await connection.getFeeForMessage(versionedTx.message, 'confirmed');
            // Fallback to 5000 lamports when RPC returns null (e.g. simulation failure)
            const feeValue = BigInt(fee.value ?? 5000);
            return {
                fee: Amount.of(feeValue, {
                    decimals: executeCtx.chain.nativeCurrency.decimals
                }),
                units: BigInt(input.type === 'instructions' ? input.computeUnitLimit ?? DEFAULT_COMPUTE_UNITS : DEFAULT_COMPUTE_UNITS),
                unitPrice: 0n,
                raw: {
                    feeForMessage: feeValue
                }
            };
        }
    });
}

/**
 * Create a simulate primitive for the Solana web3.js adapter.
 *
 * @param ctx - The adapter context.
 * @returns A simulate primitive function.
 *
 * @example
 * ```typescript
 * import { createSimulate } from '@circle-fin/adapter-solana/next'
 * import { SystemProgram, PublicKey } from '@solana/web3.js'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const simulate = createSimulate(ctx)
 * const result = await simulate(
 *   {
 *     type: 'instructions',
 *     instructions: [
 *       SystemProgram.transfer({
 *         fromPubkey: new PublicKey('...'),
 *         toPubkey: new PublicKey('...'),
 *         lamports: 1000,
 *       }),
 *     ],
 *   },
 *   { chain: Solana, address: '...' }
 * )
 * console.log(result.success) // true or false
 * ```
 */ function createSimulate(ctx) {
    return createPrimitive({
        name: 'simulate',
        adapterContext: ctx,
        inputSchema: solanaWriteInputSchema,
        execute: async (input, executeCtx)=>{
            const connection = await ctx.getConnection(executeCtx.chain);
            const signer = await ctx.getSigner();
            const { blockhash } = await connection.getLatestBlockhash();
            let versionedTx;
            // Instruction-based: build VersionedTransaction with optional ComputeBudget
            if (input.type === 'instructions') {
                const instructions = toWeb3Instructions(input.instructions);
                const allInstructions = [
                    ...instructions
                ];
                if (input.computeUnitLimit !== undefined) {
                    allInstructions.unshift(web3_js.ComputeBudgetProgram.setComputeUnitLimit({
                        units: input.computeUnitLimit
                    }));
                }
                const alts = toWeb3ALTs(input.addressLookupTableAccounts);
                const message = new web3_js.TransactionMessage({
                    payerKey: signer.publicKey,
                    recentBlockhash: blockhash,
                    instructions: allInstructions
                }).compileToV0Message(alts ? [
                    ...alts
                ] : []);
                versionedTx = new web3_js.VersionedTransaction(message);
            } else {
                // Serialized: deserialize and simulate as-is
                versionedTx = web3_js.VersionedTransaction.deserialize(input.serializedTransaction);
            }
            const result = await connection.simulateTransaction(versionedTx, {
                sigVerify: false,
                replaceRecentBlockhash: true
            });
            const success = result.value.err === null;
            return {
                success,
                error: success ? undefined : JSON.stringify(result.value.err),
                raw: {
                    logs: result.value.logs,
                    unitsConsumed: result.value.unitsConsumed,
                    err: result.value.err
                },
                traceId: executeCtx.traceId
            };
        }
    });
}

/**
 * Solana's blockhash lifetime: the runtime keeps the most recent 150
 * blockhashes in the recent-blockhashes sysvar. Beyond that horizon a
 * transaction is rejected as `BlockhashNotFound`. Used as the
 * conservative `lastValidBlockHeight` upper bound when a serialized
 * transaction's signing-time horizon is not available to the caller.
 *
 * @internal
 */ const MAX_RECENT_BLOCKHASHES = 150;
/**
 * Build a `VersionedTransaction` from instruction-based input and
 * stamp it with a freshly-fetched blockhash. The same blockhash is
 * returned for the confirmation horizon so the wire and the poll
 * target the same hash by construction.
 *
 * @internal
 */ async function buildFromInstructions(connection, payerKey, input) {
    const fresh = await connection.getLatestBlockhash();
    const instructions = toWeb3Instructions(input.instructions);
    const allInstructions = [
        ...instructions
    ];
    if (input.computeUnitLimit !== undefined) {
        allInstructions.unshift(web3_js.ComputeBudgetProgram.setComputeUnitLimit({
            units: input.computeUnitLimit
        }));
    }
    const alts = toWeb3ALTs(input.addressLookupTableAccounts);
    const message = new web3_js.TransactionMessage({
        payerKey,
        recentBlockhash: fresh.blockhash,
        instructions: allInstructions
    }).compileToV0Message(alts ? [
        ...alts
    ] : []);
    return {
        versionedTx: new web3_js.VersionedTransaction(message),
        blockhash: fresh.blockhash,
        lastValidBlockHeight: fresh.lastValidBlockHeight
    };
}
/**
 * Recover the `VersionedTransaction` from already-signed wire bytes
 * and derive a conservative confirmation horizon anchored at
 * `currentHeight + MAX_RECENT_BLOCKHASHES (150)`.
 *
 * @remarks
 * The wire's recent blockhash MUST be reused for confirmation —
 * fetching a fresh `getLatestBlockhash()` here would let the cluster
 * roll past the wire's hash silently and the poll would miss the
 * actual on-chain expiry. Throws a typed `INPUT_VALIDATION_FAILED`
 * (rather than a generic `Error`) when the deserialised message
 * lacks a `recentBlockhash` so the middleware error normalizer does
 * not collapse it into "RPC endpoint error" — the wire bytes are
 * malformed before we ever talk to an RPC.
 *
 * @internal
 */ async function loadFromSerialized(connection, input) {
    let versionedTx;
    try {
        versionedTx = web3_js.VersionedTransaction.deserialize(input.serializedTransaction);
    } catch (err) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Cannot deserialize serialized transaction: the wire bytes are ' + 'malformed or not a valid VersionedTransaction.',
            cause: {
                trace: {
                    rawError: redactRawError(err)
                }
            }
        });
    }
    const wireBlockhash = versionedTx.message.recentBlockhash;
    if (typeof wireBlockhash !== 'string' || wireBlockhash.length === 0) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Cannot derive confirmation blockhash: serialized transaction ' + 'message has no `recentBlockhash`.'
        });
    }
    // Solana's max recent-blockhash lifetime is 150 slots. Anchor the
    // upper bound on the *current* height rather than the unknown
    // signing-time height: if the wire hash was signed earlier the
    // cluster's own expiry will fire first; if it was signed at the
    // current tip we still have ~60s of confirmation budget.
    const currentHeight = await connection.getBlockHeight('confirmed');
    return {
        versionedTx,
        blockhash: wireBlockhash,
        lastValidBlockHeight: currentHeight + MAX_RECENT_BLOCKHASHES
    };
}
/**
 * Create an execute primitive for the Solana web3.js adapter.
 *
 * @remarks
 * Builds, signs, and sends a transaction. For instruction-based inputs,
 * constructs a VersionedTransaction. For serialized inputs, deserializes
 * and signs.
 *
 * **Cancellation semantics (A4):** if `invocation.signal` is already aborted
 * when `execute` runs, it throws `NETWORK_ABORTED` *before* signing or
 * sending. Once the transaction is submitted to the cluster it cannot be
 * recalled — aborting only stops the `wait()` promise, never the on-chain
 * transaction.
 *
 * @param ctx - The adapter context.
 * @param waitForTransaction - The wait primitive for building the `wait` callback.
 * @returns An execute primitive function.
 *
 * @example
 * ```typescript
 * import { createExecute } from '@circle-fin/adapter-solana/next'
 * import { createWaitForTransaction } from '@circle-fin/adapter-solana/next'
 * import { SystemProgram, PublicKey } from '@solana/web3.js'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const waitForTransaction = createWaitForTransaction(ctx)
 * const execute = createExecute(ctx, waitForTransaction)
 * const result = await execute(
 *   {
 *     type: 'instructions',
 *     instructions: [
 *       SystemProgram.transfer({
 *         fromPubkey: new PublicKey('...'),
 *         toPubkey: new PublicKey('...'),
 *         lamports: 1000,
 *       }),
 *     ],
 *   },
 *   { chain: Solana, address: '...' }
 * )
 * console.log(result.txId)
 * ```
 */ function createExecute(ctx, waitForTransaction) {
    return createPrimitive({
        name: 'execute',
        adapterContext: ctx,
        inputSchema: solanaWriteInputSchema,
        // Solana `execute` signs + submits a transaction using a recent
        // blockhash. The inner `connection.sendTransaction` already runs its
        // own `maxRetries` loop (3 for keypair signers, 0 for provider
        // signers). An outer middleware retry would re-send the identical
        // signed wire on a transient RPC failure and rely on non-uniform
        // RPC dedup to avoid a duplicate signature confirmation — a risk
        // for financial flows. Keep the primitive single-shot.
        retryable: false,
        execute: async (input, executeCtx)=>{
            // Cooperative cancellation (A4): refuse to sign/broadcast if the caller
            // already aborted. We never abort between broadcast and confirmation —
            // once `sendTransaction` resolves the tx is live on the cluster; abort
            // can only stop the `wait()` below, never the on-chain transaction.
            throwIfAborted(executeCtx.signal, 'execute');
            const connection = await ctx.getConnection(executeCtx.chain);
            const signer = await ctx.getSigner();
            // Resolve the confirmation horizon (`blockhash`,
            // `lastValidBlockHeight`) BEFORE building / deserialising the
            // tx so that downstream `confirmTransaction` and the `wait()`
            // callback both target the SAME blockhash the wire actually
            // carries. The two branch helpers preserve this invariant: the
            // `instructions` branch stamps a fresh blockhash onto the
            // newly-compiled message, while the `serializedTransaction`
            // branch recovers the wire's existing blockhash and derives a
            // conservative `lastValidBlockHeight` from `getBlockHeight() +
            // MAX_RECENT_BLOCKHASHES`. See each helper's JSDoc for why
            // re-fetching `getLatestBlockhash()` for serialized input
            // would silently miss real on-chain expiry.
            const { versionedTx, blockhash, lastValidBlockHeight } = input.type === 'instructions' ? await buildFromInstructions(connection, signer.publicKey, input) : await loadFromSerialized(connection, input);
            const isProvider = isProviderSigner(signer);
            let signature;
            // Provider signer (e.g. wallet adapter): sign via provider, skip preflight, no retries
            if (isProvider) {
                const signedTx = await signer.signTransaction(versionedTx);
                if (input.type === 'instructions' && input.signers && input.signers.length > 0) {
                    const extraSigners = toWeb3Signers(input.signers);
                    signedTx.sign([
                        ...extraSigners
                    ]);
                }
                signature = await connection.sendTransaction(signedTx, {
                    preflightCommitment: 'confirmed',
                    maxRetries: 0,
                    skipPreflight: true
                });
            } else {
                // Keypair signer: sign locally, run preflight, allow 3 retries
                const extraSigners = input.type === 'instructions' && input.signers ? toWeb3Signers(input.signers) : [];
                const allSigners = [
                    signer,
                    ...extraSigners
                ];
                versionedTx.sign(allSigners);
                signature = await connection.sendTransaction(versionedTx, {
                    preflightCommitment: 'confirmed',
                    maxRetries: 3
                });
            }
            // Confirmation is intentionally delegated to `wait()`. Calling
            // `confirmTransaction` here AND inside `waitForTransaction` would
            // double the polling latency and RPC load on every happy path.
            // `wait()` has full blockhash plumbing + timeout race + indexing
            // retry, so the inline confirm adds nothing.
            // Surface the primitive's traceId on the ExecuteResult (and on the
            // Confirmation returned by `wait()`) so callers can correlate the
            // returned signature with the `op.phase.*` events emitted during
            // submission without racing the event bus.
            const { traceId } = executeCtx;
            return {
                txId: signature,
                traceId,
                wait: async ()=>{
                    // Plumb the ORIGINAL signing-time blockhash + height into
                    // the wait primitive. Solana validates expiry via this
                    // pair, and fetching a fresh `getLatestBlockhash()` inside
                    // `wait()` would reset the expiry window relative to the
                    // wait moment, masking already-expired transactions as
                    // "successful" when their landing slot drifts past the
                    // real (signed) horizon.
                    const waitInput = {
                        txId: signature,
                        blockhash,
                        lastValidBlockHeight
                    };
                    const waitMeta = {
                        chain: executeCtx.chain,
                        address: executeCtx.address
                    };
                    // Forward the same signal so cancelling the invocation also stops
                    // this post-broadcast wait (the tx keeps settling). Omit the
                    // invocation arg entirely when there is no signal.
                    const confirmation = executeCtx.signal === undefined ? await waitForTransaction(waitInput, waitMeta) : await waitForTransaction(waitInput, waitMeta, {
                        signal: executeCtx.signal
                    });
                    return {
                        ...confirmation,
                        traceId
                    };
                }
            };
        }
    });
}

/**
 * Create a prepare primitive for the Solana web3.js adapter.
 *
 * @remarks
 * Composes the estimate, simulate, and execute primitives into a single
 * `PrepareResult` object that provides `single()`, `transactions[].estimate()`,
 * `transactions[].simulate()`, and `transactions[].execute()` methods.
 *
 * @param options - The primitives to compose.
 * @returns A prepare primitive function.
 *
 * @example
 * ```typescript
 * import { createSolanaPrepare } from '@circle-fin/adapter-solana/next'
 * import { createEstimate, createSimulate, createExecute, createWaitForTransaction } from '@circle-fin/adapter-solana/next'
 * import { SystemProgram, PublicKey } from '@solana/web3.js'
 * import { Solana } from '@circle-fin/bridge-kit/chains'
 *
 * const estimate = createEstimate(ctx)
 * const simulate = createSimulate(ctx)
 * const waitForTransaction = createWaitForTransaction(ctx)
 * const execute = createExecute(ctx, waitForTransaction)
 * const prepare = createSolanaPrepare({ ctx, estimate, simulate, execute })
 *
 * const result = await prepare(
 *   {
 *     type: 'instructions',
 *     instructions: [
 *       SystemProgram.transfer({
 *         fromPubkey: new PublicKey('...'),
 *         toPubkey: new PublicKey('...'),
 *         lamports: 1000,
 *       }),
 *     ],
 *   },
 *   { chain: Solana, address: '...' }
 * )
 * const tx = result.single()
 * const feeEstimate = await tx.estimate()
 * ```
 */ function createSolanaPrepare(options) {
    const { ctx, estimate, simulate, execute } = options;
    return createPrepare({
        adapterContext: ctx,
        prepare: (input, prepareCtx)=>{
            const inputs = Array.isArray(input) ? input : [
                input
            ];
            const operationCtx = {
                chain: prepareCtx.chain,
                address: prepareCtx.address
            };
            // Map each input to PreparedSolanaTransaction; built === input (no pre-build step)
            return inputs.map((item)=>({
                    input: item,
                    built: item,
                    estimate: async ()=>estimate(item, operationCtx),
                    simulate: async ()=>simulate(item, operationCtx),
                    execute: async ()=>execute(item, operationCtx)
                }));
        }
    });
}

/**
 * Normalise a raw signer into the keypair-or-fallback shape that
 * Gateway's `signBurnIntents` expects.
 *
 * @remarks
 * `signBurnIntents` decides between (a) ed25519-signing with
 * `signer.secretKey` and (b) the `provider.signMessage` fallback by
 * checking whether `secretKey` is `undefined`. There are two failure
 * modes we must guard against here:
 *
 * 1. `secretKey === undefined` — the canonical "no keypair" case,
 *    safe by construction.
 * 2. `secretKey instanceof Uint8Array && secretKey.length === 0` — a
 *    structural-typing footgun. Code paths that satisfy the `Signer`
 *    interface with `get secretKey() { return new Uint8Array(0) }`
 *    (so the type-checker is happy) used to slip past the keypair
 *    gate, and Gateway would then ed25519-sign with an all-zeros
 *    private key, producing a garbage signature that the attestation
 *    service silently rejects.
 *
 * Both shapes are normalised here to the absent case so downstream
 * (`signBurnIntents`) takes the `provider.signMessage` fallback.
 *
 * Exported for unit testing — not part of the public adapter surface.
 *
 * @internal
 */ function normaliseSignerForGateway(signer) {
    // Bind to a local so TS keeps the narrowed `Uint8Array` type when we
    // assemble the return value; without this, `exactOptionalPropertyTypes`
    // treats `signer.secretKey` as possibly-undefined again at the property
    // assignment site.
    const { secretKey } = signer;
    if (secretKey !== undefined && secretKey.length > 0) {
        return {
            secretKey
        };
    }
    return {};
}
/**
 * Create all Solana actions from adapter primitives.
 *
 * @param deps - Adapter context and the primitives needed by actions.
 * @returns A typed action registry.
 *
 * @example
 * ```typescript
 * import { createActionsFromAdapter } from '@circle-fin/adapter-solana/next'
 * import { createAdapterContext } from '@circle-fin/adapter-solana/next'
 * import { createRead, createSolanaPrepare } from '@circle-fin/adapter-solana/next'
 * import { SolanaMainnet } from '@circle-fin/bridge-kit/chains'
 *
 * const ctx = createAdapterContext({ capabilities, getConnection, getSigner })
 * const read = createRead(ctx)
 * const prepare = createSolanaPrepare({ ctx, estimate, simulate, execute })
 *
 * const actions = createActionsFromAdapter({
 *   ctx,
 *   read,
 *   prepare,
 *   getAddress: ctx.getAddress,
 * })
 *
 * const balance = await actions['native.balanceOf'](
 *   { chain: SolanaMainnet, address: '7xKX...' },
 *   { walletAddress: '7xKX...' },
 * )
 * ```
 */ function createActionsFromAdapter(deps) {
    return createSolanaActions(deps, {
        getNativeBalance: async (chain, wallet)=>{
            const connection = await deps.ctx.getConnection(chain);
            const balance = await connection.getBalance(new web3_js.PublicKey(wallet));
            return BigInt(balance);
        },
        getAnchorProvider: deps.ctx.getAnchorProvider,
        // Expose the underlying Keypair signer so Gateway's signBurnIntents can
        // fall back to direct Ed25519 signing when the AnchorProvider wallet
        // wrapper (SimpleWallet) doesn't surface signMessage. See
        // createGatewayBuilders.executeSignBurnIntents for the full rationale.
        getSigner: async ()=>{
            const signer = await deps.ctx.getSigner();
            return normaliseSignerForGateway(signer);
        }
    });
}
/**
 * Create a type-safe action dispatch function from an action registry.
 *
 * @param actions - The Solana action registry.
 * @returns An overloaded dispatch function.
 *
 * @example
 * ```typescript
 * import {
 *   createActionsFromAdapter,
 *   createActionDispatch,
 * } from '@circle-fin/adapter-solana/next'
 * import { createAdapterContext } from '@circle-fin/adapter-solana/next'
 * import { SolanaMainnet } from '@circle-fin/bridge-kit/chains'
 *
 * const ctx = createAdapterContext({ capabilities, getConnection, getSigner })
 * const actions = createActionsFromAdapter({
 *   ctx,
 *   read,
 *   prepare,
 *   getAddress: ctx.getAddress,
 * })
 * const dispatch = createActionDispatch(actions)
 *
 * const balance = await dispatch(
 *   'native.balanceOf',
 *   { chain: SolanaMainnet, address: '7xKX...' },
 *   { walletAddress: '7xKX...' },
 * )
 * ```
 */ function createActionDispatch(actions) {
    function dispatch(key, ...args) {
        const fn = actions[key];
        if (args.length === 0) return fn;
        return fn(...args);
    }
    return dispatch;
}

// ============================================================================
// Factories
// ============================================================================
/**
 * Create the adapter from options (context is created internally).
 *
 * @typeParam TCapabilities - The adapter capabilities type.
 * @param options - The adapter configuration options.
 * @returns A fully assembled Solana web3.js adapter with legacy compatibility.
 *
 * @example
 * ```typescript
 * import { createAdapter } from '@circle-fin/adapter-solana/next'
 * import { Connection } from '@solana/web3.js'
 * import { SolanaMainnet } from '@circle-fin/bridge-kit/chains'
 *
 * const adapter = createAdapter({
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaMainnet],
 *   },
 *   getConnection: ({ chain }) =>
 *     new Connection(chain.rpcUrls.default.http[0]),
 *   getSigner: () => mySigner,
 * })
 * ```
 */ function createAdapter(options) {
    const ctx = createAdapterContext(options);
    return createAdapterFromContext(ctx);
}
/**
 * Create the adapter from an existing context.
 *
 * @remarks
 * Compose all standalone primitives, then assemble the adapter
 * and wrap it with legacy compatibility methods.
 *
 * @param ctx - The pre-built adapter context.
 * @returns A fully assembled Solana web3.js adapter with legacy compatibility.
 *
 * @example
 * ```typescript
 * import { createAdapterContext, createAdapterFromContext } from '@circle-fin/adapter-solana/next'
 * import { SolanaMainnet } from '@circle-fin/bridge-kit/chains'
 *
 * const ctx = createAdapterContext({ capabilities, getConnection, getSigner })
 * const adapter = createAdapterFromContext(ctx)
 * ```
 */ function createAdapterFromContext(ctx) {
    // Primitives (order matters — some depend on others)
    const read = createRead(ctx);
    const calculateFee = createCalculateFee(ctx);
    const estimate = createEstimate(ctx);
    const simulate = createSimulate(ctx);
    const waitForTransaction = createWaitForTransaction(ctx);
    const execute = createExecute(ctx, waitForTransaction);
    const prepare = createSolanaPrepare({
        ctx,
        estimate,
        simulate,
        execute
    });
    // Read the mint account through the same connection the primitives use, so
    // an SPL mint outside the token registry still resolves its decimals.
    const getTokenDecimals = async (mintAddress, chain)=>resolveSolanaTokenDecimalsFromMint(async (mint)=>{
            const connection = await ctx.getConnection(chain);
            const info = await connection.getAccountInfo(new web3_js.PublicKey(mint));
            return info ? {
                data: info.data,
                owner: info.owner.toBase58()
            } : null;
        }, mintAddress, chain);
    // Actions
    const actions = createActionsFromAdapter({
        ctx,
        read: read,
        prepare,
        getAddress: ctx.getAddress
    });
    // Assemble: wires capabilities, getAddress, action dispatch, events,
    // validateChainSupport automatically from ctx.
    const adapter = assembleAdapter({
        ctx,
        chainType: 'solana',
        primitives: {
            read: read,
            prepare,
            waitForTransaction
        },
        actions,
        extras: {
            calculateFee,
            getTokenDecimals
        }
    });
    // Wrap with legacy compatibility
    return withLegacyCompat(adapter, createSolanaLegacyConfig({
        calculateFee
    }));
}

// ============================================================================
// Implementation
// ============================================================================
/**
 * Wrap a Solana Connection with RPC-level observability.
 *
 * @remarks
 * Creates a Proxy around the Connection that intercepts all async method calls.
 * For each RPC call:
 *
 * 1. Emits an `rpc.call` event at debug level before the call
 * 2. On success: records `rpc.duration` histogram + `rpc.call.succeeded` counter
 * 3. On failure: records `rpc.duration` histogram + `rpc.call.failed` counter,
 *    emits an `rpc.call.failed` error event with extracted error info
 *
 * Private methods (starting with `_`) and synchronous methods are not instrumented.
 *
 * @param base - The Solana Connection to wrap
 * @param options - Runtime and optional chain label
 * @returns An instrumented Connection with the same interface
 *
 * @example
 * ```typescript
 * import { Connection } from '@solana/web3.js'
 * import { instrumentConnection } from '@circle-fin/adapter-solana/next'
 * import { createRuntime } from '@core/runtime'
 *
 * const conn = new Connection('https://api.mainnet-beta.solana.com')
 * const runtime = createRuntime()
 * const instrumented = instrumentConnection(conn, { runtime, chain: 'Solana' })
 * const balance = await instrumented.getBalance(publicKey)
 * ```
 */ function instrumentConnection(base, options) {
    const { runtime, chain } = options;
    return new Proxy(base, {
        get (target, prop, receiver) {
            const value = Reflect.get(target, prop, receiver);
            if (typeof value !== 'function' || typeof prop !== 'string') {
                return value;
            }
            // Skip internal/private methods and non-RPC helpers
            if (prop.startsWith('_')) {
                return value;
            }
            return (...args)=>{
                const result = value.apply(target, args);
                // Only instrument methods that return promises (i.e., actual RPC calls)
                if (!(result instanceof Promise)) {
                    return result;
                }
                const start = runtime.clock.now();
                const tags = {
                    method: prop,
                    ...chain ? {
                        chain
                    } : {}
                };
                runtime.events.emit({
                    name: 'rpc.call',
                    level: 'debug',
                    at: start,
                    tags
                });
                return result.then((res)=>{
                    const durationMs = runtime.clock.since(start);
                    runtime.events.emit({
                        name: 'rpc.call.succeeded',
                        level: 'debug',
                        at: runtime.clock.now(),
                        tags,
                        data: {
                            durationMs,
                            method: prop
                        }
                    });
                    runtime.metrics.histogram('rpc.duration').observe({
                        ...tags,
                        status: 'success'
                    }, durationMs);
                    runtime.metrics.counter('rpc.call.succeeded').inc(tags);
                    return res;
                }, (err)=>{
                    const durationMs = runtime.clock.since(start);
                    runtime.metrics.histogram('rpc.duration').observe({
                        ...tags,
                        status: 'failed'
                    }, durationMs);
                    runtime.metrics.counter('rpc.call.failed').inc(tags);
                    runtime.events.emit({
                        name: 'rpc.call.failed',
                        level: 'error',
                        at: runtime.clock.now(),
                        tags,
                        data: {
                            durationMs,
                            method: prop,
                            error: extractErrorInfo(err)
                        }
                    });
                    throw err;
                });
            };
        }
    });
}

/**
 * Creates a Solana Keypair from a given private key string.
 *
 * This function supports multiple private key formats:
 * 1. Base58-encoded string
 * 2. Base64-encoded string
 * 3. JSON array of numbers representing the byte values of the secret key
 *
 * @param privateKey - The private key string in one of the supported formats.
 * @returns A Solana Keypair constructed from the provided secret key.
 * @throws Throws an error if the privateKey cannot be decoded in any supported format.
 */ function keypairFromPrivateKey(privateKey) {
    try {
        const secretKey = parsePrivateKeyToBytes(privateKey);
        // Keypair.fromSecretKey can handle both 32-byte and 64-byte keys correctly.
        return web3_js.Keypair.fromSecretKey(secretKey);
    } catch (error) {
        // Re-throw with a consistent, user-friendly error message.
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(`Invalid private key format. Please provide a valid Base58, base64, or array format private key. Original error: ${message}`);
    }
}

// ============================================================================
// Factory
// ============================================================================
/**
 * Create a new Solana adapter from a private key.
 *
 * @remarks
 * The derived keypair is used for signing and address resolution.
 * Private key adapters are always `user-controlled`.
 *
 * @param params - Private key and optional overrides.
 * @returns A configured `SolanaWeb3Adapter`.
 * @throws KitError if the private key is invalid.
 *
 * @example
 * ```typescript
 * import { createSolanaAdapterFromPrivateKey } from '@circle-fin/adapter-solana/next'
 *
 * const adapter = createSolanaAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 * })
 * ```
 */ function createSolanaAdapterFromPrivateKey(params) {
    if (typeof params.privateKey !== 'string' || params.privateKey.trim() === '') {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'privateKey is required and must be a non-empty string ' + '(Base58, Base64, or JSON array format).'
        });
    }
    let keypair;
    try {
        keypair = keypairFromPrivateKey(params.privateKey);
    } catch  {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            // Omit error details to prevent private key leakage
            message: 'Failed to derive keypair from private key. Please verify the key format (Base58, Base64, or JSON array).'
        });
    }
    const capabilities = resolveSolanaCapabilities(params.capabilities);
    if (capabilities.addressContext === 'developer-controlled') {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Private key adapters cannot use "developer-controlled" address context. ' + 'The address is deterministically derived from the private key.'
        });
    }
    const runtime = resolveRuntime(params.runtime);
    const connectionCache = new Map();
    const wrapConnection = (conn, chainName)=>instrumentConnection(conn, {
            runtime,
            ...chainName !== undefined && chainName !== '' ? {
                chain: chainName
            } : {}
        });
    return createAdapter({
        capabilities,
        runtime,
        ...params.tokens !== undefined && {
            tokens: params.tokens
        },
        ...params.config !== undefined && {
            config: params.config
        },
        getConnection: (chain)=>{
            if (params.connection) {
                const cached = connectionCache.get(chain.name);
                if (cached) return cached;
                const wrapped = wrapConnection(params.connection, chain.name);
                connectionCache.set(chain.name, wrapped);
                return wrapped;
            }
            const cached = connectionCache.get(chain.name);
            if (cached) return cached;
            if (params.getConnection) {
                const conn = params.getConnection(chain);
                if (conn instanceof Promise) {
                    throw new KitError({
                        ...InputError.VALIDATION_FAILED,
                        recoverability: 'FATAL',
                        message: 'getConnection must return a synchronous Connection for private key adapters.'
                    });
                }
                const wrapped = wrapConnection(conn, chain.name);
                connectionCache.set(chain.name, wrapped);
                return wrapped;
            }
            const conn = createConnection(chain);
            const wrapped = wrapConnection(conn, chain.name);
            connectionCache.set(chain.name, wrapped);
            return wrapped;
        },
        getSigner: ()=>keypair
    });
}

// ============================================================================
// Factory
// ============================================================================
/**
 * Create a new Solana adapter from a wallet provider.
 *
 * @remarks
 * Connects to the wallet if not already connected and creates a
 * provider signer wrapper.
 *
 * @param params - The provider and optional overrides.
 * @returns A configured `SolanaWeb3Adapter`.
 * @throws {KitError} When the wallet provider does not have a public key after connection.
 * @throws {KitError} When getConnection returns a Promise in synchronous mode.
 *
 * @example
 * ```typescript
 * import { createSolanaAdapterFromProvider } from '@circle-fin/adapter-solana/next'
 *
 * const adapter = await createSolanaAdapterFromProvider({
 *   provider: window.solana,
 * })
 * ```
 */ async function createSolanaAdapterFromProvider(params) {
    const { provider } = params;
    if (provider == null || typeof provider !== 'object') {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'provider is required and must be a Solana wallet provider object ' + '(e.g., window.solana from Phantom, Solflare, etc.).'
        });
    }
    if (!provider.isConnected) {
        await provider.connect();
    }
    if (!provider.publicKey) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: 'Wallet provider does not have a public key available. Please ensure the wallet is properly connected.'
        });
    }
    const providerSigner = {
        publicKey: new web3_js.PublicKey(provider.publicKey.toString()),
        get secretKey () {
            return new Uint8Array(0);
        },
        isProviderSigner: true,
        signTransaction: async (transaction)=>{
            const result = await provider.signTransaction(transaction);
            return result;
        },
        signAllTransactions: async (transactions)=>{
            if (provider.signAllTransactions) {
                const result = await provider.signAllTransactions(transactions);
                return result;
            }
            const signed = [];
            for (const tx of transactions){
                const signedTx = await provider.signTransaction(tx);
                signed.push(signedTx);
            }
            return signed;
        },
        signMessage: async (message)=>{
            if (provider.signMessage) {
                return await provider.signMessage(message);
            }
            throw new KitError({
                ...InputError.UNSUPPORTED_ACTION,
                recoverability: 'FATAL',
                message: 'Message signing not supported by this wallet provider'
            });
        }
    };
    const capabilities = resolveSolanaCapabilities(params.capabilities);
    const runtime = resolveRuntime(params.runtime);
    const connectionCache = new Map();
    const wrapConnection = (conn, chainName)=>instrumentConnection(conn, {
            runtime,
            ...chainName !== undefined && chainName !== '' ? {
                chain: chainName
            } : {}
        });
    return createAdapter({
        capabilities,
        runtime,
        ...params.tokens !== undefined && {
            tokens: params.tokens
        },
        ...params.config !== undefined && {
            config: params.config
        },
        getConnection: (chain)=>{
            if (params.connection) {
                const cached = connectionCache.get(chain.name);
                if (cached) return cached;
                const wrapped = wrapConnection(params.connection, chain.name);
                connectionCache.set(chain.name, wrapped);
                return wrapped;
            }
            const cached = connectionCache.get(chain.name);
            if (cached) return cached;
            const conn = createConnection(chain);
            const wrapped = wrapConnection(conn, chain.name);
            connectionCache.set(chain.name, wrapped);
            return wrapped;
        },
        getSigner: ()=>providerSigner
    });
}

exports.createActionDispatch = createActionDispatch;
exports.createActionsFromAdapter = createActionsFromAdapter;
exports.createCalculateFee = createCalculateFee;
exports.createEstimate = createEstimate;
exports.createExecute = createExecute;
exports.createRead = createRead;
exports.createRuntime = createRuntime;
exports.createSimulate = createSimulate;
exports.createSolanaActions = createSolanaActions;
exports.createSolanaAdapter = createAdapter;
exports.createSolanaAdapterContext = createAdapterContext;
exports.createSolanaAdapterFromContext = createAdapterFromContext;
exports.createSolanaAdapterFromPrivateKey = createSolanaAdapterFromPrivateKey;
exports.createSolanaAdapterFromProvider = createSolanaAdapterFromProvider;
exports.createSolanaPrepare = createSolanaPrepare;
exports.createTokenRegistry = createTokenRegistry;
exports.createWaitForTransaction = createWaitForTransaction;
exports.solanaReadInputSchema = solanaReadInputSchema;
exports.solanaWriteInputSchema = solanaWriteInputSchema;
//# sourceMappingURL=next.cjs.map
