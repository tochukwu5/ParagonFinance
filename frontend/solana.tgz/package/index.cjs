/**
 * Copyright (c) 2026, Circle Internet Group, Inc. All rights reserved.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

'use strict';

// Buffer polyfill setup - executes before any other code
// Ensures globalThis.Buffer is available for Solana libraries
const { Buffer } = require('buffer');
if (typeof globalThis !== 'undefined' && typeof globalThis.Buffer === 'undefined') {
    globalThis.Buffer = Buffer;
}
if (typeof window !== 'undefined' && typeof window.Buffer === 'undefined') {
    window.Buffer = Buffer;
}


var web3_js = require('@solana/web3.js');
var zod = require('zod');
var bn_js = require('bn.js');
var anchor = require('@coral-xyz/anchor');
var bs58 = require('bs58');
var ed25519 = require('@noble/curves/ed25519');
var bytes = require('@ethersproject/bytes');
var address = require('@ethersproject/address');
var units = require('@ethersproject/units');

function _interopDefault (e) { return e && e.__esModule ? e.default : e; }

var bs58__default = /*#__PURE__*/_interopDefault(bs58);

/**
 * Valid recoverability values for error handling strategies.
 *
 * - FATAL errors are thrown immediately (invalid inputs, insufficient funds)
 * - RETRYABLE errors are returned when a flow fails to start but could work later
 * - RESUMABLE errors are returned when a flow fails mid-execution but can be continued
 */ const RECOVERABILITY_VALUES = [
    'RETRYABLE',
    'RESUMABLE',
    'FATAL'
];
/**
 * Error type constants for categorizing errors by origin.
 *
 * This const object provides a reference for error types, enabling
 * IDE autocomplete and preventing typos when creating custom errors.
 *
 * @remarks
 * While internal error definitions use string literals with type annotations
 * for strict type safety, this constant is useful for developers creating
 * custom error instances or checking error types programmatically.
 *
 * @example
 * ```typescript
 * import { ERROR_TYPES, KitError } from '@core/errors'
 *
 * // Use for type checking
 * if (error.type === ERROR_TYPES.BALANCE) {
 *   console.log('This is a balance error')
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Use as reference when creating custom errors
 * const error = new KitError({
 *   code: 9999,
 *   name: 'CUSTOM_ERROR',
 *   type: ERROR_TYPES.BALANCE,  // IDE autocomplete works here
 *   recoverability: 'FATAL',
 *   message: 'Custom balance error'
 * })
 * ```
 */ const ERROR_TYPES = {
    /** User input validation and parameter checking */ INPUT: 'INPUT',
    /** Insufficient token balances and amount validation */ BALANCE: 'BALANCE',
    /** On-chain execution: reverts, gas issues, transaction failures */ ONCHAIN: 'ONCHAIN',
    /** Blockchain RPC provider issues and endpoint problems */ RPC: 'RPC',
    /** Internet connectivity, DNS resolution, connection issues */ NETWORK: 'NETWORK',
    /** API throttling, request frequency limits errors */ RATE_LIMIT: 'RATE_LIMIT',
    /** Service errors */ SERVICE: 'SERVICE',
    /** Upstream provider/AMM liquidity unavailable for the requested size */ LIQUIDITY: 'LIQUIDITY',
    /** Catch-all for unrecognized errors (code 0) */ UNKNOWN: 'UNKNOWN'
};
/**
 * Array of valid error type values for validation.
 * Derived from ERROR_TYPES const object.
 */ const ERROR_TYPE_VALUES = Object.values(ERROR_TYPES);

// Create mutable arrays for Zod enum validation
const RECOVERABILITY_ARRAY = [
    ...RECOVERABILITY_VALUES
];
const ERROR_TYPE_ARRAY = [
    ...ERROR_TYPE_VALUES
];
/**
 * Error code ranges for validation.
 * Single source of truth for valid error code ranges.
 *
 * Note: Code 0 is special - it's the UNKNOWN catch-all error.
 */ const ERROR_CODE_RANGES = [
    {
        min: 1000,
        max: 1999,
        type: 'INPUT'
    },
    {
        min: 3000,
        max: 3999,
        type: 'NETWORK'
    },
    {
        min: 4000,
        max: 4999,
        type: 'RPC'
    },
    {
        min: 5000,
        max: 5999,
        type: 'ONCHAIN'
    },
    {
        min: 6000,
        max: 6999,
        type: 'LIQUIDITY'
    },
    {
        min: 7000,
        max: 7999,
        type: 'RATE_LIMIT'
    },
    {
        min: 8000,
        max: 8999,
        type: 'SERVICE'
    },
    {
        min: 9000,
        max: 9999,
        type: 'BALANCE'
    }
];
/** Special code for UNKNOWN errors */ const UNKNOWN_ERROR_CODE = 0;
/**
 * Zod schema for validating ErrorDetails objects.
 *
 * This schema provides runtime validation for all ErrorDetails properties,
 * ensuring type safety and proper error handling for JavaScript consumers.
 *
 * @example
 * ```typescript
 * import { errorDetailsSchema } from '@core/errors'
 *
 * const result = errorDetailsSchema.safeParse({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Source and destination networks must be different'
 * })
 *
 * if (!result.success) {
 *   console.error('Validation failed:', result.error.issues)
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Runtime error
 * const result = errorDetailsSchema.safeParse({
 *   code: 9001,
 *   name: 'BALANCE_INSUFFICIENT_TOKEN',
 *   type: 'BALANCE',
 *   recoverability: 'FATAL',
 *   message: 'Insufficient USDC balance'
 * })
 * ```
 */ const errorDetailsSchema = zod.z.object({
    /**
   * Numeric identifier following standardized ranges:
   * - 0: UNKNOWN - Catch-all for unrecognized errors
   * - 1000-1999: INPUT errors - Parameter validation
   * - 3000-3999: NETWORK errors - Connectivity issues
   * - 4000-4999: RPC errors - Provider issues, gas estimation
   * - 5000-5999: ONCHAIN errors - Transaction/simulation failures
   * - 6000-6999: LIQUIDITY errors - Insufficient upstream liquidity
   * - 7000-7999: RATE_LIMIT errors - API throttling
   * - 8000-8999: SERVICE errors - Internal service errors
   * - 9000-9999: BALANCE errors - Insufficient funds
   */ code: zod.z.number().int('Error code must be an integer').refine((code)=>code === UNKNOWN_ERROR_CODE || ERROR_CODE_RANGES.some((range)=>code >= range.min && code <= range.max), {
        message: 'Error code must be 0 (UNKNOWN) or in valid ranges: 1000-1999 (INPUT), 3000-3999 (NETWORK), 4000-4999 (RPC), 5000-5999 (ONCHAIN), 6000-6999 (LIQUIDITY), 7000-7999 (RATE_LIMIT), 8000-8999 (SERVICE), 9000-9999 (BALANCE)'
    }),
    /** Human-readable ID (e.g., "INPUT_NETWORK_MISMATCH", "BALANCE_INSUFFICIENT_TOKEN") */ name: zod.z.string().min(1, 'Error name must be a non-empty string').regex(/^[A-Z_][A-Z0-9_]*$/, 'Error name must match pattern: ^[A-Z_][A-Z0-9_]*$'),
    /** Error category indicating where the error originated */ type: zod.z.enum(ERROR_TYPE_ARRAY, {
        errorMap: ()=>({
                message: 'Error type must be one of: INPUT, BALANCE, ONCHAIN, RPC, NETWORK, RATE_LIMIT, SERVICE, LIQUIDITY, UNKNOWN'
            })
    }),
    /** Error handling strategy */ recoverability: zod.z.enum(RECOVERABILITY_ARRAY, {
        errorMap: ()=>({
                message: 'Recoverability must be one of: RETRYABLE, RESUMABLE, FATAL'
            })
    }),
    /** User-friendly explanation with context */ message: zod.z.string().min(1, 'Error message must be a non-empty string').max(1000, 'Error message must be 1000 characters or less'),
    /** Raw error details, context, or the original error that caused this one. */ cause: zod.z.object({
        /** Free-form error payload from underlying system */ trace: zod.z.unknown().optional()
    }).optional()
});

/**
 * Validates an ErrorDetails object using Zod schema.
 *
 * @param details - The object to validate
 * @returns The validated ErrorDetails object
 * @throws TypeError When validation fails
 *
 * @example
 * ```typescript
 * import { validateErrorDetails } from '@core/errors'
 *
 * try {
 *   const validDetails = validateErrorDetails({
 *     code: 1001,
 *     name: 'NETWORK_MISMATCH',
 *     recoverability: 'FATAL',
 *     message: 'Source and destination networks must be different'
 *   })
 * } catch (error) {
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */ function validateErrorDetails(details) {
    const result = errorDetailsSchema.safeParse(details);
    if (!result.success) {
        const issues = result.error.issues.map((issue)=>`${issue.path.join('.')}: ${issue.message}`).join(', ');
        throw new TypeError(`Invalid ErrorDetails: ${issues}`);
    }
    return result.data;
}

/**
 * Maximum length for error messages in fallback validation errors.
 *
 * KitError enforces a 1000-character limit on error messages. When creating
 * fallback validation errors that combine multiple Zod issues, we use 950
 * characters to leave a 50-character buffer for:
 * - The error message prefix ("Invalid bridge parameters: ")
 * - Potential encoding differences or formatting overhead
 * - Safety margin to prevent KitError constructor failures
 *
 * This ensures that even with concatenated issue summaries, the final message
 * stays within KitError's constraints.
 */ const MAX_MESSAGE_LENGTH = 950;

/**
 * Structured error class for App Kit operations.
 *
 * This class extends the native Error class while implementing the ErrorDetails
 * interface, providing a consistent error format for programmatic handling
 * across the App Kits ecosystem. All properties are immutable to ensure
 * error objects cannot be modified after creation.
 *
 * @example
 * ```typescript
 * import { KitError } from '@core/errors'
 *
 * const error = new KitError({
 *   code: 1001,
 *   name: 'INPUT_NETWORK_MISMATCH',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Cannot bridge between mainnet and testnet'
 * })
 *
 * if (error instanceof KitError) {
 *   console.log(`Error ${error.code}: ${error.name}`)
 *   // → "Error 1001: INPUT_NETWORK_MISMATCH"
 * }
 * ```
 *
 * @example
 * ```typescript
 * import { KitError } from '@core/errors'
 *
 * // Error with cause information
 * const error = new KitError({
 *   code: 1002,
 *   name: 'INPUT_INVALID_AMOUNT',
 *   type: 'INPUT',
 *   recoverability: 'FATAL',
 *   message: 'Amount must be greater than zero',
 *   cause: {
 *     trace: { providedAmount: -100, minimumAmount: 0 }
 *   }
 * })
 *
 * throw error
 * ```
 */ /**
 * Brand symbol for `KitError`.
 *
 * @remarks
 * Uses `Symbol.for(...)` (the global symbol registry) rather than a
 * module-local `Symbol(...)`, so every `dist/*` bundle that compiles
 * this file ends up with the *same* symbol identity. This is the
 * mechanism that makes {@link isKitError} robust across multiple
 * separately-bundled copies of `@core/errors` — `instanceof` fails
 * cross-bundle (each bundle has its own `KitError` constructor),
 * but a registry symbol resolves to the same value in every bundle.
 *
 * Exported for use by {@link isKitError} only — consumers should
 * treat this as an implementation detail and call `isKitError`
 * instead of inspecting the brand directly.
 *
 * @internal
 */ const KIT_ERROR_BRAND = Symbol.for('circle.KitError');
class KitError extends Error {
    /** Numeric identifier following standardized ranges (1000+ for INPUT errors) */ code;
    /** Human-readable ID (e.g., "NETWORK_MISMATCH") */ name;
    /** Error category indicating where the error originated */ type;
    /** Error handling strategy */ recoverability;
    /** Raw error details, context, or the original error that caused this one. */ cause;
    /**
   * Create a new KitError instance.
   *
   * @param details - The error details object containing all required properties.
   * @throws \{TypeError\} When details parameter is missing or invalid.
   */ constructor(details){
        // Truncate message if it exceeds maximum length to prevent validation errors
        let message = details.message;
        if (message.length > MAX_MESSAGE_LENGTH) {
            message = `${message.slice(0, MAX_MESSAGE_LENGTH - 3)}...`;
        }
        const truncatedDetails = {
            ...details,
            message
        };
        // Validate input at runtime for JavaScript consumers using Zod
        const validatedDetails = validateErrorDetails(truncatedDetails);
        super(validatedDetails.message);
        // Set properties as readonly at runtime
        Object.defineProperties(this, {
            // Brand stamp. Non-enumerable so JSON.stringify / console.log do
            // not dump a `[Symbol(circle.KitError)]: true` line into operator
            // logs, but observable to anyone holding `KIT_ERROR_BRAND`. The
            // symbol is registered (`Symbol.for`) so distinct `dist/*` copies
            // of `@core/errors` resolve to the same identity, which is what
            // makes the brand a cross-bundle-safe replacement for the
            // `instanceof KitError` check used previously.
            [KIT_ERROR_BRAND]: {
                value: true,
                writable: false,
                enumerable: false,
                configurable: false
            },
            name: {
                value: validatedDetails.name,
                writable: false,
                enumerable: true,
                configurable: false
            },
            code: {
                value: validatedDetails.code,
                writable: false,
                enumerable: true,
                configurable: false
            },
            type: {
                value: validatedDetails.type,
                writable: false,
                enumerable: true,
                configurable: false
            },
            recoverability: {
                value: validatedDetails.recoverability,
                writable: false,
                enumerable: true,
                configurable: false
            },
            ...validatedDetails.cause && {
                cause: {
                    value: validatedDetails.cause,
                    writable: false,
                    enumerable: true,
                    configurable: false
                }
            }
        });
    }
}

/**
 * Standardized error code ranges for consistent categorization:
 *
 * - 0: UNKNOWN - Catch-all for unrecognized errors
 * - 1000-1999: INPUT errors - Parameter validation, input format errors
 * - 3000-3999: NETWORK errors - Internet connectivity, DNS, connection issues
 * - 4000-4999: RPC errors - Blockchain provider issues, gas estimation, nonce errors
 * - 5000-5999: ONCHAIN errors - Transaction/simulation failures, gas exhaustion, reverts
 * - 6000-6999: LIQUIDITY errors - Upstream provider/AMM liquidity unavailable
 * - 7000-7999: RATE_LIMIT errors - API throttling, request frequency limits
 * - 8000-8999: SERVICE errors - Internal service errors, server failures
 * - 9000-9999: BALANCE errors - Insufficient funds, token balance, allowance
 */ /**
 * Standardized error definitions for INPUT type errors.
 *
 * Each entry combines the numeric error code, string name, and type
 * to ensure consistency when creating error instances.
 *
 * Error codes follow a hierarchical numbering scheme where the first digit
 * indicates the error category (1 = INPUT) and subsequent digits provide
 * specific error identification within that category.
 *
 *
 * @example
 * ```typescript
 * import { InputError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...InputError.NETWORK_MISMATCH,
 *   recoverability: 'FATAL',
 *   message: 'Source and destination networks must be different'
 * })
 *
 * // Access code, name, and type individually if needed
 * console.log(InputError.NETWORK_MISMATCH.code)  // 1001
 * console.log(InputError.NETWORK_MISMATCH.name)  // 'INPUT_NETWORK_MISMATCH'
 * console.log(InputError.NETWORK_MISMATCH.type)  // 'INPUT'
 * ```
 */ const InputError = {
    /** Invalid amount format or value (negative, zero, or malformed) */ INVALID_AMOUNT: {
        code: 1002,
        name: 'INPUT_INVALID_AMOUNT',
        type: 'INPUT'
    },
    /** Unsupported or invalid bridge route configuration */ UNSUPPORTED_ROUTE: {
        code: 1003,
        name: 'INPUT_UNSUPPORTED_ROUTE',
        type: 'INPUT'
    },
    /** Invalid wallet or contract address format */ INVALID_ADDRESS: {
        code: 1004,
        name: 'INPUT_INVALID_ADDRESS',
        type: 'INPUT'
    },
    /** Invalid or unsupported chain identifier */ INVALID_CHAIN: {
        code: 1005,
        name: 'INPUT_INVALID_CHAIN',
        type: 'INPUT'
    },
    /** Unsupported token for chain */ UNSUPPORTED_TOKEN: {
        code: 1006,
        name: 'INPUT_UNSUPPORTED_TOKEN',
        type: 'INPUT'
    },
    /** Action not supported by this adapter / ecosystem */ UNSUPPORTED_ACTION: {
        code: 1008,
        name: 'INPUT_UNSUPPORTED_ACTION',
        type: 'INPUT'
    },
    /** No route satisfies the slippage or minimum-output constraint */ SLIPPAGE_CONSTRAINT_NOT_MET: {
        code: 1009,
        name: 'INPUT_SLIPPAGE_CONSTRAINT_NOT_MET',
        type: 'INPUT'
    },
    /** General validation failure for complex validation rules */ VALIDATION_FAILED: {
        code: 1098,
        name: 'INPUT_VALIDATION_FAILED',
        type: 'INPUT'
    }};
/**
 * Standardized error definitions for BALANCE type errors.
 *
 * BALANCE errors indicate insufficient funds or allowance issues
 * that prevent transaction execution.
 *
 * @example
 * ```typescript
 * import { BalanceError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...BalanceError.INSUFFICIENT_TOKEN,
 *   recoverability: 'FATAL',
 *   message: 'Insufficient USDC balance on Ethereum',
 *   cause: { trace: { required: '100', available: '50' } }
 * })
 * ```
 */ const BalanceError = {
    /** Insufficient token balance for transaction */ INSUFFICIENT_TOKEN: {
        code: 9001,
        name: 'BALANCE_INSUFFICIENT_TOKEN',
        type: 'BALANCE'
    },
    /** Insufficient native token (ETH/SOL/etc) for gas fees */ INSUFFICIENT_GAS: {
        code: 9002,
        name: 'BALANCE_INSUFFICIENT_GAS',
        type: 'BALANCE'
    }};
/**
 * Standardized error definitions for ONCHAIN type errors.
 *
 * ONCHAIN errors occur during transaction execution, simulation,
 * or interaction with smart contracts on the blockchain.
 *
 * @example
 * ```typescript
 * import { OnchainError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...OnchainError.SIMULATION_FAILED,
 *   recoverability: 'FATAL',
 *   message: 'Simulation failed: ERC20 transfer amount exceeds balance',
 *   cause: { trace: { reason: 'ERC20: transfer amount exceeds balance' } }
 * })
 * ```
 */ const OnchainError = {
    /** Transaction reverted on-chain after execution */ TRANSACTION_REVERTED: {
        code: 5001,
        name: 'ONCHAIN_TRANSACTION_REVERTED',
        type: 'ONCHAIN'
    },
    /** Pre-flight transaction simulation failed */ SIMULATION_FAILED: {
        code: 5002,
        name: 'ONCHAIN_SIMULATION_FAILED',
        type: 'ONCHAIN'
    },
    /** Transaction ran out of gas during execution */ OUT_OF_GAS: {
        code: 5003,
        name: 'ONCHAIN_OUT_OF_GAS',
        type: 'ONCHAIN'
    },
    /** Transaction size exceeds blockchain limit */ TRANSACTION_TOO_LARGE: {
        code: 5005,
        name: 'ONCHAIN_TRANSACTION_TOO_LARGE',
        type: 'ONCHAIN'
    },
    /** Unknown blockchain error that cannot be categorized */ UNKNOWN_BLOCKCHAIN_ERROR: {
        code: 5099,
        name: 'ONCHAIN_UNKNOWN_BLOCKCHAIN_ERROR',
        type: 'ONCHAIN'
    }
};
/**
 * Standardized error definitions for RPC type errors.
 *
 * RPC errors occur when communicating with blockchain RPC providers,
 * including endpoint failures, invalid responses, and provider-specific issues.
 *
 * @example
 * ```typescript
 * import { RpcError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...RpcError.ENDPOINT_ERROR,
 *   recoverability: 'RETRYABLE',
 *   message: 'RPC endpoint unavailable on Ethereum',
 *   cause: { trace: { endpoint: 'https://mainnet.infura.io' } }
 * })
 * ```
 */ const RpcError = {
    /** RPC endpoint returned error or is unavailable */ ENDPOINT_ERROR: {
        code: 4001,
        name: 'RPC_ENDPOINT_ERROR',
        type: 'RPC'
    },
    /** Invalid or unexpected RPC response format */ INVALID_RESPONSE: {
        code: 4002,
        name: 'RPC_INVALID_RESPONSE',
        type: 'RPC'
    },
    /** Nonce-related errors from RPC provider */ NONCE_ERROR: {
        code: 4003,
        name: 'RPC_NONCE_ERROR',
        type: 'RPC'
    }
};
/**
 * Standardized error definitions for NETWORK type errors.
 *
 * NETWORK errors indicate connectivity issues at the network layer,
 * including DNS failures, connection timeouts, and unreachable endpoints.
 *
 * @example
 * ```typescript
 * import { NetworkError } from '@core/errors'
 *
 * const error = new KitError({
 *   ...NetworkError.CONNECTION_FAILED,
 *   recoverability: 'RETRYABLE',
 *   message: 'Failed to connect to Ethereum network',
 *   cause: { trace: { error: 'ECONNREFUSED' } }
 * })
 * ```
 */ const NetworkError = {
    /** Network connection failed or unreachable */ CONNECTION_FAILED: {
        code: 3001,
        name: 'NETWORK_CONNECTION_FAILED',
        type: 'NETWORK'
    }};

/**
 * Creates error for unsupported token on chain.
 *
 * This error is thrown when a token is not supported on the specified chain.
 *
 * @param token - The token symbol (e.g., 'USDC', 'USDT')
 * @param chain - The chain name where the token is unsupported
 * @returns KitError with specific token support details
 *
 * @example
 * ```typescript
 * import { createUnsupportedTokenError } from '@core/errors'
 *
 * throw createUnsupportedTokenError('USDC', 'UnknownChain')
 * // Message: "USDC is not supported on UnknownChain"
 * ```
 */ function createUnsupportedTokenError(token, chain) {
    const errorDetails = {
        ...InputError.UNSUPPORTED_TOKEN,
        recoverability: 'FATAL',
        message: `${token} is not supported on ${chain}.`,
        cause: {
            trace: {
                token,
                chain
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for invalid amount format or precision.
 *
 * This error is thrown when the provided amount doesn't meet validation
 * requirements such as precision, range, or format.
 *
 * @param amount - The invalid amount string
 * @param reason - Specific reason why amount is invalid
 * @returns KitError with amount details and validation rule
 *
 * @example
 * ```typescript
 * import { createInvalidAmountError } from '@core/errors'
 *
 * throw createInvalidAmountError('0.000001', 'Amount must be at least 0.01 USDC')
 * // Message: "Invalid amount '0.000001': Amount must be at least 0.01 USDC"
 *
 * throw createInvalidAmountError('1,000.50', 'Amount must be a numeric string with dot (.) as decimal separator, with no thousand separators or comma decimals')
 * // Message: "Invalid amount '1,000.50': Amount must be a numeric string with dot (.) as decimal separator, with no thousand separators or comma decimals."
 * ```
 */ function createInvalidAmountError(amount, reason) {
    const errorDetails = {
        ...InputError.INVALID_AMOUNT,
        recoverability: 'FATAL',
        message: `Invalid amount '${amount}': ${reason}.`,
        cause: {
            trace: {
                amount,
                reason
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for invalid chain configuration.
 *
 * This error is thrown when the provided chain doesn't meet the required
 * configuration or is not supported for the operation.
 *
 * @param chain - The invalid chain name or identifier
 * @param reason - Specific reason why chain is invalid
 * @returns KitError with chain details and validation rule
 *
 * @example
 * ```typescript
 * import { createInvalidChainError } from '@core/errors'
 *
 * throw createInvalidChainError('UnknownChain', 'Chain is not supported by this bridge')
 * // Message: "Invalid chain 'UnknownChain': Chain is not supported by this bridge"
 * ```
 */ function createInvalidChainError(chain, reason) {
    const errorDetails = {
        ...InputError.INVALID_CHAIN,
        recoverability: 'FATAL',
        message: `Invalid chain '${chain}': ${reason}.`,
        cause: {
            trace: {
                chain,
                reason
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates error for general validation failure.
 *
 * This error is thrown when input validation fails for reasons not covered
 * by more specific error types.
 *
 * @param field - The field that failed validation
 * @param value - The invalid value (can be any type)
 * @param reason - Specific reason why validation failed
 * @returns KitError with validation details
 *
 * @example
 * ```typescript
 * import { createValidationFailedError } from '@core/errors'
 *
 * throw createValidationFailedError('recipient', 'invalid@email', 'Must be a valid wallet address')
 * // Message: "Validation failed for 'recipient': 'invalid@email' - Must be a valid wallet address"
 *
 * throw createValidationFailedError('chainId', 999, 'Unsupported chain ID')
 * // Message: "Validation failed for 'chainId': 999 - Unsupported chain ID"
 *
 * throw createValidationFailedError('config', { invalid: true }, 'Missing required properties')
 * // Message: "Validation failed for 'config': [object Object] - Missing required properties"
 * ```
 */ function createValidationFailedError(field, value, reason) {
    // Convert value to string for display, handling different types appropriately
    let valueString;
    if (typeof value === 'string') {
        valueString = `'${value}'`;
    } else if (typeof value === 'object' && value !== null) {
        valueString = JSON.stringify(value);
    } else {
        valueString = String(value);
    }
    const errorDetails = {
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: `Validation failed for '${field}': ${valueString} - ${reason}.`,
        cause: {
            trace: {
                field,
                value,
                reason
            }
        }
    };
    return new KitError(errorDetails);
}
/**
 * Creates a KitError from a Zod validation error with detailed error information.
 *
 * This factory function converts Zod validation failures into standardized KitError
 * instances with INPUT_VALIDATION_FAILED code (1098). It extracts all Zod issues
 * and includes them in both the error message and trace for debugging, providing
 * developers with comprehensive validation feedback.
 *
 * The error message includes all validation errors concatenated with semicolons.
 *
 * @param zodError - The Zod validation error containing one or more validation issues
 * @param context - Context string describing what was being validated (e.g., 'bridge parameters', 'user input')
 * @returns KitError with INPUT_VALIDATION_FAILED code and structured validation details
 *
 * @example
 * ```typescript
 * import { createValidationErrorFromZod } from '@core/errors'
 * import { z } from 'zod'
 *
 * const schema = z.object({
 *   name: z.string().min(3),
 *   age: z.number().positive()
 * })
 *
 * const result = schema.safeParse({ name: 'ab', age: -1 })
 * if (!result.success) {
 *   throw createValidationErrorFromZod(result.error, 'user data')
 * }
 * // Throws: KitError with message:
 * // "Invalid user data: name: String must contain at least 3 character(s); age: Number must be greater than 0"
 * // And cause.trace.validationErrors containing all validation errors as an array
 * ```
 *
 * @example
 * ```typescript
 * // Usage in validation functions
 * import { createValidationErrorFromZod } from '@core/errors'
 *
 * function validateBridgeParams(params: unknown): asserts params is BridgeParams {
 *   const result = bridgeParamsSchema.safeParse(params)
 *   if (!result.success) {
 *     throw createValidationErrorFromZod(result.error, 'bridge parameters')
 *   }
 * }
 * ```
 */ function createValidationErrorFromZod(zodError, context) {
    // Format each Zod issue as "path: message"
    const validationErrors = zodError.issues.map((issue)=>{
        const path = issue.path.length > 0 ? `${issue.path.join('.')}: ` : '';
        return `${path}${issue.message}`;
    });
    // Join all errors with semicolons to show complete validation feedback
    const issueSummary = validationErrors.join('; ');
    const allErrors = issueSummary || 'Invalid Input';
    // Build full message from context and validation errors
    const fullMessage = `Invalid ${context}: ${allErrors}`;
    const errorDetails = {
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message: fullMessage,
        cause: {
            trace: {
                validationErrors,
                zodError: zodError.message,
                zodIssues: zodError.issues
            }
        }
    };
    return new KitError(errorDetails);
}

/**
 * Creates error for insufficient token balance.
 *
 * This error is thrown when a wallet does not have enough tokens to
 * complete a transaction. The error is FATAL as it requires user
 * intervention to add funds.
 *
 * @param chain - The blockchain network where the balance check failed
 * @param token - The token symbol (e.g., 'USDC', 'ETH')
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with insufficient token balance details
 *
 * @example
 * ```typescript
 * import { createInsufficientTokenBalanceError } from '@core/errors'
 *
 * throw createInsufficientTokenBalanceError('Ethereum', 'USDC')
 * // Message: "Insufficient USDC balance on Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * try {
 *   await transfer(...)
 * } catch (error) {
 *   throw createInsufficientTokenBalanceError('Base', 'USDC', {
 *     rawError: error,
 *     balance: '1000000',
 *     amount: '5000000',
 *   })
 * }
 * ```
 */ function createInsufficientTokenBalanceError(chain, token, trace) {
    return new KitError({
        ...BalanceError.INSUFFICIENT_TOKEN,
        recoverability: 'FATAL',
        message: `Insufficient ${token} balance on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
                token
            }
        }
    });
}
/**
 * Creates error for insufficient gas funds.
 *
 * This error is thrown when a wallet does not have enough native tokens
 * (ETH, SOL, etc.) to pay for transaction gas fees. The error is FATAL
 * as it requires user intervention to add gas funds.
 *
 * @param chain - The blockchain network where the gas check failed
 * @param nativeToken - Native token symbol (e.g. 'ETH', 'SOL', 'AVAX') for a specific message, defaults to 'native token'
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with insufficient gas details
 *
 * @example
 * ```typescript
 * import { createInsufficientGasError } from '@core/errors'
 *
 * throw createInsufficientGasError('Ethereum')
 * // Message: "Insufficient native token on Ethereum to cover gas fees"
 *
 * throw createInsufficientGasError('Ethereum', 'ETH')
 * // Message: "Insufficient ETH on Ethereum to cover gas fees"
 * ```
 *
 * @example
 * ```typescript
 * throw createInsufficientGasError('Ethereum', 'ETH', {
 *   rawError: error,
 *   walletAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
 * })
 * ```
 */ function createInsufficientGasError(chain, nativeToken = 'native token', trace) {
    return new KitError({
        ...BalanceError.INSUFFICIENT_GAS,
        recoverability: 'FATAL',
        message: `Insufficient ${nativeToken} on ${chain} to cover gas fees`,
        cause: {
            trace: {
                ...trace,
                chain
            }
        }
    });
}

/**
 * Creates error for transaction simulation failures.
 *
 * This error is thrown when a pre-flight transaction simulation fails,
 * typically due to contract logic that would revert. The error is FATAL
 * as it indicates the transaction would fail if submitted.
 *
 * @param chain - The blockchain network where the simulation failed
 * @param reason - The reason for simulation failure (e.g., revert message)
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @returns KitError with simulation failure details
 *
 * @example
 * ```typescript
 * import { createSimulationFailedError } from '@core/errors'
 *
 * throw createSimulationFailedError('Ethereum', 'ERC20: insufficient allowance')
 * // Message: "Simulation failed on Ethereum: ERC20: insufficient allowance"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * throw createSimulationFailedError('Ethereum', 'ERC20: insufficient allowance', {
 *   rawError: error,
 *   txHash: '0x1234...',
 *   gasLimit: '21000',
 * })
 * ```
 */ function createSimulationFailedError(chain, reason, trace) {
    return new KitError({
        ...OnchainError.SIMULATION_FAILED,
        recoverability: 'FATAL',
        message: `Simulation failed on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason
            }
        }
    });
}
/**
 * Creates error for transaction reverts.
 *
 * This error is thrown when a transaction is submitted and confirmed
 * but reverts on-chain. The error is FATAL as it indicates the
 * transaction executed but failed.
 *
 * @param chain - The blockchain network where the transaction reverted
 * @param reason - The reason for the revert (e.g., revert message)
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @param txHash - The transaction hash if the transaction was submitted (optional)
 * @param explorerUrl - The block explorer URL for the transaction (optional)
 * @returns KitError with transaction revert details
 *
 * @example
 * ```typescript
 * import { createTransactionRevertedError } from '@core/errors'
 *
 * throw createTransactionRevertedError('Base', 'Slippage exceeded')
 * // Message: "Transaction reverted on Base: Slippage exceeded"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context and transaction details for debugging
 * throw createTransactionRevertedError(
 *   'Base',
 *   'Slippage exceeded',
 *   { rawError: error },
 *   '0x123...',
 *   'https://basescan.org/tx/0x123...'
 * )
 * ```
 */ function createTransactionRevertedError(chain, reason, trace, txHash, explorerUrl) {
    return new KitError({
        ...OnchainError.TRANSACTION_REVERTED,
        recoverability: 'FATAL',
        message: `Transaction reverted on ${chain}: ${reason}`,
        cause: {
            trace: {
                ...trace,
                chain,
                reason,
                ...txHash !== undefined && txHash !== '' && {
                    txHash
                },
                ...explorerUrl !== undefined && explorerUrl !== '' && {
                    explorerUrl
                }
            }
        }
    });
}
/**
 * Creates error for out of gas failures.
 *
 * This error is thrown when a transaction runs out of gas during execution.
 * The error is FATAL as it requires adjusting gas limits or transaction logic.
 *
 * @param chain - The blockchain network where the transaction ran out of gas
 * @param trace - Optional trace context to include in error (can include rawError and additional debugging data)
 * @param txHash - The transaction hash if the transaction was submitted (optional)
 * @param explorerUrl - The block explorer URL for the transaction (optional)
 * @returns KitError with out of gas details
 *
 * @example
 * ```typescript
 * import { createOutOfGasError } from '@core/errors'
 *
 * throw createOutOfGasError('Polygon')
 * // Message: "Transaction ran out of gas on Polygon"
 * ```
 *
 * @example
 * ```typescript
 * // With trace context for debugging
 * throw createOutOfGasError('Polygon', {
 *   gasUsed: '50000',
 *   gasLimit: '45000',
 * },
 *  '0xabc...',
 *   'https://polygonscan.com/tx/0xabc...'
 * )
 * ```
 */ function createOutOfGasError(chain, trace, txHash, explorerUrl) {
    return new KitError({
        ...OnchainError.OUT_OF_GAS,
        recoverability: 'FATAL',
        message: `Transaction ran out of gas on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain,
                ...txHash !== undefined && txHash !== '' && {
                    txHash
                },
                ...explorerUrl !== undefined && explorerUrl !== '' && {
                    explorerUrl
                }
            }
        }
    });
}
/**
 * Creates error for transaction size exceeding blockchain limits.
 *
 * This error is thrown when a transaction's serialized size exceeds
 * the blockchain's maximum transaction size limit. The error is FATAL
 * as it requires reducing the transaction size (e.g., fewer instructions,
 * smaller data payloads, or splitting into multiple transactions).
 *
 * Common on Solana where transactions have strict size limits (e.g., max 1232 bytes).
 *
 * @param chain - The blockchain network where the size limit was exceeded
 * @param rawError - The original error from the underlying system (optional)
 * @returns KitError with transaction size exceeded details
 *
 * @example
 * ```typescript
 * import { createTransactionTooLargeError } from '@core/errors'
 *
 * throw createTransactionTooLargeError('Solana')
 * // Message: "Transaction size exceeds limit on Solana"
 * ```
 *
 * @example
 * ```typescript
 * import { createTransactionTooLargeError } from '@core/errors'
 *
 * // With raw error containing size details
 * throw createTransactionTooLargeError(
 *   'Solana',
 *   new Error('transaction too large: max: encoded/raw 1644/1232')
 * )
 * // Error includes size information in cause.trace
 * ```
 */ function createTransactionTooLargeError(chain, rawError) {
    return new KitError({
        ...OnchainError.TRANSACTION_TOO_LARGE,
        recoverability: 'FATAL',
        message: `Transaction size exceeds limit on ${chain}`,
        cause: {
            trace: {
                chain,
                rawError
            }
        }
    });
}
/**
 * Creates error for unknown blockchain errors that cannot be categorized.
 *
 * This error is used as a fallback when a blockchain error doesn't match
 * any known patterns (balance, simulation, gas, network, RPC, etc.).
 * The error is FATAL as we cannot determine if it's retriable without
 * understanding the underlying cause.
 *
 * The original error message and context are preserved in the trace for
 * debugging purposes.
 *
 * @param chain - The blockchain network where the error occurred
 * @param originalMessage - The original error message from the blockchain
 * @param rawError - The original error object from the underlying system (optional)
 * @returns KitError with unknown blockchain error details
 *
 * @example
 * ```typescript
 * import { createUnknownBlockchainError } from '@core/errors'
 *
 * throw createUnknownBlockchainError('Ethereum', 'Unknown protocol error')
 * // Message: "Unknown blockchain error on Ethereum: Unknown protocol error"
 * ```
 *
 * @example
 * ```typescript
 * import { createUnknownBlockchainError } from '@core/errors'
 *
 * // With raw error for debugging
 * const rawError = new Error('Unexpected blockchain state')
 * throw createUnknownBlockchainError('Solana', rawError.message, rawError)
 * // Error preserves full context in cause.trace
 * ```
 */ function createUnknownBlockchainError(chain, originalMessage, rawError) {
    const errorMessage = originalMessage ? 'Unknown blockchain error on ' + chain + ': ' + originalMessage : 'Unknown blockchain error on ' + chain;
    return new KitError({
        ...OnchainError.UNKNOWN_BLOCKCHAIN_ERROR,
        recoverability: 'FATAL',
        message: errorMessage,
        cause: {
            trace: {
                chain,
                rawError
            }
        }
    });
}

/**
 * Create error for RPC endpoint failures.
 *
 * Throw when an RPC provider endpoint fails, returns an error,
 * or is unavailable. The error is RETRYABLE as RPC issues are often temporary.
 *
 * @param chain - The blockchain network where the RPC error occurred.
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with RPC endpoint error details.
 *
 * @example
 * ```typescript
 * import { createRpcEndpointError } from '@core/errors'
 *
 * throw createRpcEndpointError('Ethereum')
 * // Message: "RPC endpoint error on Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * throw createRpcEndpointError('Ethereum', {
 *   rawError: error,
 *   endpoint: 'https://mainnet.infura.io/v3/...',
 *   statusCode: 429,
 * })
 * ```
 */ function createRpcEndpointError(chain, trace) {
    return new KitError({
        ...RpcError.ENDPOINT_ERROR,
        recoverability: 'RETRYABLE',
        message: `RPC endpoint error on ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain
            }
        }
    });
}

/**
 * Create error for network connection failures.
 *
 * Throw when network connectivity issues prevent reaching
 * the blockchain network. The error is RETRYABLE as network issues are
 * often temporary.
 *
 * @param chain - The blockchain network where the connection failed.
 * @param trace - Optional trace context (can include rawError and debugging data).
 * @returns KitError with network connection error details.
 *
 * @example
 * ```typescript
 * import { createNetworkConnectionError } from '@core/errors'
 *
 * throw createNetworkConnectionError('Ethereum')
 * // Message: "Network connection failed for Ethereum"
 * ```
 *
 * @example
 * ```typescript
 * throw createNetworkConnectionError('Ethereum', {
 *   rawError: error,
 *   endpoint: 'https://eth-mainnet.g.alchemy.com/v2/...',
 *   retryCount: 3,
 * })
 * ```
 */ function createNetworkConnectionError(chain, trace) {
    return new KitError({
        ...NetworkError.CONNECTION_FAILED,
        recoverability: 'RETRYABLE',
        message: `Network connection failed for ${chain}`,
        cause: {
            trace: {
                ...trace,
                chain
            }
        }
    });
}

/**
 * Normalizes optional transaction details for error factories.
 *
 * Converts empty strings to undefined to ensure clean error traces.
 *
 * @param txHash - The transaction hash.
 * @param explorerUrl - The explorer URL.
 * @returns Normalized values or undefined.
 */ function normalizeTransactionDetails(txHash, explorerUrl) {
    const normalized = {};
    if (txHash !== undefined && txHash !== '') {
        normalized.txHash = txHash;
    }
    if (explorerUrl !== undefined && explorerUrl !== '') {
        normalized.explorerUrl = explorerUrl;
    }
    return normalized;
}
/**
 * Pattern that matches on-chain revert reasons caused by slippage or
 * price constraints. When a revert matches, the error is surfaced as
 * {@link InputError.SLIPPAGE_CONSTRAINT_NOT_MET} (RETRYABLE) instead of
 * a generic simulation-failed / transaction-reverted error.
 *
 * @internal
 */ const SLIPPAGE_REVERT_PATTERN = /slippage|lower than the minimum required|less than the initial balance|minimum.?output|price.?impact|stop.?limit|InsufficientOutput|InsufficientFinalBalance/i;
/**
 * Handle simulation / execution revert errors, distinguishing slippage
 * constraint failures from generic reverts and simulation failures.
 *
 * @internal
 */ function parseRevertError(msg, error, context) {
    const reason = extractRevertReason(msg, error) ?? 'Transaction reverted';
    if (SLIPPAGE_REVERT_PATTERN.test(reason)) {
        return new KitError({
            ...InputError.SLIPPAGE_CONSTRAINT_NOT_MET,
            recoverability: 'RETRYABLE',
            message: `Transaction on ${context.chain} reverted: "${reason}". ` + 'Try increasing slippageBps or adjusting stopLimit.',
            cause: {
                trace: {
                    rawError: error,
                    chain: context.chain,
                    reason
                }
            }
        });
    }
    if (/simulation failed/i.test(msg) || context.operation === 'simulation') {
        return createSimulationFailedError(context.chain, reason, {
            rawError: error
        });
    }
    const { txHash, explorerUrl } = normalizeTransactionDetails(context.txHash, context.explorerUrl);
    return createTransactionRevertedError(context.chain, reason, {
        rawError: error
    }, txHash, explorerUrl);
}
/**
 * Parses raw blockchain errors into structured KitError instances.
 *
 * This function uses pattern matching to identify common blockchain error
 * types and converts them into standardized KitError format. It handles
 * errors from viem, ethers, Solana web3.js, and other blockchain libraries.
 *
 * The parser recognizes 6 main error patterns:
 * 1. Insufficient balance errors
 * 2. Simulation/execution reverted errors
 * 3. Gas-related errors
 * 4. Network connectivity errors
 * 5. RPC provider errors
 * 6. Transaction size limit errors
 *
 * When errors don't match known patterns, the parser uses operation context
 * (e.g., 'simulation', 'estimateGas') to categorize them appropriately.
 * Unrecognized errors without context are categorized as UNKNOWN_BLOCKCHAIN_ERROR.
 *
 * @param error - The raw error from the blockchain library
 * @param context - Context information including chain and optional token
 * @returns A structured KitError instance
 *
 * @example
 * ```typescript
 * import { parseBlockchainError } from '@core/errors'
 *
 * try {
 *   await walletClient.sendTransaction(...)
 * } catch (error) {
 *   throw parseBlockchainError(error, {
 *     chain: 'Ethereum',
 *     token: 'USDC',
 *     operation: 'transfer'
 *   })
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Minimal usage
 * try {
 *   await connection.sendTransaction(...)
 * } catch (error) {
 *   throw parseBlockchainError(error, { chain: 'Solana' })
 * }
 * ```
 *
 * @example
 * ```typescript
 * // With transaction hash and explorer URL
 * import { buildExplorerUrl } from '@core/utils'
 * import { Ethereum } from '@core/chains'
 *
 * try {
 *   const txHash = await walletClient.sendTransaction(...)
 *   await waitForTransaction(txHash)
 * } catch (error) {
 *   const explorerUrl = buildExplorerUrl(Ethereum, txHash)
 *   throw parseBlockchainError(error, {
 *     chain: 'Ethereum',
 *     txHash,
 *     explorerUrl
 *   })
 * }
 * ```
 */ function parseBlockchainError(error, context) {
    const msg = extractMessage(error);
    const token = context.token ?? 'token';
    // Pattern 0: Insufficient native gas token errors
    // Must run BEFORE the generic balance pattern because RPC messages like
    // "insufficient funds for gas * price + value" and "insufficient funds
    // for intrinsic transaction cost" contain "insufficient funds" which
    // would otherwise match the token balance pattern below.
    if (/insufficient funds for (gas|intrinsic transaction cost)|sender doesn't have enough funds to send tx/i.test(msg)) {
        return createInsufficientGasError(context.chain, undefined, {
            rawError: error
        });
    }
    // Pattern 1: Insufficient token balance errors
    // Matches balance-related errors from ERC20 contracts, native transfers, and Solana programs
    if (/transfer amount exceeds balance|insufficient (balance|funds)|burn amount exceeded/i.test(msg)) {
        return createInsufficientTokenBalanceError(context.chain, token, {
            rawError: error
        });
    }
    // Pattern 1b: Gateway-specific contract reverts
    // Matched before the generic simulation/revert pattern so the error
    // messages are actionable rather than opaque hex selectors.
    const gatewayError = parseGatewayContractError(msg, context, error);
    if (gatewayError !== null) {
        return gatewayError;
    }
    // Pattern 2: Simulation and execution reverts
    // Matches contract revert errors and simulation failures
    if (/execution reverted|simulation failed|transaction reverted|transaction failed/i.test(msg)) {
        return parseRevertError(msg, error, context);
    }
    // Pattern 3: Gas-related errors
    // Matches gas estimation failures and gas exhaustion
    // Check specific patterns first, then generic "gas" patterns
    // Gas estimation failures are RPC issues
    if (/gas estimation failed|cannot estimate gas/i.test(msg)) {
        return createRpcEndpointError(context.chain, {
            rawError: error
        });
    }
    // Gas exhaustion errors
    // Use specific patterns without wildcards to avoid ReDoS
    if (/out of gas|gas limit exceeded|exceeds block gas limit/i.test(msg)) {
        const { txHash, explorerUrl } = normalizeTransactionDetails(context.txHash, context.explorerUrl);
        return createOutOfGasError(context.chain, {
            rawError: error
        }, txHash, explorerUrl);
    }
    // Pattern 4: Network connectivity errors
    // Matches connection failures, DNS errors, and timeouts
    if (/connection (refused|failed)|network|timeout|ENOTFOUND|ECONNREFUSED/i.test(msg)) {
        return createNetworkConnectionError(context.chain, {
            rawError: error
        });
    }
    // Pattern 5: RPC provider errors
    // Matches RPC endpoint errors, invalid responses, rate limits, and
    // transient JSON-RPC internal errors (e.g. ethers.js "could not coalesce error").
    // Note: "internal error" alone is too broad — contracts like USDT emit
    // "An internal error was received" for on-chain assertion failures.
    // We require JSON-RPC context (codes -32603/-32000) instead.
    if (/rpc|invalid response|rate limit|too many requests|could not coalesce|no response|server error|json-rpc\s+internal|internal json-rpc|-32603|-32000/i.test(msg)) {
        return createRpcEndpointError(context.chain, {
            rawError: error
        });
    }
    // Pattern 6: Transaction size limit errors
    // Matches transaction size errors from various blockchains:
    // - Solana: "transaction too large: max: encoded/raw 1644/1232"
    // - Generic: "transaction exceeds size limit", "max transaction size"
    // Split into two checks to reduce regex complexity for SonarQube
    const isSizeError = /transaction (?:too large|exceeds size limit|size exceeds)|encoded\/raw\s+\d+\/\d+|max transaction size/i.test(msg) || /(?:tx|transaction) size is too big:\s*\d+,\s*max:\s*\d+/i.test(msg);
    if (isSizeError) {
        return createTransactionTooLargeError(context.chain, error);
    }
    // Fallback based on operation context
    // Gas-related operations are RPC calls
    if (context.operation === 'estimateGas' || context.operation === 'getGasPrice') {
        return createRpcEndpointError(context.chain, {
            rawError: error
        });
    }
    // Simulation operations that don't match standard patterns should still be
    // categorized as simulation failures. This handles cases where blockchain
    // libraries throw generic errors (e.g., "fail", "error") during staticCall
    // operations without descriptive messages. The operation context is authoritative
    // about what was being attempted, even when error messages are unclear.
    //
    // Example: ethers.js staticCall rejection with message "fail"
    //   - Message doesn't match /execution reverted|simulation failed/
    //   - But context.operation === 'simulation' tells us it was a simulation
    //   - Result: SIMULATION_FAILED (accurate) vs UNKNOWN_BLOCKCHAIN_ERROR (misleading)
    if (context.operation === 'simulation') {
        return createSimulationFailedError(context.chain, msg.length > 0 ? msg : 'Simulation failed', {
            rawError: error
        });
    }
    // Final fallback for truly unrecognized errors
    // Only errors that don't match any pattern AND lack operation context
    // are categorized as unknown.
    return createUnknownBlockchainError(context.chain, msg.length > 0 ? msg : 'Unknown error', {
        rawError: error
    });
}
/**
 * Type guard to check if error has Solana-Kit structure with logs.
 *
 * Checks if the error object contains a context with logs array,
 * which is the structure used by Solana Kit errors.
 *
 * @param error - Unknown error to check
 * @returns True if error has Solana-Kit logs structure
 */ function hasSolanaLogs(error) {
    return error !== null && typeof error === 'object' && 'context' in error && error.context !== null && typeof error.context === 'object' && 'logs' in error.context && Array.isArray(error.context.logs);
}
/**
 * Extracts a human-readable error message from various error types.
 *
 * Handles Error objects, string errors, objects with message properties,
 * Solana-Kit errors with context logs, and falls back to string representation.
 * For Solana-Kit errors, extracts Anchor error messages from transaction logs.
 *
 * @param error - Unknown error to extract message from
 * @returns Extracted error message string
 *
 * @example
 * ```typescript
 * const msg1 = extractMessage(new Error('test'))  // 'test'
 * const msg2 = extractMessage('string error')     // 'string error'
 * const msg3 = extractMessage({ message: 'obj' }) // 'obj'
 * ```
 */ function extractMessage(error) {
    // Check for Solana-Kit errors with context.logs
    if (hasSolanaLogs(error)) {
        // Extract Anchor error message from logs
        const anchorLog = error.context.logs.find((log)=>log.includes('AnchorError') || log.includes('Error Message'));
        if (anchorLog !== undefined) {
            // Return the anchor error log which contains the detailed message
            return anchorLog;
        }
    }
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message);
    }
    return String(error);
}
/**
 * Mapping of custom error selectors to human-readable error names.
 *
 * These selectors correspond to custom errors from the contracts.
 * When a transaction reverts with a custom error, the 4-byte selector
 * (first 4 bytes of keccak256 of the error signature) is included in the error message.
 *
 */ const CUSTOM_ERROR_SELECTORS = {
    '0xd93c0665': 'This contract is currently paused',
    '0x3ee5aeb5': 'Security check failed due to a reentrancy attempt',
    '0x8baa579f': 'The provided signature is invalid or could not be verified',
    '0x1ab7da6b': 'This request has expired',
    '0x64eee62e': 'No instructions provided',
    '0x3c46992e': 'Too many execution steps were provided',
    '0xe066e60e': 'Exceeds maximum token inputs limit',
    '0x5566df5c': 'The beneficiary address is invalid',
    '0xf41d7bc6': 'Execution ID already used',
    '0x948726e2': 'The account balance does not meet the required minimum',
    '0x01aa0452': 'The permit type provided is not supported',
    '0x13be252b': 'Token approval failed and the allowance is insufficient',
    '0x5274afe7': 'Token transfer or approval failed',
    '0x00bc1dcb': 'One of the execution targets is invalid',
    '0x5d693841': 'Cannot approve a zero address or a native token',
    '0x3ec5cfe1': 'Cannot validate output for a zero address token',
    '0x492fd70e': 'Instruction call failed without revert data',
    '0xba235e1a': 'The received token amount is lower than the minimum required',
    '0x9147d463': 'Final balance is less than the initial balance',
    '0xf4b3b1bc': 'Native token transfer to the beneficiary failed'
};
/**
 * Attempts to extract an error selector from an error object or message.
 *
 * Checks multiple sources in priority order:
 * 1. `error.data` field
 * 2. Message pattern: "custom error 0x8baa579f"
 *
 * @param msg - The error message
 * @param error - The error object (optional)
 * @returns The 4 bytes selector , or undefined if not found
 */ function extractErrorSelector(msg, error) {
    // Check error.data field
    if (error !== null && typeof error === 'object' && 'data' in error) {
        if (typeof error.data === 'string' && /^0x[0-9a-f]{8}$/i.test(error.data)) {
            return error.data.toLowerCase();
        }
    }
    // Check for "custom error 0x8baa579f" in the message
    const match = /custom error (0x[0-9a-f]{8})\b/i.exec(msg);
    const selector = match?.[1];
    if (selector !== undefined && selector.length > 0) {
        return selector.toLowerCase();
    }
    return undefined;
}
/**
 * Extracts the revert reason from an error message and error object.
 *
 * Attempts to parse out the meaningful reason from execution revert errors,
 * removing common prefixes like "execution reverted:" or "reverted:".
 * If the error contains a custom error selector, it will be resolved to its
 * human-readable description with the selector included for developer reference.
 *
 * Supports multiple error formats:
 * - Custom error with selector in `error.data` field (e.g., `{ data: "0x8baa579f", ... }`)
 * - Message with selector pattern: `"Execution reverted with reason: custom error 0x8baa579f"`
 * - Standard revert: `"execution reverted: Insufficient funds"`
 *
 * @param msg - The error message to extract from
 * @param error - The full error object (optional, used to extract selector from `data` field)
 * @returns The extracted revert reason, or null if not found
 *
 * @example
 * ```typescript
 * const reason = extractRevertReason(
 *   'execution reverted: ERC20: transfer amount exceeds balance'
 * )
 * // Returns: 'ERC20: transfer amount exceeds balance'
 * ```
 *
 * @example
 * ```typescript
 * const reason = extractRevertReason(
 *   'Simulation failed: Execution reverted with reason: Insufficient allowance'
 * )
 * // Returns: 'Insufficient allowance'
 * ```
 *
 * @example
 * ```typescript
 * // Custom error with selector in message
 * const reason = extractRevertReason(
 *   'Execution reverted with reason: custom error 0x8baa579f'
 * )
 * // Returns: 'The provided signature is invalid or could not be verified (0x8baa579f)'
 * ```
 *
 * @example
 * ```typescript
 * // Error with data field
 * const reason = extractRevertReason(
 *   'execution reverted (unknown custom error)',
 *   { data: '0x8baa579f' }
 * )
 * // Returns: 'The provided signature is invalid or could not be verified (0x8baa579f)'
 * ```
 *
 * @example
 * ```typescript
 * // Unrecognized selector preserved for debugging
 * const reason = extractRevertReason(
 *   'execution reverted (unknown custom error)',
 *   { data: '0xdeadbeef' }
 * )
 * // Returns: 'Transaction reverted with error (0xdeadbeef)'
 * ```
 */ function extractRevertReason(msg, error) {
    // Try to extract and decode custom error selector
    const selector = extractErrorSelector(msg, error);
    if (selector !== undefined) {
        const errorMessage = CUSTOM_ERROR_SELECTORS[selector];
        if (errorMessage !== undefined) {
            return `${errorMessage} (${selector})`;
        }
    }
    // Try to extract reason after "execution reverted:" or "reason:"
    // Use [^\n.]+ instead of .+? to avoid ReDoS vulnerability
    // Fall back to standard revert reason extraction
    const patterns = [
        /(?:execution reverted|reverted):\s*([^\n.]+)/i,
        /reason:\s*([^\n.]+)/i,
        /with reason:\s*([^\n.]+)/i
    ];
    for (const pattern of patterns){
        const match = pattern.exec(msg);
        const extractedReason = match?.at(1);
        if (extractedReason !== undefined && extractedReason.length > 0) {
            return extractedReason.trim();
        }
    }
    // Preserve unrecognized selector so it appears in error output for debugging
    if (selector !== undefined) {
        return `Transaction reverted with error (${selector})`;
    }
    return null;
}
/**
 * Parses Gateway smart-contract revert selectors into specific KitError types.
 *
 * Returns `null` when the message does not match any known Gateway revert,
 * allowing the caller to fall through to generic patterns.
 *
 * @param msg - The extracted error message string.
 * @param context - Parse error context (chain, token, operation).
 * @param error - The original raw error for the trace payload.
 * @returns A KitError if a Gateway pattern matched, otherwise `null`.
 *
 * @internal Called by {@link parseBlockchainError} — not re-exported from
 *   the `@core/errors` barrel.
 *
 * @example
 * ```typescript
 * // Internal usage within parseBlockchainError:
 * import { parseGatewayContractError } from './parseBlockchainError'
 *
 * const gatewayError = parseGatewayContractError(
 *   'execution reverted: WithdrawalValueExceedsAvailableBalance',
 *   { chain: 'Ethereum', token: 'USDC', operation: 'withdraw' },
 *   new Error('execution reverted'),
 * )
 * if (gatewayError !== null) {
 *   // KitError with INSUFFICIENT_TOKEN balance details
 *   console.log(gatewayError.message)
 * }
 *
 * // Returns null for unrecognised reverts (caller falls through to generic parsing)
 * const unknown = parseGatewayContractError(
 *   'execution reverted: SomeUnknownError()',
 *   { chain: 'Base', token: 'USDC', operation: 'deposit' },
 *   new Error('execution reverted'),
 * )
 * console.log(unknown) // null
 * ```
 */ function parseGatewayContractError(msg, context, error) {
    const token = context.token ?? 'token';
    if (/WithdrawalValueExceedsAvailableBalance|InsufficientDepositBalance/i.test(msg)) {
        return createInsufficientTokenBalanceError(context.chain, token, {
            rawError: error
        });
    }
    if (/WithdrawalNotYetAvailable|WithdrawalDelayNotElapsed/i.test(msg)) {
        return createTransactionRevertedError(context.chain, 'Withdrawal is not yet available — the withdrawal delay has not elapsed', {
            rawError: error
        });
    }
    if (/NoWithdrawingBalance/i.test(msg)) {
        return createTransactionRevertedError(context.chain, 'No pending withdrawal balance — call initiateWithdrawal() first', {
            rawError: error
        });
    }
    return null;
}

/**
 * Safely extracts error message from any error type.
 *
 * This utility handles different error types gracefully, extracting
 * meaningful messages from Error instances, string errors, or providing
 * a fallback for unknown error types. Never throws.
 *
 * @param error - Unknown error to extract message from
 * @returns Error message string, or fallback message
 *
 * @example
 * ```typescript
 * import { getErrorMessage } from '@core/errors'
 *
 * try {
 *   await riskyOperation()
 * } catch (error) {
 *   const message = getErrorMessage(error)
 *   console.log('Error occurred:', message)
 *   // Works with Error, KitError, string, or any other type
 * }
 * ```
 */ function getErrorMessage(error) {
    if (error instanceof Error) {
        return error.message;
    }
    if (typeof error === 'string') {
        return error;
    }
    if (typeof error === 'object' && error !== null && 'message' in error) {
        return String(error.message);
    }
    return 'An unknown error occurred';
}

/**
 * @packageDocumentation
 * @module ChainDefinitions
 *
 * This module provides a complete type system for blockchain chain definitions.
 * It supports both EVM and non‑EVM chains, token configurations, and multiple
 * versions of the Cross-Chain Transfer Protocol (CCTP). Additionally, utility types
 * are provided to extract subsets of chains (e.g. chains supporting USDC, EURC, or specific
 * CCTP versions) from a provided collection.
 *
 * All types are fully documented with TSDoc to maximize developer experience.
 */ // -----------------------------------------------------------------------------
// Currency and Base Types
// -----------------------------------------------------------------------------
/**
 * Represents basic information about a currency or token.
 * @category Types
 * @description Provides the essential properties of a cryptocurrency or token.
 * @example
 * ```typescript
 * const ethCurrency: Currency = {
 *   name: "Ether",
 *   symbol: "ETH",
 *   decimals: 18
 * };
 * ```
 */ exports.Blockchain = void 0;
(function(Blockchain) {
    Blockchain["Algorand"] = "Algorand";
    Blockchain["Algorand_Testnet"] = "Algorand_Testnet";
    Blockchain["Aptos"] = "Aptos";
    Blockchain["Aptos_Testnet"] = "Aptos_Testnet";
    Blockchain["Arc_Testnet"] = "Arc_Testnet";
    Blockchain["Arbitrum"] = "Arbitrum";
    Blockchain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    Blockchain["Avalanche"] = "Avalanche";
    Blockchain["Avalanche_Fuji"] = "Avalanche_Fuji";
    Blockchain["Base"] = "Base";
    Blockchain["Base_Sepolia"] = "Base_Sepolia";
    Blockchain["Celo"] = "Celo";
    Blockchain["Celo_Alfajores_Testnet"] = "Celo_Alfajores_Testnet";
    Blockchain["Codex"] = "Codex";
    Blockchain["Codex_Testnet"] = "Codex_Testnet";
    Blockchain["Cronos"] = "Cronos";
    Blockchain["Cronos_Testnet"] = "Cronos_Testnet";
    Blockchain["Edge"] = "Edge";
    Blockchain["Edge_Testnet"] = "Edge_Testnet";
    Blockchain["Ethereum"] = "Ethereum";
    Blockchain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    Blockchain["Hedera"] = "Hedera";
    Blockchain["Hedera_Testnet"] = "Hedera_Testnet";
    Blockchain["HyperEVM"] = "HyperEVM";
    Blockchain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    Blockchain["Injective"] = "Injective";
    Blockchain["Injective_Testnet"] = "Injective_Testnet";
    Blockchain["Ink"] = "Ink";
    Blockchain["Ink_Testnet"] = "Ink_Testnet";
    Blockchain["Linea"] = "Linea";
    Blockchain["Linea_Sepolia"] = "Linea_Sepolia";
    Blockchain["Monad"] = "Monad";
    Blockchain["Monad_Testnet"] = "Monad_Testnet";
    Blockchain["Morph"] = "Morph";
    Blockchain["Morph_Testnet"] = "Morph_Testnet";
    Blockchain["NEAR"] = "NEAR";
    Blockchain["NEAR_Testnet"] = "NEAR_Testnet";
    Blockchain["Noble"] = "Noble";
    Blockchain["Noble_Testnet"] = "Noble_Testnet";
    Blockchain["Optimism"] = "Optimism";
    Blockchain["Optimism_Sepolia"] = "Optimism_Sepolia";
    Blockchain["Pharos"] = "Pharos";
    Blockchain["Pharos_Testnet"] = "Pharos_Testnet";
    Blockchain["Plasma"] = "Plasma";
    Blockchain["Plasma_Testnet"] = "Plasma_Testnet";
    Blockchain["Polkadot_Asset_Hub"] = "Polkadot_Asset_Hub";
    Blockchain["Polkadot_Westmint"] = "Polkadot_Westmint";
    Blockchain["Plume"] = "Plume";
    Blockchain["Plume_Testnet"] = "Plume_Testnet";
    Blockchain["Polygon"] = "Polygon";
    Blockchain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    Blockchain["Sei"] = "Sei";
    Blockchain["Sei_Testnet"] = "Sei_Testnet";
    Blockchain["Solana"] = "Solana";
    Blockchain["Solana_Devnet"] = "Solana_Devnet";
    Blockchain["Sonic"] = "Sonic";
    Blockchain["Sonic_Testnet"] = "Sonic_Testnet";
    Blockchain["Stellar"] = "Stellar";
    Blockchain["Stellar_Testnet"] = "Stellar_Testnet";
    Blockchain["Sui"] = "Sui";
    Blockchain["Sui_Testnet"] = "Sui_Testnet";
    Blockchain["Unichain"] = "Unichain";
    Blockchain["Unichain_Sepolia"] = "Unichain_Sepolia";
    Blockchain["World_Chain"] = "World_Chain";
    Blockchain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
    Blockchain["XDC"] = "XDC";
    Blockchain["XDC_Apothem"] = "XDC_Apothem";
    Blockchain["X_Layer"] = "X_Layer";
    Blockchain["X_Layer_Testnet"] = "X_Layer_Testnet";
    Blockchain["ZKSync_Era"] = "ZKSync_Era";
    Blockchain["ZKSync_Sepolia"] = "ZKSync_Sepolia";
})(exports.Blockchain || (exports.Blockchain = {}));
var SwapChain;
(function(SwapChain) {
    // Original 4 chains
    SwapChain["Ethereum"] = "Ethereum";
    SwapChain["Base"] = "Base";
    SwapChain["Polygon"] = "Polygon";
    SwapChain["Solana"] = "Solana";
    // Additional supported chains
    SwapChain["Arbitrum"] = "Arbitrum";
    SwapChain["Optimism"] = "Optimism";
    SwapChain["Avalanche"] = "Avalanche";
    SwapChain["Linea"] = "Linea";
    SwapChain["Ink"] = "Ink";
    SwapChain["World_Chain"] = "World_Chain";
    SwapChain["Unichain"] = "Unichain";
    SwapChain["Plume"] = "Plume";
    SwapChain["Sei"] = "Sei";
    SwapChain["Sonic"] = "Sonic";
    SwapChain["XDC"] = "XDC";
    SwapChain["HyperEVM"] = "HyperEVM";
    SwapChain["Monad"] = "Monad";
    // Testnet chains with swap support
    SwapChain["Arc_Testnet"] = "Arc_Testnet";
})(SwapChain || (SwapChain = {}));
var BridgeChain;
(function(BridgeChain) {
    // Mainnet chains with CCTPv2 support
    BridgeChain["Arbitrum"] = "Arbitrum";
    BridgeChain["Avalanche"] = "Avalanche";
    BridgeChain["Base"] = "Base";
    BridgeChain["Codex"] = "Codex";
    BridgeChain["Cronos"] = "Cronos";
    BridgeChain["Edge"] = "Edge";
    BridgeChain["Ethereum"] = "Ethereum";
    BridgeChain["HyperEVM"] = "HyperEVM";
    BridgeChain["Injective"] = "Injective";
    BridgeChain["Ink"] = "Ink";
    BridgeChain["Linea"] = "Linea";
    BridgeChain["Monad"] = "Monad";
    BridgeChain["Morph"] = "Morph";
    BridgeChain["Optimism"] = "Optimism";
    BridgeChain["Pharos"] = "Pharos";
    BridgeChain["Plasma"] = "Plasma";
    BridgeChain["Plume"] = "Plume";
    BridgeChain["Polygon"] = "Polygon";
    BridgeChain["Sei"] = "Sei";
    BridgeChain["Solana"] = "Solana";
    BridgeChain["Sonic"] = "Sonic";
    BridgeChain["Unichain"] = "Unichain";
    BridgeChain["World_Chain"] = "World_Chain";
    BridgeChain["XDC"] = "XDC";
    BridgeChain["X_Layer"] = "X_Layer";
    // Testnet chains with CCTPv2 support
    BridgeChain["Arc_Testnet"] = "Arc_Testnet";
    BridgeChain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    BridgeChain["Avalanche_Fuji"] = "Avalanche_Fuji";
    BridgeChain["Base_Sepolia"] = "Base_Sepolia";
    BridgeChain["Codex_Testnet"] = "Codex_Testnet";
    BridgeChain["Cronos_Testnet"] = "Cronos_Testnet";
    BridgeChain["Edge_Testnet"] = "Edge_Testnet";
    BridgeChain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    BridgeChain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    BridgeChain["Injective_Testnet"] = "Injective_Testnet";
    BridgeChain["Ink_Testnet"] = "Ink_Testnet";
    BridgeChain["Linea_Sepolia"] = "Linea_Sepolia";
    BridgeChain["Monad_Testnet"] = "Monad_Testnet";
    BridgeChain["Morph_Testnet"] = "Morph_Testnet";
    BridgeChain["Optimism_Sepolia"] = "Optimism_Sepolia";
    BridgeChain["Pharos_Testnet"] = "Pharos_Testnet";
    BridgeChain["Plasma_Testnet"] = "Plasma_Testnet";
    BridgeChain["Plume_Testnet"] = "Plume_Testnet";
    BridgeChain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    BridgeChain["Sei_Testnet"] = "Sei_Testnet";
    BridgeChain["Solana_Devnet"] = "Solana_Devnet";
    BridgeChain["Sonic_Testnet"] = "Sonic_Testnet";
    BridgeChain["Unichain_Sepolia"] = "Unichain_Sepolia";
    BridgeChain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
    BridgeChain["XDC_Apothem"] = "XDC_Apothem";
    BridgeChain["X_Layer_Testnet"] = "X_Layer_Testnet";
})(BridgeChain || (BridgeChain = {}));
var UnifiedBalanceChain;
(function(UnifiedBalanceChain) {
    // Mainnet chains with Gateway V1 support
    UnifiedBalanceChain["Arbitrum"] = "Arbitrum";
    UnifiedBalanceChain["Avalanche"] = "Avalanche";
    UnifiedBalanceChain["Base"] = "Base";
    UnifiedBalanceChain["Ethereum"] = "Ethereum";
    UnifiedBalanceChain["HyperEVM"] = "HyperEVM";
    UnifiedBalanceChain["Optimism"] = "Optimism";
    UnifiedBalanceChain["Polygon"] = "Polygon";
    UnifiedBalanceChain["Sei"] = "Sei";
    UnifiedBalanceChain["Solana"] = "Solana";
    UnifiedBalanceChain["Sonic"] = "Sonic";
    UnifiedBalanceChain["Unichain"] = "Unichain";
    UnifiedBalanceChain["World_Chain"] = "World_Chain";
    // Testnet chains with Gateway V1 support
    UnifiedBalanceChain["Arbitrum_Sepolia"] = "Arbitrum_Sepolia";
    UnifiedBalanceChain["Arc_Testnet"] = "Arc_Testnet";
    UnifiedBalanceChain["Avalanche_Fuji"] = "Avalanche_Fuji";
    UnifiedBalanceChain["Base_Sepolia"] = "Base_Sepolia";
    UnifiedBalanceChain["Ethereum_Sepolia"] = "Ethereum_Sepolia";
    UnifiedBalanceChain["HyperEVM_Testnet"] = "HyperEVM_Testnet";
    UnifiedBalanceChain["Optimism_Sepolia"] = "Optimism_Sepolia";
    UnifiedBalanceChain["Polygon_Amoy_Testnet"] = "Polygon_Amoy_Testnet";
    UnifiedBalanceChain["Sei_Testnet"] = "Sei_Testnet";
    UnifiedBalanceChain["Solana_Devnet"] = "Solana_Devnet";
    UnifiedBalanceChain["Sonic_Testnet"] = "Sonic_Testnet";
    UnifiedBalanceChain["Unichain_Sepolia"] = "Unichain_Sepolia";
    UnifiedBalanceChain["World_Chain_Sepolia"] = "World_Chain_Sepolia";
})(UnifiedBalanceChain || (UnifiedBalanceChain = {}));
var EarnChain;
(function(EarnChain) {
    EarnChain["Arc_Testnet"] = "Arc_Testnet";
})(EarnChain || (EarnChain = {}));
/**
 * Blockchains supported as the source chain for cross-chain Earn deposits.
 *
 * Single source of truth for the source allowlist: the Earn Service bridge
 * route map is `satisfies`-checked against {@link EarnBridgeSourceBlockchain},
 * and both the type and the runtime validation schema derive from this array.
 *
 * @example
 * ```typescript
 * import { EARN_BRIDGE_SOURCE_BLOCKCHAINS } from '@core/chains'
 *
 * console.log(EARN_BRIDGE_SOURCE_BLOCKCHAINS.join(', '))
 * ```
 */ const EARN_BRIDGE_SOURCE_BLOCKCHAINS = [
    "Arbitrum_Sepolia",
    "Base_Sepolia",
    "Ethereum_Sepolia"
];
/**
 * Blockchains supported as the destination (vault) chain for cross-chain Earn
 * deposits. Single source of truth for the destination allowlist.
 *
 * @example
 * ```typescript
 * import { EARN_BRIDGE_DESTINATION_BLOCKCHAINS } from '@core/chains'
 *
 * console.log(EARN_BRIDGE_DESTINATION_BLOCKCHAINS.join(', '))
 * ```
 */ const EARN_BRIDGE_DESTINATION_BLOCKCHAINS = [
    "Arc_Testnet"
];

/**
 * Helper function to define a chain with proper TypeScript typing.
 *
 * This utility function works with TypeScript's `as const` assertion to create
 * strongly-typed, immutable chain definition objects. It preserves literal types
 * from the input and ensures the resulting object maintains all type information.
 *
 * When used with `as const`, it allows TypeScript to infer the most specific
 * possible types for all properties, including string literals and numeric literals,
 * rather than widening them to general types like string or number.
 * @typeParam T - The specific chain definition type (must extend ChainDefinition)
 * @param chain - The chain definition object, typically with an `as const` assertion
 * @returns The same chain definition with preserved literal types
 * @example
 * ```typescript
 * // Define an EVM chain with literal types preserved
 * const Ethereum = defineChain({
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   name: 'Ethereum',
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   usdcAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   eurcAddress: null,
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       TokenMessengerV1: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
 *       MessageTransmitterV1: '0x0a992d191deec32afe36203ad87d7d289a738f81'
 *     }
 *   }
 * } as const);
 * ```
 */ function defineChain(chain) {
    return chain;
}

/**
 * Algorand Mainnet chain definition
 * @remarks
 * This represents the official production network for the Algorand blockchain.
 */ const Algorand = defineChain({
    type: 'algorand',
    chain: exports.Blockchain.Algorand,
    name: 'Algorand',
    title: 'Algorand Mainnet',
    nativeCurrency: {
        name: 'Algo',
        symbol: 'ALGO',
        decimals: 6
    },
    isTestnet: false,
    explorerUrl: 'https://explorer.perawallet.app/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet-api.algonode.cloud'
    ],
    eurcAddress: null,
    usdcAddress: '31566704',
    usdtAddress: null,
    cctp: null
});

/**
 * Algorand Testnet chain definition
 * @remarks
 * This represents the official testnet for the Algorand blockchain.
 */ const AlgorandTestnet = defineChain({
    type: 'algorand',
    chain: exports.Blockchain.Algorand_Testnet,
    name: 'Algorand Testnet',
    title: 'Algorand Test Network',
    nativeCurrency: {
        name: 'Algo',
        symbol: 'ALGO',
        decimals: 6
    },
    isTestnet: true,
    explorerUrl: 'https://testnet.explorer.perawallet.app/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-api.algonode.cloud'
    ],
    eurcAddress: null,
    usdcAddress: '10458941',
    usdtAddress: null,
    cctp: null
});

/**
 * Aptos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Aptos blockchain.
 */ const Aptos = defineChain({
    type: 'aptos',
    chain: exports.Blockchain.Aptos,
    name: 'Aptos',
    title: 'Aptos Mainnet',
    nativeCurrency: {
        name: 'Aptos',
        symbol: 'APT',
        decimals: 8
    },
    isTestnet: false,
    explorerUrl: 'https://explorer.aptoslabs.com/txn/{hash}?network=mainnet',
    rpcEndpoints: [
        'https://fullnode.mainnet.aptoslabs.com/v1'
    ],
    eurcAddress: null,
    usdcAddress: '0xbae207659db88bea0cbead6da0ed00aac12edcdda169e591cd41c94180b46f3b',
    usdtAddress: '0x357b0b74bc833e95a115ad22604854d6b0fca151cecd94111770e5d6ffc9dc2b',
    cctp: {
        domain: 9,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9bce6734f7b63e835108e3bd8c36743d4709fe435f44791918801d0989640a9d',
                messageTransmitter: '0x177e17751820e4b4371873ca8c30279be63bdea63b88ed0f2239c2eea10f1772',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Aptos Testnet chain definition
 * @remarks
 * This represents the official test network for the Aptos blockchain.
 */ const AptosTestnet = defineChain({
    type: 'aptos',
    chain: exports.Blockchain.Aptos_Testnet,
    name: 'Aptos Testnet',
    title: 'Aptos Test Network',
    nativeCurrency: {
        name: 'Aptos',
        symbol: 'APT',
        decimals: 8
    },
    isTestnet: true,
    explorerUrl: 'https://explorer.aptoslabs.com/txn/{hash}?network=testnet',
    rpcEndpoints: [
        'https://fullnode.testnet.aptoslabs.com/v1'
    ],
    eurcAddress: null,
    usdcAddress: '0x69091fbab5f7d635ee7ac5098cf0c1efbe31d68fec0f2cd565e8d168daf52832',
    usdtAddress: null,
    cctp: {
        domain: 9,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x5f9b937419dda90aa06c1836b7847f65bbbe3f1217567758dc2488be31a477b9',
                messageTransmitter: '0x081e86cebf457a0c6004f35bd648a2794698f52e0dde09a48619dcd3d4cc23d9',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * @packageDocumentation
 * @module SwapTokenRegistry
 *
 * Central swap token registry for swap-supported tokens.
 *
 * Contains metadata for all tokens that can be used in swap operations,
 * including decimals, categories, and descriptions. All packages should import
 * from this registry instead of maintaining separate token lists.
 */ /**
 * Swap token metadata.
 */ /**
 * Complete swap token registry - single source of truth for all swap-supported tokens.
 *
 * @remarks
 * All packages should import from this registry for swap operations.
 * Adding a new swap token requires updating only this registry.
 *
 * The NATIVE token is handled separately as it resolves dynamically based on chain.
 *
 * @example
 * ```typescript
 * import { SWAP_TOKEN_REGISTRY } from '@core/chains'
 *
 * // Get token decimals
 * const decimals = SWAP_TOKEN_REGISTRY.USDC.decimals  // 6
 *
 * // Check if token is stablecoin
 * const isStable = SWAP_TOKEN_REGISTRY.DAI.category === 'stablecoin'  // true
 * ```
 */ const SWAP_TOKEN_REGISTRY = {
    // ============================================================================
    // Stablecoins (6 decimals)
    // ============================================================================
    USDC: {
        symbol: 'USDC',
        decimals: 6,
        category: 'stablecoin',
        description: 'USD Coin'
    },
    EURC: {
        symbol: 'EURC',
        decimals: 6,
        category: 'stablecoin',
        description: 'Euro Coin'
    },
    USDT: {
        symbol: 'USDT',
        decimals: 6,
        category: 'stablecoin',
        description: 'Tether USD'
    },
    PYUSD: {
        symbol: 'PYUSD',
        decimals: 6,
        category: 'stablecoin',
        description: 'PayPal USD'
    },
    // ============================================================================
    // Stablecoins (18 decimals)
    // ============================================================================
    DAI: {
        symbol: 'DAI',
        decimals: 18,
        category: 'stablecoin',
        description: 'MakerDAO stablecoin'
    },
    USDE: {
        symbol: 'USDE',
        decimals: 18,
        category: 'stablecoin',
        description: 'Ethena USD (synthetic dollar)'
    },
    // ============================================================================
    // Wrapped Tokens
    // ============================================================================
    WBTC: {
        symbol: 'WBTC',
        decimals: 8,
        category: 'wrapped',
        description: 'Wrapped Bitcoin'
    },
    WETH: {
        symbol: 'WETH',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Ethereum'
    },
    WSOL: {
        symbol: 'WSOL',
        decimals: 9,
        category: 'wrapped',
        description: 'Wrapped Solana'
    },
    WAVAX: {
        symbol: 'WAVAX',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Avalanche'
    },
    WPOL: {
        symbol: 'WPOL',
        decimals: 18,
        category: 'wrapped',
        description: 'Wrapped Polygon'
    },
    CIRBTC: {
        symbol: 'CIRBTC',
        decimals: 8,
        category: 'wrapped',
        description: 'Circle Bitcoin'
    }
};
/**
 * Special NATIVE token constant for swap operations.
 *
 * @remarks
 * NATIVE is handled separately from SWAP_TOKEN_REGISTRY because it resolves
 * dynamically based on the chain (ETH on Ethereum, SOL on Solana, etc.).
 * Its decimals are chain-specific.
 */ const NATIVE_TOKEN = 'NATIVE';
/**
 * Array of all supported swap token symbols including NATIVE.
 * Useful for iteration, validation, and filtering.
 */ [
    ...Object.keys(SWAP_TOKEN_REGISTRY),
    NATIVE_TOKEN
];

/**
 * The bridge contract address for EVM testnet networks.
 *
 * This contract handles USDC transfers on testnet environments across
 * EVM-compatible chains. Use this address when deploying or testing
 * cross-chain USDC transfers on test networks.
 */ const BRIDGE_CONTRACT_EVM_TESTNET = '0xC5567a5E3370d4DBfB0540025078e283e36A363d';
/**
 * The bridge contract address for EVM mainnet networks.
 *
 * This contract handles USDC transfers on mainnet environments across
 * EVM-compatible chains. Use this address for production cross-chain
 * USDC transfers on live networks.
 */ const BRIDGE_CONTRACT_EVM_MAINNET = '0xB3FA262d0fB521cc93bE83d87b322b8A23DAf3F0';
/**
 * The adapter contract address for EVM mainnet networks.
 *
 * This contract serves as an adapter for integrating with various protocols
 * on EVM-compatible chains. Use this address for mainnet adapter integrations.
 */ const ADAPTER_CONTRACT_EVM_MAINNET = '0x7FB8c7260b63934d8da38aF902f87ae6e284a845';
/**
 * The adapter contract address for EVM testnet networks.
 *
 * This contract serves as an adapter for integrating with various protocols
 * on EVM-compatible testnet chains. Use this address for testnet adapter
 * integrations (e.g., Arc Testnet).
 */ const ADAPTER_CONTRACT_EVM_TESTNET = '0xBBD70b01a1CAbc96d5b7b129Ae1AAabdf50dd40b';
/**
 * The GatewayWallet contract address for EVM mainnet networks.
 *
 * This contract manages wallet operations for Gateway transactions
 * on mainnet environments across EVM-compatible chains.
 */ const GATEWAY_WALLET_EVM_MAINNET = '0x77777777Dcc4d5A8B6E418Fd04D8997ef11000eE';
/**
 * The GatewayMinter contract address for EVM mainnet networks.
 *
 * This contract handles minting operations for Gateway transactions
 * on mainnet environments across EVM-compatible chains.
 */ const GATEWAY_MINTER_EVM_MAINNET = '0x2222222d7164433c4C09B0b0D809a9b52C04C205';
/**
 * The GatewayWallet contract address for EVM testnet networks.
 *
 * This contract manages wallet operations for Gateway transactions
 * on testnet environments across EVM-compatible chains.
 */ const GATEWAY_WALLET_EVM_TESTNET = '0x0077777d7EBA4688BDeF3E311b846F25870A19B9';
/**
 * The GatewayMinter contract address for EVM testnet networks.
 *
 * This contract handles minting operations for Gateway transactions
 * on testnet environments across EVM-compatible chains.
 */ const GATEWAY_MINTER_EVM_TESTNET = '0x0022222ABE238Cc2C7Bb1f21003F0a260052475B';
/**
 * The GatewayWallet program address for Solana mainnet.
 *
 * This program manages wallet operations for Gateway transactions
 * on Solana mainnet.
 */ const GATEWAY_WALLET_SOLANA_MAINNET = 'GATEwy4YxeiEbRJLwB6dXgg7q61e6zBPrMzYj5h1pRXQ';
/**
 * The GatewayMinter program address for Solana mainnet.
 *
 * This program handles minting operations for Gateway transactions
 * on Solana mainnet.
 */ const GATEWAY_MINTER_SOLANA_MAINNET = 'GATEm5SoBJiSw1v2Pz1iPBgUYkXzCUJ27XSXhDfSyzVZ';
/**
 * The GatewayWallet program address for Solana devnet.
 *
 * This program manages wallet operations for Gateway transactions
 * on Solana devnet.
 */ const GATEWAY_WALLET_SOLANA_DEVNET = 'GATEwdfmYNELfp5wDmmR6noSr2vHnAfBPMm2PvCzX5vu';
/**
 * The GatewayMinter program address for Solana devnet.
 *
 * This program handles minting operations for Gateway transactions
 * on Solana devnet.
 */ const GATEWAY_MINTER_SOLANA_DEVNET = 'GATEmKK2ECL1brEngQZWCgMWPbvrEYqsV6u29dAaHavr';
/** TokenMessengerWithFees address shared by enabled EVM mainnet sources. */ const TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET = '0x71f54F818671cD0D7ea140Da213e5C8b5C92a408';
/** TokenMessengerWithFees address shared by enabled EVM testnet sources. */ const TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET = '0x8745D906D67C346E5eb1aEEED38Eb87F34DF0C0A';

/**
 * Arc Testnet chain definition
 * @remarks
 * This represents the test network for the Arc blockchain,
 * Circle's EVM-compatible Layer-1 designed for stablecoin finance
 * and asset tokenization. Arc uses USDC as the native gas token and
 * features the Malachite Byzantine Fault Tolerant (BFT) consensus
 * engine for sub-second finality.
 */ const ArcTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Arc_Testnet,
    name: 'Arc Testnet',
    title: 'ArcTestnet',
    nativeCurrency: {
        name: 'USDC',
        symbol: 'USDC',
        // Arc uses native USDC with 18 decimals for gas payments (EVM standard).
        // Note: The ERC-20 USDC contract at usdcAddress uses 6 decimals.
        // See: https://docs.arc.network/arc/references/contract-addresses
        decimals: 18
    },
    chainId: 5042002,
    isTestnet: true,
    explorerUrl: 'https://testnet.arcscan.app/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.testnet.arc.network/'
    ],
    eurcAddress: '0x89B50855Aa3bE2F677cD6303Cec089B5F319D72a',
    usdcAddress: '0x3600000000000000000000000000000000000000',
    usdtAddress: null,
    cctp: {
        domain: 26,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 26,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET,
                // DepositForHandler the GenericExecutor calls to run a fast cross-chain
                // deposit into the GatewayWallet above.
                depositForHandler: '0xD05E7D2E7d30b92c5F17d7d0fC575fce231F1A48'
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Arbitrum Mainnet chain definition
 * @remarks
 * This represents the official production network for the Arbitrum blockchain.
 */ const Arbitrum = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Arbitrum,
    name: 'Arbitrum',
    title: 'Arbitrum Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 42161,
    isTestnet: false,
    explorerUrl: 'https://arbiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://arb1.arbitrum.io/rpc'
    ],
    eurcAddress: null,
    usdcAddress: '0xaf88d065e77c8cc2239327c5edb3a432268e5831',
    usdtAddress: null,
    cctp: {
        domain: 3,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x19330d10D9Cc8751218eaf51E8885D058642E08A',
                messageTransmitter: '0xC30362313FBBA5cf9163F0bb16a0e01f01A896ca',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 3,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Arbitrum Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Arbitrum blockchain on Sepolia.
 */ const ArbitrumSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Arbitrum_Sepolia,
    name: 'Arbitrum Sepolia',
    title: 'Arbitrum Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 421614,
    isTestnet: true,
    explorerUrl: 'https://sepolia.arbiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia-rollup.arbitrum.io/rpc'
    ],
    eurcAddress: null,
    usdcAddress: '0x75faf114eafb1BDbe2F0316DF893fd58CE46AA4d',
    usdtAddress: null,
    cctp: {
        domain: 3,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0xaCF1ceeF35caAc005e15888dDb8A3515C41B4872',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 3,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Avalanche Mainnet chain definition
 * @remarks
 * This represents the official production network for the Avalanche blockchain.
 */ const Avalanche = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Avalanche,
    name: 'Avalanche',
    title: 'Avalanche Mainnet',
    nativeCurrency: {
        name: 'Avalanche',
        symbol: 'AVAX',
        decimals: 18
    },
    chainId: 43114,
    isTestnet: false,
    explorerUrl: 'https://subnets.avax.network/c-chain/tx/{hash}',
    rpcEndpoints: [
        'https://api.avax.network/ext/bc/C/rpc'
    ],
    eurcAddress: '0xc891eb4cbdeff6e073e859e987815ed1505c2acd',
    usdcAddress: '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E',
    usdtAddress: '0x9702230a8ea53601f5cd2dc00fdbc13d4df4a8c7',
    cctp: {
        domain: 1,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x6b25532e1060ce10cc3b0a99e5683b91bfde6982',
                messageTransmitter: '0x8186359af5f57fbb40c6b14a588d2a59c0c29880',
                confirmations: 1
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 1,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Avalanche Fuji Testnet chain definition
 * @remarks
 * This represents the official test network for the Avalanche blockchain.
 */ const AvalancheFuji = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Avalanche_Fuji,
    name: 'Avalanche Fuji',
    title: 'Avalanche Fuji Testnet',
    nativeCurrency: {
        name: 'Avalanche',
        symbol: 'AVAX',
        decimals: 18
    },
    chainId: 43113,
    isTestnet: true,
    explorerUrl: 'https://subnets-test.avax.network/c-chain/tx/{hash}',
    eurcAddress: '0x5e44db7996c682e92a960b65ac713a54ad815c6b',
    usdcAddress: '0x5425890298aed601595a70ab815c96711a31bc65',
    usdtAddress: null,
    cctp: {
        domain: 1,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0xeb08f243e5d3fcff26a9e38ae5520a669f4019d0',
                messageTransmitter: '0xa9fb1b3009dcb79e2fe346c16a604b8fa8ae0a79',
                confirmations: 1
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    rpcEndpoints: [
        'https://api.avax-test.network/ext/bc/C/rpc'
    ],
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 1,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Base chain definition
 * @remarks
 * This represents the official production network for the Base blockchain.
 */ const Base = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Base,
    name: 'Base',
    title: 'Base Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 8453,
    isTestnet: false,
    explorerUrl: 'https://basescan.org/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.base.org',
        'https://base.publicnode.com'
    ],
    eurcAddress: '0x60a3e35cc302bfa44cb288bc5a4f316fdb1adb42',
    usdcAddress: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913',
    usdtAddress: null,
    cctp: {
        domain: 6,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x1682Ae6375C4E4A97e4B583BC394c861A46D8962',
                messageTransmitter: '0xAD09780d193884d503182aD4588450C416D6F9D4',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 6,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Base Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Base blockchain on Sepolia.
 */ const BaseSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Base_Sepolia,
    name: 'Base Sepolia',
    title: 'Base Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 84532,
    isTestnet: true,
    explorerUrl: 'https://sepolia.basescan.org/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.base.org'
    ],
    eurcAddress: '0x808456652fdb597867f38412077A9182bf77359F',
    usdcAddress: '0x036CbD53842c5426634e7929541eC2318f3dCF7e',
    usdtAddress: null,
    cctp: {
        domain: 6,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 6,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Celo Mainnet chain definition
 * @remarks
 * This represents the official production network for the Celo blockchain.
 */ const Celo = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Celo,
    name: 'Celo',
    title: 'Celo Mainnet',
    nativeCurrency: {
        name: 'Celo',
        symbol: 'CELO',
        decimals: 18
    },
    chainId: 42220,
    isTestnet: false,
    explorerUrl: 'https://celoscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://forno.celo.org'
    ],
    eurcAddress: null,
    usdcAddress: '0xcebA9300f2b948710d2653dD7B07f33A8B32118C',
    usdtAddress: '0x48065fbBE25f71C9282ddf5e1cD6D6A887483D5e',
    cctp: null
});

/**
 * Celo Alfajores Testnet chain definition
 * @remarks
 * This represents the official test network for the Celo blockchain.
 */ const CeloAlfajoresTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Celo_Alfajores_Testnet,
    name: 'Celo Alfajores',
    title: 'Celo Alfajores Testnet',
    nativeCurrency: {
        name: 'Celo',
        symbol: 'CELO',
        decimals: 18
    },
    chainId: 44787,
    isTestnet: true,
    explorerUrl: 'https://alfajores.celoscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://alfajores-forno.celo-testnet.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x2F25deB3848C207fc8E0c34035B3Ba7fC157602B',
    usdtAddress: null,
    cctp: null
});

/**
 * Codex Mainnet chain definition
 * @remarks
 * This represents the main network for the Codex blockchain.
 */ const Codex = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Codex,
    name: 'Codex Mainnet',
    title: 'Codex Mainnet',
    nativeCurrency: {
        name: 'ETH',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 81224,
    isTestnet: false,
    explorerUrl: 'https://explorer.codex.xyz/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.codex.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0xd996633a415985DBd7D6D12f4A4343E31f5037cf',
    usdtAddress: null,
    cctp: {
        domain: 12,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Codex Testnet chain definition
 * @remarks
 * This represents the test network for the Codex blockchain.
 */ const CodexTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Codex_Testnet,
    name: 'Codex Testnet',
    title: 'Codex Testnet',
    nativeCurrency: {
        name: 'ETH',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 812242,
    isTestnet: true,
    explorerUrl: 'https://explorer.codex-stg.xyz/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.codex-stg.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0x6d7f141b6819C2c9CC2f818e6ad549E7Ca090F8f',
    usdtAddress: null,
    cctp: {
        domain: 12,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Cronos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Cronos blockchain.
 * Cronos is an EVM-compatible blockchain.
 */ const Cronos = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Cronos,
    name: 'Cronos',
    title: 'Cronos Mainnet',
    nativeCurrency: {
        name: 'Cronos',
        symbol: 'CRO',
        decimals: 18
    },
    chainId: 25,
    isTestnet: false,
    explorerUrl: 'https://cronoscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://evm.cronos.org'
    ],
    eurcAddress: '0xA6dE01a2d62C6B5f3525d768f34d276652C554c8',
    usdcAddress: '0x3D7F2C478aAfdB65542BCB44bCeeC05849999d2D',
    usdtAddress: null,
    cctp: {
        domain: 32,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Cronos Testnet chain definition
 * @remarks
 * This represents the official test network for the Cronos blockchain.
 * Cronos is an EVM-compatible blockchain.
 */ const CronosTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Cronos_Testnet,
    name: 'Cronos Testnet',
    title: 'Cronos Testnet',
    nativeCurrency: {
        name: 'CRO',
        symbol: 'tCRO',
        decimals: 18
    },
    chainId: 338,
    isTestnet: true,
    explorerUrl: 'https://explorer.cronos.org/testnet/tx/{hash}',
    rpcEndpoints: [
        'https://evm-t3.cronos.org'
    ],
    eurcAddress: '0x31f7538adb53cF16350e6B0c89d03D91b7D12c46',
    usdcAddress: '0xEb33dc5fac03833e132593659e1dE7256aB59794',
    usdtAddress: null,
    cctp: {
        domain: 32,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Edge Mainnet chain definition
 * @remarks
 * This represents the official production network for the Edge blockchain.
 * Edge is an EVM-compatible blockchain.
 */ const Edge = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Edge,
    name: 'Edge',
    title: 'Edge Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 3343,
    isTestnet: false,
    explorerUrl: 'https://pro.edgex.exchange/en-US/explorer/tx/{hash}',
    rpcEndpoints: [
        'https://edge-mainnet.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x98d2919b9A214E6Fa5384AC81E6864bA686Ad74c',
    usdtAddress: null,
    cctp: {
        domain: 28,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x98706A006bc632Df31CAdFCBD43F38887ce2ca5c',
                messageTransmitter: '0x5b61381Fc9e58E70EfC13a4A97516997019198ee',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: '0x6D1AaE1c34Aeb582022916a67f2A655C6f4eDFF2'
    }
});

/**
 * Edge Testnet chain definition
 * @remarks
 * This represents the official test network for the Edge blockchain.
 * Edge is an EVM-compatible blockchain.
 */ const EdgeTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Edge_Testnet,
    name: 'Edge Testnet',
    title: 'Edge Testnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 33431,
    isTestnet: true,
    explorerUrl: 'https://edge-testnet.explorer.alchemy.com/tx/{hash}',
    rpcEndpoints: [
        'https://edge-testnet.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x2d9F7CAD728051AA35Ecdc472a14cf8cDF5CFD6B',
    usdtAddress: null,
    cctp: {
        domain: 28,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Ethereum Mainnet chain definition
 * @remarks
 * This represents the official production network for the Ethereum blockchain.
 */ const Ethereum = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Ethereum,
    name: 'Ethereum',
    title: 'Ethereum Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 1,
    isTestnet: false,
    explorerUrl: 'https://etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://ethereum-rpc.publicnode.com',
        'https://ethereum.publicnode.com'
    ],
    eurcAddress: '0x1aBaEA1f7C830bD89Acc67eC4af516284b1bC33c',
    usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    usdtAddress: '0xdac17f958d2ee523a2206206994597c13d831ec7',
    cctp: {
        domain: 0,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
                messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 2
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 0,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Ethereum Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Ethereum blockchain on Sepolia.
 */ const EthereumSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Ethereum_Sepolia,
    name: 'Ethereum Sepolia',
    title: 'Ethereum Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 11155111,
    isTestnet: true,
    explorerUrl: 'https://sepolia.etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://ethereum-sepolia-rpc.publicnode.com'
    ],
    eurcAddress: '0x08210F9170F89Ab7658F0B5E3fF39b0E03C594D4',
    usdcAddress: '0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238',
    usdtAddress: null,
    cctp: {
        domain: 0,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 2
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET,
        adapter: ADAPTER_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 0,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Hedera Mainnet chain definition
 * @remarks
 * This represents the official production network for the Hedera blockchain.
 */ const Hedera = defineChain({
    type: 'hedera',
    chain: exports.Blockchain.Hedera,
    name: 'Hedera',
    title: 'Hedera Mainnet',
    nativeCurrency: {
        name: 'HBAR',
        symbol: 'HBAR',
        decimals: 18
    },
    isTestnet: false,
    explorerUrl: 'https://hashscan.io/mainnet/transaction/{hash}',
    rpcEndpoints: [
        'https://mainnet.hashio.io/api'
    ],
    eurcAddress: null,
    usdcAddress: '0.0.456858',
    usdtAddress: null,
    cctp: null
});

/**
 * Hedera Testnet chain definition
 * @remarks
 * This represents the official test network for the Hedera blockchain.
 */ const HederaTestnet = defineChain({
    type: 'hedera',
    chain: exports.Blockchain.Hedera_Testnet,
    name: 'Hedera Testnet',
    title: 'Hedera Test Network',
    nativeCurrency: {
        name: 'HBAR',
        symbol: 'HBAR',
        decimals: 18
    },
    isTestnet: true,
    explorerUrl: 'https://hashscan.io/testnet/transaction/{hash}',
    rpcEndpoints: [
        'https://testnet.hashio.io/api'
    ],
    eurcAddress: null,
    usdcAddress: '0.0.429274',
    usdtAddress: null,
    cctp: null
});

/**
 * HyperEVM Mainnet chain definition
 * @remarks
 * This represents the official production network for the HyperEVM blockchain.
 * HyperEVM is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const HyperEVM = defineChain({
    type: 'evm',
    chain: exports.Blockchain.HyperEVM,
    name: 'HyperEVM',
    title: 'HyperEVM Mainnet',
    nativeCurrency: {
        name: 'Hype',
        symbol: 'HYPE',
        decimals: 18
    },
    chainId: 999,
    isTestnet: false,
    explorerUrl: 'https://hyperevmscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.hyperliquid.xyz/evm'
    ],
    eurcAddress: null,
    usdcAddress: '0xb88339CB7199b77E23DB6E890353E22632Ba630f',
    usdtAddress: null,
    cctp: {
        domain: 19,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 19,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * HyperEVM Testnet chain definition
 * @remarks
 * This represents the official testnet for the HyperEVM blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const HyperEVMTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.HyperEVM_Testnet,
    name: 'HyperEVM Testnet',
    title: 'HyperEVM Test Network',
    nativeCurrency: {
        name: 'Hype',
        symbol: 'HYPE',
        decimals: 18
    },
    chainId: 998,
    isTestnet: true,
    explorerUrl: 'https://app.hyperliquid-testnet.xyz/explorer/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.hyperliquid-testnet.xyz/evm'
    ],
    eurcAddress: null,
    usdcAddress: '0x2B3370eE501B4a559b57D449569354196457D8Ab',
    usdtAddress: null,
    cctp: {
        domain: 19,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 19,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Injective Mainnet chain definition
 * @remarks
 * This represents the official production network for the Injective blockchain.
 * Injective is a high-performance, interoperable Layer-1 blockchain built for
 * finance, with an EVM execution layer on top of a Cosmos SDK base and
 * sub-second block finality.
 */ const Injective = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Injective,
    name: 'Injective',
    title: 'Injective Mainnet',
    nativeCurrency: {
        name: 'Injective',
        symbol: 'INJ',
        decimals: 18
    },
    chainId: 1776,
    isTestnet: false,
    explorerUrl: 'https://injscan.com/transaction/{hash}',
    rpcEndpoints: [
        'https://sentry.evm-rpc.injective.network'
    ],
    eurcAddress: null,
    usdcAddress: '0xa00C59fF5a080D2b954d0c75e46E22a0c371235a',
    usdtAddress: null,
    cctp: {
        domain: 29,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Injective Testnet chain definition
 * @remarks
 * This represents the official test network for the Injective blockchain.
 * Injective is a high-performance, interoperable Layer-1 blockchain built for
 * finance, with an EVM execution layer on top of a Cosmos SDK base and
 * sub-second block finality.
 */ const InjectiveTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Injective_Testnet,
    name: 'Injective Testnet',
    title: 'Injective Testnet',
    nativeCurrency: {
        name: 'Injective',
        symbol: 'INJ',
        decimals: 18
    },
    chainId: 1439,
    isTestnet: true,
    explorerUrl: 'https://testnet.explorer.injective.network/transaction/{hash}',
    rpcEndpoints: [
        'https://k8s.testnet.json-rpc.injective.network'
    ],
    eurcAddress: null,
    usdcAddress: '0x0C382e685bbeeFE5d3d9C29e29E341fEE8E84C5d',
    usdtAddress: null,
    cctp: {
        domain: 29,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Ink Mainnet chain definition
 * @remarks
 * This represents the official production network for the Ink blockchain.
 * Ink is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const Ink = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Ink,
    name: 'Ink',
    title: 'Ink Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 57073,
    isTestnet: false,
    explorerUrl: 'https://explorer.inkonchain.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-gel.inkonchain.com',
        'https://rpc-qnd.inkonchain.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x2D270e6886d130D724215A266106e6832161EAEd',
    usdtAddress: null,
    cctp: {
        domain: 21,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Ink Testnet chain definition
 * @remarks
 * This represents the official testnet for the Ink blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const InkTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Ink_Testnet,
    name: 'Ink Sepolia',
    title: 'Ink Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 763373,
    isTestnet: true,
    explorerUrl: 'https://explorer-sepolia.inkonchain.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-gel-sepolia.inkonchain.com',
        'https://rpc-qnd-sepolia.inkonchain.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xFabab97dCE620294D2B0b0e46C68964e326300Ac',
    usdtAddress: null,
    cctp: {
        domain: 21,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Linea Mainnet chain definition
 * @remarks
 * This represents the official production network for the Linea blockchain.
 */ const Linea = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Linea,
    name: 'Linea',
    title: 'Linea Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 59144,
    isTestnet: false,
    explorerUrl: 'https://lineascan.build/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.linea.build'
    ],
    eurcAddress: null,
    usdcAddress: '0x176211869ca2b568f2a7d4ee941e073a821ee1ff',
    usdtAddress: null,
    cctp: {
        domain: 11,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Linea Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Linea blockchain on Sepolia.
 */ const LineaSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Linea_Sepolia,
    name: 'Linea Sepolia',
    title: 'Linea Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 59141,
    isTestnet: true,
    explorerUrl: 'https://sepolia.lineascan.build/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.sepolia.linea.build'
    ],
    eurcAddress: null,
    usdcAddress: '0xfece4462d57bd51a6a552365a011b95f0e16d9b7',
    usdtAddress: null,
    cctp: {
        domain: 11,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Monad Mainnet chain definition
 * @remarks
 * This represents the official production network for the Monad blockchain.
 * Monad is a high-performance EVM-compatible Layer-1 blockchain featuring
 * over 10,000 TPS, sub-second finality, and near-zero gas fees.
 */ const Monad = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Monad,
    name: 'Monad',
    title: 'Monad Mainnet',
    nativeCurrency: {
        name: 'Monad',
        symbol: 'MON',
        decimals: 18
    },
    chainId: 143,
    isTestnet: false,
    explorerUrl: 'https://monadscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.monad.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0x754704Bc059F8C67012fEd69BC8A327a5aafb603',
    usdtAddress: null,
    cctp: {
        domain: 15,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Monad Testnet chain definition
 * @remarks
 * This represents the official test network for the Monad blockchain.
 * Monad is a high-performance EVM-compatible Layer-1 blockchain featuring
 * over 10,000 TPS, sub-second finality, and near-zero gas fees.
 */ const MonadTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Monad_Testnet,
    name: 'Monad Testnet',
    title: 'Monad Testnet',
    nativeCurrency: {
        name: 'Monad',
        symbol: 'MON',
        decimals: 18
    },
    chainId: 10143,
    isTestnet: true,
    explorerUrl: 'https://testnet.monadscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-rpc.monad.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0x534b2f3A21130d7a60830c2Df862319e593943A3',
    usdtAddress: null,
    cctp: {
        domain: 15,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Morph Mainnet chain definition
 * @remarks
 * This represents the official production network for the Morph blockchain.
 * Morph is an EVM-compatible Layer-2 blockchain built on the OP Stack.
 */ const Morph = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Morph,
    name: 'Morph',
    title: 'Morph Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 2818,
    isTestnet: false,
    explorerUrl: 'https://explorer.morph.network/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.morphl2.io'
    ],
    eurcAddress: null,
    usdcAddress: '0xCfb1186F4e93D60E60a8bDd997427D1F33bc372B',
    usdtAddress: null,
    cctp: {
        domain: 30,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 64,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Morph Hoodi Testnet chain definition
 * @remarks
 * This represents the official test network for the Morph blockchain.
 * Morph is an EVM-compatible Layer-2 blockchain built on the OP Stack.
 */ const MorphTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Morph_Testnet,
    name: 'Morph Hoodi',
    title: 'Morph Hoodi Testnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 2910,
    isTestnet: true,
    explorerUrl: 'https://explorer-hoodi.morphl2.io/tx/{hash}',
    rpcEndpoints: [
        'https://rpc-hoodi.morphl2.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x7433b41C6c5e1d58D4Da99483609520255ab661B',
    usdtAddress: null,
    cctp: {
        domain: 30,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 64,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * NEAR Protocol Mainnet chain definition
 * @remarks
 * This represents the official production network for the NEAR Protocol blockchain.
 */ const NEAR = defineChain({
    type: 'near',
    chain: exports.Blockchain.NEAR,
    name: 'NEAR Protocol',
    title: 'NEAR Mainnet',
    nativeCurrency: {
        name: 'NEAR',
        symbol: 'NEAR',
        decimals: 24
    },
    isTestnet: false,
    explorerUrl: 'https://nearblocks.io/txns/{hash}',
    rpcEndpoints: [
        'https://eth-rpc.mainnet.near.org'
    ],
    eurcAddress: null,
    usdcAddress: '17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1',
    usdtAddress: 'usdt.tether-token.near',
    cctp: null
});

/**
 * NEAR Testnet chain definition
 * @remarks
 * This represents the official test network for the NEAR Protocol blockchain.
 */ const NEARTestnet = defineChain({
    type: 'near',
    chain: exports.Blockchain.NEAR_Testnet,
    name: 'NEAR Protocol Testnet',
    title: 'NEAR Test Network',
    nativeCurrency: {
        name: 'NEAR',
        symbol: 'NEAR',
        decimals: 24
    },
    isTestnet: true,
    explorerUrl: 'https://testnet.nearblocks.io/txns/{hash}',
    rpcEndpoints: [
        'https://eth-rpc.testnet.near.org'
    ],
    eurcAddress: null,
    usdcAddress: '3e2210e1184b45b64c8a434c0a7e7b23cc04ea7eb7a6c3c32520d03d4afcb8af',
    usdtAddress: null,
    cctp: null
});

/**
 * Noble Mainnet chain definition
 * @remarks
 * This represents the official production network for the Noble blockchain.
 */ const Noble = defineChain({
    type: 'noble',
    chain: exports.Blockchain.Noble,
    name: 'Noble',
    title: 'Noble Mainnet',
    nativeCurrency: {
        name: 'Noble USDC',
        symbol: 'USDC',
        decimals: 6
    },
    isTestnet: false,
    explorerUrl: 'https://www.mintscan.io/noble/tx/{hash}',
    rpcEndpoints: [
        'https://noble-rpc.polkachu.com'
    ],
    eurcAddress: null,
    usdcAddress: 'uusdc',
    usdtAddress: null,
    cctp: {
        domain: 4,
        contracts: {
            v1: {
                type: 'merged',
                contract: 'noble12l2w4ugfz4m6dd73yysz477jszqnfughxvkss5',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Noble Testnet chain definition
 * @remarks
 * This represents the official test network for the Noble blockchain.
 */ const NobleTestnet = defineChain({
    type: 'noble',
    chain: exports.Blockchain.Noble_Testnet,
    name: 'Noble Testnet',
    title: 'Noble Test Network',
    nativeCurrency: {
        name: 'Noble USDC',
        symbol: 'USDC',
        decimals: 6
    },
    isTestnet: true,
    explorerUrl: 'https://www.mintscan.io/noble-testnet/tx/{hash}',
    rpcEndpoints: [
        'https://noble-testnet-rpc.polkachu.com'
    ],
    eurcAddress: null,
    usdcAddress: 'uusdc',
    usdtAddress: null,
    cctp: {
        domain: 4,
        contracts: {
            v1: {
                type: 'merged',
                contract: 'noble12l2w4ugfz4m6dd73yysz477jszqnfughxvkss5',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Optimism Mainnet chain definition
 * @remarks
 * This represents the official production network for the Optimism blockchain.
 */ const Optimism = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Optimism,
    name: 'Optimism',
    title: 'Optimism Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 10,
    isTestnet: false,
    explorerUrl: 'https://optimistic.etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.optimism.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
    usdtAddress: null,
    cctp: {
        domain: 2,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x2B4069517957735bE00ceE0fadAE88a26365528f',
                messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 2,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Optimism Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Optimism blockchain on Sepolia.
 */ const OptimismSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Optimism_Sepolia,
    name: 'Optimism Sepolia',
    title: 'Optimism Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 11155420,
    isTestnet: true,
    explorerUrl: 'https://sepolia-optimistic.etherscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.optimism.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x5fd84259d66Cd46123540766Be93DFE6D43130D7',
    usdtAddress: null,
    cctp: {
        domain: 2,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 2,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Pharos Mainnet chain definition
 * @remarks
 * This represents the official production network for the Pharos blockchain.
 * Pharos is a modular, full-stack parallel Layer 1 blockchain with
 * sub-second finality and EVM compatibility.
 */ const Pharos = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Pharos,
    name: 'Pharos',
    title: 'Pharos Mainnet',
    nativeCurrency: {
        name: 'Pharos',
        symbol: 'PHAROS',
        decimals: 18
    },
    chainId: 1672,
    isTestnet: false,
    explorerUrl: 'https://pharos.socialscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.pharos.xyz'
    ],
    eurcAddress: null,
    usdcAddress: '0xC879C018dB60520F4355C26eD1a6D572cdAC1815',
    usdtAddress: null,
    cctp: {
        domain: 31,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Pharos Atlantic Testnet chain definition
 * @remarks
 * This represents the official test network for the Pharos blockchain.
 * Pharos is a modular, full-stack parallel Layer 1 blockchain with
 * sub-second finality and EVM compatibility.
 */ const PharosTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Pharos_Testnet,
    name: 'Pharos Atlantic',
    title: 'Pharos Atlantic Testnet',
    nativeCurrency: {
        name: 'Pharos',
        symbol: 'PHAROS',
        decimals: 18
    },
    chainId: 688689,
    isTestnet: true,
    explorerUrl: 'https://atlantic.pharosscan.xyz/tx/{hash}',
    rpcEndpoints: [
        'https://atlantic.dplabs-internal.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xcfC8330f4BCAB529c625D12781b1C19466A9Fc8B',
    usdtAddress: null,
    cctp: {
        domain: 31,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Plasma Mainnet chain definition
 * @remarks
 * This represents the official production network for the Plasma blockchain.
 * Plasma is an EVM-equivalent Layer 1 blockchain purpose-built for global
 * stablecoin payments, with deterministic BFT finality (PlasmaBFT/Fast-HotStuff).
 */ const Plasma = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Plasma,
    name: 'Plasma',
    title: 'Plasma Mainnet',
    nativeCurrency: {
        name: 'Plasma',
        symbol: 'XPL',
        decimals: 18
    },
    chainId: 9745,
    isTestnet: false,
    explorerUrl: 'https://plasmascan.to/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.plasma.to'
    ],
    eurcAddress: '0x3EE196E78d4d4248b849B8E1C7F44C5457FAFD2C',
    usdcAddress: '0x2d661C89D812261039AF9764eceaAee884f5F67F',
    usdtAddress: null,
    cctp: {
        domain: 33,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 3,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * Plasma Testnet chain definition
 * @remarks
 * This represents the official test network for the Plasma blockchain.
 * Plasma is an EVM-equivalent Layer 1 blockchain purpose-built for global
 * stablecoin payments, with deterministic BFT finality (PlasmaBFT/Fast-HotStuff).
 */ const PlasmaTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Plasma_Testnet,
    name: 'Plasma Testnet',
    title: 'Plasma Testnet',
    nativeCurrency: {
        name: 'Plasma',
        symbol: 'XPL',
        decimals: 18
    },
    chainId: 9746,
    isTestnet: true,
    explorerUrl: 'https://testnet.plasmascan.to/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-rpc.plasma.to'
    ],
    eurcAddress: '0x98AfA0F93Dd993B736399f9074eDcEBD1985A330',
    usdcAddress: '0xE67Fb267022cBA8064Dd388CC2FED724F3120D9D',
    usdtAddress: null,
    cctp: {
        domain: 33,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 3,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Plume Mainnet chain definition
 * @remarks
 * This represents the official production network for the Plume blockchain.
 * Plume is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const Plume = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Plume,
    name: 'Plume',
    title: 'Plume Mainnet',
    nativeCurrency: {
        name: 'Plume',
        symbol: 'PLUME',
        decimals: 18
    },
    chainId: 98866,
    isTestnet: false,
    explorerUrl: 'https://explorer.plume.org/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.plume.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x222365EF19F7947e5484218551B56bb3965Aa7aF',
    usdtAddress: null,
    cctp: {
        domain: 22,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * Plume Testnet chain definition
 * @remarks
 * This represents the official testnet for the Plume blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const PlumeTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Plume_Testnet,
    name: 'Plume Testnet',
    title: 'Plume Test Network',
    nativeCurrency: {
        name: 'Plume',
        symbol: 'PLUME',
        decimals: 18
    },
    chainId: 98867,
    isTestnet: true,
    explorerUrl: 'https://testnet-explorer.plume.org/tx/{hash}',
    rpcEndpoints: [
        'https://testnet-rpc.plume.org'
    ],
    eurcAddress: null,
    usdcAddress: '0xcB5f30e335672893c7eb944B374c196392C19D18',
    usdtAddress: null,
    cctp: {
        domain: 22,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * Polkadot Asset Hub chain definition
 * @remarks
 * This represents the official asset management parachain for the Polkadot blockchain.
 */ const PolkadotAssetHub = defineChain({
    type: 'polkadot',
    chain: exports.Blockchain.Polkadot_Asset_Hub,
    name: 'Polkadot Asset Hub',
    title: 'Polkadot Asset Hub',
    nativeCurrency: {
        name: 'Polkadot',
        symbol: 'DOT',
        decimals: 10
    },
    isTestnet: false,
    explorerUrl: 'https://polkadot.subscan.io/extrinsic/{hash}',
    rpcEndpoints: [
        'https://asset-hub-polkadot-rpc.n.dwellir.com'
    ],
    eurcAddress: null,
    usdcAddress: '1337',
    usdtAddress: '1984',
    cctp: null
});

/**
 * Polkadot Westmint chain definition
 * @remarks
 * This represents an asset management parachain in the Polkadot ecosystem.
 */ const PolkadotWestmint = defineChain({
    type: 'polkadot',
    chain: exports.Blockchain.Polkadot_Westmint,
    name: 'Polkadot Westmint',
    title: 'Polkadot Westmint',
    nativeCurrency: {
        name: 'Polkadot',
        symbol: 'DOT',
        decimals: 10
    },
    isTestnet: false,
    explorerUrl: 'https://assethub-polkadot.subscan.io/extrinsic/{hash}',
    rpcEndpoints: [
        'https://westmint-rpc.polkadot.io'
    ],
    eurcAddress: null,
    usdcAddress: 'Asset ID 31337',
    usdtAddress: null,
    cctp: null
});

/**
 * Polygon Mainnet chain definition
 * @remarks
 * This represents the official production network for the Polygon blockchain.
 */ const Polygon = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Polygon,
    name: 'Polygon',
    title: 'Polygon Mainnet',
    nativeCurrency: {
        name: 'POL',
        symbol: 'POL',
        decimals: 18
    },
    chainId: 137,
    isTestnet: false,
    explorerUrl: 'https://polygonscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://polygon.publicnode.com',
        'https://polygon.drpc.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
    usdtAddress: null,
    cctp: {
        domain: 7,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9daF8c91AEFAE50b9c0E69629D3F6Ca40cA3B3FE',
                messageTransmitter: '0xF3be9355363857F3e001be68856A2f96b4C39Ba9',
                confirmations: 200
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 33,
                fastConfirmations: 13
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 7,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Polygon Amoy Testnet chain definition
 * @remarks
 * This represents the official test network for the Polygon blockchain.
 */ const PolygonAmoy = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Polygon_Amoy_Testnet,
    name: 'Polygon Amoy',
    title: 'Polygon Amoy Testnet',
    nativeCurrency: {
        name: 'POL',
        symbol: 'POL',
        decimals: 18
    },
    chainId: 80002,
    isTestnet: true,
    explorerUrl: 'https://amoy.polygonscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://polygon-amoy-bor-rpc.publicnode.com',
        'https://polygon-amoy.drpc.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x41e94eb019c0762f9bfcf9fb1e58725bfb0e7582',
    usdtAddress: null,
    cctp: {
        domain: 7,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x9f3B8679c73C2Fef8b59B4f3444d4e156fb70AA5',
                messageTransmitter: '0x7865fAfC2db2093669d92c0F33AeEF291086BEFD',
                confirmations: 200
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 33,
                fastConfirmations: 13
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 7,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sei Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sei blockchain.
 * Sei is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const Sei = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Sei,
    name: 'Sei',
    title: 'Sei Mainnet',
    nativeCurrency: {
        name: 'Sei',
        symbol: 'SEI',
        decimals: 18
    },
    chainId: 1329,
    isTestnet: false,
    explorerUrl: 'https://seiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://evm-rpc.sei-apis.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xe15fC38F6D8c56aF07bbCBe3BAf5708A2Bf42392',
    usdtAddress: null,
    cctp: {
        domain: 16,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 16,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sei Testnet chain definition
 * @remarks
 * This represents the official testnet for the Sei blockchain.
 * Used for development and testing purposes before deploying to mainnet.
 */ const SeiTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Sei_Testnet,
    name: 'Sei Testnet',
    title: 'Sei Test Network',
    nativeCurrency: {
        name: 'Sei',
        symbol: 'SEI',
        decimals: 18
    },
    chainId: 1328,
    isTestnet: true,
    explorerUrl: 'https://testnet.seiscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://evm-rpc-testnet.sei-apis.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x4fCF1784B31630811181f670Aea7A7bEF803eaED',
    usdtAddress: null,
    cctp: {
        domain: 16,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 16,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sonic Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sonic blockchain.
 */ const Sonic = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Sonic,
    name: 'Sonic',
    title: 'Sonic Mainnet',
    nativeCurrency: {
        name: 'Sonic',
        symbol: 'S',
        decimals: 18
    },
    chainId: 146,
    isTestnet: false,
    explorerUrl: 'https://sonicscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.soniclabs.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x29219dd400f2Bf60E5a23d13Be72B486D4038894',
    usdtAddress: null,
    cctp: {
        domain: 13,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 13,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Sonic Testnet chain definition
 * @remarks
 * This represents the official test network for the Sonic blockchain.
 */ const SonicTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Sonic_Testnet,
    name: 'Sonic Testnet',
    title: 'Sonic Testnet',
    nativeCurrency: {
        name: 'Sonic',
        symbol: 'S',
        decimals: 18
    },
    chainId: 14601,
    isTestnet: true,
    explorerUrl: 'https://testnet.sonicscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://rpc.testnet.soniclabs.com'
    ],
    eurcAddress: null,
    usdcAddress: '0x0BA304580ee7c9a980CF72e55f5Ed2E9fd30Bc51',
    usdtAddress: null,
    cctp: {
        domain: 13,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 1,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 13,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Solana Mainnet chain definition
 * @remarks
 * This represents the official production network for the Solana blockchain.
 */ const Solana = defineChain({
    type: 'solana',
    chain: exports.Blockchain.Solana,
    name: 'Solana',
    title: 'Solana Mainnet',
    nativeCurrency: {
        name: 'Solana',
        symbol: 'SOL',
        decimals: 9
    },
    isTestnet: false,
    explorerUrl: 'https://solscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://api.mainnet-beta.solana.com'
    ],
    eurcAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
    usdcAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
    usdtAddress: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
    cctp: {
        domain: 5,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
                messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd',
                confirmations: 32
            },
            v2: {
                type: 'split',
                tokenMessenger: 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe',
                messageTransmitter: 'CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC',
                confirmations: 32,
                fastConfirmations: 3
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: 'DFaauJEjmiHkPs1JG89A4p95hDWi9m9SAEERY1LQJiC3'
    },
    gateway: {
        domain: 5,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_SOLANA_MAINNET,
                minter: GATEWAY_MINTER_SOLANA_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Solana Devnet chain definition
 * @remarks
 * This represents the development test network for the Solana blockchain.
 */ const SolanaDevnet = defineChain({
    type: 'solana',
    chain: exports.Blockchain.Solana_Devnet,
    name: 'Solana Devnet',
    title: 'Solana Development Network',
    nativeCurrency: {
        name: 'Solana',
        symbol: 'SOL',
        decimals: 9
    },
    isTestnet: true,
    explorerUrl: 'https://solscan.io/tx/{hash}?cluster=devnet',
    eurcAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr',
    usdcAddress: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
    usdtAddress: null,
    cctp: {
        domain: 5,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
                messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd',
                confirmations: 32
            },
            v2: {
                type: 'split',
                tokenMessenger: 'CCTPV2vPZJS2u2BBsUoscuikbYjnpFmbFsvVuJdgUMQe',
                messageTransmitter: 'CCTPV2Sm4AdWt5296sk4P66VBZ7bEhcARwFaaS9YPbeC',
                confirmations: 32,
                fastConfirmations: 3
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: 'DFaauJEjmiHkPs1JG89A4p95hDWi9m9SAEERY1LQJiC3'
    },
    rpcEndpoints: [
        'https://api.devnet.solana.com'
    ],
    gateway: {
        domain: 5,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_SOLANA_DEVNET,
                minter: GATEWAY_MINTER_SOLANA_DEVNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Stellar Mainnet chain definition
 * @remarks
 * This represents the official production network for the Stellar blockchain.
 */ const Stellar = defineChain({
    type: 'stellar',
    chain: exports.Blockchain.Stellar,
    name: 'Stellar',
    title: 'Stellar Mainnet',
    nativeCurrency: {
        name: 'Stellar Lumens',
        symbol: 'XLM',
        decimals: 7
    },
    isTestnet: false,
    explorerUrl: 'https://stellar.expert/explorer/public/tx/{hash}',
    rpcEndpoints: [
        'https://horizon.stellar.org'
    ],
    eurcAddress: 'EURC-GDHU6WRG4IEQXM5NZ4BMPKOXHW76MZM4Y2IEMFDVXBSDP6SJY4ITNPP2',
    usdcAddress: 'USDC-GA5ZSEJYB37JRC5AVCIA5MOP4RHTM335X2KGX3IHOJAPP5RE34K4KZVN',
    usdtAddress: null,
    cctp: null
});

/**
 * Stellar Testnet chain definition
 * @remarks
 * This represents the official test network for the Stellar blockchain.
 */ const StellarTestnet = defineChain({
    type: 'stellar',
    chain: exports.Blockchain.Stellar_Testnet,
    name: 'Stellar Testnet',
    title: 'Stellar Test Network',
    nativeCurrency: {
        name: 'Stellar Lumens',
        symbol: 'XLM',
        decimals: 7
    },
    isTestnet: true,
    explorerUrl: 'https://stellar.expert/explorer/testnet/tx/{hash}',
    rpcEndpoints: [
        'https://horizon-testnet.stellar.org'
    ],
    eurcAddress: 'EURC-GB3Q6QDZYTHWT7E5PVS3W7FUT5GVAFC5KSZFFLPU25GO7VTC3NM2ZTVO',
    usdcAddress: 'USDC-GBBD47IF6LWK7P7MDEVSCWR7DPUWV3NY3DTQEVFL4NAT4AQH3ZLLFLA5',
    usdtAddress: null,
    cctp: null
});

/**
 * Sui Mainnet chain definition
 * @remarks
 * This represents the official production network for the Sui blockchain.
 */ const Sui = defineChain({
    type: 'sui',
    chain: exports.Blockchain.Sui,
    name: 'Sui',
    title: 'Sui Mainnet',
    nativeCurrency: {
        name: 'Sui',
        symbol: 'SUI',
        decimals: 9
    },
    isTestnet: false,
    explorerUrl: 'https://suiscan.xyz/mainnet/tx/{hash}',
    rpcEndpoints: [
        'https://fullnode.mainnet.sui.io'
    ],
    eurcAddress: null,
    usdcAddress: '0xdba34672e30cb065b1f93e3ab55318768fd6fef66c15942c9f7cb846e2f900e7::usdc::USDC',
    usdtAddress: null,
    cctp: {
        domain: 8,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x2aa6c5d56376c371f88a6cc42e852824994993cb9bab8d3e6450cbe3cb32b94e',
                messageTransmitter: '0x08d87d37ba49e785dde270a83f8e979605b03dc552b5548f26fdf2f49bf7ed1b',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Sui Testnet chain definition
 * @remarks
 * This represents the official test network for the Sui blockchain.
 */ const SuiTestnet = defineChain({
    type: 'sui',
    chain: exports.Blockchain.Sui_Testnet,
    name: 'Sui Testnet',
    title: 'Sui Test Network',
    nativeCurrency: {
        name: 'Sui',
        symbol: 'SUI',
        decimals: 9
    },
    isTestnet: true,
    explorerUrl: 'https://suiscan.xyz/testnet/tx/{hash}',
    rpcEndpoints: [
        'https://fullnode.testnet.sui.io'
    ],
    eurcAddress: null,
    usdcAddress: '0xa1ec7fc00a6f40db9693ad1415d0c193ad3906494428cf252621037bd7117e29::usdc::USDC',
    usdtAddress: null,
    cctp: {
        domain: 8,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x31cc14d80c175ae39777c0238f20594c6d4869cfab199f40b69f3319956b8beb',
                messageTransmitter: '0x4931e06dce648b3931f890035bd196920770e913e43e45990b383f6486fdd0a5',
                confirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    }
});

/**
 * Unichain Mainnet chain definition
 * @remarks
 * This represents the official production network for the Unichain blockchain.
 */ const Unichain = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Unichain,
    name: 'Unichain',
    title: 'Unichain Mainnet',
    nativeCurrency: {
        name: 'Uni',
        symbol: 'UNI',
        decimals: 18
    },
    chainId: 130,
    isTestnet: false,
    explorerUrl: 'https://unichain.blockscout.com/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.unichain.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x078D782b760474a361dDA0AF3839290b0EF57AD6',
    usdtAddress: null,
    cctp: {
        domain: 10,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x4e744b28E787c3aD0e810eD65A24461D4ac5a762',
                messageTransmitter: '0x353bE9E2E38AB1D19104534e4edC21c643Df86f4',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 10,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * Unichain Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the Unichain blockchain.
 */ const UnichainSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.Unichain_Sepolia,
    name: 'Unichain Sepolia',
    title: 'Unichain Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Uni',
        symbol: 'UNI',
        decimals: 18
    },
    chainId: 1301,
    isTestnet: true,
    explorerUrl: 'https://unichain-sepolia.blockscout.com/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.unichain.org'
    ],
    eurcAddress: null,
    usdcAddress: '0x31d0220469e10c4E71834a79b1f276d740d3768F',
    usdtAddress: null,
    cctp: {
        domain: 10,
        contracts: {
            v1: {
                type: 'split',
                tokenMessenger: '0x8ed94B8dAd2Dc5453862ea5e316A8e71AAed9782',
                messageTransmitter: '0xbc498c326533d675cf571B90A2Ced265ACb7d086',
                confirmations: 65
            },
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 10,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * World Chain chain definition
 * @remarks
 * This represents the main network for the World Chain blockchain.
 */ const WorldChain = defineChain({
    type: 'evm',
    chain: exports.Blockchain.World_Chain,
    name: 'World Chain',
    title: 'World Chain',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 480,
    isTestnet: false,
    explorerUrl: 'https://worldscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://worldchain-mainnet.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x79A02482A880bCE3F13e09Da970dC34db4CD24d1',
    usdtAddress: null,
    cctp: {
        domain: 14,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cF5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    },
    gateway: {
        domain: 14,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_MAINNET,
                minter: GATEWAY_MINTER_EVM_MAINNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * World Chain Sepolia chain definition
 * @remarks
 * This represents the test network for the World Chain blockchain.
 */ const WorldChainSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.World_Chain_Sepolia,
    name: 'World Chain Sepolia',
    title: 'World Chain Sepolia',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 4801,
    isTestnet: true,
    explorerUrl: 'https://sepolia.worldscan.org/tx/{hash}',
    rpcEndpoints: [
        'https://worldchain-sepolia.drpc.org',
        'https://worldchain-sepolia.g.alchemy.com/public'
    ],
    eurcAddress: null,
    usdcAddress: '0x66145f38cBAC35Ca6F1Dfb4914dF98F1614aeA88',
    usdtAddress: null,
    cctp: {
        domain: 14,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xe737e5cebeeba77efe34d4aa090756590b1ce275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    },
    gateway: {
        domain: 14,
        contracts: {
            v1: {
                wallet: GATEWAY_WALLET_EVM_TESTNET,
                minter: GATEWAY_MINTER_EVM_TESTNET
            }
        },
        forwarderSupported: {
            source: true,
            destination: true
        }
    }
});

/**
 * XDC Mainnet chain definition
 * @remarks
 * This represents the official production network for the XDC blockchain.
 * XDC is a Layer 1 blockchain specialized for DeFi and trading applications
 * with native orderbook and matching engine.
 */ const XDC = defineChain({
    type: 'evm',
    chain: exports.Blockchain.XDC,
    name: 'XDC',
    title: 'XDC Mainnet',
    nativeCurrency: {
        name: 'XDC',
        symbol: 'XDC',
        decimals: 18
    },
    chainId: 50,
    isTestnet: false,
    explorerUrl: 'https://xdcscan.io/tx/{hash}',
    rpcEndpoints: [
        'https://erpc.xdcrpc.com',
        'https://erpc.xinfin.network'
    ],
    eurcAddress: null,
    usdcAddress: '0xfA2958CB79b0491CC627c1557F441eF849Ca8eb1',
    usdtAddress: null,
    cctp: {
        domain: 18,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_MAINNET,
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 3,
                fastConfirmations: 3
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET,
        adapter: ADAPTER_CONTRACT_EVM_MAINNET
    }
});

/**
 * XDC Apothem Testnet chain definition
 * @remarks
 * This represents the official test network for the XDC Network, known as Apothem.
 */ const XDCApothem = defineChain({
    type: 'evm',
    chain: exports.Blockchain.XDC_Apothem,
    name: 'Apothem Network',
    title: 'Apothem Network',
    nativeCurrency: {
        name: 'TXDC',
        symbol: 'TXDC',
        decimals: 18
    },
    chainId: 51,
    isTestnet: true,
    explorerUrl: 'https://testnet.xdcscan.com/tx/{hash}',
    rpcEndpoints: [
        'https://erpc.apothem.network'
    ],
    eurcAddress: null,
    usdcAddress: '0xb5AB69F7bBada22B28e79C8FFAECe55eF1c771D4',
    usdtAddress: null,
    cctp: {
        domain: 18,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                tokenMessengerWithFees: TOKEN_MESSENGER_WITH_FEES_EVM_TESTNET,
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 3,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: true
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * X Layer Mainnet chain definition
 * @remarks
 * This represents the official production network for the X Layer blockchain.
 * X Layer is an EVM-compatible OP Stack Layer-2 blockchain built by OKX,
 * using OKB as its native gas token. (Migrated from Polygon zkEVM/CDK to the
 * OP Stack on 2025-10-27; older docs describing it as zkEVM are obsolete.)
 */ const XLayer = defineChain({
    type: 'evm',
    chain: exports.Blockchain.X_Layer,
    name: 'X Layer',
    title: 'X Layer Mainnet',
    nativeCurrency: {
        name: 'OKB',
        symbol: 'OKB',
        decimals: 18
    },
    chainId: 196,
    isTestnet: false,
    explorerUrl: 'https://www.oklink.com/xlayer/tx/{hash}',
    rpcEndpoints: [
        'https://xlayerrpc.okx.com'
    ],
    eurcAddress: null,
    usdcAddress: '0xB6CEceAB302E2E4948951eE7843FC24E92933061',
    usdtAddress: null,
    cctp: {
        domain: 37,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x28b5a0e9C621a5BadaA536219b3a228C8168cf5d',
                messageTransmitter: '0x81D40F21F12A8F0E3252Bccb954D722d4c464B64',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_MAINNET
    }
});

/**
 * X Layer Testnet chain definition
 * @remarks
 * This represents the official test network for the X Layer blockchain.
 * X Layer is an EVM-compatible OP Stack Layer-2 blockchain built by OKX,
 * using OKB as its native gas token. (Migrated from Polygon zkEVM/CDK to the
 * OP Stack on 2025-10-27; older docs describing it as zkEVM are obsolete.)
 */ const XLayerTestnet = defineChain({
    type: 'evm',
    chain: exports.Blockchain.X_Layer_Testnet,
    name: 'X Layer Testnet',
    title: 'X Layer Testnet',
    nativeCurrency: {
        name: 'OKB',
        symbol: 'OKB',
        decimals: 18
    },
    chainId: 1952,
    isTestnet: true,
    // Deliberately not oklink.com (used for mainnet): viem's bundled OKLink
    // testnet URL targets the deprecated pre-rebrand chain ID 195, not this
    // chain's ID (1952). Verified against the internal chain-expansion-scripts
    // config (`v2config.sandbox.yml`) — do not "normalize" this to match mainnet.
    explorerUrl: 'https://web3.okx.com/explorer/x-layer-testnet/tx/{hash}',
    rpcEndpoints: [
        'https://testrpc.xlayer.tech'
    ],
    eurcAddress: null,
    usdcAddress: '0xDec90b78111Ba2fc6FC6d84d8B9ec159A2d4b9B3',
    usdtAddress: null,
    cctp: {
        domain: 37,
        contracts: {
            v2: {
                type: 'split',
                tokenMessenger: '0x8FE6B999Dc680CcFDD5Bf7EB0974218be2542DAA',
                messageTransmitter: '0xE737e5cEBEEBa77EFE34D4aa090756590b1CE275',
                confirmations: 65,
                fastConfirmations: 1
            }
        },
        forwarderSupported: {
            source: false,
            destination: false
        }
    },
    kitContracts: {
        bridge: BRIDGE_CONTRACT_EVM_TESTNET
    }
});

/**
 * ZKSync Era Mainnet chain definition
 * @remarks
 * This represents the official production network for the ZKSync Era blockchain.
 */ const ZKSyncEra = defineChain({
    type: 'evm',
    chain: exports.Blockchain.ZKSync_Era,
    name: 'ZKSync Era',
    title: 'ZKSync Era Mainnet',
    nativeCurrency: {
        name: 'Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 324,
    isTestnet: false,
    explorerUrl: 'https://explorer.zksync.io/tx/{hash}',
    rpcEndpoints: [
        'https://mainnet.era.zksync.io'
    ],
    eurcAddress: null,
    usdcAddress: '0x1d17CBcF0D6D143135aE902365D2E5e2A16538D4',
    usdtAddress: null,
    cctp: null
});

/**
 * ZKSync Era Sepolia Testnet chain definition
 * @remarks
 * This represents the official test network for the ZKSync Era blockchain on Sepolia.
 */ const ZKSyncEraSepolia = defineChain({
    type: 'evm',
    chain: exports.Blockchain.ZKSync_Sepolia,
    name: 'ZKSync Era Sepolia',
    title: 'ZKSync Era Sepolia Testnet',
    nativeCurrency: {
        name: 'Sepolia Ether',
        symbol: 'ETH',
        decimals: 18
    },
    chainId: 300,
    isTestnet: true,
    explorerUrl: 'https://sepolia.explorer.zksync.io/tx/{hash}',
    rpcEndpoints: [
        'https://sepolia.era.zksync.dev'
    ],
    eurcAddress: null,
    usdcAddress: '0xAe045DE5638162fa134807Cb558E15A3F5A7F853',
    usdtAddress: null,
    cctp: null
});

var Blockchains = {
  __proto__: null,
  Algorand: Algorand,
  AlgorandTestnet: AlgorandTestnet,
  Aptos: Aptos,
  AptosTestnet: AptosTestnet,
  Arbitrum: Arbitrum,
  ArbitrumSepolia: ArbitrumSepolia,
  ArcTestnet: ArcTestnet,
  Avalanche: Avalanche,
  AvalancheFuji: AvalancheFuji,
  Base: Base,
  BaseSepolia: BaseSepolia,
  Celo: Celo,
  CeloAlfajoresTestnet: CeloAlfajoresTestnet,
  Codex: Codex,
  CodexTestnet: CodexTestnet,
  Cronos: Cronos,
  CronosTestnet: CronosTestnet,
  Edge: Edge,
  EdgeTestnet: EdgeTestnet,
  Ethereum: Ethereum,
  EthereumSepolia: EthereumSepolia,
  Hedera: Hedera,
  HederaTestnet: HederaTestnet,
  HyperEVM: HyperEVM,
  HyperEVMTestnet: HyperEVMTestnet,
  Injective: Injective,
  InjectiveTestnet: InjectiveTestnet,
  Ink: Ink,
  InkTestnet: InkTestnet,
  Linea: Linea,
  LineaSepolia: LineaSepolia,
  Monad: Monad,
  MonadTestnet: MonadTestnet,
  Morph: Morph,
  MorphTestnet: MorphTestnet,
  NEAR: NEAR,
  NEARTestnet: NEARTestnet,
  Noble: Noble,
  NobleTestnet: NobleTestnet,
  Optimism: Optimism,
  OptimismSepolia: OptimismSepolia,
  Pharos: Pharos,
  PharosTestnet: PharosTestnet,
  Plasma: Plasma,
  PlasmaTestnet: PlasmaTestnet,
  Plume: Plume,
  PlumeTestnet: PlumeTestnet,
  PolkadotAssetHub: PolkadotAssetHub,
  PolkadotWestmint: PolkadotWestmint,
  Polygon: Polygon,
  PolygonAmoy: PolygonAmoy,
  Sei: Sei,
  SeiTestnet: SeiTestnet,
  Solana: Solana,
  SolanaDevnet: SolanaDevnet,
  Sonic: Sonic,
  SonicTestnet: SonicTestnet,
  Stellar: Stellar,
  StellarTestnet: StellarTestnet,
  Sui: Sui,
  SuiTestnet: SuiTestnet,
  Unichain: Unichain,
  UnichainSepolia: UnichainSepolia,
  WorldChain: WorldChain,
  WorldChainSepolia: WorldChainSepolia,
  XDC: XDC,
  XDCApothem: XDCApothem,
  XLayer: XLayer,
  XLayerTestnet: XLayerTestnet,
  ZKSyncEra: ZKSyncEra,
  ZKSyncEraSepolia: ZKSyncEraSepolia
};

/**
 * Check whether a given chain supports Gateway protocol version 1.
 *
 * This type guard function examines a chain definition to determine if it has Gateway v1
 * contract configurations. It checks that the chain has a gateway object with a
 * `contracts.v1` entry present.
 *
 * @param chain - The chain definition to check for Gateway v1 support
 * @returns `true` if `chain.gateway?.contracts?.v1` is defined, `false` otherwise
 *
 * @example
 * ```typescript
 * import { isGatewayV1Supported, Base } from '@core/chains'
 *
 * if (isGatewayV1Supported(Base)) {
 *   // TypeScript knows Base.gateway is defined here
 *   console.log('Gateway domain:', Base.gateway.domain)
 *   console.log('Wallet address:', Base.gateway.contracts.v1.wallet)
 *   console.log('Minter address:', Base.gateway.contracts.v1.minter)
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Usage in conditional flow
 * function getGatewayWalletAddress(chain: ChainDefinition): string | null {
 *   if (isGatewayV1Supported(chain)) {
 *     return chain.gateway.contracts.v1.wallet
 *   }
 *   return null
 * }
 * ```
 */ function isGatewayV1Supported(chain) {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- JS consumers may pass a gateway object without contracts
    return chain.gateway?.contracts?.v1 !== undefined;
}

/**
 * Zod schema for validating Gateway v1 contract addresses.
 *
 * @example
 * ```typescript
 * gatewayV1ContractsSchema.parse({
 *   wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *   minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 * })
 * ```
 */ const gatewayV1ContractsSchema = zod.z.object({
    wallet: zod.z.string({
        required_error: 'Gateway wallet address is required. Please provide a valid contract address.',
        invalid_type_error: 'Gateway wallet address must be a string.'
    }).min(1, 'Gateway wallet address cannot be empty.'),
    minter: zod.z.string({
        required_error: 'Gateway minter address is required. Please provide a valid contract address.',
        invalid_type_error: 'Gateway minter address must be a string.'
    }).min(1, 'Gateway minter address cannot be empty.'),
    depositForHandler: zod.z.string({
        invalid_type_error: 'Gateway depositForHandler address must be a string.'
    }).min(1, 'Gateway depositForHandler address cannot be empty.').optional()
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Zod schema for validating the versioned Gateway contracts map.
 *
 * @description Mirrors the {@link GatewayContracts} type: a partial map of
 * protocol versions to their contract addresses, following the same pattern
 * as {@link CCTPContracts}.
 *
 * @example
 * ```typescript
 * gatewayContractsSchema.parse({
 *   v1: {
 *     wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *     minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *   }
 * })
 * ```
 */ const gatewayContractsSchema = zod.z.object({
    v1: gatewayV1ContractsSchema.optional()
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Zod schema for validating the full Gateway configuration.
 *
 * @description Mirrors the {@link GatewayConfig} type: a domain number plus
 * a versioned contracts map, following the same pattern as {@link CCTPConfig}.
 *
 * @example
 * ```typescript
 * gatewayConfigSchema.parse({
 *   domain: 6,
 *   contracts: {
 *     v1: {
 *       wallet: '0x1234567890abcdef1234567890abcdef12345678',
 *       minter: '0xabcdef1234567890abcdef1234567890abcdef12'
 *     }
 *   }
 * })
 * ```
 */ const gatewayConfigSchema = zod.z.object({
    domain: zod.z.number({
        required_error: 'Gateway domain is required. Please provide a valid domain number.',
        invalid_type_error: 'Gateway domain must be a number.'
    }),
    contracts: gatewayContractsSchema,
    forwarderSupported: zod.z.object({
        source: zod.z.boolean(),
        destination: zod.z.boolean()
    })
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Base schema for common chain definition properties.
 * This contains all properties shared between EVM and non-EVM chains.
 */ const baseChainDefinitionSchema = zod.z.object({
    chain: zod.z.nativeEnum(exports.Blockchain, {
        required_error: 'Chain enum is required. Please provide a valid Blockchain enum value.',
        invalid_type_error: 'Chain must be a valid Blockchain enum value.'
    }),
    name: zod.z.string({
        required_error: 'Chain name is required. Please provide a valid chain name.',
        invalid_type_error: 'Chain name must be a string.'
    }),
    title: zod.z.string().optional(),
    nativeCurrency: zod.z.object({
        name: zod.z.string(),
        symbol: zod.z.string(),
        decimals: zod.z.number()
    }),
    isTestnet: zod.z.boolean({
        required_error: 'isTestnet is required. Please specify whether this is a testnet.',
        invalid_type_error: 'isTestnet must be a boolean.'
    }),
    explorerUrl: zod.z.string({
        required_error: 'Explorer URL is required. Please provide a valid explorer URL.',
        invalid_type_error: 'Explorer URL must be a string.'
    }),
    rpcEndpoints: zod.z.array(zod.z.string()),
    eurcAddress: zod.z.string().nullable(),
    usdcAddress: zod.z.string().nullable(),
    usdtAddress: zod.z.string().nullable(),
    cctp: zod.z.any().nullable(),
    kitContracts: zod.z.object({
        bridge: zod.z.string().optional(),
        adapter: zod.z.string().optional()
    }).optional(),
    gateway: gatewayConfigSchema.optional()
});
/**
 * Zod schema for validating EVM chain definitions specifically.
 * This schema extends the base schema with EVM-specific properties.
 *
 * @example
 * ```typescript
 * import { evmChainDefinitionSchema } from '@core/chains/validation'
 * import { Blockchain } from '@core/chains'
 *
 * const ethereumChain = {
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   name: 'Ethereum',
 *   chainId: 1,
 *   nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
 *   isTestnet: false,
 *   explorerUrl: 'https://etherscan.io/tx/{hash}',
 *   usdcAddress: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
 *   eurcAddress: null,
 *   cctp: null
 * }
 *
 * const result = evmChainDefinitionSchema.safeParse(ethereumChain)
 * if (result.success) {
 *   console.log('EVM chain definition is valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */ const evmChainDefinitionSchema = baseChainDefinitionSchema.extend({
    type: zod.z.literal('evm'),
    chainId: zod.z.number({
        required_error: 'EVM chains must have a chainId. Please provide a valid EVM chain ID.',
        invalid_type_error: 'EVM chain ID must be a number.'
    })
}).strict() //// Reject any additional properties not defined in the schema
;
/**
 * Zod schema for validating non-EVM chain definitions.
 * This schema extends the base schema with non-EVM specific properties.
 */ const nonEvmChainDefinitionSchema = baseChainDefinitionSchema.extend({
    type: zod.z.enum([
        'algorand',
        'avalanche',
        'solana',
        'aptos',
        'near',
        'stellar',
        'sui',
        'hedera',
        'noble',
        'polkadot'
    ])
}).strict() // Reject any additional properties not defined in the schema
;
/**
 * Discriminated union schema for all chain definitions.
 * This schema validates different chain types based on their 'type' field.
 *
 * @example
 * ```typescript
 * import { chainDefinitionSchema } from '@core/chains/validation'
 * import { Blockchain } from '@core/chains'
 *
 * // EVM chain
 * chainDefinitionSchema.parse({
 *   type: 'evm',
 *   chain: Blockchain.Ethereum,
 *   chainId: 1,
 *   // ... other properties
 * })
 *
 * // Non-EVM chain
 * chainDefinitionSchema.parse({
 *   type: 'solana',
 *   chain: Blockchain.Solana,
 *   // ... other properties (no chainId)
 * })
 * ```
 */ const chainDefinitionSchema = zod.z.discriminatedUnion('type', [
    evmChainDefinitionSchema,
    nonEvmChainDefinitionSchema
]);
/**
 * Zod schema for validating chain identifiers.
 * This schema accepts either a string blockchain identifier, a Blockchain enum value,
 * or a full ChainDefinition object.
 *
 * @example
 * ```typescript
 * import { chainIdentifierSchema } from '@core/chains/validation'
 * import { Blockchain, Ethereum } from '@core/chains'
 *
 * // All of these are valid:
 * chainIdentifierSchema.parse('Ethereum')
 * chainIdentifierSchema.parse(Blockchain.Ethereum)
 * chainIdentifierSchema.parse(Ethereum)
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>val in exports.Blockchain, 'Must be a valid Blockchain enum value as string'),
    zod.z.nativeEnum(exports.Blockchain),
    chainDefinitionSchema
]);
/**
 * Zod schema for validating swap-specific chain identifiers.
 *
 * Validates chains based on:
 * - CCTPv2 support (adapter contract deployed)
 * - Mainnet only (no testnets)
 * - At least one supported token available
 *
 */ zod.z.union([
    // String blockchain identifier (accepts SwapChain enum values)
    zod.z.string().refine((val)=>val in SwapChain, (val)=>({
            message: `"${val}" is not a supported swap chain. ` + `Supported chains: ${Object.values(SwapChain).join(', ')}`
        })),
    // SwapChain enum
    zod.z.nativeEnum(SwapChain),
    // ChainDefinition object (checks if chain.chain is in SwapChain)
    chainDefinitionSchema.refine((chain)=>chain.chain in SwapChain, (chain)=>({
            message: `"${chain.chain}" is not a supported swap chain. ` + `Supported chains: ${Object.values(SwapChain).join(', ')}`
        }))
]);
/**
 * Zod schema for validating bridge chain identifiers.
 *
 * This schema validates that the provided chain is supported for CCTPv2 bridging.
 * It accepts either a BridgeChain enum value, a string matching a BridgeChain value,
 * or a ChainDefinition for a supported chain.
 *
 * Use this schema when validating chain parameters for bridge operations to ensure
 * only CCTPv2-supported chains are accepted at runtime.
 *
 * @example
 * ```typescript
 * import { bridgeChainIdentifierSchema } from '@core/chains/validation'
 * import { BridgeChain, Chains } from '@core/chains'
 *
 * // Valid - BridgeChain enum value
 * bridgeChainIdentifierSchema.parse(BridgeChain.Ethereum)
 *
 * // Valid - string literal
 * bridgeChainIdentifierSchema.parse('Base_Sepolia')
 *
 * // Valid - ChainDefinition (validated by CCTP support)
 * bridgeChainIdentifierSchema.parse(Chains.Solana)
 *
 * // Invalid - Algorand is not in BridgeChain (throws ZodError)
 * bridgeChainIdentifierSchema.parse('Algorand')
 * ```
 *
 * @see {@link BridgeChain} for the enum of supported chains.
 */ zod.z.union([
    zod.z.string().refine((val)=>val in BridgeChain, (val)=>({
            message: `Chain "${val}" is not supported for bridging. Only chains in the BridgeChain enum support CCTPv2 bridging.`
        })),
    chainDefinitionSchema.refine((chainDef)=>chainDef.chain in BridgeChain, (chainDef)=>({
            message: `Chain "${chainDef.name}" (${chainDef.chain}) is not supported for bridging. Only chains in the BridgeChain enum support CCTPv2 bridging.`
        }))
]);
/**
 * Zod schema for validating earn-specific chain identifiers.
 *
 * Validate that the provided chain is supported for earn (vault
 * deposit/withdraw) operations. Currently only Arc Testnet is
 * supported.
 *
 * Accept an EarnChain enum value, a matching string literal, or
 * a ChainDefinition for a supported chain.
 *
 * @example
 * ```typescript
 * import { earnChainIdentifierSchema } from '@core/chains'
 * import { ArcTestnet, EarnChain } from '@core/chains'
 *
 * // Valid
 * earnChainIdentifierSchema.parse(EarnChain.Arc_Testnet)
 * earnChainIdentifierSchema.parse('Arc_Testnet')
 * earnChainIdentifierSchema.parse(ArcTestnet)
 *
 * // Invalid (throws ZodError)
 * earnChainIdentifierSchema.parse('Solana')
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>val in EarnChain, (val)=>({
            message: `"${val}" is not a supported earn chain. ` + `Supported chains: ${Object.values(EarnChain).join(', ')}`
        })),
    zod.z.nativeEnum(EarnChain),
    chainDefinitionSchema.refine((chain)=>chain.chain in EarnChain, (chain)=>({
            message: `"${chain.chain}" is not a supported earn chain. ` + `Supported chains: ${Object.values(EarnChain).join(', ')}`
        }))
]);
// Widened views so `.includes()` accepts arbitrary strings under strict TS.
const EARN_BRIDGE_SOURCE_CHAIN_VALUES = EARN_BRIDGE_SOURCE_BLOCKCHAINS;
const EARN_BRIDGE_DESTINATION_CHAIN_VALUES = EARN_BRIDGE_DESTINATION_BLOCKCHAINS;
/**
 * Zod schema for validating the source chain of a cross-chain Earn deposit.
 *
 * Accept a supported source Blockchain value, a matching string literal, or a
 * ChainDefinition for a supported source chain. Source chains are Ethereum
 * Sepolia, Arbitrum Sepolia, and Base Sepolia.
 *
 * @example
 * ```typescript
 * import { earnBridgeSourceChainIdentifierSchema } from '@core/chains'
 *
 * // Valid
 * earnBridgeSourceChainIdentifierSchema.parse('Ethereum_Sepolia')
 *
 * // Invalid (throws ZodError)
 * earnBridgeSourceChainIdentifierSchema.parse('Arc_Testnet')
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>EARN_BRIDGE_SOURCE_CHAIN_VALUES.includes(val), (val)=>({
            message: `"${val}" is not a supported cross-chain Earn source chain. ` + `Supported chains: ${EARN_BRIDGE_SOURCE_BLOCKCHAINS.join(', ')}`
        })),
    chainDefinitionSchema.refine((chain)=>EARN_BRIDGE_SOURCE_CHAIN_VALUES.includes(chain.chain), (chain)=>({
            message: `"${chain.chain}" is not a supported cross-chain Earn source chain. ` + `Supported chains: ${EARN_BRIDGE_SOURCE_BLOCKCHAINS.join(', ')}`
        }))
]);
/**
 * Zod schema for validating the destination chain of a cross-chain Earn
 * deposit.
 *
 * Accept a supported destination Blockchain value, a matching string literal,
 * or a ChainDefinition for a supported destination chain. Currently only Arc
 * Testnet is supported.
 *
 * @example
 * ```typescript
 * import { earnBridgeDestinationChainIdentifierSchema } from '@core/chains'
 *
 * // Valid
 * earnBridgeDestinationChainIdentifierSchema.parse('Arc_Testnet')
 *
 * // Invalid (throws ZodError)
 * earnBridgeDestinationChainIdentifierSchema.parse('Ethereum_Sepolia')
 * ```
 */ zod.z.union([
    zod.z.string().refine((val)=>EARN_BRIDGE_DESTINATION_CHAIN_VALUES.includes(val), (val)=>({
            message: `"${val}" is not a supported cross-chain Earn destination chain. ` + `Supported chains: ${EARN_BRIDGE_DESTINATION_BLOCKCHAINS.join(', ')}`
        })),
    chainDefinitionSchema.refine((chain)=>EARN_BRIDGE_DESTINATION_CHAIN_VALUES.includes(chain.chain), (chain)=>({
            message: `"${chain.chain}" is not a supported cross-chain Earn destination chain. ` + `Supported chains: ${EARN_BRIDGE_DESTINATION_BLOCKCHAINS.join(', ')}`
        }))
]);
/**
 * Zod schema for validating unified balance chain identifiers.
 *
 * This schema validates that the provided chain is supported for unified balance operations.
 * It accepts either a UnifiedBalanceChain enum value, a string matching a UnifiedBalanceChain value,
 * or a ChainDefinition for a supported chain.
 *
 * Use this schema when validating chain parameters for unified balance operations to ensure
 * only Gateway V1-supported chains are accepted at runtime.
 *
 * @example
 * ```typescript
 * import { unifiedBalanceChainIdentifierSchema } from '@core/chains/validation'
 * import { UnifiedBalanceChain, Chains } from '@core/chains'
 *
 * // Valid - UnifiedBalanceChain enum value
 * unifiedBalanceChainIdentifierSchema.parse(UnifiedBalanceChain.Ethereum)
 *
 * // Valid - string literal
 * unifiedBalanceChainIdentifierSchema.parse('Ethereum')
 *
 * // Invalid - Algorand is not in UnifiedBalanceChain (throws ZodError)
 * unifiedBalanceChainIdentifierSchema.parse('Algorand')
 * ```
 *
 * @see {@link UnifiedBalanceChain} for the enum of supported chains.
 */ const supportedUnifiedBalanceChains = Object.keys(UnifiedBalanceChain).join(', ');
zod.z.union([
    zod.z.string().refine((val)=>val in UnifiedBalanceChain, (val)=>({
            message: `Chain "${val}" is not supported for unified balance operations. Supported chains: ${supportedUnifiedBalanceChains}.`
        })),
    chainDefinitionSchema.refine((chainDef)=>chainDef.chain in UnifiedBalanceChain, (chainDef)=>({
            message: `Chain "${chainDef.name}" (${chainDef.chain}) is not supported for unified balance operations. Supported chains: ${supportedUnifiedBalanceChains}.`
        }))
]);

// Internal enum used after input normalization.
const swapTokenEnumSchema = zod.z.enum([
    ...Object.keys(SWAP_TOKEN_REGISTRY),
    NATIVE_TOKEN
]);
/**
 * Zod schema for validating supported swap token symbols.
 *
 * Accepts any token symbol from the SWAP_TOKEN_REGISTRY plus NATIVE.
 * Input matching is case-insensitive and normalized to uppercase.
 *
 * @example
 * ```typescript
 * import { supportedSwapTokenSchema } from '@core/chains'
 *
 * const result = supportedSwapTokenSchema.safeParse('USDC')
 * if (result.success) {
 *   console.log('Valid swap token:', result.data)
 * }
 * ```
 */ zod.z.string().transform((value)=>value.toUpperCase()).pipe(swapTokenEnumSchema);

/**
 * Get all supported EVM chain definitions.
 *
 * This function searches through all available blockchain definitions and returns
 * only those that are EVM-compatible. It provides a comprehensive list of all
 * EVM chains supported by the App Kits ecosystem.
 *
 * @returns Array of all EVM chain definitions supported by the library
 *
 * @example
 * ```typescript
 * import { getAllEvmChains } from '@core/chains'
 *
 * const evmChains = getAllEvmChains()
 * console.log(`Found ${evmChains.length} EVM chains`)
 *
 * // List all EVM chain names
 * evmChains.forEach(chain => {
 *   console.log(`- ${chain.name} (Chain ID: ${chain.chainId})`)
 * })
 *
 * // Use for adapter capabilities
 * const capabilities = {
 *   addressContext: 'user-controlled',
 *   supportedChains: getAllEvmChains() // Support all EVM chains
 * }
 * ```
 *
 * @example
 * ```typescript
 * import { getAllEvmChains } from '@core/chains'
 *
 * // Filter for mainnet chains only
 * const mainnetChains = getAllEvmChains().filter(chain => !chain.isTestnet)
 *
 * // Filter for specific chains
 * const layer2Chains = getAllEvmChains().filter(chain =>
 *   ['Base', 'Polygon', 'Arbitrum', 'Optimism'].includes(chain.name)
 * )
 * ```
 */ function getAllEvmChains() {
    return Object.values(Blockchains).filter((chain)=>chain.type === 'evm');
}

/**
 * Retrieve a chain definition by its blockchain enum value.
 *
 * Searches the set of known chain definitions and returns the one matching the provided
 * blockchain enum or string value. Throws an error if no matching chain is found.
 *
 * @param blockchain - The blockchain enum or its string representation to look up.
 * @returns The corresponding ChainDefinition object for the given blockchain.
 *
 * @throws Error If no chain definition is found for the provided enum value.
 *
 * @example
 * ```typescript
 * import { getChainByEnum } from '@core/chains'
 * import { Blockchain } from '@core/chains'
 *
 * const ethereum = getChainByEnum(Blockchain.Ethereum)
 * console.log(ethereum.name) // "Ethereum"
 * ```
 */ const getChainByEnum = (blockchain)=>{
    const chain = Object.values(Blockchains).find((chain)=>{
        return chain.chain === blockchain;
    });
    if (!chain) {
        throw new Error(`No chain definition found for blockchain: ${blockchain}`);
    }
    return chain;
};

/**
 * Resolves a flexible chain identifier to a ChainDefinition.
 *
 * This function handles all three supported formats:
 * - ChainDefinition objects (passed through unchanged)
 * - Blockchain enum values (resolved via getChainByEnum)
 * - String literals of blockchain values (resolved via getChainByEnum)
 *
 * @param chainIdentifier - The chain identifier to resolve
 * @returns The resolved ChainDefinition object
 * @throws Error if the chain identifier cannot be resolved
 *
 * @example
 * ```typescript
 * import { resolveChainIdentifier } from '@core/chains'
 * import { Blockchain, Ethereum } from '@core/chains'
 *
 * // All of these resolve to the same ChainDefinition:
 * const chain1 = resolveChainIdentifier(Ethereum)
 * const chain2 = resolveChainIdentifier(Blockchain.Ethereum)
 * const chain3 = resolveChainIdentifier('Ethereum')
 * ```
 */ function resolveChainIdentifier(chainIdentifier) {
    // Handle null explicitly (typeof null === 'object' in JavaScript)
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
    if (chainIdentifier === null) {
        throw new Error(`Invalid chain identifier type: null. Expected ChainDefinition object, Blockchain enum, or string literal.`);
    }
    // If it's already a ChainDefinition object, return it unchanged
    if (typeof chainIdentifier === 'object') {
        return chainIdentifier;
    }
    // If it's a string or enum value, resolve it via getChainByEnum
    if (typeof chainIdentifier === 'string') {
        return getChainByEnum(chainIdentifier);
    }
    // This should never happen with proper typing, but provide a fallback
    throw new Error(`Invalid chain identifier type: ${typeof chainIdentifier}. Expected ChainDefinition object, Blockchain enum, or string literal.`);
}

/**
 * Extract the default RPC endpoint from a chain definition.
 *
 * This utility function provides a standardized way to access the primary
 * RPC endpoint from a chain definition. It returns the first endpoint in
 * the rpcEndpoints array, which is considered the primary/default endpoint.
 *
 * @param chain - The chain definition containing RPC endpoints
 * @returns The default RPC endpoint URL
 * @throws Error when no RPC endpoints are available
 *
 * @example
 * ```typescript
 * import { getDefaultRpcEndpoint } from '@core/chains'
 * import { Ethereum } from '@core/chains'
 *
 * // Get the default RPC endpoint for Ethereum
 * const rpcUrl = getDefaultRpcEndpoint(Ethereum)
 * console.log(rpcUrl) // "https://cloudflare-eth.com"
 * ```
 *
 * @example
 * ```typescript
 * import { getDefaultRpcEndpoint } from '@core/chains'
 * import { resolveChainIdentifier } from '@core/chains'
 *
 * // Use with dynamic chain resolution
 * const chain = resolveChainIdentifier('Polygon')
 * const rpcUrl = getDefaultRpcEndpoint(chain)
 * console.log(rpcUrl) // "https://polygon.publicnode.com"
 * ```
 *
 * @example
 * ```typescript
 * import { getDefaultRpcEndpoint } from '@core/chains'
 * import { createPublicClient, http } from 'viem'
 * import { getViemChainByEnum } from '@adapters/viem.v2'
 *
 * // Use with viem PublicClient creation
 * const chain = resolveChainIdentifier('Ethereum')
 * const viemChain = getViemChainByEnum(chain.chain)
 * const rpcUrl = getDefaultRpcEndpoint(chain)
 *
 * const publicClient = createPublicClient({
 *   chain: viemChain,
 *   transport: http(rpcUrl)
 * })
 * ```
 */ function getDefaultRpcEndpoint(chain) {
    const defaultEndpoint = chain.rpcEndpoints[0];
    if (defaultEndpoint === undefined || defaultEndpoint === '') {
        throw new Error(`No RPC endpoints found for chain ${chain.name}. Please ensure the chain definition includes default RPC endpoints.`);
    }
    return defaultEndpoint;
}

/**
 * Type-safe registry for managing and executing blockchain action handlers.
 *
 * Provides a centralized system for registering action handlers with full
 * TypeScript type safety, ensuring that handlers can only be registered
 * with compatible action keys and payload types. Supports both individual
 * handler registration and batch registration operations.
 *
 * @remarks
 * The registry uses a Map internally for O(1) lookups and maintains type
 * safety through generic constraints and careful type assertions. All
 * type assertions are validated at registration time to ensure runtime
 * type safety matches compile-time guarantees.
 */ class ActionRegistry {
    actionHandlers = new Map();
    /**
   * Register a type-safe action handler for a specific action key.
   *
   * Associates an action handler function with its corresponding action key,
   * ensuring compile-time type safety between the action and its expected
   * payload structure. The handler will be available for execution via
   * {@link executeAction}.
   *
   * @typeParam TActionKey - The specific action key being registered.
   * @param action - The action key to register the handler for.
   * @param handler - The handler function for processing this action type.
   * @returns Void.
   *
   * @throws Error When action parameter is not a valid string.
   * @throws TypeError When handler parameter is not a function.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   * import type { ActionHandler } from '@core/adapter'
   *
   * const registry = new ActionRegistry()
   *
   * // Register a CCTP deposit handler
   * const depositHandler: ActionHandler<'cctp.v2.depositForBurn'> = async (params, resolved) => {
   *   console.log('Processing deposit:', params.amount)
   *   return {
   *     chainId: params.chainId,
   *     data: '0x...',
   *     to: '0x...',
   *     value: '0'
   *   }
   * }
   *
   * registry.registerHandler('cctp.v2.depositForBurn', depositHandler)
   * ```
   */ registerHandler(action, handler) {
        // Runtime validation for JavaScript consumers
        if (typeof action !== 'string' || action.length === 0) {
            throw new TypeError(`Action must be a non-empty string, received: ${typeof action}`);
        }
        if (typeof handler !== 'function') {
            throw new TypeError(`Handler must be a function, received: ${typeof handler}`);
        }
        // The handler is upcast to ActionHandler<ActionKeys> for storage,
        // but type safety is maintained at the call site through the generic constraint
        this.actionHandlers.set(action, handler);
    }
    /**
   * Register multiple action handlers in a single operation.
   *
   * Efficiently register multiple handlers from a record object, where keys
   * are action identifiers and values are their corresponding handler
   * functions. Provides a convenient way to bulk-register handlers while
   * maintaining type safety.
   *
   * @param handlers - A record mapping action keys to their handler functions.
   * @returns Void.
   *
   * @throws {Error} When handlers parameter is not a valid object.
   * @throws {Error} When any individual handler registration fails.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   * import type { ActionHandler, ActionHandlers } from '@core/adapter'
   *
   * const registry = new ActionRegistry()
   *
   * // Register multiple handlers at once
   * const tokenHandlers: ActionHandlers = {
   *   'token.approve': async (params, resolved) => ({
   *     chainId: resolved.chain,
   *     data: '0x095ea7b3...',
   *     to: params.tokenAddress,
   *     value: '0'
   *   }),
   *   'token.transfer': async (params, resolved) => ({
   *     chainId: resolved.chain,
   *     data: '0xa9059cbb...',
   *     to: params.tokenAddress,
   *     value: '0'
   *   })
   * }
   *
   * registry.registerHandlers(tokenHandlers)
   * console.log('Registered multiple token handlers')
   * ```
   */ registerHandlers(handlers) {
        // Runtime validation for JavaScript consumers
        if (typeof handlers !== 'object' || handlers === null) {
            throw new Error(`Handlers must be a non-null object, received: ${typeof handlers}`);
        }
        // Register each handler individually to benefit from per-handler validation
        for (const [action, handler] of Object.entries(handlers)){
            this.registerHandler(action, handler);
        }
    }
    /**
   * Check whether a specific action is supported by this registry.
   *
   * Determine if a handler has been registered for the given action key.
   * Use this method to conditionally execute actions or provide appropriate
   * error messages when actions are not available.
   *
   * @param action - The action key to check for support.
   * @returns True if the action is supported, false otherwise.
   *
   * @throws {Error} When action parameter is not a valid string.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   *
   * const registry = new ActionRegistry()
   *
   * // Check if actions are supported before attempting to use them
   * if (registry.supportsAction('token.approve')) {
   *   console.log('Token approval is supported')
   * } else {
   *   console.log('Token approval not available')
   * }
   *
   * // Conditional logic based on support
   * const action = 'cctp.v2.depositForBurn'
   * if (registry.supportsAction(action)) {
   *   // Safe to execute
   *   console.log(`${action} is available`)
   * } else {
   *   console.warn(`${action} is not registered`)
   * }
   * ```
   */ supportsAction(action) {
        // Runtime validation for JavaScript consumers
        if (typeof action !== 'string' || action.length === 0) {
            throw new TypeError(`Action must be a non-empty string, received: ${typeof action}`);
        }
        return this.actionHandlers.has(action);
    }
    /**
   * Execute a registered action handler with type-safe parameters.
   *
   * Look up and execute the handler associated with the given action key,
   * passing the provided parameters and context, returning the resulting prepared
   * chain request. TypeScript ensures the parameters match the expected
   * structure for the specified action.
   *
   * @typeParam TActionKey - The specific action key being executed.
   * @param action - The action key identifying which handler to execute.
   * @param params - The parameters to pass to the action handler.
   * @param context - The resolved operation context with concrete chain and address values.
   * @returns A promise resolving to the prepared chain request.
   * @throws {KitError} When the handler execution fails with a structured error.
   * @throws {Error} When no handler is registered for the specified action.
   * @throws {Error} When the handler execution fails with an unstructured error.
   *
   * @example
   * ```typescript
   * import { ActionRegistry } from '@core/adapter'
   * import type { ChainEnum } from '@core/chains'
   *
   * const registry = new ActionRegistry()
   *
   * // First register a handler
   * registry.registerHandler('token.approve', async (params, context) => ({
   *   chainId: context.chain, // Always defined
   *   data: '0x095ea7b3...',
   *   to: params.tokenAddress,
   *   value: '0'
   * }))
   *
   * // Execute the action with resolved context (typically called from adapter.prepareAction)
   * const resolvedContext = { chain: 'Base', address: '0x123...' }
   * const result = await registry.executeAction('token.approve', {
   *   chainId: ChainEnum.Ethereum,
   *   tokenAddress: '0xA0b86a33E6441c8C1c7C16e4c5e3e5b5e4c5e3e5b5e4c5e',
   *   delegate: '0x1234567890123456789012345678901234567890',
   *   amount: '1000000'
   * }, resolvedContext)
   *
   * console.log('Transaction prepared:', result.data)
   * ```
   */ async executeAction(action, params, context) {
        // Runtime validation for JavaScript consumers
        if (typeof action !== 'string' || action.length === 0) {
            throw new TypeError(`Action must be a non-empty string, received: ${typeof action}`);
        }
        const handler = this.actionHandlers.get(action);
        if (!handler) {
            throw new Error(`Action ${action} is not supported`);
        }
        try {
            // Type safety is guaranteed by the registration process
            return await handler(params, context);
        } catch (error) {
            // If it's already a KitError with structured information, re-throw as-is
            // to preserve error code, name, type, recoverability, and cause
            if (error instanceof KitError) {
                throw error;
            }
            // For other errors, re-throw with context for better debugging
            const message = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to execute action ${action}: ${message}`);
        }
    }
}

/**
 * Canonical list of actions that do not prepare or submit transactions.
 *
 * @internal
 */ const READ_ACTION_KEYS = [
    'token.allowance',
    'token.balanceOf',
    'token.name',
    'native.balanceOf',
    'usdc.allowance',
    'usdc.balanceOf',
    'usdc.name',
    'gateway.v1.isDelegate',
    'gateway.v1.withdrawingBalance',
    'gateway.v1.withdrawalBlock',
    'gateway.v1.signBurnIntents'
];
const READ_ACTION_KEY_SET = new Set(READ_ACTION_KEYS);
/**
 * Check whether a runtime value identifies a read action.
 *
 * @param action - The value to classify.
 * @returns Whether the value is a registered read-action key.
 *
 * @example
 * ```typescript
 * import { isReadActionKey } from '@core/adapter'
 *
 * if (isReadActionKey(value)) {
 *   await adapter.readAction(value, params, context)
 * }
 * ```
 *
 * @internal
 */ function isReadActionKey(action) {
    return typeof action === 'string' && READ_ACTION_KEY_SET.has(action);
}

/**
 * Resolves an operation context into concrete chain and address values.
 *
 * This function ensures that action handlers always receive defined chain and address
 * values by applying validation and resolution logic based on the adapter's capabilities.
 * It enforces compile-time and runtime address requirements based on the adapter's
 * address control model.
 *
 * **Resolution logic**:
 * - **Chain**: Uses provided chain identifier and resolves to ChainDefinition
 * - **Address**:
 *   - For user-controlled adapters: Retrieves current address from adapter (context address ignored)
 *   - For developer-controlled adapters: Uses address provided in context (required)
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type for compile-time validation
 * @param adapter - The typed adapter instance with capabilities defined
 * @param ctx - Operation context with compile-time validated address requirements
 * @returns Promise resolving to concrete chain and address values
 * @throws Error when adapter capabilities are not defined
 * @throws Error when operation context is not provided
 * @throws Error when address is required but not provided (developer-controlled)
 * @throws Error when adapter.getAddress() fails (user-controlled)
 *
 * @example
 * ```typescript
 * import { resolveOperationContext } from '@core/adapter'
 *
 * // User-controlled adapter - address forbidden in context
 * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
 * const resolved = await resolveOperationContext(userAdapter, {
 *   chain: 'Base' // address will be resolved from wallet
 * })
 * console.log(resolved.chain)   // ChainDefinition - always defined
 * console.log(resolved.address) // string - resolved from adapter
 *
 * // Developer-controlled adapter - address required in context
 * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
 * const resolved = await resolveOperationContext(devAdapter, {
 *   chain: 'Base',
 *   address: '0x123...' // Required and enforced at compile time
 * })
 * console.log(resolved.address) // '0x123...' - from context
 * ```
 */ async function resolveOperationContext(adapter, ctx) {
    // Adapter must have capabilities defined
    if (adapter.capabilities === undefined) {
        throw new Error('Adapter capabilities must be defined. Please ensure the adapter implements the capabilities property.');
    }
    // Operation context is required for new typed adapters
    if (ctx === undefined) {
        throw new Error('Operation context is required. Please provide a context with the required chain and address information.');
    }
    // Resolve chain from context (required)
    const resolvedChain = resolveChainIdentifier(ctx.chain);
    // Resolve address based on adapter capabilities
    let resolvedAddress;
    if (adapter.capabilities.addressContext === 'developer-controlled') {
        // Developer-controlled: address must be explicitly provided
        if (!ctx.address) {
            throw new Error('Address is required for developer-controlled adapters. Please provide an address in the operation context.');
        }
        resolvedAddress = ctx.address;
    } else {
        // User-controlled: get current address from adapter
        try {
            // Pass resolved chain to getAddress for adapters that support it (like ViemAdapter)
            // The chain parameter is optional in implementations, so this is safe
            resolvedAddress = await adapter.getAddress(resolvedChain);
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            throw new Error(`Failed to resolve address from user-controlled adapter: ${message}`);
        }
    }
    return {
        chain: resolvedChain,
        address: resolvedAddress
    };
}

/**
 * Create the standard error for a missing or non-read action.
 *
 * @param action - The unsupported action value.
 * @returns A fatal unsupported-action error.
 *
 * @internal
 */ function createUnsupportedReadActionError(action) {
    return new KitError({
        ...InputError.UNSUPPORTED_ACTION,
        recoverability: 'FATAL',
        message: `Read action "${String(action)}" is not registered in this adapter.`
    });
}
/**
 * Execute a read through the adapter's dedicated read seam when available.
 *
 * @remarks
 * Fall back to the legacy `prepareAction().execute()` contract so providers
 * remain runtime-compatible with adapter versions released before `readAction`.
 * Consumers must upgrade their adapter package for reads to bypass custom
 * `prepareAction` wrappers.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type.
 * @typeParam TActionKey - The read action key.
 * @param adapter - The adapter that owns the read action.
 * @param action - The read action to execute.
 * @param params - The parameters for the read action.
 * @param ctx - The operation context.
 * @returns The raw read-action result.
 * @throws {KitError} When `action` is not a supported read-action key.
 *
 * @example
 * ```typescript
 * import { executeAdapterReadAction } from '@core/adapter'
 * import { Ethereum } from '@core/chains'
 *
 * const allowance = await executeAdapterReadAction(
 *   adapter,
 *   'token.allowance',
 *   { tokenAddress, delegate },
 *   { chain: Ethereum },
 * )
 * ```
 *
 * @internal
 */ async function executeAdapterReadAction(adapter, action, params, ctx) {
    if (!isReadActionKey(action)) {
        throw createUnsupportedReadActionError(action);
    }
    const runtimeAdapter = adapter;
    if (typeof runtimeAdapter.readAction === 'function') {
        return runtimeAdapter.readAction(action, params, ctx);
    }
    let request;
    try {
        request = await adapter.prepareAction(action, params, ctx);
    } catch (error) {
        if (error instanceof Error && error.message === `Action ${action} is not supported`) {
            throw createUnsupportedReadActionError(action);
        }
        throw error;
    }
    return request.execute();
}
/**
 * Read and parse a token allowance while supporting older adapter versions.
 *
 * @remarks
 * Prefer the adapter's dedicated read seam and fall back to the legacy
 * `prepareAction().execute()` contract when the runtime adapter predates it.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type.
 * @param adapter - The adapter that owns the allowance action.
 * @param params - The token and delegate whose allowance is being read.
 * @param ctx - The operation context.
 * @returns The non-negative allowance in token base units.
 * @throws {KitError} When the action is unsupported or its response is malformed.
 *
 * @example
 * ```typescript
 * import { readTokenAllowance } from '@core/adapter'
 * import { Ethereum } from '@core/chains'
 *
 * const allowance = await readTokenAllowance(
 *   adapter,
 *   { tokenAddress, delegate },
 *   { chain: Ethereum },
 * )
 * ```
 *
 * @internal
 */ async function readTokenAllowance(adapter, params, ctx) {
    return parseAllowanceResponse(await executeAdapterReadAction(adapter, 'token.allowance', params, ctx));
}
/**
 * Parse a raw token allowance response into base units.
 *
 * @param allowanceRaw - The adapter response, optionally wrapped as an Amount output.
 * @returns The non-negative allowance as a bigint, or zero for a missing value.
 * @throws {KitError} When the response cannot represent a non-negative bigint.
 *
 * @example
 * ```typescript
 * import { parseAllowanceResponse } from '@core/adapter'
 *
 * const allowance = parseAllowanceResponse({ amount: { raw: 1000000n } })
 * ```
 */ function parseAllowanceResponse(allowanceRaw) {
    let value = allowanceRaw;
    if (typeof value === 'object' && value !== null && 'amount' in value) {
        const amount = value.amount;
        if (typeof amount === 'object' && amount !== null && 'raw' in amount) {
            value = amount.raw;
        }
    }
    if (value === undefined || value === null) {
        return 0n;
    }
    let allowance;
    if (typeof value === 'bigint') {
        allowance = value;
    } else if (typeof value === 'string') {
        try {
            allowance = BigInt(value);
        } catch  {
            allowance = undefined;
        }
    }
    if (allowance === undefined || allowance < 0n) {
        throw createValidationFailedError('token.allowance', value, 'token.allowance response must be a non-negative bigint-compatible string or bigint');
    }
    return allowance;
}

/**
 * Abstract class defining the standard interface for an adapter that interacts with a specific blockchain.
 *
 * An `Adapter` is responsible for encapsulating chain-specific logic necessary to
 * perform operations like sending transactions, querying balances, or interacting with smart contracts.
 * Implementations of this class will provide concrete logic for a particular blockchain protocol.
 *
 * This abstraction allows the App Kit to work with multiple blockchains in a uniform way.
 *
 * @typeParam TAdapterCapabilities - The adapter capabilities type for compile-time address validation.
 * When provided, enables strict typing of operation context based on the adapter's address control model.
 */ class Adapter {
    /**
   * Capabilities of this adapter, defining address control model and supported chains.
   *
   * This property determines how the adapter behaves, especially for address selection
   * and bridge API requirements. The `addressContext` must match the adapter's type parameter.
   *
   * @remarks
   * The `addressContext` value must align with the adapter's generic type parameter for proper
   * type safety in bridge operations.
   *
   * @example
   * ```typescript
   * // User-controlled adapter (private key, browser wallet)
   * capabilities = {
   *   addressContext: 'user-controlled', // Address implicit in bridge operations
   *   supportedChains: [Ethereum, Base, Polygon]
   * }
   *
   * // Developer-controlled adapter (enterprise provider)
   * capabilities = {
   *   addressContext: 'developer-controlled', // Address required in bridge operations
   *   supportedChains: [Ethereum, Base, Solana]
   * }
   * ```
   */ capabilities;
    /**
   * Registry of available actions for this adapter.
   *
   * The {@link ActionRegistry} provides a catalog of supported operations
   * (such as token transfers, approvals, etc.) that can be performed by this adapter
   * on the connected blockchain. This enables dynamic discovery and invocation
   * of chain-specific or cross-chain actions in a type-safe manner.
   *
   * @readonly
   */ actionRegistry = new ActionRegistry();
    /**
   * Prepares (but does not execute) an action for the connected blockchain.
   *
   * This method looks up the appropriate action handler for the given action key
   * and prepares the transaction request using the provided parameters. The returned
   * {@link PreparedChainRequest} allows developers to estimate gas costs and execute
   * the transaction at a later time, enabling pre-flight simulation and deferred execution.
   *
   * **Compile-time Address Validation**: When used with typed adapters that have capabilities,
   * this method enforces address requirements at compile time:
   * - **User-controlled adapters**: The `address` field is forbidden in the context
   * - **Developer-controlled adapters**: The `address` field is required in the context
   * - **Legacy adapters**: The `address` field remains optional for backward compatibility
   *
   * @remarks
   * This method does not send any transaction to the network. Instead, it returns a
   * prepared request object with `estimate()` and `execute()` methods, allowing
   * developers to inspect, simulate, or submit the transaction as needed.
   *
   * @param action - The action key identifying which handler to use for preparation.
   * @param params - The parameters to pass to the action handler.
   * @param ctx - Operation context with compile-time validated address requirements based on adapter capabilities.
   * @returns A promise that resolves to a {@link PreparedChainRequest} for estimation and execution.
   * @throws Error If the specified action key does not correspond to a registered handler.
   * @throws Error If the provided parameters are invalid for the action.
   * @throws Error If the operation context cannot be resolved.
   *
   * @example
   * ```typescript
   * // User-controlled adapter (address forbidden)
   * const userAdapter: Adapter<{ addressContext: 'user-controlled', supportedChains: [] }>
   * await userAdapter.prepareAction('token.approve', params, {
   *   chain: 'Ethereum'
   *   // address: '0x123...' // ❌ TypeScript error: address not allowed
   * })
   *
   * // Developer-controlled adapter (address required)
   * const devAdapter: Adapter<{ addressContext: 'developer-controlled', supportedChains: [] }>
   * await devAdapter.prepareAction('token.approve', params, {
   *   chain: 'Ethereum',
   *   address: '0x123...' // ✅ Required for developer-controlled
   * })
   * ```
   */ async prepareAction(action, params, ctx) {
        // Only prepares the action; does not execute it.
        // The returned PreparedChainRequest allows for estimation and execution.
        // Resolve the operation context to ensure handlers receive concrete values
        const resolvedContext = await resolveOperationContext(this, ctx);
        return this.actionRegistry.executeAction(action, params, resolvedContext);
    }
    /**
   * Execute a non-transaction action without routing through transaction preparation.
   *
   * @remarks
   * Use this seam for balance, allowance, contract-state, and other actions
   * classified as reads. It never calls {@link Adapter.prepareAction}, so
   * transaction authorization wrappers only observe actions that can produce a
   * signable chain request.
   *
   * @typeParam TActionKey - The read action key.
   * @param action - The read action to execute.
   * @param params - The parameters for the read action.
   * @param ctx - The operation context.
   * @returns The raw action response.
   * @throws {KitError} When the key is not a read action or no handler is registered.
   * @throws Error When the operation context or action handler fails.
   *
   * @example
   * ```typescript
   * import { Ethereum } from '@core/chains'
   *
   * const balance = await adapter.readAction(
   *   'token.balanceOf',
   *   { tokenAddress, walletAddress },
   *   { chain: Ethereum },
   * )
   * ```
   *
   * @internal
   */ async readAction(action, params, ctx) {
        if (!isReadActionKey(action) || !this.actionRegistry.supportsAction(action)) {
            throw createUnsupportedReadActionError(action);
        }
        const resolvedContext = await resolveOperationContext(this, ctx);
        const request = await this.actionRegistry.executeAction(action, params, resolvedContext);
        return request.execute();
    }
    /**
   * Read the current token allowance a delegate holds over an owner's tokens.
   *
   * @remarks
   * Perform a network read through {@link Adapter.readAction}. This method
   * never routes through {@link Adapter.prepareAction}. On chains without an
   * allowance model, such as Solana, return the maximum uint256 value.
   *
   * @param params - The token to query and the delegate whose allowance is being read.
   * @param ctx - Operation context with compile-time validated address requirements.
   * @returns A promise resolving to the current allowance in the token's base units.
   * @throws {KitError} When the adapter does not register a `token.allowance` handler.
   * @throws Error When the operation context or action handler fails.
   *
   * @example
   * ```typescript
   * import type { Adapter } from '@core/adapter'
   * import { Ethereum } from '@core/chains'
   *
   * declare const adapter: Adapter
   *
   * const allowance = await adapter.getTokenAllowance(
   *   {
   *     tokenAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
   *     delegate: '0x1111111111111111111111111111111111111111',
   *   },
   *   { chain: Ethereum },
   * )
   * console.log(allowance) // 1000000n
   * ```
   */ async getTokenAllowance(params, ctx) {
        return readTokenAllowance(this, params, ctx);
    }
    /**
   * Ensures the adapter is operating on the specified chain, switching if necessary.
   *
   * This method provides a unified interface for establishing chain preconditions across different adapter types.
   * The behavior varies based on the adapter's capabilities:
   * - **Private key adapters**: Recreate clients with new RPC endpoints
   * - **Browser wallet adapters**: Request chain switch via EIP-1193 or equivalent
   * - **Multi-entity adapters**: Validate chain support (operations are contextual)
   *
   * @param chain - The target chain for operations.
   * @returns A promise that resolves when the adapter is operating on the specified chain.
   * @throws When the target chain is not supported or chain switching fails.
   *
   * @remarks
   * This method always calls `switchToChain()` to ensure consistency across all adapter types.
   * The underlying implementations handle idempotent switching efficiently (e.g., browser wallets
   * gracefully handle switching to the current chain, private key adapters recreate lightweight clients).
   *
   * @example
   * ```typescript
   * // Private key adapter - switches chains seamlessly
   * await privateKeyAdapter.ensureChain(Base)
   *
   * // Browser wallet - requests user to switch chains
   * await metamaskAdapter.ensureChain(Polygon)
   *
   * // Multi-entity adapter - validates chain is supported
   * await circleWalletsAdapter.ensureChain(Ethereum)
   * ```
   */ async ensureChain(targetChain) {
        this.validateChainSupport(targetChain);
        // Always delegate to switchToChain - implementations handle idempotent switching
        try {
            await this.switchToChain(targetChain);
        } catch (error) {
            throw new Error(`Failed to switch to chain ${targetChain.name}: ${error instanceof Error ? error.message : String(error)}`);
        }
    }
    /**
   * Validate that the target chain is supported by this adapter.
   *
   * @param targetChain - The chain to validate.
   * @throws KitError with INVALID_CHAIN code if the chain is not supported by this adapter.
   */ validateChainSupport(targetChain) {
        if (this.capabilities?.supportedChains) {
            const isSupported = this.capabilities.supportedChains.some((supportedChain)=>supportedChain.chain === targetChain.chain);
            if (!isSupported) {
                const supportedCount = this.capabilities.supportedChains.length;
                // List supported chain names for better user experience
                const supportedChainNames = this.capabilities.supportedChains.map((chainDef)=>chainDef.name).join(', ');
                const reason = `Not supported by this adapter. It supports ${supportedCount.toString()} ${supportedCount === 1 ? 'chain' : 'chains'}: ${supportedChainNames}`;
                throw createInvalidChainError(targetChain.name, reason);
            }
        } else if (this.chainType && targetChain.type !== this.chainType) {
            const reason = `Chain type mismatch: adapter supports ${this.chainType} chains, but received ${targetChain.type ?? 'unknown'} chain`;
            throw createInvalidChainError(targetChain.name, reason);
        }
    }
}

// Import global type declarations
/**
 * Check whether the current runtime is Node.js.
 *
 * @returns `true` when running in Node.js, `false` otherwise.
 *
 * @example
 * ```typescript
 * import { isNodeEnvironment } from '@core/utils'
 *
 * if (isNodeEnvironment()) {
 *   console.log('Running in Node.js')
 * }
 * ```
 */ const isNodeEnvironment = ()=>typeof process !== 'undefined' && typeof process.versions === 'object' && typeof process.versions.node === 'string';

/**
 * Validates data against a Zod schema and throws a KitError on failure.
 *
 * This utility function provides consistent validation and error formatting across the codebase.
 * It performs the validation and formats error messages with contextual information while
 * preserving all individual validation errors in a structured format.
 *
 * @param value - The value to validate
 * @param schema - The Zod schema to validate against
 * @param message - Error message (e.g., 'Invalid EVM address', 'Configuration error')
 * @returns Asserts that value is of type T (type narrowing)
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098) and detailed error information
 *
 * @example
 * ```typescript
 * import { validateOrThrow } from '@core/utils'
 * import { z } from 'zod'
 *
 * const userSchema = z.object({
 *   name: z.string().min(3),
 *   age: z.number().positive()
 * })
 *
 * // This will throw KitError if validation fails
 * validateOrThrow({ name: 'Jo', age: -1 }, userSchema, 'Invalid user data')
 * // Throws: KitError with code 1098 and message "Invalid user data: name: String must contain at least 3 character(s)"
 * ```
 *
 * @example
 * ```typescript
 * // Usage in assertion functions with flexible messaging
 * validateOrThrow(address, evmAddressSchema, 'Invalid EVM address')
 * validateOrThrow(config, configSchema, 'Configuration error')
 * validateOrThrow(params, paramSchema, 'Bad parameters')
 * ```
 *
 * @example
 * ```typescript
 * // Usage in validation functions
 * function validateUserParams(params: unknown): void {
 *   validateOrThrow(params, userSchema, 'Invalid user parameters')
 *   // If we reach here, params is guaranteed to be valid
 * }
 * ```
 */ function validateOrThrow(value, schema, message) {
    const result = schema.safeParse(value);
    if (!result.success) {
        throw createValidationErrorFromZod(result.error, message);
    }
}

/**
 * Detect the format of the provided address string.
 *
 * Analyzes the address format and returns the corresponding chain type or bytes32
 * format. Supports EVM addresses (0x-prefixed 40-char hex), bytes32 addresses
 * (0x-prefixed 64-char hex), and Solana addresses (base58 encoded 32-byte keys).
 *
 * @param address - The address string to analyze.
 * @returns The detected format: 'evm', 'solana', or 'bytes32'.
 * @throws Error if the address format is unrecognized.
 *
 * @example
 * ```typescript
 * import { detectFormat } from '@core/utils'
 *
 * // EVM address
 * const evmFormat = detectFormat('0x1234567890abcdef1234567890abcdef12345678')
 * console.log(evmFormat) // 'evm'
 *
 * // Solana address
 * const solanaFormat = detectFormat('11111111111111111111111111111112')
 * console.log(solanaFormat) // 'solana'
 *
 * // Bytes32 address
 * const bytes32Format = detectFormat('0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(bytes32Format) // 'bytes32'
 * ```
 */ const detectFormat = (address)=>{
    if (/^0x[0-9a-fA-F]{40}$/.test(address)) {
        return 'evm';
    }
    if (/^0x[0-9a-fA-F]{64}$/.test(address)) {
        return 'bytes32';
    }
    const decoded = bs58__default.decode(address);
    if (decoded.length === 32) return 'solana';
    throw new Error(`Unsupported address format: ${address}`);
};
/**
 * Convert an EVM address or Solana base58 key into a 32-byte hex string.
 *
 * This function normalizes addresses from different blockchain formats into a
 * standardized 32-byte hex representation. EVM addresses are zero-padded to
 * 32 bytes, while Solana addresses are decoded from base58 format.
 *
 * @param address - The address string to convert.
 * @returns A 32-byte hex string (0x-prefixed).
 * @throws Error if the address format is unsupported.
 *
 * @example
 * ```typescript
 * import { toBytes32 } from '@core/utils'
 *
 * // Convert EVM address
 * const evmBytes32 = toBytes32('0x1234567890abcdef1234567890abcdef12345678')
 * console.log(evmBytes32) // '0x0000000000000000000000001234567890abcdef1234567890abcdef12345678'
 *
 * // Convert Solana address
 * const solanaBytes32 = toBytes32('11111111111111111111111111111112')
 * console.log(solanaBytes32) // '0x...' (32-byte hex representation)
 * ```
 */ const toBytes32 = (address)=>{
    const fmt = detectFormat(address);
    switch(fmt){
        case 'evm':
            // pad 20-byte address → 32 bytes
            return bytes.hexZeroPad(address, 32);
        case 'bytes32':
            return address;
        case 'solana':
            // base58 decode → raw 32 bytes → hex
            return bytes.hexlify(bs58__default.decode(address));
    }
    throw new Error(`Unsupported address format: ${address}`);
};
/**
 * Convert a bytes32 hex string to a checksummed EVM address.
 *
 * This function extracts the last 20 bytes from a 32-byte hex string and
 * converts it to a valid EVM address with EIP-55 checksum formatting.
 *
 * @param bytes32 - The 32-byte hex string (with or without 0x prefix).
 * @returns A checksummed EVM address (0x-prefixed).
 * @throws Error if the input is not a valid hex string.
 *
 * @example
 * ```typescript
 * import { bytes32ToEvm } from '@core/utils'
 *
 * // Convert bytes32 to EVM address
 * const evmAddress = bytes32ToEvm('0x0000000000000000000000001234567890abcdef1234567890abcdef12345678')
 * console.log(evmAddress) // '0x1234567890AbcdEF1234567890aBcdeF12345678' (checksummed)
 *
 * // Works without 0x prefix too
 * const evmAddress2 = bytes32ToEvm('0000000000000000000000001234567890abcdef1234567890abcdef12345678')
 * console.log(evmAddress2) // '0x1234567890AbcdEF1234567890aBcdeF12345678'
 * ```
 */ const bytes32ToEvm = (bytes32)=>{
    // remove 0x prefix
    const hex = bytes32.startsWith('0x') ? bytes32.slice(2) : bytes32;
    // take last 20 bytes (40 hex chars)
    const ethHex = '0x' + hex.slice(-40);
    // apply EIP-55 checksum
    return address.getAddress(ethHex);
};
/**
 * Convert a bytes32 hex string to a Solana base58 address.
 *
 * This function takes a 32-byte hex string and converts it to a Solana
 * public key address using base58 encoding.
 *
 * @param bytes32 - The 32-byte hex string (with or without 0x prefix).
 * @returns A Solana address in base58 format.
 * @throws Error if the input is not a valid hex string.
 *
 * @example
 * ```typescript
 * import { bytes32ToSolana } from '@core/utils'
 *
 * // Convert bytes32 to Solana address
 * const solanaAddress = bytes32ToSolana('0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(solanaAddress) // Base58 encoded address
 *
 * // Works without 0x prefix too
 * const solanaAddress2 = bytes32ToSolana('1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef')
 * console.log(solanaAddress2) // Base58 encoded address
 * ```
 */ function bytes32ToSolana(bytes32) {
    const hex = bytes32.startsWith('0x') ? bytes32.slice(2) : bytes32;
    const buffer = Buffer.from(hex, 'hex');
    return bs58__default.encode(new Uint8Array(buffer));
}
/**
 * Convert any supported address format into the target format.
 * @param address - input address (auto-detected)
 * @param targetFormat - one of 'evm', 'solana', or 'bytes32'
 * @returns converted address string
 */ const convertAddress = (address, targetFormat)=>{
    const current = detectFormat(address);
    if (current === targetFormat) return address;
    // first normalize to bytes32
    const asBytes32 = toBytes32(address);
    // then to target
    switch(targetFormat){
        case 'bytes32':
            return asBytes32;
        case 'evm':
            return bytes32ToEvm(asBytes32);
        case 'solana':
            return bytes32ToSolana(asBytes32);
    }
    throw new Error(`Unsupported address format: ${address}`);
};

/**
 * Convert a value from its smallest unit representation to a human-readable decimal string.
 *
 * This function normalizes token values from their blockchain representation (where
 * everything is stored as integers in the smallest denomination) to human-readable
 * decimal format. Uses the battle-tested implementation from \@ethersproject/units.
 *
 * @param value - The value in smallest units (e.g., "1000000" for 1 USDC with 6 decimals)
 * @param decimals - The number of decimal places for the unit conversion
 * @returns A human-readable decimal string (e.g., "1.0")
 * @throws Error if the value is not a valid numeric string
 *
 * @example
 * ```typescript
 * import { formatUnits } from '@core/utils'
 *
 * // Format USDC (6 decimals)
 * const usdcFormatted = formatUnits('1000000', 6)
 * console.log(usdcFormatted) // "1.0"
 *
 * // Format ETH (18 decimals)
 * const ethFormatted = formatUnits('1000000000000000000', 18)
 * console.log(ethFormatted) // "1.0"
 *
 * // Format with fractional part
 * const fractionalFormatted = formatUnits('1500000', 6)
 * console.log(fractionalFormatted) // "1.5"
 * ```
 */ const formatUnits = (value, decimals)=>{
    return units.formatUnits(value, decimals);
};

/**
 * Safely stringify an object that may contain BigInt values.
 *
 * Converts BigInt to string to avoid JSON serialization errors.
 * This is particularly useful for blockchain-related objects that often
 * contain BigInt values (e.g., token amounts, lamports, gas values) which
 * cannot be directly serialized by JSON.stringify().
 *
 * @param obj - The object to stringify.
 * @returns JSON string with BigInt values converted to strings.
 *
 * @example
 * ```typescript
 * import { safeStringify } from '@core/utils'
 *
 * const simulationResult = {
 *   err: { InstructionError: [0, 'Custom'] },
 *   unitsConsumed: 200000n,  // BigInt
 *   logs: ['Program log: Error']
 * }
 *
 * const json = safeStringify(simulationResult)
 * // Result: '{"err":{"InstructionError":[0,"Custom"]},"unitsConsumed":"200000","logs":[...]}'
 * ```
 *
 * @example
 * ```typescript
 * import { safeStringify } from '@core/utils'
 *
 * const tokenAmount = {
 *   value: 1000000000000000000n,  // 1 ETH in wei
 *   decimals: 18
 * }
 *
 * const json = safeStringify(tokenAmount)
 * // Result: '{"value":"1000000000000000000","decimals":18}'
 * ```
 */ function safeStringify(obj) {
    return JSON.stringify(obj, (_, value)=>typeof value === 'bigint' ? value.toString() : value);
}

/**
 * Schema for validating hexadecimal strings with '0x' prefix.
 *
 * This schema validates that a string:
 * - Is a string type
 * - Is not empty after trimming
 * - Starts with '0x'
 * - Contains only valid hexadecimal characters (0-9, a-f, A-F) after '0x'
 *
 * @remarks
 * This schema does not validate length, making it suitable for various hex string types
 * like addresses, transaction hashes, and other hex-encoded data.
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { hexStringSchema } from '@core/adapter'
 *
 * const validAddress = '0x1234567890123456789012345678901234567890'
 * const validTxHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const addressResult = hexStringSchema.safeParse(validAddress)
 * const txHashResult = hexStringSchema.safeParse(validTxHash)
 * console.log(addressResult.success) // true
 * console.log(txHashResult.success) // true
 * ```
 */ const hexStringSchema = zod.z.string().min(1, 'Hex string is required').refine((value)=>value.trim().length > 0, 'Hex string cannot be empty').refine((value)=>value.startsWith('0x'), 'Hex string must start with 0x prefix').refine((value)=>{
    const hexPattern = /^0x[0-9a-fA-F]+$/;
    return hexPattern.test(value);
}, 'Hex string contains invalid characters. Only hexadecimal characters (0-9, a-f, A-F) are allowed after 0x');
/**
 * Schema for validating EVM addresses.
 *
 * This schema validates that a string is a properly formatted EVM address:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 42 characters long (0x + 40 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmAddressSchema } from '@core/adapter'
 *
 * const validAddress = '0x1234567890123456789012345678901234567890'
 *
 * const result = evmAddressSchema.safeParse(validAddress)
 * console.log(result.success) // true
 * ```
 */ hexStringSchema.refine((value)=>value.length === 42, 'EVM address must be exactly 42 characters long (0x + 40 hex characters)').transform((value)=>value);
/**
 * Schema for validating transaction hashes.
 *
 * This schema validates that a string is a properly formatted transaction hash:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 66 characters long (0x + 64 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmTransactionHashSchema } from '@core/adapter'
 *
 * const validTxHash = '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef'
 *
 * const result = evmTransactionHashSchema.safeParse(validTxHash)
 * console.log(result.success) // true
 * ```
 */ hexStringSchema.refine((value)=>value.length === 66, 'Transaction hash must be exactly 66 characters long (0x + 64 hex characters)');
/**
 * Schema for validating EVM signatures.
 *
 * This schema validates that a string is a properly formatted 65-byte EVM
 * signature:
 * - Must be a valid hex string with '0x' prefix
 * - Must be exactly 132 characters long (0x + 130 hex characters)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { evmSignatureSchema } from '@core/adapter'
 *
 * const validSignature = `0x${'ab'.repeat(65)}`
 *
 * const result = evmSignatureSchema.safeParse(validSignature)
 * console.log(result.success) // true
 * ```
 */ hexStringSchema.refine((value)=>value.length === 132, 'EVM signature must be exactly 132 characters long (0x + 130 hex characters)').transform((value)=>value);
/**
 * Schema for validating base58-encoded strings.
 *
 * This schema validates that a string:
 * - Is a string type
 * - Is not empty after trimming
 * - Contains only valid base58 characters (1-9, A-H, J-N, P-Z, a-k, m-z)
 * - Does not contain commonly confused characters (0, O, I, l)
 *
 * @remarks
 * This schema does not validate length, making it suitable for various base58-encoded data
 * like Solana addresses, transaction signatures, and other base58-encoded data.
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { base58StringSchema } from '@core/adapter'
 *
 * const validAddress = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 * const validTxHash = '3Jf8k2L5mN9pQ7rS1tV4wX6yZ8aB2cD4eF5gH7iJ9kL1mN3oP5qR7sT9uV1wX3yZ5'
 *
 * const addressResult = base58StringSchema.safeParse(validAddress)
 * const txHashResult = base58StringSchema.safeParse(validTxHash)
 * console.log(addressResult.success) // true
 * console.log(txHashResult.success) // true
 * ```
 */ const base58StringSchema = zod.z.string().min(1, 'Base58 string is required').refine((value)=>value.trim().length > 0, 'Base58 string cannot be empty').refine((value)=>{
    // Base58 alphabet: 123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz
    // Excludes: 0, O, I, l to avoid confusion
    const base58Pattern = /^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/;
    return base58Pattern.test(value);
}, 'Base58 string contains invalid characters. Only base58 characters (1-9, A-H, J-N, P-Z, a-k, m-z) are allowed');
/**
 * Schema for validating Solana addresses.
 *
 * This schema validates that a string is a properly formatted Solana address:
 * - Must be a valid base58-encoded string
 * - Must be between 32-44 characters long (typical length for base58-encoded 32-byte addresses)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { solanaAddressSchema } from '@core/adapter'
 *
 * const validAddress = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 *
 * const result = solanaAddressSchema.safeParse(validAddress)
 * console.log(result.success) // true
 * ```
 */ const solanaAddressSchema = base58StringSchema.refine((value)=>value.length >= 32 && value.length <= 44, 'Solana address must be between 32-44 characters long (base58-encoded 32-byte address)');
/**
 * Schema for validating Solana transaction hashes.
 *
 * This schema validates that a string is a properly formatted Solana transaction hash:
 * - Must be a valid base58-encoded string
 * - Must be between 86-88 characters long (typical length for base58-encoded 64-byte signatures)
 *
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { solanaTransactionHashSchema } from '@core/adapter'
 *
 * const validTxHash = '5VfYmGBjvQKe3xgLtTQPSMEUdpEVHrJwLK7pKBJWKzYpNBE2g3kJrq7RSe9M8DqzQJ5J2aZPTjHLvd4WgxPpJKS'
 *
 * const result = solanaTransactionHashSchema.safeParse(validTxHash)
 * console.log(result.success) // true
 * ```
 */ const solanaTransactionHashSchema = base58StringSchema.refine((value)=>value.length >= 86 && value.length <= 88, 'Solana transaction hash must be between 86-88 characters long (base58-encoded 64-byte signature)');
/**
 * Schema for validating Adapter objects.
 * Checks for the required methods that define an Adapter.
 */ zod.z.object({
    prepare: zod.z.function(),
    waitForTransaction: zod.z.function(),
    getAddress: zod.z.function()
});

/**
 * Asserts that the provided parameters match the Solana address interface.
 * The validation includes:
 * - A valid Solana address (32-44 character base58-encoded string)
 *
 * @param address - The address to validate
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { assertSolanaAddress } from '@core/adapter'
 *
 * // Prepare Solana address
 * const address = 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'
 *
 * // This will throw if validation fails
 * assertSolanaAddress(address)
 *
 * // If we get here, address is guaranteed to be valid
 * console.log('Solana address is valid')
 * ```
 */ function assertSolanaAddress(address) {
    validateOrThrow(address, solanaAddressSchema, 'Invalid Solana address');
}

/**
 * Asserts that the provided parameters match the Solana transaction hash interface.
 * The validation includes:
 * - A valid Solana transaction hash (86-88 character base58-encoded string)
 *
 * @param txHash - The transaction hash to validate
 * @throws {KitError} If validation fails with INPUT_VALIDATION_FAILED code (1098), with details about which properties failed
 *
 * @example
 * ```typescript
 * import { assertSolanaTransactionHash } from '@core/adapter'
 *
 * // Prepare Solana transaction hash
 * const txHash = '3jUKrQp1UGq5ih6FTDUUt2kkqUfoG2o4kY5T1DoVHK2tXXDLdxJSXzuJGY4JPoRivgbi45U2bc7LZfMa6C4R3szX'
 *
 * // This will throw if validation fails
 * assertSolanaTransactionHash(txHash)
 *
 * // If we get here, transaction hash is guaranteed to be valid
 * console.log('Solana transaction hash is valid')
 * ```
 */ function assertSolanaTransactionHash(txHash) {
    validateOrThrow(txHash, solanaTransactionHashSchema, 'Invalid Solana transaction hash');
}

/**
 * Permit signature standards for gasless token approvals.
 *
 * Defines the permit types that can be used to approve token spending
 * without requiring a separate approval transaction.
 *
 * @remarks
 * - NONE: No permit, tokens must be pre-approved via separate transaction
 * - EIP2612: Standard ERC-20 permit (USDC, DAI v2, and most modern tokens)
 */ var PermitType;
(function(PermitType) {
    /** No permit required - tokens must be pre-approved */ PermitType[PermitType["NONE"] = 0] = "NONE";
    /** EIP-2612 standard permit */ PermitType[PermitType["EIP2612"] = 1] = "EIP2612";
})(PermitType || (PermitType = {}));

/**
 * Creates a no-op prepared chain request.
 *
 * @remarks
 * This function returns a no-op prepared chain request that performs no operation.
 * It is used when an action is not supported by the target chain or when
 * no actual blockchain interaction is required.
 *
 * The estimate and execute methods return placeholder values since no actual
 * transaction is performed. This allows the calling code to handle unsupported
 * operations gracefully without breaking the expected interface contract.
 *
 * @returns A promise that resolves to a no-op prepared chain request.
 * @example
 * ```typescript
 * const noopRequest = await createNoopChainRequest();
 * const gasEstimate = await noopRequest.estimate();
 * console.log(gasEstimate); // { gas: 0n, gasPrice: 0n, fee: '0' }
 *
 * const txHash = await noopRequest.execute();
 * console.log(txHash); // "0x0000000000000000000000000000000000000000000000000000000000000000"
 * ```
 */ const createNoopChainRequest = async ()=>{
    return Promise.resolve({
        type: 'noop',
        estimate: async ()=>Promise.resolve({
                gas: 0n,
                gasPrice: 0n,
                fee: '0'
            }),
        execute: async ()=>Promise.resolve('0x0000000000000000000000000000000000000000000000000000000000000000')
    });
};

/**
 * Default buffer in basis points (5%) applied to transaction fee calculations.
 * This provides a safety margin for gas price fluctuations to ensure transaction success.
 *
 * @remarks
 * This constant is used across all adapter implementations to provide consistent
 * fee buffering behavior. One basis point equals 0.01%, so 500 basis points equals 5%.
 *
 * @example
 * ```typescript
 * import { DEFAULT_BUFFER_BASIS_POINTS } from '@core/adapter'
 *
 * // Use in fee calculation
 * const bufferedFee = baseFee + (baseFee * DEFAULT_BUFFER_BASIS_POINTS) / 10000n
 * ```
 */ const DEFAULT_BUFFER_BASIS_POINTS = 500n;

/**
 * Creates default adapter capabilities with intelligent chain expansion and clean type inference.
 *
 * This utility function automatically expands to include all supported chains of the specified
 * ecosystem type. It provides maximum flexibility while maintaining a clean API and preserves
 * exact literal types for TypeScript inference.
 *
 * @param ecosystem - The ecosystem type to expand to all supported chains of that type
 * @param overrides - Optional overrides to merge with the generated capabilities
 * @returns Complete AdapterCapabilities with auto-detected supported chains and preserved types
 */ function createAdapterCapabilities(ecosystem, overrides) {
    // Use provided addressContext or default to 'user-controlled'
    const addressContext = overrides?.addressContext ?? 'user-controlled';
    // If we have valid non-empty supportedChains override, use it directly
    if (overrides?.supportedChains && overrides.supportedChains.length > 0) {
        return {
            addressContext,
            supportedChains: overrides.supportedChains,
            ...overrides
        };
    }
    // No overrides, no supportedChains in overrides, or empty supportedChains array
    // Silently fall back to auto-detection based on ecosystem type
    const supportedChains = getSupportedChains(ecosystem);
    return {
        addressContext,
        ...overrides,
        supportedChains
    };
}
/**
 * Expands to all supported chains of the specified ecosystem type.
 *
 * @param ecosystem - The ecosystem type to expand to
 * @returns Array of all supported chains of the specified ecosystem type
 *
 * @internal
 */ function getSupportedChains(ecosystem) {
    switch(ecosystem){
        case 'evm':
            // Get all EVM chains for maximum flexibility
            return getAllEvmChains();
        case 'solana':
            // Get all Solana chains
            return [
                Solana,
                SolanaDevnet
            ];
        default:
            // This should never happen due to TypeScript typing, but provides safety
            throw new Error(`Unsupported ecosystem type: ${String(ecosystem)}`);
    }
}

/**
 * Type guard to check if a signer is provider-based.
 *
 * @param signer - The signer to check
 * @returns True if the signer is provider-based
 */ function isProviderSigner(signer) {
    return signer.isProviderSigner;
}

const cachedPrograms = new Map();
/**
 * Retrieve an Anchor program instance with caching for performance.
 *
 * This utility fetches an Anchor program by its ID and caches the result
 * to avoid redundant network requests. If the program has been previously
 * loaded, it returns the cached instance instead of fetching it again.
 *
 * @param provider - The Anchor provider with connection and wallet context.
 * @param programId - The on-chain program ID as a base58 string.
 * @returns A Promise resolving to the Anchor program instance.
 * @throws Error if the program cannot be loaded or if the programId is invalid.
 *
 * @example
 * ```typescript
 * import { Connection, Keypair } from '@solana/web3.js'
 * import { AnchorProvider, BN } from '@coral-xyz/anchor'
 * import { getProgram } from './getProgram'
 *
 * async function interactWithProgram() {
 *   // Setup provider
 *   const connection = new Connection('https://api.devnet.solana.com')
 *   const wallet = {
 *     publicKey: Keypair.generate().publicKey,
 *     signTransaction: async (tx) => tx,
 *     signAllTransactions: async (txs) => txs,
 *   }
 *   const provider = new AnchorProvider(connection, wallet, {})
 *
 *   // Get program instance
 *   const tokenMessengerProgram = await getProgram(
 *     provider,
 *     'cctp11111111111111111111111111111111111111'
 *   )
 *
 *   // Use the program
 *   const accounts = await tokenMessengerProgram.account.tokenMessenger.all()
 *   console.log('Found', accounts.length, 'token messenger accounts')
 *
 *   // Subsequent calls will use the cached program
 *   const cachedProgram = await getProgram(
 *     provider,
 *     'cctp11111111111111111111111111111111111111'
 *   )
 * }
 * ```
 */ const getProgram = async (provider, programId)=>{
    const hit = cachedPrograms.get(programId);
    if (hit) return hit;
    const programKey = new web3_js.PublicKey(programId);
    const program = await anchor.Program.at(programKey, provider);
    cachedPrograms.set(programId, program);
    return program;
};

/**
 * Parses a private key string into raw bytes.
 *
 * This shared utility supports multiple Solana private key formats:
 * - Base58 encoded strings (most common)
 * - Base64 encoded strings
 * - JSON array format (e.g., "[1,2,3,...]")
 *
 * @param privateKey - The private key string in any supported format
 * @returns Raw key bytes as Uint8Array
 * @throws Error when the private key format is invalid or unsupported
 *
 * @remarks
 * This function extracts the common private key parsing logic shared between
 * all Solana adapters. It handles format detection, decoding, and validation,
 * but does not create adapter-specific key objects (Keypair vs KitSigner).
 *
 * @example
 * ```typescript
 * import { parsePrivateKeyToBytes } from '@core/adapter-solana'
 *
 * // Base58 format (most common)
 * const keyBytes = parsePrivateKeyToBytes('5Kk7...')
 *
 * // Base64 format
 * const keyBytes2 = parsePrivateKeyToBytes('base64string==')
 *
 * // JSON array format
 * const keyBytes3 = parsePrivateKeyToBytes('[1,2,3,4,...]')
 * ```
 */ function parsePrivateKeyToBytes(privateKey) {
    // Define decoding strategies in priority order
    const decoders = [
        /**
     * Base58 decoder (most common format for Solana private keys)
     */ (key)=>bs58__default.decode(key),
        /**
     * Base64 decoder with whitespace handling
     */ (key)=>{
            // Remove any whitespace and padding issues
            const cleanedKey = key.replace(/\s+/g, '');
            return Buffer.from(cleanedKey, 'base64');
        },
        /**
     * JSON array decoder for array format like "[1,2,3,...]"
     */ (key)=>{
            const parsed = JSON.parse(key);
            if (!Array.isArray(parsed) || !parsed.every((n)=>typeof n === 'number')) {
                throw new Error('JSON format must be an array of numbers');
            }
            return new Uint8Array(parsed);
        }
    ];
    let secretKey;
    // Try each decoder until one succeeds
    for (const decoder of decoders){
        try {
            secretKey = decoder(privateKey);
            // Validate key length (Solana secret keys are typically 32 or 64 bytes)
            if (secretKey.length === 32 || secretKey.length === 64) {
                return secretKey;
            }
        } catch  {
        // Continue to next decoder - we expect some decoders to fail
        }
    }
    // If no decoder succeeded, throw a descriptive error
    throw new Error(`Invalid private key format. Please provide a valid Base58, base64, or array format private key.`);
}

/**
 * Solana mainnet genesis hash
 */ const SOLANA_MAINNET_GENESIS_HASH = '5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d';
/**
 * Solana devnet genesis hash
 */ const SOLANA_DEVNET_GENESIS_HASH = 'EtWTRABZaYq6iMfeYKouRu166VU2xqa1wcaWoxPkrZBG';
/**
 * Default public key address (equivalent to PublicKey.default).
 *
 * @remarks
 * This is the System Program ID that represents the default/system address
 * in Solana. It's used as a fallback value for optional parameters like
 * destinationCaller in CCTP operations, where it means "any address can call".
 *
 * This constant provides consistency across different Solana transport libraries
 * and avoids the need to import \@solana/web3.js just for PublicKey.default.
 */ const SOLANA_DEFAULT_PUBLIC_KEY = '11111111111111111111111111111111';
/**
 * Compute unit limits for CCTP operations on Solana.
 *
 * @remarks
 * These values are based on observed compute unit consumption in production transactions.
 * Each limit includes headroom above the typical observed usage to accommodate variations.
 *
 * - `mint`: ~220k observed for receiveMessage operations, 350k provides safety margin
 * - `depositForBurn`: ~150k observed, 200k provides safety margin
 *
 * Setting explicit compute unit limits is required for CCTP transactions to avoid
 * the default 200k limit, which may be insufficient for complex operations like mint.
 *
 * @example
 * ```typescript
 * import { CCTP_COMPUTE_UNITS } from '@core/adapter-solana'
 *
 * // Use when building CCTP mint transaction
 * const preparedRequest = await adapter.prepare({
 *   instructions,
 *   computeUnitLimit: CCTP_COMPUTE_UNITS.mint,
 * }, context)
 * ```
 */ const CCTP_COMPUTE_UNITS = {
    mint: 350_000};
/**
 * CCTP Address Lookup Table address for Solana mainnet.
 *
 * @remarks
 * This ALT contains pre-loaded account addresses used in CCTP v2 transactions,
 * reducing transaction size by replacing full 32-byte addresses with 1-byte indices.
 *
 * @example
 * ```typescript
 * import { CCTP_ALT_ADDRESS_MAINNET } from '@core/adapter-solana'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const altAddress = new PublicKey(CCTP_ALT_ADDRESS_MAINNET)
 * ```
 */ const CCTP_ALT_ADDRESS_MAINNET = 'qj4EYgsGpnRdt9rvQW3wWZR8JVaKPg9rG9EB8DNgfz8';
/**
 * CCTP Address Lookup Table address for Solana devnet.
 */ const CCTP_ALT_ADDRESS_DEVNET = '29VCJ73d5aR5dE6oxaUkipntw1tFzDDKNLqrXE2ujWHW';
// ============================================================================
// Gateway Wallet Program PDA Seeds
// ============================================================================
/**
 * PDA seeds for the Gateway Wallet program.
 *
 * @remarks
 * These seeds are used to derive Program Derived Addresses (PDAs) for the
 * Gateway Wallet program on Solana. They are sourced from the official
 * Circle Gateway Wallet contracts repository.
 *
 * Source: {@link https://github.com/circlefin/solana-gateway-contracts/blob/master/programs/gateway-wallet/src/seeds.rs}
 *
 * These seeds must match the on-chain program exactly. Changing these values
 * will result in incorrect PDA derivation and failed transactions.
 */ const GATEWAY_WALLET_SEEDS = {
    /**
   * Seed for the GatewayWallet state account PDA.
   * Derived as: `PDA(programId, ["gateway_wallet"])`
   */ gatewayWallet: 'gateway_wallet',
    /**
   * Seed for the custody token account PDA.
   * Derived as: `PDA(programId, ["gateway_wallet_custody", tokenMint])`
   */ custodyTokenAccount: 'gateway_wallet_custody',
    /**
   * Seed for the gateway deposit account PDA.
   * Derived as: `PDA(programId, ["gateway_deposit", tokenMint, depositor])`
   */ deposit: 'gateway_deposit',
    /**
   * Seed for the gateway delegate account PDA.
   * Derived as: `PDA(programId, ["gateway_delegate", tokenMint, depositor, delegate])`
   */ delegate: 'gateway_delegate',
    /**
   * Seed for the denylist account PDA.
   * Derived as: `PDA(programId, ["denylist", address])`
   */ denylist: 'denylist'
};

/**
 * Maps a ChainDefinition to its corresponding SolanaNetwork name.
 *
 * @param chain - The chain definition to map
 * @returns The corresponding SolanaNetwork name
 * @internal
 */ function chainDefinitionToNetwork(chain) {
    if (chain.chain === exports.Blockchain.Solana) {
        return 'mainnet-beta';
    } else if (chain.chain === exports.Blockchain.Solana_Devnet) {
        return 'devnet';
    }
    // Fallback: use isTestnet to determine network
    return chain.isTestnet ? 'devnet' : 'mainnet-beta';
}
/**
 * Maps a Solana genesis hash to its corresponding ChainDefinition.
 *
 * This shared utility eliminates duplicate chain detection logic across
 * all Solana adapters. It provides consistent mapping from genesis hash
 * to chain definitions for mainnet, devnet, and future networks.
 *
 * @param genesisHash - The genesis hash string from the Solana network
 * @returns The corresponding ChainDefinition for the network
 * @throws Error if the genesis hash is not recognized/supported
 *
 * @remarks
 * This function centralizes the chain detection logic that can be used by
 * various Solana adapters in their getChain() implementations.
 *
 * @example
 * ```typescript
 * import { mapGenesisHashToChain } from '@core/adapter-solana'
 *
 * // In an adapter's getChain() method
 * const genesisHash = await connection.getGenesisHash()
 * const chainDefinition = mapGenesisHashToChain(genesisHash)
 * ```
 */ function mapGenesisHashToChain(genesisHash) {
    // Map genesis hash to known chain definitions
    if (genesisHash === SOLANA_MAINNET_GENESIS_HASH) {
        return getChainByEnum(exports.Blockchain.Solana);
    } else if (genesisHash === SOLANA_DEVNET_GENESIS_HASH) {
        return getChainByEnum(exports.Blockchain.Solana_Devnet);
    } else {
        throw new KitError({
            ...InputError.UNSUPPORTED_ROUTE,
            recoverability: 'FATAL',
            message: `Unsupported Solana network with genesis hash: ${genesisHash}. ` + `Only mainnet and devnet are currently supported.`,
            cause: {
                trace: {
                    genesisHash,
                    supportedNetworks: [
                        'mainnet',
                        'devnet'
                    ]
                }
            }
        });
    }
}
/**
 * Detect Solana network from RPC endpoint URL.
 *
 * @param endpoint - The RPC endpoint URL to analyze.
 * @returns The detected network name.
 *
 * @remarks
 * This function performs heuristic detection by parsing the endpoint URL
 * and checking for common network identifiers in the hostname. It serves
 * as a fallback when genesis hash lookup is unavailable.
 *
 * Detection logic:
 * - Contains "devnet" → returns "devnet"
 * - Contains "testnet" → returns "testnet"
 * - Contains "localhost" or "127.0.0.1" → returns "localnet"
 * - Otherwise → defaults to "mainnet-beta"
 */ function detectFromEndpoint(endpoint) {
    const host = (()=>{
        try {
            const url = new URL(endpoint);
            const hostname = url.hostname.toLowerCase();
            // Validate that we got a meaningful hostname
            // If hostname is empty or too short (likely malformed URL like "invalid://url"),
            // fall back to checking the whole endpoint string
            if (hostname && hostname.length > 3) {
                return hostname;
            }
            // Fall through to endpoint check if hostname is invalid or too short
            return endpoint.toLowerCase();
        } catch  {
            // URL parsing failed, check the whole endpoint string
            return endpoint.toLowerCase();
        }
    })();
    if (host.includes('devnet')) return 'devnet';
    if (host.includes('testnet')) return 'testnet';
    if (host.includes('localhost') || host.includes('127.0.0.1')) return 'localnet';
    return 'mainnet-beta';
}
/**
 * Get the Solana network name from a connection using genesis hash.
 *
 * @param connection - The Solana connection.
 * @returns Promise resolving to the network name (e.g., "devnet", "mainnet-beta").
 *
 * @remarks
 * This function uses the genesis hash to reliably identify the network,
 * which works with any RPC endpoint (official or custom). This is more
 * robust than URL string matching which can fail with non-standard RPC providers.
 *
 * @example
 * ```typescript
 * import { Connection } from '@solana/web3.js'
 * import { getNetworkFromConnection } from '@core/adapter-solana'
 *
 * const connection = new Connection('https://api.devnet.solana.com')
 * const network = await getNetworkFromConnection(connection)
 * console.log(network) // "devnet"
 *
 * // Works with custom RPC URLs too
 * const customConnection = new Connection('https://my-custom-rpc.com')
 * const customNetwork = await getNetworkFromConnection(customConnection)
 * console.log(customNetwork) // Returns network based on actual genesis hash
 * ```
 */ async function getNetworkFromConnection(connection) {
    try {
        const genesisHash = await connection.getGenesisHash();
        // Use mapGenesisHashToChain as single source of truth for genesis hash mapping
        try {
            const chain = mapGenesisHashToChain(genesisHash);
            return chainDefinitionToNetwork(chain);
        } catch  {
            // Unknown genesis hash, fallback to URL detection
            return detectFromEndpoint(connection.rpcEndpoint);
        }
    } catch  {
        // Fallback to URL-based detection if genesis hash fetch fails
        return detectFromEndpoint(connection.rpcEndpoint);
    }
}

/**
 * Default transaction confirmation timeout in milliseconds.
 *
 * @constant
 * @remarks
 * This 60-second timeout provides sufficient time for transaction
 * confirmation while preventing indefinite waiting in failure scenarios.
 */ const DEFAULT_TX_TIMEOUT = 60000;
/**
 * Gets the standard connection configuration for @solana/web3.js adapters.
 *
 * This shared utility eliminates duplicate connection configuration across
 * Solana adapters and ensures consistent behavior for timeouts, retries,
 * commitment levels, and HTTP headers.
 *
 * @param userAgent - Optional custom user agent string. Defaults to 'app-kit/1.0.0'
 * @returns Standard connection configuration object
 *
 * @remarks
 * These settings are optimized for production use and provide:
 * - Consistent 'confirmed' commitment level
 * - 60-second transaction confirmation timeout
 * - Rate limiting retry enabled for better reliability
 * - Proper User-Agent identification for RPC providers
 *
 * @example
 * ```typescript
 * import { getStandardConnectionConfig } from '@core/adapter-solana'
 * import { Connection } from '@solana/web3.js'
 *
 * const config = getStandardConnectionConfig()
 * const connection = new Connection(rpcUrl, config)
 * ```
 */ function getStandardConnectionConfig(userAgent = 'app-kit/1.0.0') {
    return {
        commitment: 'confirmed',
        confirmTransactionInitialTimeout: DEFAULT_TX_TIMEOUT,
        disableRetryOnRateLimit: false,
        // A raw `User-Agent` request header is forbidden in browsers, so only set
        // it in Node. Browser RPC requests simply omit it.
        httpHeaders: isNodeEnvironment() ? {
            'User-Agent': userAgent
        } : {}
    };
}

/**
 * Return a `PublicKey` parsed from the provided string, or the Solana default when absent.
 *
 * Accepts base58 strings or 0x-prefixed hex strings. Whitespace-only and empty inputs return
 * the Solana default `PublicKey`.
 * Throws when the provided non-empty input is not a valid public key.
 *
 * @param value - The optional public key string (base58 or 0x-hex).
 * @returns The parsed `PublicKey` from input, or the Solana default when missing.
 */ function getOrDefaultPublicKey(value) {
    if (typeof value !== 'string') return web3_js.PublicKey.default;
    const trimmed = value.trim();
    if (trimmed.length === 0) return web3_js.PublicKey.default;
    if (trimmed.startsWith('0x')) {
        return new web3_js.PublicKey(Buffer.from(trimmed.replace(/^0x/, ''), 'hex'));
    }
    return new web3_js.PublicKey(trimmed);
}

/**
 * Convert lamports to SOL with specified decimal precision.
 *
 * This utility formats Solana's native token amounts (measured in lamports)
 * into human-readable SOL values with configurable decimal places.
 *
 * @param lamports - The amount in lamports (1 SOL = 1,000,000,000 lamports).
 * @param decimals - Number of decimal places to display (default: 6).
 * @returns Formatted SOL amount as a string with the specified decimal precision.
 *
 * @remarks
 * - Accepts both bigint and number types for lamports
 * - Uses LAMPORTS_PER_SOL constant (1,000,000,000) from \@solana/web3.js
 * - Returns a fixed-precision string suitable for display in error messages and logs
 * - For financial calculations, consider keeping values in lamports (bigint) until final display
 *
 * @example
 * ```typescript
 * import { lamportsToSol } from '@core/adapter-solana'
 *
 * // Convert 1 SOL
 * const sol1 = lamportsToSol(1_000_000_000)
 * console.log(sol1) // "1.000000"
 *
 * // Convert with 4 decimal places
 * const sol2 = lamportsToSol(1_500_000_000, 4)
 * console.log(sol2) // "1.5000"
 *
 * // Convert from bigint
 * const sol3 = lamportsToSol(250_000_000n, 2)
 * console.log(sol3) // "0.25"
 * ```
 */ function lamportsToSol(lamports, decimals = 6) {
    return (Number(lamports) / web3_js.LAMPORTS_PER_SOL).toFixed(decimals);
}

// ============================================================================
// Balance Calculation Functions
// ============================================================================
/**
 * Calculate the total SOL required for creating Associated Token Accounts.
 *
 * @param ataCount - The number of ATAs to create. Defaults to 1 for backward compatibility.
 * @returns Total lamports required (rent × count + transaction fees including compute units).
 *
 * @remarks
 * Returns the cost for creating ATAs:
 * - ATA rent: 2,039,280 lamports per ATA
 * - Transaction fee: 5,000 lamports (includes signature + compute)
 *
 * The transaction fee is only counted once, not multiplied by the ATA count.
 *
 * @example
 * ```typescript
 * import { calculateRequiredSolForAtas } from '@core/adapter-solana'
 *
 * // Calculate SOL needed for 1 ATA
 * const requiredLamports = calculateRequiredSolForAtas()
 * console.log(`Required: ${requiredLamports} lamports`) // 2,044,280 lamports
 *
 * // Calculate SOL needed for 2 ATAs
 * const requiredFor2 = calculateRequiredSolForAtas(2)
 * console.log(`Required: ${requiredFor2} lamports`) // 4,083,560 lamports
 * ```
 */ function calculateRequiredSolForAtas(ataCount = 1) {
    const rentTotal = ATA_RENT_EXEMPT_LAMPORTS * BigInt(ataCount);
    const transactionFee = TRANSACTION_FEE_LAMPORTS;
    return rentTotal + transactionFee;
}
/**
 * Get the SOL balance for a given wallet address.
 *
 * @param connection - The Solana connection.
 * @param address - The wallet address to check.
 * @returns Promise resolving to the balance in lamports.
 *
 * @example
 * ```typescript
 * import { Connection, PublicKey } from '@solana/web3.js'
 * import { getSolBalance } from '@core/adapter-solana'
 *
 * const connection = new Connection('https://api.devnet.solana.com')
 * const walletAddress = new PublicKey('8YNk...')
 *
 * const balance = await getSolBalance(connection, walletAddress)
 * console.log(`Balance: ${balance} lamports`)
 * ```
 */ async function getSolBalance(connection, address) {
    assertSolanaAddress(address.toBase58());
    try {
        const balance = await connection.getBalance(address);
        return BigInt(balance);
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new KitError({
            ...RpcError.ENDPOINT_ERROR,
            recoverability: 'RETRYABLE',
            message: `Failed to get SOL balance for ${address.toBase58()}: ${errorMessage}`,
            cause: {
                trace: {
                    address: address.toBase58(),
                    originalError: errorMessage
                }
            }
        });
    }
}
// ============================================================================
// Error Message Builders
// ============================================================================
/**
 * Builds an insufficient token balance error message.
 *
 * @param walletAddress - The wallet address for the error message.
 * @returns Formatted error message string.
 *
 * @remarks
 * Provides a clear message when the wallet lacks sufficient SPL tokens
 * (typically USDC) to complete the transfer operation. The message guides
 * users to check their token balance before retrying.
 *
 * @example
 * ```typescript
 * import { buildInsufficientTokenError } from '@core/adapter-solana'
 *
 * const errorMsg = buildInsufficientTokenError('ABC123...')
 * throw new Error(errorMsg)
 * ```
 */ function buildInsufficientTokenError(walletAddress) {
    return `Insufficient token balance.\n\n` + `Your wallet (${walletAddress}) does not have enough tokens to complete this transfer.\n\n` + `Please ensure your wallet has sufficient token balance before initiating the transfer.`;
}
/**
 * Builds an account not found error message.
 *
 * @param walletAddress - The wallet address for the error message.
 * @param currentBalanceSol - The current SOL balance formatted as string.
 * @returns Formatted error message string.
 *
 * @remarks
 * This error typically indicates a missing Associated Token Account (ATA)
 * or insufficient SOL to create required accounts. The message provides
 * context about the current balance and required SOL for ATA creation.
 *
 * @example
 * ```typescript
 * import { buildAccountNotFoundError } from '@core/adapter-solana'
 *
 * const errorMsg = buildAccountNotFoundError('ABC123...', '0.005000')
 * throw new Error(errorMsg)
 * ```
 */ function buildAccountNotFoundError(walletAddress, currentBalanceSol) {
    return `Account not found.\n\n` + `A required account is missing. This typically means the Associated Token Account (ATA) doesn't exist or insufficient SOL to create it.\n\n` + `Your wallet (${walletAddress}) has ${currentBalanceSol} SOL.\n\n` + `Please ensure your wallet has sufficient SOL for account creation (~0.00204 SOL per ATA + transaction fees).`;
}
/**
 * Extracts meaningful error details from simulation logs.
 *
 * @param logs - The simulation logs from the failed transaction.
 * @param errorObj - The error object from simulation result.
 * @returns The extracted error details as a string.
 *
 * @remarks
 * Prioritizes error details in the following order:
 * 1. Anchor program errors (most specific)
 * 2. Constraint errors (moderately specific)
 * 3. Generic error object (fallback)
 *
 * Removes "Program log:" prefixes for cleaner error messages.
 *
 * @example
 * ```typescript
 * import { extractErrorDetails } from '@core/adapter-solana'
 *
 * const logs = [
 *   'Program log: AnchorError: Invalid state',
 *   'Program log: Error Code: 6000'
 * ]
 * const details = extractErrorDetails(logs, { Custom: 6000 })
 * // Returns: "AnchorError: Invalid state"
 * ```
 */ function extractErrorDetails(logs, errorObj) {
    // Safely stringify error object, handling BigInt values
    let errorString;
    try {
        errorString = safeStringify(errorObj);
    } catch  {
        errorString = String(errorObj);
    }
    const anchorErrorLog = logs.find((log)=>log.includes('AnchorError') || log.includes('Error Message'));
    const constraintLog = logs.find((log)=>log.includes('Error Code'));
    if (anchorErrorLog) {
        return anchorErrorLog.replace(/^Program log:\s*/, '');
    } else if (constraintLog) {
        return constraintLog;
    }
    return `Error: ${errorString}`;
}
/**
 * Builds a generic error message for unclassified simulation failures.
 *
 * @param errorDetails - The extracted error details.
 * @param walletAddress - The wallet address for context.
 * @param network - The network name for context.
 * @returns Formatted error message string.
 *
 * @remarks
 * This is a fallback error message used when the simulation failure
 * doesn't match any specific error patterns (insufficient SOL, insufficient
 * tokens, account not found). Includes wallet and network context for debugging.
 *
 * @example
 * ```typescript
 * import { buildGenericSimulationError } from '@core/adapter-solana'
 *
 * const errorMsg = buildGenericSimulationError(
 *   'Error: Custom program error',
 *   'ABC123...',
 *   'mainnet-beta'
 * )
 * throw new Error(errorMsg)
 * ```
 */ function buildGenericSimulationError(errorDetails, walletAddress, network) {
    return `Transaction simulation failed.\n\n` + `${errorDetails}\n\n` + `Wallet: ${walletAddress}\n` + `Network: ${network}`;
}
/**
 * Calculates the SOL requirements for a transaction based on ATA creation count.
 *
 * @param ataCount - The number of Associated Token Accounts to create.
 * @returns {@link SolRequirements} object with total requirements and detailed breakdown.
 *
 * @remarks
 * This function wraps the lower-level `calculateRequiredSolForAtas` from the errors module
 * and provides additional breakdown information useful for error messages.
 *
 * The function calculates the total SOL required for a transaction consisting of:
 * - ATA rent-exempt balance (per ATA): ~0.00204 SOL each
 * - Transaction fees (including compute units): ~0.000005 SOL
 *
 * The breakdown object provides individual cost components for detailed error messages
 * and helps users understand exactly what they're paying for.
 *
 * **Important**: The transaction fee is counted once per transaction, not per ATA.
 * The formula is: `(ATA rent × count) + one transaction fee`
 *
 * This is a shared helper used by both adapter implementations (web3.js and \@solana/kit)
 * to ensure consistent SOL requirement calculations across different transport libraries.
 *
 * @example
 * ```typescript
 * import { calculateRequiredSolForAtasWithBreakdown } from '@core/adapter-solana'
 *
 * // Transaction creating 2 ATAs
 * const requirements = calculateRequiredSolForAtasWithBreakdown(2)
 * console.log(`Total required: ${requirements.totalRequiredLamports} lamports`)
 * console.log(`Creating ${requirements.breakdown.ataCount} ATAs`)
 * console.log(`ATA rent: ${requirements.breakdown.ataRent} lamports`)
 * console.log(`Transaction fee: ${requirements.breakdown.transactionFee} lamports`)
 * ```
 *
 * @example
 * ```typescript
 * // Transaction with no ATA creation (e.g., ATA already exists)
 * const requirements = calculateRequiredSolForAtasWithBreakdown(0)
 * // Only transaction fee is required
 * console.log(`Total: ${requirements.totalRequiredLamports} lamports`)
 * ```
 */ function calculateRequiredSolForAtasWithBreakdown(ataCount) {
    // Calculate individual components for breakdown
    const transactionFee = TRANSACTION_FEE_LAMPORTS;
    const ataRent = ATA_RENT_EXEMPT_LAMPORTS * BigInt(ataCount);
    // Use the shared calculation function
    const totalRequiredLamports = calculateRequiredSolForAtas(ataCount);
    return {
        totalRequiredLamports,
        breakdown: {
            transactionFee,
            ataRent,
            ataCount
        }
    };
}
/**
 * Type guard assertion function that ensures instructions are present.
 *
 * This function narrows the type of params to guarantee instructions exist.
 * It should never throw in normal operation as prepare() validates instructions.
 *
 * @param params - The params object to validate
 * @throws KitError if instructions are missing (should never happen)
 */ function assertInstructions(params) {
    if (!params.instructions || params.instructions.length === 0) {
        throw createValidationFailedError('instructions', params.instructions, 'Instructions are required but were not provided.');
    }
}
/**
 * Throws appropriate errors based on simulation failure analysis.
 *
 * @param walletInfo - The wallet information including address, balance, and network.
 * @param solRequirements - The calculated SOL requirements for the transaction.
 * @param logs - The simulation logs from the failed transaction.
 * @param errorObj - The error object from simulation result.
 * @throws InsufficientSolError When wallet lacks sufficient SOL for transaction.
 * @throws KitError For token balance, account not found, or generic simulation errors.
 *
 * @remarks
 * This function analyzes simulation errors and throws the appropriate error type
 * in prioritized order:
 *
 * 1. **Insufficient SOL** (highest priority): When wallet lacks sufficient SOL
 *    for ATA creation and transaction fees.
 * 2. **Insufficient Token Balance**: When wallet lacks enough USDC or other SPL tokens.
 * 3. **Account Not Found**: When required accounts (typically ATAs) are missing.
 * 4. **Generic Simulation Errors**: Catches all other errors with detailed context.
 *
 * This is a shared helper used by both adapter implementations to ensure consistent
 * error handling behavior across different Solana transport libraries.
 *
 * @example
 * ```typescript
 * import { throwSimulationError } from '@core/adapter-solana'
 *
 * const walletInfo = await getWalletInfo(...)
 * const solRequirements = calculateRequiredSol(...)
 * const logs = ['Program log: insufficient lamports']
 * const errorObj = { InsufficientFundsForRent: {} }
 *
 * // This will throw an appropriate error
 * throwSimulationError(walletInfo, solRequirements, logs, errorObj)
 * ```
 */ function throwSimulationError(walletInfo, solRequirements, logs, errorObj) {
    // Safely stringify error object, handling BigInt values
    let errorString;
    try {
        errorString = safeStringify(errorObj);
    } catch  {
        errorString = String(errorObj);
    }
    const fullLogText = Array.isArray(logs) ? logs.join('\n') : String(logs);
    const hasInsufficientSol = BigInt(walletInfo.currentBalanceLamports) < solRequirements.totalRequiredLamports;
    // Check for insufficient SOL balance (highest priority)
    // Combine balance check with error message validation to avoid false positives
    // where error mentions "insufficient" but refers to tokens/other resources.
    // We check for specific SOL-related error messages, not the generic "insufficient"
    // to avoid catching token errors like "insufficient funds" from SPL Token program.
    const errorMentionsSol = fullLogText.includes('InsufficientFunds') || fullLogText.includes('insufficient lamports') || errorString.includes('InsufficientFunds') || errorString.includes('insufficient lamports');
    // Check for account not found errors early (needed for SOL prioritization logic)
    // AccountNotFound errors originate from the Solana runtime when a transaction references
    // an account that doesn't exist on-chain. This commonly occurs when:
    // - An Associated Token Account (ATA) hasn't been created yet
    // - A referenced program account is missing
    // Reference: https://www.solanakit.com/api/type-aliases/TransactionError
    // TransactionError::AccountNotFound is returned when an account doesn't exist
    const hasAccountNotFound = errorString.includes('AccountNotFound') || fullLogText.includes('AccountNotFound');
    // Prioritize SOL error when:
    // 1. Error explicitly mentions SOL-related issues
    // 2. Creating ATAs (fundamentally requires SOL)
    // 3. AccountNotFound + insufficient SOL (likely can't create account due to lack of SOL)
    const hasAtaCreation = solRequirements.breakdown.ataCount > 0;
    if (hasInsufficientSol && (errorMentionsSol || hasAtaCreation || hasAccountNotFound)) {
        // In simulation context, we only know the count, not specific ATA details
        // In practice, ataCount is always 0 or 1 (user's USDC ATA)
        const missingAta = solRequirements.breakdown.ataCount > 0 ? {
            ownerAddress: walletInfo.walletAddress,
            mintAddress: '',
            ataAddress: '',
            description: 'Associated Token Account for Stablecoin'
        } : undefined;
        throw new InsufficientSolError(walletInfo.walletAddress, BigInt(walletInfo.currentBalanceLamports), solRequirements.totalRequiredLamports, missingAta, walletInfo.network);
    }
    // Check for insufficient token (USDC) balance
    const hasInsufficientToken = fullLogText.includes('insufficient funds') || fullLogText.includes('transfer amount exceeds balance') || errorString.includes('insufficient funds') || errorString.includes('transfer amount exceeds balance');
    if (hasInsufficientToken) {
        const errorMessage = buildInsufficientTokenError(walletInfo.walletAddress);
        throw new KitError({
            ...BalanceError.INSUFFICIENT_TOKEN,
            recoverability: 'FATAL',
            message: errorMessage,
            cause: {
                trace: {
                    walletAddress: walletInfo.walletAddress,
                    network: walletInfo.network,
                    logs: fullLogText,
                    error: errorString
                }
            }
        });
    }
    // If we reach here and have AccountNotFound (not caught by SOL check above),
    // it means we have sufficient SOL but the account still doesn't exist
    if (hasAccountNotFound) {
        const errorMessage = buildAccountNotFoundError(walletInfo.walletAddress, walletInfo.currentBalanceSol);
        throw new KitError({
            ...OnchainError.SIMULATION_FAILED,
            recoverability: 'FATAL',
            message: errorMessage,
            cause: {
                trace: {
                    walletAddress: walletInfo.walletAddress,
                    currentBalanceLamports: walletInfo.currentBalanceLamports,
                    currentBalanceSol: walletInfo.currentBalanceSol,
                    network: walletInfo.network,
                    error: errorString,
                    logs: fullLogText
                }
            }
        });
    }
    // Handle generic simulation errors
    const errorDetails = extractErrorDetails(logs, errorObj);
    const errorMessage = buildGenericSimulationError(errorDetails, walletInfo.walletAddress, walletInfo.network);
    throw new KitError({
        ...OnchainError.SIMULATION_FAILED,
        recoverability: 'FATAL',
        message: errorMessage,
        cause: {
            trace: {
                walletAddress: walletInfo.walletAddress,
                network: walletInfo.network,
                errorDetails,
                error: errorString,
                logs: fullLogText
            }
        }
    });
}

// ============================================================================
// Constants
// ============================================================================
/**
 * Rent-exempt balance required for a single Associated Token Account.
 * Approximately 2,039,280 lamports (~0.00203928 SOL).
 */ const ATA_RENT_EXEMPT_LAMPORTS = 2_039_280n;
/**
 * Estimated transaction fee in lamports (includes base signature fee + compute units).
 * Approximately 5,000 lamports (~0.000005 SOL).
 *
 * @remarks
 * This covers typical ATA creation and transfer operations. For complex transactions
 * with high compute requirements, actual fees may be higher.
 */ const TRANSACTION_FEE_LAMPORTS = 5000n;
/**
 * Validate SOL balance for ATA creation and throw InsufficientSolError if insufficient.
 *
 * @param connection - The Solana connection.
 * @param owner - The wallet owner public key.
 * @param mint - The token mint public key.
 * @param ataAddress - The associated token account address.
 * @param description - Optional description of the ATA (e.g., "User USDC ATA").
 * @throws InsufficientSolError if balance is insufficient.
 *
 * @example
 * ```typescript
 * import { validateSolBalance } from '@core/adapter-solana'
 *
 * try {
 *   await validateSolBalance(connection, owner, mint, ataAddress)
 * } catch (error) {
 *   if (error instanceof InsufficientSolError) {
 *     console.log(error.walletAddress)
 *     console.log(error.currentBalanceLamports)
 *   }
 * }
 * ```
 *
 * @example
 * ```typescript
 * // With description
 * await validateSolBalance(connection, owner, mint, ataAddress, 'User USDC ATA')
 * ```
 */ async function validateSolBalance(connection, owner, mint, ataAddress, description) {
    const balance = await getSolBalance(connection, owner);
    const requiredBalance = calculateRequiredSolForAtas();
    if (balance < requiredBalance) {
        const missingAta = {
            ownerAddress: owner.toBase58(),
            mintAddress: mint.toBase58(),
            ataAddress: ataAddress.toBase58(),
            ...{
                description
            }
        };
        // Determine network from connection using genesis hash
        const network = await getNetworkFromConnection(connection);
        throw new InsufficientSolError(owner.toBase58(), balance, requiredBalance, missingAta, network);
    }
}
// ============================================================================
// Custom Error Classes
// ============================================================================
/**
 * Custom error class for insufficient SOL errors when creating Associated Token Accounts.
 * Provides structured error information with actionable instructions.
 *
 * This error extends KitError and uses the BALANCE_INSUFFICIENT_GAS error code
 * since SOL is the native token used for gas fees and account rent on Solana.
 *
 * @example
 * ```typescript
 * import { InsufficientSolError, type MissingAtaInfo } from '@core/adapter-solana'
 *
 * const missingAta: MissingAtaInfo = {
 *   ownerAddress: '8YNkbQyGPvBvSDA9Ao3JEj7B4nzKwn9RqMdG5ctTpvQj',
 *   mintAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *   ataAddress: 'ABC...XYZ',
 *   description: 'User USDC ATA'
 * }
 *
 * const error = new InsufficientSolError(
 *   '8YNkbQyGPvBvSDA9Ao3JEj7B4nzKwn9RqMdG5ctTpvQj',
 *   1_000_000n,        // Current balance: 0.001 SOL
 *   2_044_280n,        // Required: 0.00204428 SOL
 *   missingAta,
 *   'devnet'
 * )
 *
 * console.log(error.message)
 * // "Insufficient SOL to create 1 Associated Token Account.
 * // The Solana wallet (8YNk...) has 0.0010 SOL but needs at least
 * // 0.002044 SOL to pay for account creation rent..."
 *
 * // Access KitError properties
 * console.log(error.code) // 9002
 * console.log(error.name) // 'BALANCE_INSUFFICIENT_GAS'
 * console.log(error.type) // 'BALANCE'
 * ```
 */ class InsufficientSolError extends KitError {
    /**
   * The wallet address that needs SOL.
   */ walletAddress;
    /**
   * Current SOL balance in lamports.
   */ currentBalanceLamports;
    /**
   * Required SOL amount in lamports.
   */ requiredBalanceLamports;
    /**
   * Details about which ATAs need to be created.
   */ missingAta;
    /**
   * The chain network (e.g., "devnet", "mainnet-beta").
   */ network;
    /**
   * Creates a new InsufficientSolError.
   *
   * @param walletAddress - The wallet address that needs SOL.
   * @param currentBalanceLamports - Current SOL balance in lamports.
   * @param requiredBalanceLamports - Required SOL amount in lamports.
   * @param missingAta - Optional details about the specific ATA that needs creation.
   * @param network - The Solana network (e.g., "devnet", "mainnet-beta").
   */ constructor(walletAddress, currentBalanceLamports, requiredBalanceLamports, missingAta, network){
        const message = InsufficientSolError.buildErrorMessage(walletAddress, currentBalanceLamports, requiredBalanceLamports, missingAta);
        super({
            ...BalanceError.INSUFFICIENT_GAS,
            recoverability: 'FATAL',
            message,
            cause: {
                trace: {
                    walletAddress,
                    currentBalanceLamports: currentBalanceLamports.toString(),
                    requiredBalanceLamports: requiredBalanceLamports.toString(),
                    ...missingAta && {
                        missingAta
                    },
                    network
                }
            }
        });
        // Set additional properties after super() call
        this.walletAddress = walletAddress;
        this.currentBalanceLamports = currentBalanceLamports;
        this.requiredBalanceLamports = requiredBalanceLamports;
        this.missingAta = missingAta;
        this.network = network;
    }
    /**
   * Build the complete error message by composing all message sections.
   *
   * @param walletAddress - The wallet address that needs SOL.
   * @param currentBalanceLamports - Current SOL balance in lamports.
   * @param requiredBalanceLamports - Required SOL amount in lamports.
   * @param missingAtas - Array of ATAs with details (may be empty if details unknown).
   * @returns The complete formatted error message.
   *
   * @remarks
   * This method orchestrates the message building by calling specialized
   * methods for each section: main message, ATA list, and instructions.
   */ static buildErrorMessage(walletAddress, currentBalanceLamports, requiredBalanceLamports, missingAta) {
        const mainMessage = this.buildMainMessage(walletAddress, currentBalanceLamports, requiredBalanceLamports);
        const ataList = this.buildMissingAtasListMessage(missingAta);
        const instructions = this.buildInstructions(walletAddress, currentBalanceLamports, requiredBalanceLamports);
        return `${mainMessage}${ataList}${instructions}`;
    }
    /**
   * Build the main error message section with balance information and rent breakdown.
   *
   * @param walletAddress - The wallet address that needs SOL.
   * @param currentBalanceLamports - Current SOL balance in lamports.
   * @param requiredBalanceLamports - Required SOL amount in lamports.
   * @param ataCount - Number of ATAs that need to be created (derived from missingAtas.length).
   * @returns Formatted main message with balance details and rent breakdown.
   *
   * @remarks
   * This message includes:
   * - Number of ATAs that need creation (with proper singular/plural)
   * - Current wallet balance in SOL
   * - Required balance in SOL
   * - Rent per ATA breakdown
   * - Transaction fee breakdown
   *
   * @example
   * ```typescript
   * // Returns a message like:
   * // "Insufficient SOL to create 1 Associated Token Account.
   * // The Solana wallet (8YNk...AoJ) has 0.0010 SOL but needs at least
   * // 0.00204428 SOL to pay for account creation rent (~0.00203928 SOL per ATA)
   * // and transaction fees (~0.00000500 SOL)."
   * ```
   */ static buildMainMessage(walletAddress, currentBalanceLamports, requiredBalanceLamports) {
        const currentBalanceSol = lamportsToSol(currentBalanceLamports);
        const requiredBalanceSol = lamportsToSol(requiredBalanceLamports);
        const shortfallLamports = requiredBalanceLamports - currentBalanceLamports;
        const shortfallSol = lamportsToSol(shortfallLamports);
        const rentPerAtaSol = lamportsToSol(ATA_RENT_EXEMPT_LAMPORTS, 8);
        const txFeeSol = lamportsToSol(TRANSACTION_FEE_LAMPORTS, 8);
        return `Insufficient SOL to create Associated Token Account.\n\n` + `Wallet: ${walletAddress}\n` + `Current balance: ${currentBalanceSol} SOL (${currentBalanceLamports.toString()} lamports)\n` + `Required: ${requiredBalanceSol} SOL (${requiredBalanceLamports.toString()} lamports)\n` + `Shortfall: ${shortfallSol} SOL (${shortfallLamports.toString()} lamports)\n\n` + `This swap requires creating an Associated Token Account which needs:\n` + `- ATA rent-exempt balance: ~${rentPerAtaSol} SOL per ATA\n` + `- Transaction fees: ~${txFeeSol} SOL\n`;
    }
    /**
   * Build a formatted list of missing ATAs with owner addresses and descriptions.
   *
   * @param missingAtas - Array of ATAs that need to be created.
   * @returns Formatted ATA list, or empty string if only one ATA is missing.
   *
   * @remarks
   * This method only generates output when multiple ATAs are missing. For a single
   * ATA, it returns an empty string since the main message already covers the case.
   * Each ATA in the list shows:
   * - Index number
   * - Shortened owner address (first 4 and last 3 characters)
   * - Optional description in parentheses
   *
   * @example
   * ```typescript
   * // Returns for 2+ ATAs:
   * // "\nMissing ATAs for:
   * //   1. 8YNk...AoJ (User USDC ATA)
   * //   2. Anot...123 (Protocol fee wallet ATA)"
   * ```
   */ static buildMissingAtasListMessage(ata) {
        if (ata === undefined) {
            return '';
        }
        let message = `\nMissing ATA for:\n`;
        const shortAddress = `${ata.ownerAddress.slice(0, 4)}...${ata.ownerAddress.slice(-3)}`;
        const description = ata.description ? ` (${ata.description})` : '';
        message += `. ${shortAddress}${description}\n`;
        return message;
    }
    /**
   * Build the instructions section for adding SOL to the wallet.
   *
   * @param walletAddress - The wallet address to receive SOL.
   * @returns Formatted instructions for devnet and mainnet.
   *
   * @remarks
   * Provides actionable next steps for the user:
   * - For devnet: CLI command for airdrop
   * - For mainnet: Instructions to send SOL via wallet/exchange
   *
   * @example
   * ```typescript
   * // Returns:
   * // "\nAction: Add at least 0.003 SOL to your wallet to complete this swap.\n\n` +
   * // For devnet: solana airdrop 0.1 8YNk...AoJ --url devnet
   * // For mainnet: Send SOL to 8YNk...AoJ using a wallet or exchange."
   * ```
   */ static buildInstructions(walletAddress, currentBalanceLamports, requiredBalanceLamports) {
        const shortfallLamports = requiredBalanceLamports - currentBalanceLamports;
        const shortfallSol = lamportsToSol(shortfallLamports);
        return `\nAction: Add at least ${shortfallSol} SOL to your wallet to complete this swap.\n\n` + `For devnet: solana airdrop 0.1 ${walletAddress} --url devnet\n` + `For mainnet: Send SOL to ${walletAddress} using a wallet or exchange.`;
    }
}

/**
 * Fetches an Address Lookup Table account from the network.
 *
 * @param connection - The Solana connection to use for fetching.
 * @param altAddress - The public key of the ALT to fetch.
 * @returns Promise resolving to the AddressLookupTableAccount, or null if not found.
 *
 * @example
 * ```typescript
 * import { fetchAddressLookupTable } from '@core/adapter-solana'
 * import { Connection, PublicKey } from '@solana/web3.js'
 *
 * const connection = new Connection('https://api.mainnet-beta.solana.com')
 * const altAddress = new PublicKey('qj4EYgsGpnRdt9rvQW3wWZR8JVaKPg9rG9EB8DNgfz8')
 * const alt = await fetchAddressLookupTable(connection, altAddress)
 * ```
 */ async function fetchAddressLookupTable(connection, altAddress) {
    const response = await connection.getAddressLookupTable(altAddress);
    return response.value ?? null;
}
/**
 * Gets the CCTP Address Lookup Table address for a Solana chain.
 *
 * @param chain - The Solana chain definition to get the ALT address from.
 * @returns The ALT address as a string, or null if not available.
 *
 * @remarks
 * Returns the appropriate ALT constant based on the chain:
 * - Solana mainnet: Returns {@link CCTP_ALT_ADDRESS_MAINNET}
 * - Solana devnet: Returns {@link CCTP_ALT_ADDRESS_DEVNET} (currently null)
 * - Non-Solana chains: Returns null
 *
 * @example
 * ```typescript
 * import { getCctpAltAddress } from '@core/adapter-solana'
 * import { Solana } from '@core/chains'
 *
 * const altAddress = getCctpAltAddress(Solana)
 * if (altAddress) {
 *   console.log('CCTP ALT:', altAddress)
 * }
 * ```
 */ function getCctpAltAddress(chain) {
    // Only Solana chains have ALT support
    if (chain.type !== 'solana') {
        return null;
    }
    // Return appropriate constant based on network
    return chain.isTestnet ? CCTP_ALT_ADDRESS_DEVNET : CCTP_ALT_ADDRESS_MAINNET;
}
/**
 * Fetches the CCTP Address Lookup Table accounts for a Solana chain.
 *
 * @param connection - The Solana connection to use for fetching.
 * @param chain - The Solana chain definition.
 * @returns Promise resolving to an array of AddressLookupTableAccount objects.
 *         Returns an empty array if no ALT is configured or fetch fails.
 *
 * @remarks
 * This is the primary method for obtaining ALT accounts for CCTP transactions.
 * It handles:
 * - Extracting the ALT address from chain configuration
 * - Fetching the ALT account from the network
 *
 * @example
 * ```typescript
 * import { getCctpAddressLookupTableAccounts } from '@core/adapter-solana'
 * import { Connection } from '@solana/web3.js'
 * import { Solana } from '@core/chains'
 *
 * const connection = new Connection('https://api.mainnet-beta.solana.com')
 * const altAccounts = await getCctpAddressLookupTableAccounts(connection, Solana)
 *
 * // Use in transaction building
 * const preparedRequest = await adapter.prepare({
 *   instructions,
 *   addressLookupTableAccounts: altAccounts,
 *   computeUnitLimit: CCTP_COMPUTE_UNITS.mint,
 * }, context)
 * ```
 */ async function getCctpAddressLookupTableAccounts(connection, chain) {
    const altAddress = getCctpAltAddress(chain);
    if (altAddress === null) {
        return [];
    }
    try {
        const altPubkey = new web3_js.PublicKey(altAddress);
        const altAccount = await fetchAddressLookupTable(connection, altPubkey);
        if (altAccount) {
            return [
                altAccount
            ];
        }
    } catch (error) {
        // Log warning but don't fail - transaction can still work without ALT
        // (though it may exceed size limits for complex operations)
        console.warn(`Failed to fetch CCTP Address Lookup Table for ${chain.name}:`, error);
    }
    return [];
}

/**
 * SPL Token program ID (standard, non-2022).
 *
 * @remarks
 * Address: TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA
 */ const TOKEN_PROGRAM_ID = new web3_js.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
/**
 * SPL Associated Token Account program ID.
 *
 * @remarks
 * Address: ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL
 */ const ASSOCIATED_TOKEN_PROGRAM_ID = new web3_js.PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');
/**
 * Derive the Associated Token Account address for a given mint and owner.
 *
 * Equivalent to \@solana/spl-token's `getAssociatedTokenAddressSync`.
 *
 * @param mint - The token mint public key.
 * @param owner - The wallet owner public key.
 * @param allowOwnerOffCurve - Allow the owner to be off the ed25519 curve
 *   (e.g. PDA owners). Defaults to `false`.
 * @param programId - The token program owning the account.
 *   Defaults to the standard SPL Token program.
 * @param associatedTokenProgramId - The ATA program.
 *   Defaults to the standard ATA program.
 * @returns The derived ATA public key.
 *
 * @throws KitError with code 1004 (INPUT_INVALID_ADDRESS) when owner is off the ed25519 curve and allowOwnerOffCurve is false.
 *
 * @example
 * ```typescript
 * import { getAssociatedTokenAddressSync } from '@core/adapter-solana'
 * import { PublicKey } from '@solana/web3.js'
 *
 * const ata = getAssociatedTokenAddressSync(
 *   new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'),
 *   new PublicKey('DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN'),
 * )
 * ```
 */ const getAssociatedTokenAddressSync = (mint, owner, allowOwnerOffCurve = false, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>{
    if (!allowOwnerOffCurve && !web3_js.PublicKey.isOnCurve(owner.toBuffer())) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Owner ${owner.toBase58()} is off the ed25519 curve`,
            cause: {
                trace: {
                    reason: 'Owner is off the ed25519 curve',
                    owner: owner.toBase58()
                }
            }
        });
    }
    const [address] = web3_js.PublicKey.findProgramAddressSync([
        owner.toBuffer(),
        programId.toBuffer(),
        mint.toBuffer()
    ], associatedTokenProgramId);
    return address;
};
/**
 * Build an ATA instruction with the given accounts and data.
 * @internal
 */ const buildAssociatedTokenAccountInstruction = (payer, associatedToken, owner, mint, instructionData, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>new web3_js.TransactionInstruction({
        keys: [
            {
                pubkey: payer,
                isSigner: true,
                isWritable: true
            },
            {
                pubkey: associatedToken,
                isSigner: false,
                isWritable: true
            },
            {
                pubkey: owner,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: mint,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: web3_js.SystemProgram.programId,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: programId,
                isSigner: false,
                isWritable: false
            }
        ],
        programId: associatedTokenProgramId,
        data: instructionData
    });
/**
 * Create an instruction to create an Associated Token Account.
 *
 * Equivalent to \@solana/spl-token's `createAssociatedTokenAccountInstruction`.
 *
 * @param payer - The account paying for the creation (writable signer).
 * @param associatedToken - The ATA address to create (writable).
 * @param owner - The wallet that will own the ATA.
 * @param mint - The token mint.
 * @param programId - The token program. Defaults to SPL Token.
 * @param associatedTokenProgramId - The ATA program.
 * @returns A transaction instruction.
 *
 * @example
 * ```typescript
 * import { createAssociatedTokenAccountInstruction } from '@core/adapter-solana'
 *
 * const ix = createAssociatedTokenAccountInstruction(payer, ata, owner, mint)
 * ```
 */ const createAssociatedTokenAccountInstruction = (payer, associatedToken, owner, mint, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>buildAssociatedTokenAccountInstruction(payer, associatedToken, owner, mint, Buffer.alloc(0), programId, associatedTokenProgramId);
/**
 * Create an idempotent instruction to create an Associated Token Account.
 *
 * Unlike {@link createAssociatedTokenAccountInstruction}, this variant
 * succeeds even if the ATA already exists (uses discriminator `1`).
 *
 * Equivalent to \@solana/spl-token's
 * `createAssociatedTokenAccountIdempotentInstruction`.
 *
 * @param payer - The account paying for the creation (writable signer).
 * @param associatedToken - The ATA address to create (writable).
 * @param owner - The wallet that will own the ATA.
 * @param mint - The token mint.
 * @param programId - The token program. Defaults to SPL Token.
 * @param associatedTokenProgramId - The ATA program.
 * @returns A transaction instruction.
 *
 * @example
 * ```typescript
 * import {
 *   createAssociatedTokenAccountIdempotentInstruction,
 * } from '@core/adapter-solana'
 *
 * const ix = createAssociatedTokenAccountIdempotentInstruction(
 *   payer, ata, owner, mint,
 * )
 * ```
 */ const createAssociatedTokenAccountIdempotentInstruction = (payer, associatedToken, owner, mint, programId = TOKEN_PROGRAM_ID, associatedTokenProgramId = ASSOCIATED_TOKEN_PROGRAM_ID)=>buildAssociatedTokenAccountInstruction(payer, associatedToken, owner, mint, Buffer.from([
        1
    ]), programId, associatedTokenProgramId);
/**
 * SPL Token-2022 (Token Extensions) program ID.
 *
 * @remarks
 * Address: TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb
 */ const TOKEN_2022_PROGRAM_ID = new web3_js.PublicKey('TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb');
/**
 * Detect whether a mint account is owned by the standard Token Program or Token-2022.
 *
 * Fetch the mint account info and inspect its `owner` field. Fall back to
 * `TOKEN_PROGRAM_ID` when the account does not exist on-chain. Transient RPC
 * errors (timeouts, rate limits) are re-thrown so callers can handle them
 * explicitly rather than silently deriving an ATA with the wrong program ID.
 *
 * @param connection - The active Solana RPC connection.
 * @param mintKey - The public key of the mint account to inspect.
 * @returns The owning token program (`TOKEN_PROGRAM_ID` or `TOKEN_2022_PROGRAM_ID`).
 *
 * @example
 * ```typescript
 * import { detectTokenProgram, getAssociatedTokenAddressSync } from '@core/adapter-solana'
 *
 * const programId = await detectTokenProgram(connection, mintPubkey)
 * const ata = getAssociatedTokenAddressSync(mint, owner, false, programId)
 * ```
 */ const detectTokenProgram = async (connection, mintKey)=>{
    try {
        const accountInfo = await connection.getAccountInfo(mintKey, 'confirmed');
        if (accountInfo?.owner.equals(TOKEN_2022_PROGRAM_ID)) {
            return TOKEN_2022_PROGRAM_ID;
        }
        return TOKEN_PROGRAM_ID;
    } catch (error) {
        if (error instanceof Error && /could not find account/i.test(error.message)) {
            return TOKEN_PROGRAM_ID;
        }
        throw error;
    }
};
/**
 * Create a TransferChecked instruction for an SPL token.
 *
 * Token-2022 mints reject the basic `Transfer` instruction and require
 * `TransferChecked`, which includes the mint address and expected decimals.
 * This variant is safe for both standard Token and Token-2022 programs.
 *
 * @param source - The source token account (writable).
 * @param mint - The token mint (read-only, used for decimal verification).
 * @param destination - The destination token account (writable).
 * @param owner - The owner/authority of the source account (signer).
 * @param amount - The number of tokens to transfer (in smallest units).
 * @param decimals - The expected number of decimals for the mint.
 * @param programId - The token program. Defaults to SPL Token.
 * @returns A transaction instruction.
 *
 * @example
 * ```typescript
 * import { createTransferCheckedInstruction } from '@core/adapter-solana'
 *
 * const ix = createTransferCheckedInstruction(
 *   sourceAta, usdcMint, destAta, owner, 1_000_000n, 6,
 * )
 * ```
 */ const createTransferCheckedInstruction = (source, mint, destination, owner, amount, decimals, programId = TOKEN_PROGRAM_ID)=>{
    const data = Buffer.alloc(10);
    data.writeUInt8(12, 0) // TransferChecked instruction discriminator
    ;
    data.writeBigUInt64LE(BigInt(amount), 1);
    data.writeUInt8(decimals, 9);
    return new web3_js.TransactionInstruction({
        keys: [
            {
                pubkey: source,
                isSigner: false,
                isWritable: true
            },
            {
                pubkey: mint,
                isSigner: false,
                isWritable: false
            },
            {
                pubkey: destination,
                isSigner: false,
                isWritable: true
            },
            {
                pubkey: owner,
                isSigner: true,
                isWritable: false
            }
        ],
        programId,
        data
    });
};
/**
 * Mint account data layout size (standard SPL Token).
 * @internal
 */ const MINT_SIZE = 82;
/**
 * Offset of the `decimals` byte within the mint account data.
 * @internal
 */ const DECIMALS_OFFSET = 44;
/**
 * Fetch mint account info from chain and return a minimal mint object.
 *
 * Equivalent to \@solana/spl-token's `getMint` (returns only the fields
 * this SDK needs: `decimals`).
 *
 * @param connection - The Solana RPC connection.
 * @param mintAddress - The public key of the mint account.
 * @param commitment - Optional commitment level.
 * @param programId - Expected owning program. Defaults to SPL Token.
 * @returns An object containing `decimals`.
 *
 * @throws KitError when the account does not exist or is not owned by
 *   the expected token program.
 *
 * @example
 * ```typescript
 * import { getMint, TOKEN_PROGRAM_ID } from '@core/adapter-solana'
 * import { Connection, PublicKey } from '@solana/web3.js'
 *
 * const conn = new Connection('https://api.mainnet-beta.solana.com')
 * const mint = await getMint(conn, new PublicKey('EPjFWdd5...'), 'confirmed')
 * console.log(mint.decimals) // 6
 * ```
 */ const getMint = async (connection, mintAddress, commitment, programId = TOKEN_PROGRAM_ID)=>{
    const info = await connection.getAccountInfo(mintAddress, commitment);
    if (!info) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Mint account ${mintAddress.toBase58()} does not exist`,
            cause: {
                trace: {
                    reason: 'Account not found',
                    mint: mintAddress.toBase58()
                }
            }
        });
    }
    if (!info.owner.equals(programId)) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Mint account ${mintAddress.toBase58()} is not owned by the expected token program`,
            cause: {
                trace: {
                    reason: 'Unexpected program owner',
                    mint: mintAddress.toBase58(),
                    expectedOwner: programId.toBase58(),
                    actualOwner: info.owner.toBase58()
                }
            }
        });
    }
    if (info.data.length < MINT_SIZE) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Mint account ${mintAddress.toBase58()} has invalid data (expected at least ${String(MINT_SIZE)} bytes, got ${String(info.data.length)})`,
            cause: {
                trace: {
                    reason: 'Invalid mint data size',
                    mint: mintAddress.toBase58(),
                    dataLength: info.data.length
                }
            }
        });
    }
    const decimals = info.data[DECIMALS_OFFSET];
    if (decimals === undefined) {
        throw new KitError({
            ...InputError.INVALID_ADDRESS,
            recoverability: 'FATAL',
            message: `Mint account ${mintAddress.toBase58()} is missing decimals at offset ${String(DECIMALS_OFFSET)}`
        });
    }
    return {
        decimals
    };
};

/**
 * Verify and return the user's associated token account for a given mint.
 *
 * This function checks if the user's associated token account (ATA) exists
 * for the specified mint address. If the account doesn't exist, it checks
 * the user's SOL balance and throws a detailed error with instructions
 * for creating the ATA.
 *
 * @param connection - The Solana RPC connection to use for querying.
 * @param owner - The owner's public key for which to check the ATA.
 * @param mint - The token mint address to check against.
 * @returns The verified associated token account address.
 * @throws InsufficientSolError if the ATA doesn't exist and the user lacks sufficient SOL.
 * @throws KitError with OnchainError.SIMULATION_FAILED if the ATA doesn't exist but user has sufficient SOL.
 *
 * @example
 * ```typescript
 * import { Connection, PublicKey } from '@solana/web3.js'
 * import { KitError, OnchainError } from '@core/errors'
 * import { InsufficientSolError } from '@core/adapter-solana'
 * import { assertAtaExists } from './assertAtaExists'
 *
 * const connection = new Connection('https://api.devnet.solana.com')
 * const owner = new PublicKey('8YNkTuuLhJYqGKvgTLnkiXNJKfJxHBu8uKGkDEtGrAoJ')
 * const mint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v') // USDC mint
 *
 * async function checkAta() {
 *   try {
 *     const ataAddress = await assertAtaExists(connection, owner, mint)
 *     console.log(`ATA exists: ${ataAddress.toBase58()}`)
 *   } catch (error) {
 *     if (error instanceof InsufficientSolError) {
 *       console.error('Need SOL to create ATA:', error.message)
 *     } else if (error instanceof KitError && error.code === OnchainError.SIMULATION_FAILED.code) {
 *       console.error('ATA missing but has SOL:', error.message)
 *     }
 *   }
 * }
 * ```
 */ const assertAtaExists = async (connection, owner, mint)=>{
    const tokenProgramId = await detectTokenProgram(connection, mint);
    const ata = getAssociatedTokenAddressSync(mint, owner, false, tokenProgramId);
    const info = await connection.getAccountInfo(ata);
    if (!info) {
        // Check SOL balance before throwing error
        await validateSolBalance(connection, owner, mint, ata, 'User USDC ATA');
        // User has SOL but ATA doesn't exist - get balance for error message
        const currentBalance = await getSolBalance(connection, owner);
        // User has SOL but ATA doesn't exist - provide instructions
        throw new KitError({
            ...OnchainError.SIMULATION_FAILED,
            recoverability: 'FATAL',
            message: `Missing USDC ATA: ${ata.toBase58()}. ` + `Your wallet has sufficient SOL (${lamportsToSol(currentBalance, 4)} SOL), ` + `but the Associated Token Account needs to be created. ` + `The SDK will create it automatically when you execute the transaction. ` + `If you need to create it manually, use: ` + `spl-token create-account ${mint.toBase58()} --owner ${owner.toBase58()}`,
            cause: {
                trace: {
                    ataAddress: ata.toBase58(),
                    mintAddress: mint.toBase58(),
                    ownerAddress: owner.toBase58(),
                    currentBalance: currentBalance.toString(),
                    currentBalanceSol: lamportsToSol(currentBalance, 4)
                }
            }
        });
    }
    return ata;
};

/**
 * Resolve the chain from action params and assert it is a Solana chain.
 *
 * @param params - Action payload containing an optional `chain`.
 * @param context - Resolved operation context (fallback chain source).
 * @returns The resolved Solana chain definition.
 * @throws {KitError} If the resolved chain is not Solana.
 */ function assertSolanaChain(params, context) {
    const chain = params.chain ?? context.chain;
    if (chain.type !== 'solana') {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `Expected Solana chain definition, but received chain type: ${chain.type}`
        });
    }
    return chain;
}

/**
 * Assert that a method exists on an Anchor program and return it.
 *
 * Centralise the `in` type-narrowing guard and the {@link KitError}
 * throw so each gateway action is a one-liner instead of a 7-line block.
 *
 * @param program - The Anchor program instance.
 * @param methodName - The expected instruction method name.
 * @returns The program method, ready to be invoked.
 * @throws KitError INVALID_CHAIN if the method is not found.
 *
 * @example
 * ```typescript
 * const method = assertProgramMethod(program, 'deposit')
 * const ix = await method(new BN(amount)).accounts({ ... }).instruction()
 * ```
 */ function assertProgramMethod(program, methodName) {
    if (!(methodName in program.methods)) {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `${methodName} method not found in program ${program.programId.toBase58()}. The on-chain program may be outdated or misconfigured.`
        });
    }
    const method = program.methods[methodName];
    if (typeof method !== 'function') {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `${methodName} on program ${program.programId.toBase58()} is not a callable method (got ${typeof method}).`
        });
    }
    return method;
}

/**
 * Derive the PDAs required by the Gateway Wallet `deposit` and `deposit_for`
 * instructions.
 *
 * @param programId - The Gateway Wallet program ID.
 * @param depositor - The depositor public key whose balance will be credited.
 * @param tokenMint - The token mint (e.g. USDC) public key.
 * @param sender - The transaction signer (owner). For `deposit` this equals
 *   depositor; for `deposit_for` it may differ.
 * @returns Derived PDA addresses for the Gateway deposit accounts.
 *
 * @example
 * ```typescript
 * import { PublicKey } from '@solana/web3.js'
 * const pdas = deriveGatewayDepositPdas(
 *   new PublicKey('GATEwy4Y...'),
 *   depositorKey,
 *   usdcMintKey,
 *   senderKey,
 * )
 * ```
 */ function deriveGatewayDepositPdas(programId, depositor, tokenMint, sender) {
    const [gatewayWallet] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.gatewayWallet)
    ], programId);
    const [deposit] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.deposit),
        tokenMint.toBuffer(),
        depositor.toBuffer()
    ], programId);
    const [custodyTokenAccount] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.custodyTokenAccount),
        tokenMint.toBuffer()
    ], programId);
    const [senderDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.denylist),
        sender.toBuffer()
    ], programId);
    const [depositorDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.denylist),
        depositor.toBuffer()
    ], programId);
    return {
        gatewayWallet,
        deposit,
        custodyTokenAccount,
        senderDenylist,
        depositorDenylist
    };
}
/**
 * Derive the PDAs required by the Gateway Wallet `add_delegate` and
 * `remove_delegate` instructions.
 *
 * IDL PDA seeds for `delegateAccount`:
 *   `["gateway_delegate", tokenMint, depositor, delegate(arg)]`
 *
 * @param programId - The Gateway Wallet program ID.
 * @param depositor - The depositor public key granting/revoking delegation.
 * @param delegate - The delegate public key being authorized/revoked.
 * @param tokenMint - The token mint (e.g. USDC) public key.
 * @returns Derived PDA addresses for the Gateway delegate accounts.
 *
 * @example
 * ```typescript
 * import { PublicKey } from '@solana/web3.js'
 * const pdas = deriveGatewayDelegatePdas(
 *   new PublicKey('GATEwy4Y...'),
 *   depositorKey,
 *   delegateKey,
 *   usdcMintKey,
 * )
 * ```
 */ function deriveGatewayDelegatePdas(programId, depositor, delegate, tokenMint) {
    const [gatewayWallet] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.gatewayWallet)
    ], programId);
    const [delegateAccount] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.delegate),
        tokenMint.toBuffer(),
        depositor.toBuffer(),
        delegate.toBuffer()
    ], programId);
    const [depositorDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.denylist),
        depositor.toBuffer()
    ], programId);
    const [delegateDenylist] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.denylist),
        delegate.toBuffer()
    ], programId);
    return {
        gatewayWallet,
        delegateAccount,
        depositorDenylist,
        delegateDenylist
    };
}

/**
 * Resolve the Gateway Wallet program ID for a Solana chain with Gateway v1
 * support.
 *
 * @param chain - Chain definition (must be Solana with Gateway v1 configured).
 * @returns Gateway Wallet program ID as a base58 string.
 * @throws {KitError} INVALID_CHAIN if the chain does not support Gateway v1.
 *
 * @example
 * ```typescript
 * import { Solana } from '@core/chains'
 * const programId = getGatewayWalletProgramId(Solana)
 * // 'GATEwy4YxeiEbRJLwB6dXgg7q61e6zBPrMzYj5h1pRXQ'
 * ```
 */ function getGatewayWalletProgramId(chain) {
    if (!isGatewayV1Supported(chain)) {
        throw new KitError({
            ...InputError.INVALID_CHAIN,
            recoverability: 'FATAL',
            message: `Gateway Wallet program ID not found: chain "${chain.name}" does not have Gateway v1 contracts configured.`,
            cause: {
                trace: {
                    chain: chain.name
                }
            }
        });
    }
    return chain.gateway.contracts.v1.wallet;
}

// GatewayDeposit PDA layout — custom 2-byte discriminator [21, 1]:
//   2  bytes  discriminator
//   1  byte   bump
//  32  bytes  depositor
//  32  bytes  token_mint
//   8  bytes  available_amount   (u64 LE)  offset 67
//   8  bytes  withdrawing_amount (u64 LE)  offset 75
//   8  bytes  withdrawal_block   (u64 LE)  offset 83
const LAYOUT_BASE = 2 + 1 + 32 + 32;
/**
 * Named byte offsets for u64 fields in the `GatewayDeposit` PDA.
 *
 * Keeping offsets co-located with the layout comment ensures any future
 * layout change is reflected in a single place.
 */ const GatewayDepositOffset = {
    withdrawingBalance: LAYOUT_BASE + 8,
    withdrawalBlock: LAYOUT_BASE + 8 + 8
};
/**
 * Prepare a chain request that reads a single u64 field from the
 * `GatewayDeposit` PDA at the given byte offset.
 *
 * Handles chain assertion, program-ID lookup, PDA derivation, and account
 * fetching — the boilerplate shared by every PDA-based read action.
 *
 * @param params  - Token mint, depositor public key, and optional chain override.
 * @param adapter - Solana adapter for provider/connection access.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @param offset  - Byte offset of the target u64 field (use {@link GatewayDepositOffset}).
 * @returns Prepared chain request whose `execute()` resolves to the field value
 *   as a decimal string, or `'0'` if the PDA does not exist / is too short.
 * @throws {KitError} If the chain is not Solana or does not support Gateway v1.
 */ async function prepareGatewayDepositRead(params, adapter, context, offset) {
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const connection = provider.connection;
    const tokenMint = new web3_js.PublicKey(params.token);
    const depositor = new web3_js.PublicKey(params.depositor);
    const programId = new web3_js.PublicKey(walletProgramId);
    const pdas = deriveGatewayDepositPdas(programId, depositor, tokenMint, depositor);
    const noop = await createNoopChainRequest();
    return {
        type: 'solana',
        estimate: noop.estimate,
        execute: async ()=>{
            const accountInfo = await connection.getAccountInfo(pdas.deposit, 'confirmed');
            if (!accountInfo || accountInfo.data.length < offset + 8) {
                return '0';
            }
            if (accountInfo.data[0] !== 21 || accountInfo.data[1] !== 1) {
                return '0';
            }
            const value = accountInfo.data.readBigUInt64LE(offset);
            return value.toString();
        }
    };
}

/**
 * Prepare a Solana Gateway Wallet `deposit` transaction.
 *
 * Deposit tokens into the Gateway Wallet on behalf of the signer. The
 * resulting balance is credited to the signer's Gateway deposit account.
 * Corresponds to the
 * [GatewayWallet deposit instruction](https://developers.circle.com/gateway/references/solana-programs#deposit).
 *
 * @param params - Action payload containing token mint address and amount.
 * @param adapter - Solana adapter for chain context and transaction
 *   preparation.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request for the deposit instruction.
 * @throws Error If the chain is not Solana, does not support Gateway v1, or
 *   the user's token account does not exist.
 *
 * @example
 * ```typescript
 * import { deposit } from './deposit'
 *
 * const prepared = await deposit(
 *   { token: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', value: 1_000_000n },
 *   adapter,
 *   context,
 * )
 * await prepared.execute()
 * ```
 */ const deposit = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const tokenMint = new web3_js.PublicKey(params.token);
    const program = await getProgram(provider, walletProgramId);
    const ownerTokenAccount = await assertAtaExists(provider.connection, user, tokenMint);
    const pdas = deriveGatewayDepositPdas(program.programId, user, tokenMint, user);
    const method = assertProgramMethod(program, 'deposit');
    const instruction = await method(new bn_js.BN(params.value.toString())).accounts({
        payer: user,
        owner: user,
        gatewayWallet: pdas.gatewayWallet,
        ownerTokenAccount,
        custodyTokenAccount: pdas.custodyTokenAccount,
        deposit: pdas.deposit,
        depositorDenylist: pdas.depositorDenylist
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

/**
 * Prepare a Solana Gateway Wallet `deposit_for` transaction.
 *
 * Deposit tokens on behalf of another address. The tokens are transferred
 * from the signer's token account to the Gateway Wallet custody and the
 * resulting balance is credited to the specified `depositor`.
 * Corresponds to the
 * [GatewayWallet deposit_for instruction](https://developers.circle.com/gateway/references/solana-programs#deposit).
 *
 * @param params - Action payload containing token mint, depositor address,
 *   and amount.
 * @param adapter - Solana adapter for chain context and transaction
 *   preparation.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request for the deposit_for instruction.
 * @throws Error If the chain is not Solana, does not support Gateway v1, or
 *   the user's token account does not exist.
 *
 * @example
 * ```typescript
 * import { depositFor } from './depositFor'
 *
 * const prepared = await depositFor(
 *   {
 *     token: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *     depositor: 'TargetDepositorPublicKey...',
 *     value: 1_000_000n,
 *   },
 *   adapter,
 *   context,
 * )
 * await prepared.execute()
 * ```
 */ const depositFor = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const tokenMint = new web3_js.PublicKey(params.token);
    const depositor = new web3_js.PublicKey(params.depositor);
    const program = await getProgram(provider, walletProgramId);
    const ownerTokenAccount = await assertAtaExists(provider.connection, user, tokenMint);
    const pdas = deriveGatewayDepositPdas(program.programId, depositor, tokenMint, user);
    const method = assertProgramMethod(program, 'depositFor');
    const instruction = await method(new bn_js.BN(params.value.toString()), depositor).accounts({
        payer: user,
        owner: user,
        gatewayWallet: pdas.gatewayWallet,
        ownerTokenAccount,
        custodyTokenAccount: pdas.custodyTokenAccount,
        deposit: pdas.deposit,
        senderDenylist: pdas.senderDenylist,
        depositorDenylist: pdas.depositorDenylist
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

/**
 * Prepare a Solana Gateway Wallet `add_delegate` transaction.
 *
 * Grants spending rights to a delegate address on the signer's Gateway
 * account for the specified token. Corresponds to the
 * [GatewayWallet add_delegate instruction](https://developers.circle.com/gateway/references/solana-programs).
 *
 * @param params - Action payload containing token mint and delegate address.
 * @param adapter - Solana adapter for chain context and transaction preparation.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request for the add_delegate instruction.
 * @throws Error If the chain is not Solana or does not support Gateway v1.
 */ const addDelegate = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const tokenMint = new web3_js.PublicKey(params.token);
    const delegate = new web3_js.PublicKey(params.delegate);
    const program = await getProgram(provider, walletProgramId);
    const pdas = deriveGatewayDelegatePdas(program.programId, user, delegate, tokenMint);
    const method = assertProgramMethod(program, 'addDelegate');
    const instruction = await method(delegate).accountsPartial({
        payer: user,
        depositor: user,
        gatewayWallet: pdas.gatewayWallet,
        tokenMint,
        delegateAccount: pdas.delegateAccount,
        depositorDenylist: pdas.depositorDenylist,
        delegateDenylist: pdas.delegateDenylist
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

/**
 * Prepare a Solana Gateway Wallet `remove_delegate` transaction.
 *
 * Revokes spending rights from a delegate address on the signer's Gateway
 * account for the specified token. Corresponds to the
 * [GatewayWallet remove_delegate instruction](https://developers.circle.com/gateway/references/solana-programs).
 *
 * @param params - Action payload containing token mint and delegate address.
 * @param adapter - Solana adapter for chain context and transaction preparation.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request for the remove_delegate instruction.
 * @throws Error If the chain is not Solana or does not support Gateway v1.
 */ const removeDelegate = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const tokenMint = new web3_js.PublicKey(params.token);
    const delegate = new web3_js.PublicKey(params.delegate);
    const program = await getProgram(provider, walletProgramId);
    const pdas = deriveGatewayDelegatePdas(program.programId, user, delegate, tokenMint);
    const method = assertProgramMethod(program, 'removeDelegate');
    const instruction = await method(delegate).accountsPartial({
        payer: user,
        depositor: user,
        gatewayWallet: pdas.gatewayWallet,
        tokenMint,
        delegateAccount: pdas.delegateAccount,
        depositorDenylist: pdas.depositorDenylist,
        delegateDenylist: pdas.delegateDenylist
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

/**
 * Check whether an address is an active delegate on Solana.
 *
 * Unlike EVM where a contract view function is called, Solana delegate status
 * is determined by reading the `gateway_delegate` PDA
 * (`["gateway_delegate", tokenMint, depositor, delegate]`) and inspecting its
 * on-chain status byte (`0x01` = active, `0x02` = removed). The PDA persists
 * even after removal, so mere existence is not sufficient.
 *
 * @param params - Action payload: token mint, depositor (owner), and delegate.
 * @param adapter - Solana adapter for chain context.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request whose `execute()` resolves to `"true"`/`"false"`.
 */ const isDelegate = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const connection = provider.connection;
    const tokenMint = new web3_js.PublicKey(params.token);
    const depositor = new web3_js.PublicKey(params.depositor);
    const delegate = new web3_js.PublicKey(params.delegate);
    const programId = new web3_js.PublicKey(walletProgramId);
    const pdas = deriveGatewayDelegatePdas(programId, depositor, delegate, tokenMint);
    // The delegate PDA persists even after removal. The program stores a
    // status byte at offset 3: 0x01 = active, 0x02 = removed.
    const DELEGATE_STATUS_OFFSET = 3;
    const DELEGATE_ACTIVE_STATUS = 0x01;
    const noop = await createNoopChainRequest();
    return {
        type: 'solana',
        estimate: noop.estimate,
        execute: async ()=>{
            const accountInfo = await connection.getAccountInfo(pdas.delegateAccount, params.commitment ?? 'confirmed');
            if (!accountInfo || accountInfo.data.length <= DELEGATE_STATUS_OFFSET) {
                return String(false);
            }
            const status = accountInfo.data[DELEGATE_STATUS_OFFSET];
            return String(status === DELEGATE_ACTIVE_STATUS);
        }
    };
};

/**
 * Prepare a Solana Gateway Wallet `initiate_withdrawal` transaction.
 *
 * Starts a delayed fund removal from the caller's Gateway deposit account.
 * A mandatory withdrawal delay must elapse before {@link withdraw} can
 * complete the removal. Corresponds to the
 * [GatewayWallet initiate_withdrawal instruction](https://developers.circle.com/gateway/references/solana-programs#initiatewithdrawal).
 *
 * @param params - Action payload containing token mint address and amount.
 * @param adapter - Solana adapter for chain context and transaction preparation.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request for the initiate_withdrawal instruction.
 * @throws KitError If the chain is not Solana or does not support Gateway v1.
 */ const initiateWithdrawal = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const tokenMint = new web3_js.PublicKey(params.token);
    const program = await getProgram(provider, walletProgramId);
    const pdas = deriveGatewayDepositPdas(program.programId, user, tokenMint, user);
    const method = assertProgramMethod(program, 'initiateWithdrawal');
    // accountsPartial: Anchor resolves remaining accounts (token program, system
    // program, etc.) from the on-chain IDL. Only user-specific accounts are
    // supplied here. See deposit.ts for the .accounts() alternative.
    const instruction = await method(new bn_js.BN(params.value.toString())).accountsPartial({
        depositor: user,
        gatewayWallet: pdas.gatewayWallet,
        deposit: pdas.deposit
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

/**
 * Prepare a Solana Gateway Wallet `withdraw` transaction.
 *
 * Completes a previously initiated fund removal after the withdrawal delay
 * has elapsed. The full pending withdrawal balance is returned to the
 * depositor's token account. Corresponds to the
 * [GatewayWallet withdraw instruction](https://developers.circle.com/gateway/references/solana-programs#withdraw).
 *
 * @param params - Action payload containing token mint address.
 * @param adapter - Solana adapter for chain context and transaction preparation.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request for the withdraw instruction.
 * @throws KitError If the chain is not Solana, does not support Gateway v1, or
 *   the user's token account does not exist.
 */ const withdraw = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const connection = provider.connection;
    const user = provider.wallet.publicKey;
    const tokenMint = new web3_js.PublicKey(params.token);
    const program = await getProgram(provider, walletProgramId);
    const ownerTokenAccount = await assertAtaExists(connection, user, tokenMint);
    const pdas = deriveGatewayDepositPdas(program.programId, user, tokenMint, user);
    const method = assertProgramMethod(program, 'withdraw');
    // accountsPartial: Anchor resolves remaining accounts (token program, system
    // program, etc.) from the on-chain IDL. Only user-specific accounts are
    // supplied here. See deposit.ts for the .accounts() alternative.
    const instruction = await method().accountsPartial({
        depositor: user,
        gatewayWallet: pdas.gatewayWallet,
        depositorTokenAccount: ownerTokenAccount,
        custodyTokenAccount: pdas.custodyTokenAccount,
        deposit: pdas.deposit
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

/**
 * Read the pending withdrawal balance from the Solana `GatewayDeposit` PDA.
 *
 * @param params - Action payload: token mint and depositor public key.
 * @param adapter - Solana adapter for chain context.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request whose `execute()` resolves to the
 *   withdrawing balance as a string (smallest unit).
 * @throws {KitError} If the chain is not Solana or does not support Gateway v1.
 */ const withdrawingBalance = async (params, adapter, context)=>prepareGatewayDepositRead(params, adapter, context, GatewayDepositOffset.withdrawingBalance);

/**
 * Read the withdrawal block from the Solana `GatewayDeposit` PDA.
 *
 * Return the slot number at which a pending withdrawal can be completed.
 * The depositor must wait until the current slot reaches this value
 * before calling `withdraw`.
 *
 * @param params - Action payload: token mint and depositor public key.
 * @param adapter - Solana adapter for chain context.
 * @param context - Resolved operation context (chain must support Gateway v1).
 * @returns Prepared chain request whose `execute()` resolves to the
 *   withdrawal block (slot) number as a string.
 * @throws {KitError} If the chain is not Solana or does not support Gateway v1.
 */ const withdrawalBlock = async (params, adapter, context)=>prepareGatewayDepositRead(params, adapter, context, GatewayDepositOffset.withdrawalBlock);

/**
 * Prepare a Solana transaction that invokes the Gateway Wallet program's
 * `gatewayBurn` instruction with encoded burn data and a burn signature.
 *
 * @param params - The action payload containing `calldataBytes` and `signature`
 *   (hex strings, optional `0x` prefix), and optional `chain` to override context.
 * @param adapter - The Solana adapter used to obtain the Anchor provider and to prepare the request.
 * @param context - The resolved operation context (chain and address).
 * @returns A prepared chain request whose execute step submits the burn instruction.
 * @throws Error when the chain is not Solana, when the Gateway Wallet program lacks
 *   a `gatewayBurn` method, or when provider/program setup fails.
 *
 * @example
 * ```typescript
 * import { gatewayBurn } from '@core/adapter-solana'
 * const prepared = await gatewayBurn(
 *   { calldataBytes: '0x...', signature: '0x...' },
 *   adapter,
 *   context,
 * )
 * const txHash = await prepared.execute()
 * ```
 */ const gatewayBurn = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    const walletProgramId = getGatewayWalletProgramId(chain);
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const program = await getProgram(provider, walletProgramId);
    if (typeof params.calldataBytes !== 'string') {
        throw createValidationFailedError('calldataBytes', params.calldataBytes, 'must be a hex string');
    }
    if (typeof params.signature !== 'string') {
        throw createValidationFailedError('signature', params.signature, 'must be a hex string');
    }
    const calldataBytes = Buffer.from(params.calldataBytes.startsWith('0x') ? params.calldataBytes.slice(2) : params.calldataBytes, 'hex');
    const signature = Buffer.from(params.signature.startsWith('0x') ? params.signature.slice(2) : params.signature, 'hex');
    const [gatewayWallet] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from(GATEWAY_WALLET_SEEDS.gatewayWallet)
    ], program.programId);
    const method = assertProgramMethod(program, 'gatewayBurn');
    const instruction = await method({
        encodedBurnData: calldataBytes,
        burnSignature: signature
    }).accounts({
        payer: user,
        signer: user,
        gatewayWallet
    }).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

const enc = new TextEncoder();
const GATEWAY_MINTER_SEED = enc.encode('gateway_minter');
const GATEWAY_MINTER_CUSTODY_SEED = enc.encode('gateway_minter_custody');
const USED_TRANSFER_SPEC_HASH_SEED = enc.encode('used_transfer_spec_hash');
// Attestation header offsets (big-endian)
const NUM_ATTESTATIONS_OFFSET = 84;
const ELEMENTS_OFFSET = 88;
// Per-element field offsets (relative to element start)
const DEST_TOKEN_OFFSET = 0;
const DEST_RECIPIENT_OFFSET = 32;
const TRANSFER_SPEC_HASH_OFFSET = 72;
const HOOK_DATA_LENGTH_OFFSET = 104;
const HOOK_DATA_OFFSET = 108;
/**
 * Parse the attestation binary to extract each element's
 * destination_token, destination_recipient, and transfer_spec_hash.
 *
 * @param attestation - The raw attestation buffer (e.g. from hex payload).
 * @returns An array of elements used to build remaining accounts for gatewayMint.
 */ /** Minimum bytes needed to read the numAttestations header field. */ const MIN_ATTESTATION_HEADER_BYTES = NUM_ATTESTATIONS_OFFSET + 4;
/** Fixed size of an attestation element before the variable hook_data. */ const ELEMENT_FIXED_BYTES = HOOK_DATA_OFFSET;
function parseAttestationElements(attestation) {
    if (attestation.length < MIN_ATTESTATION_HEADER_BYTES) {
        throw createValidationFailedError('attestation', `length=${String(attestation.length)}`, `Attestation buffer too short to read header (need ${String(MIN_ATTESTATION_HEADER_BYTES)} bytes)`);
    }
    const numAttestations = attestation.readUInt32BE(NUM_ATTESTATIONS_OFFSET);
    const elements = [];
    let offset = ELEMENTS_OFFSET;
    for(let i = 0; i < numAttestations; i++){
        if (offset + ELEMENT_FIXED_BYTES > attestation.length) {
            throw createValidationFailedError('attestation', `element=${String(i)}, offset=${String(offset)}`, `Attestation buffer truncated at element ${String(i)} (need ${String(offset + ELEMENT_FIXED_BYTES)} bytes, have ${String(attestation.length)})`);
        }
        const destToken = new web3_js.PublicKey(attestation.subarray(offset + DEST_TOKEN_OFFSET, offset + DEST_TOKEN_OFFSET + 32));
        const destRecipient = new web3_js.PublicKey(attestation.subarray(offset + DEST_RECIPIENT_OFFSET, offset + DEST_RECIPIENT_OFFSET + 32));
        const transferSpecHash = Buffer.from(attestation.subarray(offset + TRANSFER_SPEC_HASH_OFFSET, offset + TRANSFER_SPEC_HASH_OFFSET + 32));
        elements.push({
            destinationToken: destToken,
            destinationRecipient: destRecipient,
            transferSpecHash
        });
        const hookDataLen = attestation.readUInt32BE(offset + HOOK_DATA_LENGTH_OFFSET);
        const nextOffset = offset + HOOK_DATA_OFFSET + hookDataLen;
        if (nextOffset > attestation.length) {
            throw createValidationFailedError('attestation', `element=${String(i)}, hookDataLen=${String(hookDataLen)}`, `Attestation hook_data extends beyond buffer at element ${String(i)} (need ${String(nextOffset)} bytes, have ${String(attestation.length)})`);
        }
        offset = nextOffset;
    }
    return elements;
}
/**
 * Prepare a Solana transaction that invokes the Gateway Minter program's
 * `gatewayMint` instruction to mint USDC using an attestation and signature.
 *
 * @param params - The action payload containing `attestation` and `signature`
 *   (hex strings, optional `0x` prefix), and optional `chain` to override context.
 * @param adapter - The Solana adapter used to obtain the Anchor provider and to prepare the request.
 * @param context - The resolved operation context (chain and address).
 * @returns A prepared chain request whose execute step submits the mint instruction.
 * @throws Error when the chain is not Solana, when the chain does not support Gateway v1,
 *   when the Gateway Minter program lacks a `gatewayMint` method, or when provider/program setup fails.
 *
 * @example
 * ```typescript
 * import { gatewayMint } from '@core/adapter-solana'
 * const prepared = await gatewayMint(
 *   { attestation: '0x...', signature: '0x...' },
 *   adapter,
 *   context,
 * )
 * const txHash = await prepared.execute()
 * ```
 */ const gatewayMint = async (params, adapter, context)=>{
    const chain = assertSolanaChain(params, context);
    if (!isGatewayV1Supported(chain)) {
        throw createValidationFailedError('chain', chain.name, 'Gateway Minter program ID not found: chain does not have Gateway v1 contracts configured');
    }
    const minterProgramId = chain.gateway.contracts.v1.minter;
    const provider = await adapter.getAnchorProvider(context);
    const user = provider.wallet.publicKey;
    const program = await getProgram(provider, minterProgramId);
    if (typeof params.attestation !== 'string') {
        throw createValidationFailedError('attestation', params.attestation, 'must be a hex string');
    }
    if (typeof params.signature !== 'string') {
        throw createValidationFailedError('signature', params.signature, 'must be a hex string');
    }
    const attestation = Buffer.from(params.attestation.startsWith('0x') ? params.attestation.slice(2) : params.attestation, 'hex');
    const signature = Buffer.from(params.signature.startsWith('0x') ? params.signature.slice(2) : params.signature, 'hex');
    const [gatewayMinterState] = web3_js.PublicKey.findProgramAddressSync([
        GATEWAY_MINTER_SEED
    ], program.programId);
    // Parse attestation to derive remaining accounts for each element
    const elements = parseAttestationElements(attestation);
    const remainingAccounts = [];
    for (const el of elements){
        // 1. Custody token account PDA
        const [custodyPda] = web3_js.PublicKey.findProgramAddressSync([
            GATEWAY_MINTER_CUSTODY_SEED,
            el.destinationToken.toBuffer()
        ], program.programId);
        // 2. Destination recipient token account — the attestation already
        //    encodes the ATA (not the wallet), so pass it directly.
        const recipientTokenAccount = el.destinationRecipient;
        // 3. Used transfer spec hash PDA
        const [usedHashPda] = web3_js.PublicKey.findProgramAddressSync([
            USED_TRANSFER_SPEC_HASH_SEED,
            el.transferSpecHash
        ], program.programId);
        remainingAccounts.push({
            pubkey: custodyPda,
            isSigner: false,
            isWritable: true
        }, {
            pubkey: recipientTokenAccount,
            isSigner: false,
            isWritable: true
        }, {
            pubkey: usedHashPda,
            isSigner: false,
            isWritable: true
        });
    }
    const method = assertProgramMethod(program, 'gatewayMint');
    const instruction = await method({
        attestation,
        signature
    }).accounts({
        payer: user,
        destinationCaller: user,
        gatewayMinter: gatewayMinterState,
        systemProgram: web3_js.SystemProgram.programId,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID
    }).remainingAccounts(remainingAccounts).instruction();
    return adapter.prepare({
        instructions: [
            instruction
        ]
    }, context);
};

function bytesToHex(bytes) {
    const out = new Array(bytes.length);
    for(let i = 0; i < bytes.length; i++){
        out[i] = (bytes[i] ?? 0).toString(16).padStart(2, '0');
    }
    return out.join('');
}
function throwValidationError(message) {
    throw new KitError({
        ...InputError.VALIDATION_FAILED,
        recoverability: 'FATAL',
        message
    });
}
/**
 * Build a prepared chain request that signs the Gateway burn intent payload
 * (typed data) with the adapter's signer and returns the signature as a hex string.
 *
 * The request is synchronous; the actual signing happens when the returned
 * object's `execute()` is invoked. Supports raw key signing (\@noble/curves),
 * provider-backed signers that implement `signMessage`, and \@solana/kit
 * signers that implement `signMessages`.
 *
 * @param params - The action payload containing `typedData` (Uint8Array or
 *   ArrayBufferView) and optional `chain` to override context.
 * @param adapter - The Solana adapter used to obtain the signer.
 * @param context - The resolved operation context (chain and address).
 * @returns A prepared chain request with `estimate` (no-op) and `execute` that
 *   returns the signature as a `0x`-prefixed hex string.
 * @throws KitError (VALIDATION_FAILED) when the chain is not Solana or when
 *   `typedData` is not a Uint8Array or ArrayBufferView.
 *
 * @example
 * ```typescript
 * import { signBurnIntent } from '@core/adapter-solana'
 * const prepared = signBurnIntent(
 *   { typedData: encodedBurnData },
 *   adapter,
 *   context,
 * )
 * const signatureHex = await prepared.execute()
 * ```
 */ const signBurnIntent = (params, adapter, context)=>{
    assertSolanaChain(params, context);
    const raw = params.typedData;
    let encodedData;
    if (raw instanceof Uint8Array) {
        encodedData = raw;
    } else if (typeof ArrayBuffer !== 'undefined' && ArrayBuffer.isView(raw)) {
        const view = raw;
        encodedData = new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
    } else {
        throwValidationError('signBurnIntent: typedData must be a Uint8Array or ArrayBufferView to prevent signature corruption');
    }
    return {
        type: 'solana',
        estimate: async ()=>await Promise.resolve({
                gas: 0n,
                gasPrice: 0n,
                fee: '0'
            }),
        execute: async ()=>{
            const signer = await adapter.getSigner(context);
            let sigBytes;
            if (signer.isProviderSigner && signer.signMessage) {
                const result = await signer.signMessage(encodedData);
                if (!result?.signature || result?.signature?.length !== 64) {
                    throwValidationError(`Invalid signature length: ${String(result?.signature?.length ?? 'null')}`);
                }
                sigBytes = result.signature;
            } else if (signer.signMessages && signer.address) {
                const results = await signer.signMessages([
                    {
                        content: encodedData
                    }
                ]);
                const signatureDict = results[0];
                const signature = signatureDict?.[signer.address];
                if (signature?.length !== 64) {
                    throwValidationError(`Invalid signature length from signMessages: ${String(signature?.length ?? 'null')}`);
                }
                sigBytes = signature;
            } else if (signer.secretKey) {
                const skLen = signer.secretKey.length;
                if (skLen !== 32 && skLen !== 64) {
                    throwValidationError('Invalid private key: expected 32 or 64 bytes');
                }
                const privKey = skLen === 64 ? signer.secretKey.slice(0, 32) : signer.secretKey;
                sigBytes = ed25519.ed25519.sign(encodedData, privKey);
            } else {
                throwValidationError('Signer does not support any known signing method (secretKey, signMessage, or signMessages)');
            }
            return '0x' + bytesToHex(sigBytes);
        }
    };
};

/**
 * Derive all necessary Program Derived Addresses (PDAs) for the CCTP deposit-for-burn process.
 *
 * This function calculates the deterministic addresses for all accounts needed to execute
 * a cross-chain transfer from Solana to another blockchain via Circle's CCTP.
 *
 * @param tokenProg - The token messenger program instance
 * @param msgProg - The message transmitter program instance
 * @param usdcMint - The mint address for USDC on Solana
 * @param destinationDomain - The numeric domain identifier for the destination chain
 * @returns An object containing all derived PDAs required for the deposit operation
 *
 * @throws Will throw if the program IDs are invalid
 *
 * @example
 * ```typescript
 * import { Connection, PublicKey } from '@solana/web3.js'
 * import { Program } from '@coral-xyz/anchor'
 * import { derivePdas } from './derivePdas'
 *
 * // Initialize your connection and programs
 * const connection = new Connection('https://api.mainnet-beta.solana.com')
 * const tokenProgram = new Program(idl, new PublicKey('...'), { connection })
 * const msgProgram = new Program(idl, new PublicKey('...'), { connection })
 *
 * // USDC mint on Solana
 * const usdcMint = new PublicKey('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')
 *
 * // Ethereum domain ID
 * const ethereumDomain = 0
 *
 * const pdas = derivePdas(tokenProgram, msgProgram, usdcMint, ethereumDomain)
 * console.log('Token Messenger PDA:', pdas.tokenMessengerPda.toString())
 * ```
 */ const derivePdas$2 = (tokenProg, msgProg, usdcMint, destinationDomain)=>{
    // Derive sender authority PDA
    const [senderAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('sender_authority')
    ], tokenProg.programId);
    // Derive token messenger PDA
    const [tokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_messenger')
    ], tokenProg.programId);
    // Derive token minter PDA
    const [tokenMinterPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_minter')
    ], tokenProg.programId);
    // Derive local token PDA using the USDC mint
    const [localTokenPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('local_token'),
        usdcMint.toBuffer()
    ], tokenProg.programId);
    // Derive message transmitter PDA
    const [messageTransmitterPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('message_transmitter')
    ], msgProg.programId);
    // Convert destination domain to a buffer for use as a seed
    const domainSeed = Buffer.from(destinationDomain.toString(), 'utf8');
    // Derive remote token messenger PDA using the destination domain
    const [remoteTokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('remote_token_messenger'),
        domainSeed
    ], tokenProg.programId);
    return {
        senderAuthorityPda,
        tokenMessengerPda,
        tokenMinterPda,
        localTokenPda,
        messageTransmitterPda,
        remoteTokenMessengerPda
    };
};

/**
 * Convert a hex-encoded hookData string to a Buffer for Solana programs.
 *
 * This utility handles both `0x`-prefixed and non-prefixed hex strings,
 * normalizing them into a Buffer suitable for use with Anchor program methods.
 *
 * @param hookData - The hex-encoded hook data string (with or without `0x` prefix).
 * @returns A Buffer containing the decoded hook data bytes.
 * @throws KitError if hookData is empty or only contains '0x' prefix.
 *
 * @example
 * ```typescript
 * import { convertHookDataToBuffer } from './convertHookDataToBuffer'
 *
 * // With 0x prefix
 * const buffer1 = convertHookDataToBuffer('0x636374702d666f7277617264...')
 *
 * // Without 0x prefix
 * const buffer2 = convertHookDataToBuffer('636374702d666f7277617264...')
 * ```
 */ function convertHookDataToBuffer(hookData) {
    // Validate hookData is not empty (consistent with EVM validation)
    if (hookData === undefined || hookData === '' || hookData === '0x') {
        throw createValidationFailedError('hookData', hookData, 'hookData cannot be empty');
    }
    // Strip 0x prefix if present, then decode hex to Buffer
    return hookData.startsWith('0x') ? Buffer.from(hookData.slice(2), 'hex') : Buffer.from(hookData, 'hex');
}

/**
 * Create a deposit for burn instruction for CCTP cross-chain USDC transfers.
 *
 * This function builds the Solana transaction instruction needed to deposit USDC
 * for burning as part of the Cross-Chain Transfer Protocol (CCTP) flow. It supports
 * both standard depositForBurn and depositForBurnWithHook variants based on whether
 * hookData is present in the params. It also generates a fresh keypair for the message
 * event that will track the transfer.
 *
 * @param params - The deposit parameters including amount, destination details, and optional hookData.
 * @param programs - The Anchor program interfaces for tokenMessenger and messageTransmitter.
 * @param pdas - The derived program addresses required for the instruction.
 * @param userUsdcAta - The user's USDC associated token account address.
 * @param user - The user's public key that will sign the transaction.
 * @returns An object containing the transaction instructions and required signer keypair.
 * @throws KitError if the required method is not found in the tokenMessenger program.
 *
 * @example
 * ```typescript
 * import { buildInstructions } from './buildInstructions'
 *
 * // Standard depositForBurn
 * const { ixs, signer } = await buildInstructions(
 *   {
 *     amount: BigInt('1000000'),
 *     fromChain: SolanaDevnet,
 *     toChain: BaseSepolia,
 *     mintRecipient: '0x1234...',
 *     maxFee: BigInt('0'),
 *     minFinalityThreshold: 1000,
 *   },
 *   { tokenMessenger, messageTransmitter },
 *   pdas,
 *   userUsdcAta,
 *   user.publicKey
 * )
 *
 * // With hookData for CCTP forwarding
 * const { ixs, signer } = await buildInstructions(
 *   {
 *     ...params,
 *     hookData: buildForwardingHookData(),
 *   },
 *   { tokenMessenger, messageTransmitter },
 *   pdas,
 *   userUsdcAta,
 *   user.publicKey
 * )
 * ```
 */ const buildInstructions$2 = async (params, programs, pdas, userUsdcAta, user)=>{
    const { amount, toChain, mintRecipient, destinationCaller, maxFee, minFinalityThreshold } = params;
    // Detect if hookData is present (depositForBurnWithHook action)
    const hookData = 'hookData' in params ? params.hookData : undefined;
    // Generate a fresh keypair for the message event
    const messageAccount = web3_js.Keypair.generate();
    // Fund the message account for rent exemption
    // The CCTP program creates the messageSentEventData account and needs
    // the messageAccount to have sufficient lamports (~3.87M lamports ≈ 0.00387 SOL)
    // This is a refundable rent deposit, not a fee
    const rentExemptLamports = 3_900_000 // ~0.0039 SOL for safety margin
    ;
    // Create instruction to fund the message account from the user
    const fundMessageAccountIx = web3_js.SystemProgram.transfer({
        fromPubkey: user,
        toPubkey: messageAccount.publicKey,
        lamports: rentExemptLamports
    });
    // Normalize recipient and caller keys
    const mintRecipientKey = mintRecipient.startsWith('0x') ? new web3_js.PublicKey(Buffer.from(mintRecipient.replace(/^0x/, ''), 'hex')) : new web3_js.PublicKey(mintRecipient);
    const callerKey = new web3_js.PublicKey(destinationCaller ?? web3_js.PublicKey.default.toBase58());
    // Build base method args (shared between depositForBurn and depositForBurnWithHook)
    const baseMethodArgs = {
        amount: new bn_js.BN(amount.toString()),
        destinationDomain: toChain.cctp.domain,
        mintRecipient: mintRecipientKey,
        destinationCaller: callerKey,
        maxFee: new bn_js.BN(maxFee.toString()),
        minFinalityThreshold
    };
    const methodAccounts = {
        owner: user,
        senderAuthorityPda: pdas.senderAuthorityPda,
        burnTokenAccount: userUsdcAta,
        burnTokenMint: new web3_js.PublicKey(params.fromChain.usdcAddress),
        tokenMessenger: pdas.tokenMessengerPda,
        tokenMinter: pdas.tokenMinterPda,
        localToken: pdas.localTokenPda,
        remoteTokenMessenger: pdas.remoteTokenMessengerPda,
        messageTransmitter: pdas.messageTransmitterPda,
        messageSentEventData: messageAccount.publicKey,
        eventRentPayer: user,
        messageTransmitterProgram: programs.messageTransmitter.programId,
        tokenMessengerMinterProgram: programs.tokenMessenger.programId,
        tokenProgram: anchor.utils.token.TOKEN_PROGRAM_ID,
        systemProgram: web3_js.SystemProgram.programId
    };
    // Build instruction - use explicit branching for type safety
    let instruction;
    if (hookData) {
        // Use depositForBurnWithHook when hookData is present
        if (!('depositForBurnWithHook' in programs.tokenMessenger.methods)) {
            throw createValidationFailedError('tokenMessenger.methods', 'depositForBurnWithHook', 'depositForBurnWithHook method not found on program');
        }
        instruction = await programs.tokenMessenger.methods['depositForBurnWithHook']({
            ...baseMethodArgs,
            hookData: convertHookDataToBuffer(hookData)
        }).accounts(methodAccounts).signers([
            messageAccount
        ]).instruction();
    } else {
        // Use depositForBurn for standard burn without hook
        if (!('depositForBurn' in programs.tokenMessenger.methods)) {
            throw createValidationFailedError('tokenMessenger.methods', 'depositForBurn', 'depositForBurn method not found on program');
        }
        instruction = await programs.tokenMessenger.methods['depositForBurn'](baseMethodArgs).accounts(methodAccounts).signers([
            messageAccount
        ]).instruction();
    }
    return {
        ixs: [
            fundMessageAccountIx,
            instruction
        ],
        signer: messageAccount
    };
};

/**
 * Generate transaction instructions for a CCTP deposit for burn operation.
 *
 * This function orchestrates the complete flow for creating a depositForBurn or
 * depositForBurnWithHook transaction on Solana. It loads the necessary programs,
 * derives program addresses, verifies the user's USDC token account exists, and
 * builds the required instruction with signers.
 *
 * The function supports both standard depositForBurn and depositForBurnWithHook
 * variants based on whether hookData is present in the params.
 *
 * @param params - The deposit parameters containing source/destination chain details,
 *                 amount, recipient address, optional hookData, and adapter reference.
 * @returns An object containing the array of transaction instructions and required signers.
 * @throws Error if the user's USDC token account doesn't exist or if any of the
 *         required program operations fail.
 *
 * @example
 * ```typescript
 * import { getInstructions } from './getInstructions'
 *
 * // Standard depositForBurn
 * const { ixs, signers } = await getInstructions({
 *   adapter,
 *   context,
 *   amount: BigInt('1000000'),
 *   fromChain: SolanaDevnet,
 *   toChain: BaseSepolia,
 *   mintRecipient: '0x1234...',
 *   maxFee: BigInt('0'),
 *   minFinalityThreshold: 1000,
 * })
 *
 * // With hookData for CCTP forwarding
 * const { ixs, signers } = await getInstructions({
 *   ...params,
 *   hookData: buildForwardingHookData(),
 * })
 * ```
 */ const getInstructions$2 = async (params)=>{
    const provider = await params.adapter.getAnchorProvider(params.context);
    const connection = provider.connection;
    const v2config = params.fromChain.cctp.contracts.v2;
    if (!v2config || v2config.type !== 'split') {
        throw new Error('Unsupported CCTP v2 contract configuration for Solana. Expected "split" type.');
    }
    const config = v2config;
    const [tokenMessengerProgram, messageTransmitterProgram] = await Promise.all([
        getProgram(provider, config.tokenMessenger),
        getProgram(provider, config.messageTransmitter)
    ]);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(params.fromChain.usdcAddress);
    const pdas = derivePdas$2(tokenMessengerProgram, messageTransmitterProgram, usdcMint, params.toChain.cctp.domain);
    // Check if user's USDC ATA exists (this will also check SOL balance)
    const userUsdcAta = await assertAtaExists(connection, user, usdcMint);
    const { ixs, signer } = await buildInstructions$2(params, {
        tokenMessenger: tokenMessengerProgram,
        messageTransmitter: messageTransmitterProgram
    }, pdas, userUsdcAta, user);
    return {
        ixs,
        signers: [
            signer
        ]
    };
};

/**
 * Prepare a CCTP depositForBurn transaction for cross-chain USDC transfers.
 *
 * This function creates a prepared chain request for depositing USDC tokens
 * to be burned on Solana as part of the Cross-Chain Transfer Protocol (CCTP).
 * It handles default parameter values and delegates to the adapter for final
 * transaction preparation.
 *
 * @param params - The deposit parameters containing source/destination chain details,
 *                 amount, recipient address, and adapter reference.
 * @returns A prepared chain request that can be executed or simulated.
 * @throws Error if instruction generation fails or if the adapter cannot prepare
 *         the transaction.
 */ const depositForBurn = async (params, adapter, context)=>{
    const destCaller = params.destinationCaller ?? SOLANA_DEFAULT_PUBLIC_KEY;
    const maxFee = params.maxFee ?? 0n;
    const minFinality = params.minFinalityThreshold ?? 2000;
    // 1) Build instructions & signers
    const { ixs, signers } = await getInstructions$2({
        ...params,
        destinationCaller: destCaller,
        maxFee,
        minFinalityThreshold: minFinality,
        adapter,
        context
    });
    // 2) Prepare via adapter with explicit OperationContext (Solana source chain)
    return adapter.prepare({
        instructions: ixs,
        signers
    }, context);
};

/**
 * Prepare a CCTP depositForBurnWithHook transaction for cross-chain USDC transfers with forwarding.
 *
 * This function creates a prepared chain request for depositing USDC tokens
 * to be burned on Solana as part of the Cross-Chain Transfer Protocol (CCTP)
 * with hook data that signals to Circle's Orbit relayer that forwarding is requested.
 *
 * When forwarding is enabled, the relayer will automatically fetch the attestation
 * and submit the destination mint transaction on behalf of the user.
 *
 * @param params - The deposit parameters containing source/destination chain details,
 *                 amount, recipient address, hookData, and adapter reference.
 * @param adapter - The Solana adapter instance for transaction preparation and execution.
 * @param context - The resolved operation context containing chain and address information.
 * @returns A prepared chain request that can be executed or simulated.
 * @throws KitError if instruction generation fails or if the adapter cannot prepare
 *         the transaction.
 *
 * @example
 * ```typescript
 * import { buildForwardingHookData } from '@core/utils'
 *
 * const prepared = await depositForBurnWithHook(
 *   {
 *     fromChain: SolanaDevnet,
 *     toChain: BaseSepolia,
 *     amount: BigInt('1000000'),
 *     mintRecipient: '0x1234...',
 *     maxFee: BigInt('50000'),
 *     minFinalityThreshold: 1000,
 *     hookData: buildForwardingHookData(),
 *   },
 *   adapter,
 *   context
 * )
 * await prepared.execute()
 * ```
 */ const depositForBurnWithHook = async (params, adapter, context)=>{
    const destCaller = params.destinationCaller ?? SOLANA_DEFAULT_PUBLIC_KEY;
    const maxFee = params.maxFee ?? 0n;
    const minFinality = params.minFinalityThreshold ?? 2000;
    // 1) Build instructions & signers
    const { ixs, signers } = await getInstructions$2({
        ...params,
        destinationCaller: destCaller,
        maxFee,
        minFinalityThreshold: minFinality,
        adapter,
        context
    });
    // 2) Prepare via adapter with explicit OperationContext (Solana source chain)
    return adapter.prepare({
        instructions: ixs,
        signers
    }, context);
};

/**
 * Derive all program-derived addresses required for custom burn operation.
 *
 * This function derives both CCTP and bridge kit PDAs needed for the custom burn
 * operation. It handles PDAs for token messenger, message transmitter, and bridge
 * kit programs.
 *
 * @param tokenMessengerProgram - The loaded token messenger Anchor program
 * @param messageTransmitterProgram - The loaded message transmitter Anchor program
 * @param bridgeKitProgram - The loaded bridge kit Anchor program
 * @param usdcMint - The USDC token mint address
 * @param userPublicKey - The user's public key
 * @param destinationDomain - The destination chain domain ID
 * @returns An object containing all derived PDAs for both CCTP and bridge kit
 */ const derivePdas$1 = (tokenMessengerProgram, messageTransmitterProgram, bridgeKitProgram, usdcMint, userPublicKey, destinationDomain)=>{
    // Derive CCTP PDAs
    const [senderAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('sender_authority')
    ], tokenMessengerProgram.programId);
    const [tokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_messenger')
    ], tokenMessengerProgram.programId);
    const [tokenMinterPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_minter')
    ], tokenMessengerProgram.programId);
    const [localTokenPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('local_token'),
        usdcMint.toBuffer()
    ], tokenMessengerProgram.programId);
    const [messageTransmitterPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('message_transmitter')
    ], messageTransmitterProgram.programId);
    // Derive bridge kit PDAs
    const [statePda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('state')
    ], bridgeKitProgram.programId);
    const [denylistPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('denylist_account'),
        userPublicKey.toBuffer()
    ], tokenMessengerProgram.programId);
    const [eventAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('__event_authority')
    ], tokenMessengerProgram.programId);
    // Bridge Kit's own event authority PDA (used by #[event_cpi] in bridge_kit)
    const [bridgeKitEventAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('__event_authority')
    ], bridgeKitProgram.programId);
    // Convert destination domain to a buffer for use as a seed
    const domainSeed = Buffer.from(destinationDomain.toString(), 'utf8');
    // Derive remote token messenger PDA using the destination domain
    const [remoteTokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('remote_token_messenger'),
        domainSeed
    ], tokenMessengerProgram.programId);
    return {
        senderAuthorityPda,
        tokenMessengerPda,
        tokenMinterPda,
        localTokenPda,
        messageTransmitterPda,
        statePda,
        denylistPda,
        eventAuthorityPda,
        remoteTokenMessengerPda,
        bridgeKitEventAuthorityPda
    };
};

/**
 * Build the transaction instructions for a custom burn operation.
 *
 * This function creates the necessary instructions for burning USDC tokens as part
 * of a cross-chain transfer. It supports both standard bridge and bridgeWithHook
 * variants based on whether hookData is present in the params.
 *
 * @param params - The deposit parameters containing chain details, transfer specifics, and optional hookData.
 * @param programs - The loaded Anchor programs for token messenger and message transmitter.
 * @param pdas - The derived program addresses for various accounts.
 * @param userUsdcAta - The user's USDC Associated Token Account.
 * @param user - The user's public key.
 * @param usdcMint - The USDC mint address.
 * @returns An object containing the transaction instructions and required signer.
 * @throws KitError if bridge method is not found in the bridge kit program.
 * @throws Error if failed to fetch bridge kit state account or protocolFeeWallet is missing.
 * @internal
 */ const buildInstructions$1 = async (params, programs, pdas, userUsdcAta, user, usdcMint, connection)=>{
    const { bridgeKit, tokenMessenger, messageTransmitter } = programs;
    // Detect if hookData is present (customBurnWithHook action)
    const hookData = 'hookData' in params ? params.hookData : undefined;
    // Create a new keypair for message nonce
    const messageSender = web3_js.Keypair.generate();
    // Fund the message sender account for rent exemption
    // The CCTP program creates the messageSentEventData account and needs
    // the messageSender to have sufficient lamports (~3.87M lamports ≈ 0.00387 SOL)
    // This is a refundable rent deposit, not a fee
    const rentExemptLamports = 3_900_000 // ~0.0039 SOL for safety margin
    ;
    // Create instruction to fund the message sender account from the user
    const fundMessageSenderIx = web3_js.SystemProgram.transfer({
        fromPubkey: user,
        toPubkey: messageSender.publicKey,
        lamports: rentExemptLamports
    });
    // Get protocol fee wallet ATA from state account
    let state;
    try {
        state = await bridgeKit.account.state.fetch(pdas.statePda);
        if (!state?.protocolFeeWallet) {
            throw new Error(`Failed to fetch bridge kit state account ${pdas.statePda.toBase58()}: protocolFeeWallet is missing or invalid in the state account. ` + 'Verify the state account is properly initialized and the state PDA is correct.');
        }
    } catch (error) {
        throw new Error(`Failed to fetch bridge kit state from ${pdas.statePda.toBase58()}: ${error instanceof Error ? error.message : 'unknown error'}`);
    }
    // Get protocol fee wallet ATA
    const protocolFeeWalletAta = getAssociatedTokenAddressSync(usdcMint, new web3_js.PublicKey(state.protocolFeeWallet), true);
    // Get developer fee recipient ATA
    const developerFeeRecipientAta = getAssociatedTokenAddressSync(usdcMint, params.feeRecipient, true);
    // Create ATAs for fee recipients if they don't exist
    // Note: We only check account existence, NOT SOL balance, because the
    // transaction payer (user) creates these ATAs for the fee recipients
    const createFeeRecipientAtaIxs = [];
    // Check and create protocol fee wallet ATA if needed
    const protocolFeeWalletAtaInfo = await connection.getAccountInfo(protocolFeeWalletAta);
    if (!protocolFeeWalletAtaInfo) {
        createFeeRecipientAtaIxs.push(createAssociatedTokenAccountIdempotentInstruction(user, protocolFeeWalletAta, state.protocolFeeWallet, usdcMint));
    }
    // Check and create developer fee recipient ATA if needed
    const developerFeeRecipientAtaInfo = await connection.getAccountInfo(developerFeeRecipientAta);
    if (!developerFeeRecipientAtaInfo) {
        createFeeRecipientAtaIxs.push(createAssociatedTokenAccountIdempotentInstruction(user, developerFeeRecipientAta, params.feeRecipient, usdcMint));
    }
    // Build base bridge params (shared between bridge and bridgeWithHook)
    const baseBridgeParams = {
        amount: new bn_js.BN(params.amount),
        destinationDomain: params.toChain.cctp.domain,
        mintRecipient: params.mintRecipient,
        destinationCaller: params.destinationCaller,
        maxFee: new bn_js.BN(params.maxFee),
        minFinalityThreshold: params.minFinalityThreshold,
        bridgingKitFee: new bn_js.BN(params.protocolFee)
    };
    const bridgeAccounts = {
        state: pdas.statePda,
        authority: user,
        eventRentPayer: user,
        burnTokenAccount: userUsdcAta,
        protocolFeeWalletTokenAccount: protocolFeeWalletAta,
        developerFeeRecipientTokenAccount: developerFeeRecipientAta,
        senderAuthorityPda: pdas.senderAuthorityPda,
        denylistAccount: pdas.denylistPda,
        messageTransmitter: pdas.messageTransmitterPda,
        tokenMessenger: pdas.tokenMessengerPda,
        remoteTokenMessenger: pdas.remoteTokenMessengerPda,
        tokenMinter: pdas.tokenMinterPda,
        localToken: pdas.localTokenPda,
        burnTokenMint: usdcMint,
        messageSentEventData: messageSender.publicKey,
        messageTransmitterProgram: messageTransmitter.programId,
        tokenMessengerMinterProgram: tokenMessenger.programId,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: web3_js.SystemProgram.programId,
        // Bridge self-CPI event accounts injected by #[event_cpi]
        eventAuthority: pdas.bridgeKitEventAuthorityPda,
        program: bridgeKit.programId,
        // CCTP event accounts expected by CCTP programs
        cctpEventAuthority: pdas.eventAuthorityPda,
        cctpProgram: tokenMessenger.programId
    };
    // Build bridge instruction - use explicit branching for type safety
    let bridgeIx;
    if (hookData) {
        // Use bridgeWithHook when hookData is present
        if (!('bridgeWithHook' in bridgeKit.methods)) {
            throw createValidationFailedError('bridgeKit.methods', 'bridgeWithHook', 'bridgeWithHook method not found on program');
        }
        bridgeIx = await bridgeKit.methods['bridgeWithHook']({
            ...baseBridgeParams,
            hookData: convertHookDataToBuffer(hookData)
        }).accountsPartial(bridgeAccounts).signers([
            messageSender
        ]).instruction();
    } else {
        // Use bridge for standard burn without hook
        if (!('bridge' in bridgeKit.methods)) {
            throw createValidationFailedError('bridgeKit.methods', 'bridge', 'bridge method not found on program');
        }
        bridgeIx = await bridgeKit.methods['bridge'](baseBridgeParams).accountsPartial(bridgeAccounts).signers([
            messageSender
        ]).instruction();
    }
    return {
        ixs: [
            fundMessageSenderIx,
            ...createFeeRecipientAtaIxs,
            bridgeIx
        ],
        signer: messageSender
    };
};

/**
 * Generate transaction instructions for a CCTP custom burn operation.
 *
 * This function orchestrates the complete flow for creating a custom burn
 * transaction on Solana. It loads the necessary programs, derives program addresses,
 * verifies the user's USDC token account exists, and builds the required instructions
 * with signers. It supports both standard bridge and bridgeWithHook variants based on
 * whether hookData is present in the params.
 *
 * @param params - The deposit parameters containing source/destination chain details,
 *                 amount, recipient address, and adapter reference.
 * @returns An object containing the array of transaction instructions and required signers.
 * @throws Error if CCTP v2 contract configuration is not "split" type for Solana.
 * @throws Error if bridge kit contract address is not found in chain definition.
 * @throws Error if the user's USDC token account doesn't exist.
 * @throws Error if any of the required program operations fail.
 *
 * @example
 * ```typescript
 * import { getInstructions } from './getInstructions'
 * import { Connection, Keypair, sendAndConfirmTransaction, Transaction } from '@solana/web3.js'
 * import { SolanaAdapter } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet, BaseSepolia } from '@circle-fin/app-kit/chains'
 *
 * async function executeCustomBurn() {
 *   // Setup connection and wallet
 *   const connection = new Connection('https://api.devnet.solana.com')
 *   const wallet = Keypair.generate() // In production, use your actual wallet
 *
 *   // Create Solana adapter
 *   const adapter = new SolanaAdapter({
 *     connection,
 *     wallet
 *   })
 *
 *   // Get instructions
 *   const { ixs, signers } = await getInstructions({
 *     adapter,
 *     amount: BigInt('1000000'), // 1 USDC
 *     sourceChain: SolanaDevnet,
 *     destinationChain: BaseSepolia,
 *     mintRecipient: '0x1234567890abcdef1234567890abcdef12345678',
 *     maxFee: BigInt('0'),
 *     minFinalityThreshold: 1
 *   })
 *
 *   // Create and send transaction
 *   const transaction = new Transaction().add(...ixs)
 *   const signature = await sendAndConfirmTransaction(
 *     connection,
 *     transaction,
 *     [wallet, ...signers]
 *   )
 *   console.log('Transaction confirmed:', signature)
 * }
 * ```
 */ const getInstructions$1 = async (params)=>{
    const { adapter, context, fromChain, toChain } = params;
    const provider = await adapter.getAnchorProvider(context);
    const v2config = fromChain.cctp.contracts.v2;
    if (v2config?.type !== 'split') {
        throw new Error('Unsupported CCTP v2 contract configuration for Solana. Expected "split" type.');
    }
    const config = v2config;
    const bridgeKitAddress = fromChain.kitContracts?.bridge;
    if (!bridgeKitAddress) {
        throw new Error('Bridge kit contract address not found in chain definition');
    }
    const [tokenMessengerProgram, messageTransmitterProgram, bridgeKitProgram] = await Promise.all([
        getProgram(provider, config.tokenMessenger),
        getProgram(provider, config.messageTransmitter),
        getProgram(provider, bridgeKitAddress)
    ]);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(fromChain.usdcAddress);
    const userUsdcAta = await assertAtaExists(provider.connection, user, usdcMint);
    const pdas = derivePdas$1(tokenMessengerProgram, messageTransmitterProgram, bridgeKitProgram, usdcMint, user, toChain.cctp.domain);
    const { ixs, signer } = await buildInstructions$1(params, {
        bridgeKit: bridgeKitProgram,
        tokenMessenger: tokenMessengerProgram,
        messageTransmitter: messageTransmitterProgram
    }, pdas, userUsdcAta, user, usdcMint, provider.connection);
    return {
        ixs,
        signers: [
            signer
        ]
    };
};

/**
 * Zod schema for the numeric parameters of customBurn.
 * Matches existing error messages used in tests.
 */ const numericParamsSchema = zod.z.object({
    amount: zod.z.bigint({
        required_error: 'amount is required for customBurn'
    }).refine((v)=>v > 0n, 'amount must be greater than zero'),
    maxFee: zod.z.bigint({
        required_error: 'maxFee is required for customBurn'
    }).refine((v)=>v >= 0n, 'maxFee cannot be negative'),
    minFinalityThreshold: zod.z.number({
        required_error: 'minFinalityThreshold is required for customBurn',
        invalid_type_error: 'minFinalityThreshold is required for customBurn'
    }).refine((v)=>Number.isFinite(v), 'minFinalityThreshold is required for customBurn').refine((v)=>v >= 0, 'minFinalityThreshold cannot be negative'),
    protocolFee: zod.z.bigint().optional().refine((v)=>v === undefined || v >= 0n, 'protocolFee cannot be negative')
});
// Chain params are validated via explicit checks below to preserve exact error messages
/**
 * Zod schema for the address parameters of customBurn.
 * Enforces presence; format is verified by PublicKey conversion below.
 */ const addressParamsSchema = zod.z.object({
    mintRecipient: zod.z.string({
        required_error: 'mintRecipient is required for customBurn'
    }).min(1, 'mintRecipient is required for customBurn'),
    feeRecipient: zod.z.string().optional(),
    destinationCaller: zod.z.string().optional()
});
// Intentionally not exporting a combined schema to avoid type mismatch issues.
/**
 * Validates numeric parameters for customBurn operation using zod and throws with exact messages on failure.
 *
 * @param params - The action parameters to validate
 * @throws Error When any numeric parameter is invalid
 */ const validateNumericParams = (params)=>{
    const res = numericParamsSchema.safeParse(params);
    if (!res.success) {
        const first = res.error.errors[0];
        throw new Error(first?.message ?? 'Invalid numeric parameters');
    }
};
/**
 * Validates and converts address parameters to PublicKey objects.
 *
 * @param params - The action parameters to validate
 * @returns Object containing validated PublicKey instances
 * @throws Error When any address parameter is invalid
 */ const validateChainParams = (params)=>{
    // Explicit checks to match prior behavior and test expectations
    if (params.fromChain === undefined) {
        throw new Error('fromChain is required for customBurn');
    }
    if (params.toChain === undefined) {
        throw new Error('toChain is required for customBurn');
    }
};
/**
 * Validates chain parameters for customBurn operation.
 * Conversion errors surface as "Invalid <field> format: <reason>".
 *
 * @param params - The action parameters to validate
 * @throws Error When any chain parameter is invalid
 */ const validateAndConvertAddresses = (params)=>{
    // Validate required presence using zod first
    const res = addressParamsSchema.safeParse(params);
    if (!res.success) {
        const first = res.error.errors[0];
        throw new Error(first?.message ?? 'Invalid address parameters');
    }
    let mintRecipientKey;
    try {
        mintRecipientKey = params.mintRecipient.startsWith('0x') ? new web3_js.PublicKey(Buffer.from(params.mintRecipient.replace(/^0x/, ''), 'hex')) : new web3_js.PublicKey(params.mintRecipient);
    } catch (error) {
        throw new Error(`Invalid mintRecipient format: ${error instanceof Error ? error.message : 'unknown error'}`);
    }
    let feeRecipientKey;
    try {
        feeRecipientKey = getOrDefaultPublicKey(params.feeRecipient);
    } catch (error) {
        throw new Error(`Invalid feeRecipient format: ${error instanceof Error ? error.message : 'unknown error'}`);
    }
    let destinationCallerKey;
    try {
        destinationCallerKey = getOrDefaultPublicKey(params.destinationCaller);
    } catch (error) {
        throw new Error(`Invalid destinationCaller format: ${error instanceof Error ? error.message : 'unknown error'}`);
    }
    return {
        mintRecipientKey,
        feeRecipientKey,
        destinationCallerKey
    };
};

/**
 * Prepare a CCTP custom burn transaction for cross-chain USDC transfers without permit signing.
 *
 * This function creates a prepared chain request for burning USDC tokens
 * on Solana as part of the Cross-Chain Transfer Protocol (CCTP).
 * Unlike the standard depositForBurn, this version does not require permit signing,
 * making it suitable for scenarios where tokens are already approved for transfer.
 *
 * @param params - The cross-chain burn parameters including amount, recipient addresses,
 *                 fee configuration, and chain definitions. Supports both hex (0x-prefixed)
 *                 and base58 address formats for cross-chain compatibility.
 * @param adapter - The Solana adapter instance for transaction preparation and execution.
 * @returns A prepared chain request that can be executed or simulated.
 * @throws Error if amount is undefined, zero, or negative.
 * @throws Error if maxFee is undefined or negative.
 * @throws Error if minFinalityThreshold is undefined or negative.
 * @throws Error if protocolFee is negative. Defaults to 0n when omitted.
 * @throws Error if mintRecipient is undefined, empty, or has invalid format.
 * @throws Error if feeRecipient has invalid format. Defaults to `PublicKey.default` when omitted.
 * @throws Error if destinationCaller has invalid format.
 * @throws Error if fromChain or toChain is undefined.
 * @throws Error if instruction generation fails or if the adapter cannot prepare
 *         the transaction.
 *
 * @example
 * ```typescript
 * import { customBurn } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet, BaseSepolia } from '@circle-fin/app-kit/chains'
 *
 * // Assuming you have already set up your adapter
 * const request = await customBurn({
 *   amount: BigInt('1000000'), // 1 USDC
 *   fromChain: SolanaDevnet,
 *   toChain: BaseSepolia,
 *   mintRecipient: '0x742d35Cc6634C0532925a3b8D8E5e8d8D8e5e8d8D8e5e8', // EVM recipient
 *   destinationCaller: undefined, // Allow anyone to complete transfer
 *   feeRecipient: 'FeePayer1111111111111111111111111111111111111',
 *   protocolFee: BigInt('1000'),
 *   // Required CCTP parameters
 *   maxFee: BigInt('0'),
 *   minFinalityThreshold: 1
 * }, adapter)
 *
 * // Execute the prepared request
 * const result = await request.execute()
 * ```
 */ const customBurn = async (params, adapter, context)=>{
    // Validate all parameters
    validateNumericParams(params);
    validateChainParams(params);
    const { mintRecipientKey, feeRecipientKey, destinationCallerKey } = validateAndConvertAddresses(params);
    // Create validated params with all required fields guaranteed to be non-null
    const validatedParams = {
        ...params,
        adapter,
        mintRecipient: mintRecipientKey,
        protocolFee: params.protocolFee ?? 0n,
        feeRecipient: feeRecipientKey,
        destinationCaller: destinationCallerKey,
        context
    };
    const { ixs, signers } = await getInstructions$1(validatedParams);
    return adapter.prepare({
        instructions: ixs,
        signers
    }, context);
};

/**
 * Prepare a CCTP custom burn transaction with hook data for cross-chain USDC transfers with forwarding.
 *
 * This function creates a prepared chain request for burning USDC tokens on Solana as part
 * of the Cross-Chain Transfer Protocol (CCTP) with hook data that signals to Circle's Orbit
 * relayer that forwarding is requested. The relayer will automatically fetch the attestation
 * and submit the destination mint transaction on behalf of the user.
 *
 * @param params - The cross-chain burn parameters including amount, recipient addresses,
 *                 fee configuration, hookData, and chain definitions.
 * @param adapter - The Solana adapter instance for transaction preparation and execution.
 * @param context - The resolved operation context containing chain and address information.
 * @returns A prepared chain request that can be executed or simulated.
 * @throws KitError if required parameters are missing, invalid, or out of range.
 * @throws KitError if instruction generation or transaction preparation fails.
 *
 * @example
 * ```typescript
 * import { customBurnWithHook } from '@stablecoin-kits/adapter-solana'
 * import { SolanaDevnet, BaseSepolia } from '@stablecoin-kits/chains'
 * import { buildForwardingHookData } from '@core/utils'
 *
 * const request = await customBurnWithHook({
 *   amount: BigInt('1000000'), // 1 USDC
 *   fromChain: SolanaDevnet,
 *   toChain: BaseSepolia,
 *   mintRecipient: '0x742d35Cc6634C0532925a3b8D8E5e8d8D8e5e8d8D8e5e8',
 *   maxFee: BigInt('50000'), // Must cover burn fee + forwarding fee
 *   minFinalityThreshold: 1000,
 *   hookData: buildForwardingHookData(),
 * }, adapter, context)
 *
 * const result = await request.execute()
 * ```
 */ const customBurnWithHook = async (params, adapter, context)=>{
    // Validate all parameters
    validateNumericParams(params);
    validateChainParams(params);
    const { mintRecipientKey, feeRecipientKey, destinationCallerKey } = validateAndConvertAddresses(params);
    // Create validated params with all required fields guaranteed to be non-null
    const validatedParams = {
        ...params,
        adapter,
        mintRecipient: mintRecipientKey,
        protocolFee: params.protocolFee ?? 0n,
        feeRecipient: feeRecipientKey,
        destinationCaller: destinationCallerKey,
        context
    };
    const { ixs, signers } = await getInstructions$1(validatedParams);
    return adapter.prepare({
        instructions: ixs,
        signers
    }, context);
};

/**
 * Derive all Program Derived Addresses (PDAs) needed for CCTP message reception.
 *
 * This function calculates all the necessary PDAs required for receiving and processing
 * a cross-chain USDC transfer message on Solana. It handles the derivation of account
 * addresses for both the token messenger and message transmitter programs, using the
 * source chain for remote operations and the destination chain for local operations.
 *
 * @param sourceChain - The source chain definition containing CCTP domain and USDC address.
 * @param destinationChain - The destination chain definition containing USDC address.
 * @param messageTransmitterProgramId - The public key of the message transmitter program.
 * @param tokenMessengerProgramId - The public key of the token messenger program.
 * @returns An object containing all derived PDAs needed for CCTP mint operations.
 *
 * @example
 * ```typescript
 * import { PublicKey } from '@solana/web3.js'
 * import { derivePdas } from './derivePdas'
 * import { ChainDefinitionWithCCTPv2 } from '@core/chains'
 *
 * // Setup program IDs
 * const messageTransmitterProgram = new PublicKey('CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd')
 * const tokenMessengerProgram = new PublicKey('CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3')
 *
 * // Define source chain (e.g., Ethereum)
 * const sourceChain: ChainDefinitionWithCCTPv2 = {
 *   type: 'evm',
 *   name: 'Ethereum',
 *   usdcAddress: '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
 *   cctp: {
 *     domain: 0,
 *     contracts: {
 *       v2: {
 *         tokenMessenger: '0xbd3fa81b58ba92a82136038b25adec7066af3155',
 *         messageTransmitter: '0x0a992d191deec32afe36203ad87d7d289a738f81'
 *       }
 *     }
 *   }
 * }
 *
 * // Define destination chain (Solana)
 * const destinationChain: ChainDefinitionWithCCTPv2 = {
 *   type: 'solana',
 *   name: 'Solana',
 *   usdcAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
 *   cctp: {
 *     domain: 5,
 *     contracts: {
 *       v2: {
 *         tokenMessenger: 'CCTPiPYPc6AsJuwueEnWgSgucamXDZwBd53dQ11YiKX3',
 *         messageTransmitter: 'CCTPmbSD7gX1bxKPAmg77w8oFzNFpaQiQUWD43TKaecd'
 *       }
 *     }
 *   }
 * }
 *
 * // Derive all PDAs
 * const pdas = derivePdas(
 *   sourceChain,
 *   destinationChain,
 *   messageTransmitterProgram,
 *   tokenMessengerProgram
 * )
 *
 * console.log('Token Messenger PDA:', pdas.tokenMessengerPda.toBase58())
 * console.log('Message Transmitter PDA:', pdas.messageTransmitterPda.toBase58())
 * console.log('Remote Mint Key:', pdas.remoteMintKey.toBase58())
 * ```
 */ const derivePdas = (sourceChain, destinationChain, messageTransmitterProgramId, tokenMessengerProgramId)=>{
    // Source chain USDC address (used for token pair and remote operations)
    const remoteMintKey = new web3_js.PublicKey(convertAddress(sourceChain.usdcAddress, 'solana'));
    const destinationUsdcMint = new web3_js.PublicKey(destinationChain.usdcAddress);
    const [tokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_messenger')
    ], tokenMessengerProgramId);
    const [messageTransmitterPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('message_transmitter')
    ], messageTransmitterProgramId);
    const [tokenMinterPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_minter')
    ], tokenMessengerProgramId);
    const [localTokenPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('local_token'),
        destinationUsdcMint.toBuffer()
    ], tokenMessengerProgramId);
    const domainSeed = Buffer.from(sourceChain.cctp.domain.toString(), 'utf8');
    const [remoteTokenMessengerPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('remote_token_messenger'),
        domainSeed
    ], tokenMessengerProgramId);
    const [tokenPairPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('token_pair'),
        domainSeed,
        remoteMintKey.toBuffer()
    ], tokenMessengerProgramId);
    const [custodyPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('custody'),
        destinationUsdcMint.toBuffer()
    ], tokenMessengerProgramId);
    const [messageTransmitterAuthorityPda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('message_transmitter_authority'),
        tokenMessengerProgramId.toBuffer()
    ], messageTransmitterProgramId);
    return {
        tokenMessengerPda,
        messageTransmitterPda,
        tokenMinterPda,
        localTokenPda,
        remoteTokenMessengerPda,
        tokenPairPda,
        custodyPda,
        messageTransmitterAuthorityPda,
        remoteMintKey
    };
};

/**
 * Build the receiveMessage instruction for CCTP mint operations on Solana.
 *
 * This function creates the specific Solana transaction instruction needed to
 * receive a cross-chain USDC transfer message. It validates the event nonce,
 * derives the required account addresses, and constructs the receiveMessage
 * instruction with all necessary accounts and data.
 *
 * @param params - The mint parameters containing message, attestation, and chain details.
 * @param programs - The Anchor program instances for tokenMessenger and messageTransmitter.
 * @param pdas - The derived program addresses required for the instruction.
 * @param feeRecipientAta - The associated token account for fee collection.
 * @param eventNonce - The event nonce from the message (0x-prefixed hex string).
 * @returns An object containing the transaction instruction array and optional signer.
 * @throws Error if the eventNonce is invalid or if the receiveMessage method is not found.
 *
 * @example
 * ```typescript
 * import { buildInstructions } from './buildInstructions'
 * import { PublicKey, Connection, Keypair } from '@solana/web3.js'
 * import { Program, AnchorProvider } from '@coral-xyz/anchor'
 * import { getProgram } from '../../utils/getProgram/getProgram'
 * import { derivePdas } from '../derivePdas/derivePdas'
 *
 * async function buildMintInstructions() {
 *   // Setup programs and PDAs
 *   const provider = new AnchorProvider(connection, wallet, {})
 *   const tokenMessenger = await getProgram(provider, 'CCTP...')
 *   const messageTransmitter = await getProgram(provider, 'CCTP...')
 *   const pdas = derivePdas(sourceChain, messageTransmitter.programId, tokenMessenger.programId)
 *
 *   // Build the instruction
 *   const { ixs, signer } = await buildInstructions(
 *     {
 *       message: '0x1234567890abcdef...',
 *       attestation: '0xfedcba9876543210...',
 *       eventNonce: '0x0123456789abcdef...',
 *       sourceChain: Ethereum,
 *       destinationChain: SolanaDevnet,
 *       adapter: solanaAdapter
 *     },
 *     { tokenMessenger, messageTransmitter },
 *     pdas,
 *     feeRecipientAta,
 *     '0x0123456789abcdef...'
 *   )
 *
 *   console.log('Built', ixs.length, 'instructions')
 * }
 * ```
 */ const buildInstructions = async (params, programs, pdas, feeRecipientAta, eventNonce)=>{
    const { adapter, message, attestation } = params;
    const provider = await adapter.getAnchorProvider(params.context);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(params.toChain.usdcAddress);
    // Derive usedNoncePda from eventNonce
    const nonceHex = eventNonce.replace(/^0x/, '');
    if (nonceHex.length !== 64) throw new Error(`Invalid eventNonce ${eventNonce}`);
    const nonceBuf = Buffer.from(nonceHex, 'hex');
    const [usedNoncePda] = web3_js.PublicKey.findProgramAddressSync([
        Buffer.from('used_nonce'),
        nonceBuf
    ], programs.messageTransmitter.programId);
    // Determine the ATA owner (recipient of the tokens)
    const mintRecipientOwner = params.destinationAddress ? new web3_js.PublicKey(params.destinationAddress) : user;
    // Derive the USDC ATA for the recipient
    const userUsdcAta = anchor.utils.token.associatedAddress({
        mint: usdcMint,
        owner: mintRecipientOwner
    });
    if (!('receiveMessage' in programs.messageTransmitter.methods)) {
        throw new Error('receiveMessage method not found');
    }
    const instruction = await programs.messageTransmitter.methods['receiveMessage']({
        message: Buffer.from(message.replace(/^0x/, ''), 'hex'),
        attestation: Buffer.from(attestation.replace(/^0x/, ''), 'hex')
    }).accounts({
        // required accounts by IDL
        payer: user,
        caller: user,
        authorityPda: pdas.messageTransmitterAuthorityPda,
        messageTransmitter: pdas.messageTransmitterPda,
        usedNonce: usedNoncePda,
        receiver: programs.tokenMessenger.programId,
        systemProgram: web3_js.SystemProgram.programId
    }).remainingAccounts([
        {
            pubkey: pdas.tokenMessengerPda,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: pdas.remoteTokenMessengerPda,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: pdas.tokenMinterPda,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: pdas.localTokenPda,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: pdas.tokenPairPda,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: feeRecipientAta,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: userUsdcAta,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: pdas.custodyPda,
            isSigner: false,
            isWritable: true
        },
        {
            pubkey: anchor.utils.token.TOKEN_PROGRAM_ID,
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: web3_js.PublicKey.findProgramAddressSync([
                Buffer.from('__event_authority')
            ], programs.tokenMessenger.programId)[0],
            isSigner: false,
            isWritable: false
        },
        {
            pubkey: programs.tokenMessenger.programId,
            isSigner: false,
            isWritable: false
        }
    ]).instruction();
    return {
        ixs: [
            instruction
        ]
    };
};

// Transaction size estimation constants
const TX_SIZE = {
    /** Solana signature size in bytes */ SIGNATURE: 64,
    /** Message header size in bytes */ MESSAGE_HEADER: 3,
    /** Length prefix for account keys array */ ACCOUNT_KEYS_PREFIX: 1,
    /** Size of each account address in bytes */ ACCOUNT_ADDRESS: 32,
    /** Recent blockhash size in bytes */ RECENT_BLOCKHASH: 32,
    /** Length prefix for instructions array */ INSTRUCTIONS_PREFIX: 1,
    /** Program ID index size in bytes */ PROGRAM_ID_INDEX: 1,
    /** Accounts length prefix size in bytes */ ACCOUNTS_PREFIX: 1,
    /** Data length prefix size in bytes (compact-u16) */ DATA_PREFIX: 2
};
// CCTP + ATA operation limits
const OPERATION_LIMITS = {
    /** Transaction size limit with safety buffer (Solana's actual limit is 1232 bytes) */ MAX_TX_SIZE: 1220,
    /** Estimated unique accounts for CCTP + ATA operations (4 ATA + ~16 CCTP accounts) */ ESTIMATED_ACCOUNTS: 20,
    /** Number of unique accounts used by ATA creation */ ATA_ACCOUNTS: 4
};
/**
 * Estimate the size contribution of a transaction instruction.
 * @internal
 */ const estimateInstructionSize = (instruction)=>TX_SIZE.PROGRAM_ID_INDEX + TX_SIZE.ACCOUNTS_PREFIX + instruction.keys.length + TX_SIZE.DATA_PREFIX + instruction.data.length;
/**
 * Estimate the total transaction size with given instructions and accounts.
 * @internal
 */ const estimateTransactionSize = (instructions, uniqueAccountCount)=>{
    const instructionsSize = instructions.reduce((total, ix)=>total + estimateInstructionSize(ix), 0);
    return TX_SIZE.SIGNATURE + TX_SIZE.MESSAGE_HEADER + TX_SIZE.ACCOUNT_KEYS_PREFIX + uniqueAccountCount * TX_SIZE.ACCOUNT_ADDRESS + TX_SIZE.RECENT_BLOCKHASH + TX_SIZE.INSTRUCTIONS_PREFIX + instructionsSize;
};
/**
 * Check if ATA exists and return creation instruction if needed.
 * @internal
 */ const createAtaInstructionIfNeeded = async (connection, payer, owner, mint, ataAddress)=>{
    const ataAccountInfo = await connection.getAccountInfo(ataAddress);
    if (!ataAccountInfo) {
        return createAssociatedTokenAccountInstruction(payer, ataAddress, owner, mint);
    }
    return null;
};
/**
 * Validate that the payer wallet has sufficient SOL balance for ATA creation.
 * @internal
 */ const validateSolBalanceForAta = async (provider, payer)=>{
    const balance = await provider.connection.getBalance(payer);
    /**
   * Minimum SOL balance required for ATA creation:
   * - Rent-exempt minimum for token account: 0.00203928 SOL (2,039,280 lamports)
   * - Transaction fees: minimal (~0.000005 SOL)
   * - Buffer for gas price fluctuations: included in the rounded value
   * Total: 0.00204 SOL provides a safe margin above the strict minimum
   */ const MINIMUM_BALANCE_FOR_ATA = 2040000 // in lamports (0.00204 SOL)
    ;
    if (balance < MINIMUM_BALANCE_FOR_ATA) {
        const balanceSol = formatUnits(balance.toString(), 9);
        const requiredSol = formatUnits(MINIMUM_BALANCE_FOR_ATA.toString(), 9);
        throw new KitError({
            ...BalanceError.INSUFFICIENT_GAS,
            recoverability: 'FATAL',
            message: `Validation failed on Solana: Insufficient SOL balance to create Associated Token Account.\n` + `Payer wallet ${payer.toBase58()} has ${balanceSol} SOL but needs at least ` + `${requiredSol} SOL to pay for account rent and transaction fees.\n` + `Please add SOL to this payer wallet before proceeding.`,
            cause: {
                trace: {
                    reason: 'Insufficient SOL balance for ATA creation',
                    chain: 'Solana',
                    payer: payer.toBase58(),
                    currentBalance: balance.toString(),
                    currentBalanceSol: balanceSol,
                    requiredBalance: MINIMUM_BALANCE_FOR_ATA.toString(),
                    requiredBalanceSol: requiredSol
                }
            }
        });
    }
};
/**
 * Ensure Associated Token Account exists and return optimized transaction instructions.
 *
 * Handles ATA creation for fresh Solana wallets receiving USDC from other chains.
 * Attempts to combine ATA creation with mint instructions for a single signing experience.
 * If the combined transaction exceeds Solana's size limit, automatically creates the ATA
 * in a separate transaction first (requiring 2 signatures total).
 * Validates that the payer wallet has sufficient SOL balance before proceeding.
 *
 * @param params - Provider, adapter, context, payer, owner, and instructions to combine
 * @returns Instructions to execute, plus metadata about ATA inclusion
 * @throws KitError with BalanceError.INSUFFICIENT_GAS if payer wallet has insufficient SOL balance for ATA creation
 * @throws KitError with InputError.VALIDATION_FAILED if ATA address derivation is incorrect
 * @throws KitError with OnchainError.SIMULATION_FAILED if separate ATA creation fails
 *
 * @example
 * ```typescript
 * const result = await ensureAtaExists({
 *   provider,
 *   adapter,
 *   context,
 *   payer: walletPublicKey,      // Who pays for the transaction
 *   owner: recipientPublicKey,   // Who owns the ATA
 *   mint: usdcMintAddress,
 *   ataAddress: derivedAtaAddress,
 *   otherInstructions: [mintInstruction],
 * })
 *
 * if (result.ataIncluded) {
 *   console.log('ATA creation bundled with mint - single signature')
 * } else {
 *   console.log('ATA was created separately (2 signatures required)')
 * }
 * ```
 */ const ensureAtaExists = async (params)=>{
    const { provider, adapter, context, payer, owner, mint, ataAddress, otherInstructions } = params;
    // Throws KitError (INPUT_INVALID_ADDRESS / 1004) if owner is off the ed25519 curve.
    const derivedAta = getAssociatedTokenAddressSync(mint, owner);
    if (!derivedAta.equals(ataAddress)) {
        throw new KitError({
            ...InputError.VALIDATION_FAILED,
            recoverability: 'FATAL',
            message: `ATA address mismatch: expected ${derivedAta.toBase58()}, got ${ataAddress.toBase58()}`,
            cause: {
                trace: {
                    reason: 'ATA address validation failed',
                    expectedAta: derivedAta.toBase58(),
                    providedAta: ataAddress.toBase58(),
                    mint: mint.toBase58(),
                    owner: owner.toBase58()
                }
            }
        });
    }
    // Check if ATA creation is needed
    const ataInstruction = await createAtaInstructionIfNeeded(provider.connection, payer, owner, mint, ataAddress);
    // ATA already exists - return other instructions as-is
    if (!ataInstruction) {
        return {
            instructions: otherInstructions,
            ataIncluded: false,
            usedFallback: false,
            estimatedSize: estimateTransactionSize(otherInstructions, OPERATION_LIMITS.ESTIMATED_ACCOUNTS - OPERATION_LIMITS.ATA_ACCOUNTS)
        };
    }
    // ATA needs creation - validate payer has sufficient SOL balance
    await validateSolBalanceForAta(provider, payer);
    // Combine ATA creation with other instructions for single signing experience
    const combinedInstructions = [
        ataInstruction,
        ...otherInstructions
    ];
    const estimatedSize = estimateTransactionSize(combinedInstructions, OPERATION_LIMITS.ESTIMATED_ACCOUNTS);
    // Check if transaction is too large
    if (estimatedSize > OPERATION_LIMITS.MAX_TX_SIZE) {
        try {
            // Execute ATA creation in a separate transaction
            const preparedAtaRequest = await adapter.prepare({
                instructions: [
                    ataInstruction
                ]
            }, context);
            await preparedAtaRequest.execute();
            // Return only the mint instructions (ATA is now created)
            return {
                instructions: otherInstructions,
                ataIncluded: false,
                usedFallback: true,
                estimatedSize: estimateTransactionSize(otherInstructions, OPERATION_LIMITS.ESTIMATED_ACCOUNTS - OPERATION_LIMITS.ATA_ACCOUNTS)
            };
        } catch (error) {
            // Check if ATA was created despite the error (race condition)
            const ataExists = await provider.connection.getAccountInfo(ataAddress);
            if (ataExists) {
                return {
                    instructions: otherInstructions,
                    ataIncluded: false,
                    usedFallback: true,
                    estimatedSize: estimateTransactionSize(otherInstructions, OPERATION_LIMITS.ESTIMATED_ACCOUNTS - OPERATION_LIMITS.ATA_ACCOUNTS)
                };
            }
            // ATA creation failed and ATA doesn't exist
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new KitError({
                ...OnchainError.SIMULATION_FAILED,
                recoverability: 'FATAL',
                message: `Failed to create ATA separately: ${errorMessage}`,
                cause: {
                    trace: {
                        reason: 'ATA creation failed in separate transaction',
                        originalError: errorMessage,
                        mint: mint.toBase58(),
                        ataAddress: ataAddress.toBase58(),
                        owner: owner.toBase58(),
                        payer: payer.toBase58()
                    }
                }
            });
        }
    }
    // Transaction fits within size limit - return combined instructions
    return {
        instructions: combinedInstructions,
        ataIncluded: true,
        usedFallback: false,
        estimatedSize
    };
};

/**
 * Generate transaction instructions for a CCTP mint operation.
 *
 * This function orchestrates the complete flow for creating a mint
 * transaction on Solana. It loads the necessary programs, derives program
 * addresses, checks if the user's USDC token account exists (creating it in a
 * separate transaction if needed), and builds the required instruction with signers.
 *
 * @param params - The mint parameters containing source/destination chain details,
 *                 amount, recipient address, and adapter reference.
 * @returns An object containing the array of transaction instructions and required signers.
 * @throws Error if any of the required program operations fail.
 *
 * @example
 * ```typescript
 * import { getInstructions } from './getInstructions'
 * import { Connection, Keypair, sendAndConfirmTransaction, Transaction } from '@solana/web3.js'
 * import { SolanaAdapter } from '@circle-fin/adapter-solana' // Use the concrete adapter
 * import { Ethereum, SolanaDevnet } from '@core/chains'
 *
 * async function executeMint() {
 *   // Setup connection and wallet
 *   const connection = new Connection('https://api.devnet.solana.com')
 *   const wallet = Keypair.generate() // In production, use your actual wallet
 *
 *   // Create Solana adapter
 *   const adapter = new SolanaAdapter({
 *     connection,
 *     signer: wallet
 *   })
 *
 *   // Get instructions
 *   const { ixs, signers } = await getInstructions({
 *     adapter,
 *     message: '0x1234567890abcdef...', // Raw message from source chain
 *     eventNonce: '0x0123456789abcdef...', // Event nonce from the message
 *     attestation: '0xfedcba9876543210...', // Circle attestation
 *     sourceChain: Ethereum,
 *     destinationChain: SolanaDevnet
 *   })
 *
 *   // Create and send transaction
 *   const transaction = new Transaction().add(...ixs)
 *   const signature = await sendAndConfirmTransaction(
 *     connection,
 *     transaction,
 *     [wallet, ...signers]
 *   )
 *   console.log('Transaction confirmed:', signature)
 * }
 * ```
 */ const getInstructions = async (params)=>{
    const { adapter, fromChain, toChain, eventNonce } = params;
    const provider = await adapter.getAnchorProvider(params.context);
    const v2config = toChain.cctp.contracts.v2;
    if (!v2config || v2config.type !== 'split') {
        throw new Error('Unsupported CCTP v2 contract configuration for Solana. Expected "split" type.');
    }
    const config = v2config;
    const [tokenMessengerProgram, messageTransmitterProgram] = await Promise.all([
        getProgram(provider, config.tokenMessenger),
        getProgram(provider, config.messageTransmitter)
    ]);
    const user = provider.wallet.publicKey;
    const usdcMint = new web3_js.PublicKey(toChain.usdcAddress);
    const pdas = derivePdas(fromChain, toChain, messageTransmitterProgram.programId, tokenMessengerProgram.programId);
    if (!('tokenMessenger' in tokenMessengerProgram.account)) {
        throw new Error('TokenMessenger account not found');
    }
    const tokenMessengerState = await tokenMessengerProgram.account.tokenMessenger.fetch(pdas.tokenMessengerPda);
    const feeRecipientAta = anchor.utils.token.associatedAddress({
        mint: usdcMint,
        owner: tokenMessengerState['feeRecipient']
    });
    // Determine the ATA owner (recipient of the tokens)
    const mintRecipientOwner = params.destinationAddress ? new web3_js.PublicKey(params.destinationAddress) : user;
    // Derive the USDC ATA for the recipient
    const userUsdcAta = anchor.utils.token.associatedAddress({
        mint: usdcMint,
        owner: mintRecipientOwner
    });
    if (!('receiveMessage' in messageTransmitterProgram.methods)) {
        throw new Error('receiveMessage method not found');
    }
    const { ixs, signer } = await buildInstructions(params, {
        tokenMessenger: tokenMessengerProgram,
        messageTransmitter: messageTransmitterProgram
    }, pdas, feeRecipientAta, eventNonce);
    // Ensure ATA exists and combine with CCTP instructions
    // Note: user (wallet) pays for ATA creation, mintRecipientOwner owns the ATA
    const ataResult = await ensureAtaExists({
        provider,
        adapter,
        context: params.context,
        payer: user,
        owner: mintRecipientOwner,
        mint: usdcMint,
        ataAddress: userUsdcAta,
        otherInstructions: ixs
    });
    return {
        ixs: ataResult.instructions,
        signers: signer ? [
            signer
        ] : []
    };
};

/**
 * Prepare a CCTP mint transaction for receiving cross-chain USDC transfers on Solana.
 *
 * This function creates a prepared chain request for minting USDC tokens on Solana
 * as part of the Cross-Chain Transfer Protocol (CCTP) flow. It processes the
 * attestation and message from the source chain to complete the cross-chain transfer.
 *
 * The transaction includes:
 * - An explicit compute unit limit to avoid exceeding the default 200k limit
 * - Address Lookup Table (ALT) compression to reduce transaction size
 *
 * @param params - The mint parameters containing message, attestation, and chain details.
 * @returns A prepared chain request that can be executed or simulated.
 * @throws Error if instruction generation fails or if the adapter cannot prepare
 *         the transaction.
 *
 * @example
 * ```typescript
 * import { mint } from './mint'
 * import { Connection, Keypair } from '@solana/web3.js'
 * import { SolanaAdapter } from '@circle-fin/adapter-solana'
 * import { SolanaDevnet, Ethereum } from '@circle-fin/bridge-kit/chains'
 *
 * async function receiveCCTPTransfer() {
 *   // Setup connection and wallet
 *   const connection = new Connection('https://api.devnet.solana.com')
 *   const wallet = Keypair.generate() // In production, use your actual wallet
 *
 *   // Create Solana adapter
 *   const adapter = new SolanaAdapter({
 *     connection,
 *     signer: wallet
 *   })
 *
 *   // Prepare the mint transaction
 *   const preparedRequest = await mint({
 *     adapter,
 *     message: '0x1234567890abcdef...', // Raw message from source chain
 *     eventNonce: '0x0123456789abcdef...', // Event nonce from the message
 *     attestation: '0xfedcba9876543210...', // Circle attestation
 *     sourceChain: Ethereum,
 *     destinationChain: SolanaDevnet
 *   })
 *
 *   // Execute the prepared request
 *   const result = await preparedRequest.execute()
 *   console.log('USDC minted, transaction:', result.signature)
 * }
 * ```
 */ async function mint(params, adapter, context) {
    const { ixs, signers } = await getInstructions({
        ...params,
        adapter,
        context
    });
    // Get ALT address from chain config for adapters that fetch ALT themselves
    const altAddress = getCctpAltAddress(context.chain);
    const addressLookupTableAddresses = altAddress ? [
        altAddress
    ] : [];
    // Get the connection for fetching ALT accounts
    // The adapter's getConnection returns a transport-specific connection type
    // For @solana/web3.js adapters, this is a Connection object
    // For @solana/kit adapters, this will be an RPC client (and ALT fetch may fail gracefully)
    let addressLookupTableAccounts = [];
    try {
        const connection = adapter.getConnection(context.chain);
        // Fetch Address Lookup Table accounts for transaction compression
        // This reduces transaction size by using shorter indices for frequently-used addresses
        addressLookupTableAccounts = await getCctpAddressLookupTableAccounts(connection, context.chain);
    } catch  {
    // For adapters that don't return a web3.js Connection (e.g., solana-kit),
    // the ALT fetch will fail. These adapters should use addressLookupTableAddresses instead.
    }
    return adapter.prepare({
        instructions: ixs,
        signers,
        // Set explicit compute unit limit for CCTP mint operations
        // The default 200k is insufficient for receiveMessage (~280k observed)
        computeUnitLimit: CCTP_COMPUTE_UNITS.mint,
        // Use ALT to compress transaction size
        // addressLookupTableAccounts is for web3.js adapters (pre-fetched ALT data)
        // addressLookupTableAddresses is for solana-kit adapters (will fetch ALT themselves)
        addressLookupTableAccounts,
        addressLookupTableAddresses
    }, context);
}

/**
 * Prepares a Solana-compatible native SOL `transfer` transaction.
 *
 * This function creates a prepared chain request for transferring native SOL from the sender's
 * wallet to a recipient address on a Solana-based chain. It validates the provided addresses
 * and creates a SystemProgram transfer instruction.
 *
 * @param params - The action payload for the native SOL transfer:
 *   - `to`: The recipient's wallet address to send SOL to.
 *   - `amount`: The amount of SOL to transfer (in lamports, the smallest unit of SOL).
 * @param adapter - The Solana adapter providing chain context and connection.
 * @param context - The resolved operation context containing the chain definition.
 * @returns A promise that resolves to a prepared chain request for the `transfer` call.
 *   The returned request's `execute` method yields the transaction signature.
 * @throws Error if the current chain is not Solana-compatible.
 * @throws Error if the recipient address is invalid.
 * @throws Error if the amount is zero or negative.
 * @throws Error if the sender has insufficient SOL balance or the sender account is not found.
 *
 * @example
 * ```typescript
 * const prepared = await transfer({
 *   to: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
 *   amount: 1000000000n // 1 SOL (9 decimals)
 * }, adapter, context)
 * const signature = await prepared.execute()
 * console.log('SOL transfer completed:', signature)
 * ```
 */ const transfer$3 = async (params, adapter, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `Expected Solana chain definition, but received chain type: ${chain.type}`);
    }
    const { to, amount } = params;
    // Validate recipient address (required parameter)
    assertSolanaAddress(to);
    // Validate amount (required parameter)
    if (typeof amount !== 'bigint' || amount <= 0n) {
        throw createInvalidAmountError(String(amount), 'Transfer amount must be a positive bigint');
    }
    const connection = adapter.getConnection(chain);
    const signer = await adapter.getSigner(chain);
    // Create the recipient public key
    const recipientAddress = new web3_js.PublicKey(to);
    const senderAddress = signer.publicKey;
    // Check if sender has sufficient SOL balance
    // Note: This check does not account for transaction fees. The transaction may still fail
    // during execution if the remaining balance is insufficient to cover fees.
    try {
        const balance = await connection.getBalance(senderAddress, 'confirmed');
        const currentBalance = BigInt(balance);
        if (currentBalance < amount) {
            throw new Error(`Insufficient SOL balance. Available: ${currentBalance.toString()} lamports, Required: ${amount.toString()} lamports`);
        }
    } catch (error) {
        if (error instanceof Error && error.message.toLowerCase().includes('could not find account')) {
            throw new Error('Sender account not found');
        }
        throw error;
    }
    // Create the transfer instruction using SystemProgram.transfer
    const transferInstruction = web3_js.SystemProgram.transfer({
        fromPubkey: senderAddress,
        toPubkey: recipientAddress,
        lamports: amount
    });
    // Prepare the transaction with the transfer instruction
    return await adapter.prepare({
        instructions: [
            transferInstruction
        ]
    }, context);
};

/**
 * Prepares a Solana-compatible native SOL balance read.
 *
 * This function creates a prepared chain request for reading the native SOL balance
 * of a given wallet address on a Solana-based chain. If no wallet address is provided,
 * the adapter's default address is used.
 *
 * Native token balance reads are gas-free operations that query the blockchain state.
 * The result is returned in lamports (the smallest unit of SOL, where 1 SOL = 10^9 lamports).
 *
 * This action uses the adapter's `readNativeBalance` method which abstracts over different
 * Solana transport implementations (\@solana/web3.js vs \@solana/kit), ensuring compatibility
 * with all Solana adapter types.
 *
 * @param params - The action payload for the native balance lookup:
 *   - `walletAddress` (optional): The wallet address to check. Defaults to adapter address.
 * @param adapter - The Solana adapter providing chain context and balance reading capability.
 * @param context - The resolved operation context providing chain information.
 * @returns A promise resolving to a prepared chain request.
 *   The `execute` method returns the balance as a string (in lamports).
 * @throws {KitError} If the current chain is not Solana-compatible (INPUT_INVALID_CHAIN).
 * @throws Error If address validation fails or balance retrieval fails.
 *
 * @example
 * ```typescript
 * import { Solana } from '@core/chains'
 *
 * // Check balance for a specific address
 * const prepared = await balanceOf(
 *   { walletAddress: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN' },
 *   adapter,
 *   context
 * )
 * const balance = await prepared.execute()
 * console.log(balance) // e.g., "1000000000" (1 SOL in lamports)
 *
 * // Check balance for the adapter's address (no walletAddress provided)
 * const prepared2 = await balanceOf({}, adapter, context)
 * const balance2 = await prepared2.execute()
 * ```
 */ const balanceOf$2 = async (params, adapter, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `Expected Solana chain definition, but received chain type: ${chain.type}`);
    }
    // Use provided wallet address or fall back to context address
    const walletAddress = params.walletAddress ?? context.address;
    // Validate the address
    assertSolanaAddress(walletAddress);
    // Create noop request for gas estimation (reading balance is free)
    const noopRequest = await createNoopChainRequest();
    return {
        type: 'solana',
        estimate: noopRequest.estimate,
        execute: async ()=>{
            const balance = await adapter.readNativeBalance(walletAddress, chain);
            return balance.toString();
        }
    };
};

// Maximum value for a 256-bit unsigned integer (2^256 - 1)
const maxUint256 = 2n ** 256n - 1n;
/**
 * Prepares a Solana-compatible `allowance` read for any SPL token.
 *
 * This function creates a prepared chain request for reading the allowance of a given wallet (owner)
 * and delegate (spender) address for a specified SPL token on a Solana-based chain. However, Solana's
 * token program does not support ERC-20 style allowances. For cross-chain consistency, this function
 * always returns the maximum uint256 value (2^256 - 1) to represent "infinite" allowance.
 *
 * @param adapter - The Solana adapter responsible for chain context.
 * @returns A promise that resolves to a prepared chain request for the `allowance` call.
 *   The `execute` method always returns the maximum uint256 value as a string.
 * @throws Error if the current chain is not Solana-compatible.
 *
 * @example
 * ```typescript
 * const prepared = await allowance(adapter)
 * const allowanceValue = await prepared.execute()
 * console.log(allowanceValue) // "115792089237316195423570985008687907853269984665640564039457584007913129639935"
 * ```
 */ const allowance = async (_, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw new Error(`Expected Solana chain definition, but received chain type: ${chain.type}`);
    }
    // Get noop for the `estimate` call
    const noop = await createNoopChainRequest();
    // Solana does not support token allowances; return maximum uint256 value to represent "infinite" allowance
    // This ensures cross-chain consistency with EVM chains and any allowance checks will always pass
    return {
        type: 'solana',
        estimate: noop.estimate,
        execute: async ()=>Promise.resolve(maxUint256.toString())
    };
};

/**
 * Prepares a Solana-compatible `balanceOf` read for any SPL token.
 *
 * This function creates a prepared chain request for reading the balance of a given wallet address
 * for a specified SPL token on a Solana-based chain. It validates the provided addresses, derives
 * the associated token account, and queries the token account balance using the Solana RPC connection.
 * If no wallet address is provided, the adapter's default address is used.
 *
 * @param params - The action payload for the token balance lookup:
 *   - `tokenAddress`: The SPL token mint address to check the balance for.
 *   - `walletAddress` (optional): The wallet address to check the token balance for. If not provided, the adapter's address is used.
 * @param adapter - The Solana adapter providing chain context and connection.
 * @returns A promise that resolves to a prepared chain request for the `balanceOf` call.
 *   The returned request's `execute` method yields the balance as a string (in the token's smallest unit).
 * @throws Error if the current chain is not Solana-compatible, if the addresses are invalid, or if the token account is not found.
 *
 * @example
 * ```typescript
 * const prepared = await balanceOf({ tokenAddress: 'So11111111111111111111111111111111111111112', walletAddress: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN' }, adapter)
 * const balance = await prepared.execute()
 * console.log(balance) // e.g., "1000000" (for 1 token with 6 decimals)
 * ```
 */ const balanceOf$1 = async (params, adapter, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw new Error(`Expected Solana chain definition, but received chain type: ${chain.type}`);
    }
    // Get noop for the `estimate` call
    const noop = await createNoopChainRequest();
    // Helper function to create read-only prepared chain request
    const createReadOnlyRequest = (value)=>({
            type: 'solana',
            estimate: noop.estimate,
            execute: async ()=>Promise.resolve(value)
        });
    const { tokenAddress, walletAddress: walletAddressParam } = params;
    // Validate token address first (required parameter)
    assertSolanaAddress(tokenAddress);
    // Resolve wallet address (use adapter's address if not provided)
    const walletAddress = walletAddressParam ?? await adapter.getAddress(chain);
    // Validate the resolved wallet address
    assertSolanaAddress(walletAddress);
    try {
        // Use the transport-agnostic method to read token balance
        // Pass the chain from resolved context
        const balance = await adapter.readTokenBalance(tokenAddress, walletAddress, chain);
        return createReadOnlyRequest(balance);
    } catch (error) {
        // Wrap the error with more context and re-throw
        const errorMessage = error instanceof Error ? error.message : String(error);
        // Only return 0 for the specific case where the ATA doesn't exist
        // This avoids catching other ATA-related errors (e.g., UninitializedAccount, InvalidAccountData)
        if (errorMessage.toLowerCase().includes('associated token account not found')) {
            return createReadOnlyRequest('0');
        }
        throw new Error(`Failed to get token balance for ${walletAddress} from ${tokenAddress}: ${errorMessage}`);
    }
};

/**
 * Prepares a Solana-compatible `transfer` transaction for any SPL token.
 *
 * This function creates a prepared chain request for transferring SPL tokens from the sender's
 * wallet to a recipient address on a Solana-based chain. It validates the provided addresses,
 * derives the associated token accounts, and creates the necessary transfer instruction.
 * The transaction will transfer the specified amount from the sender's token account to the
 * recipient's token account.
 *
 * @param params - The action payload for the token transfer:
 *   - `tokenAddress`: The SPL token mint address to transfer.
 *   - `to`: The recipient's wallet address to send tokens to.
 *   - `amount`: The amount of tokens to transfer (in the token's smallest unit).
 * @param adapter - The Solana adapter providing chain context and connection.
 * @returns A promise that resolves to a prepared chain request for the `transfer` call.
 *   The returned request's `execute` method yields the transaction signature.
 * @throws Error if the current chain is not Solana-compatible, if the addresses are invalid,
 *         or if the token accounts are not found.
 *
 * @example
 * ```typescript
 * const prepared = await transfer({
 *   tokenAddress: 'So11111111111111111111111111111111111111112',
 *   to: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
 *   amount: 1000000n
 * }, adapter)
 * const signature = await prepared.execute()
 * console.log('Transfer completed:', signature)
 * ```
 */ const transfer$2 = async (params, adapter, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `Expected Solana chain definition, but received chain type: ${chain.type}`);
    }
    const { tokenAddress, to, amount } = params;
    // Validate token address (required parameter)
    assertSolanaAddress(tokenAddress);
    // Validate recipient address (required parameter)
    assertSolanaAddress(to);
    // Validate amount (required parameter)
    if (typeof amount !== 'bigint' || amount <= 0n) {
        throw createInvalidAmountError(String(amount), 'Transfer amount must be a positive bigint');
    }
    const connection = adapter.getConnection(chain);
    const signer = await adapter.getSigner(chain);
    // Create the token mint and address keys
    const tokenMint = new web3_js.PublicKey(tokenAddress);
    const recipientAddress = new web3_js.PublicKey(to);
    const senderAddress = signer.publicKey;
    // Detect the owning token program (standard Token vs Token-2022) so ATAs
    // are derived with the correct program ID. Token-2022 mints (e.g. PYUSD)
    // produce a different ATA address when the wrong program is used.
    const tokenProgramId = await detectTokenProgram(connection, tokenMint);
    const senderAta = getAssociatedTokenAddressSync(tokenMint, senderAddress, false, tokenProgramId);
    const recipientAta = getAssociatedTokenAddressSync(tokenMint, recipientAddress, false, tokenProgramId);
    // Check if sender's token account exists and has sufficient balance.
    // The response also provides decimals needed for TransferChecked.
    let tokenDecimals;
    try {
        const senderAccountInfo = await connection.getTokenAccountBalance(senderAta, 'confirmed');
        if (!senderAccountInfo.value) {
            throw new Error(`Sender token account not found for token ${tokenAddress}`);
        }
        tokenDecimals = senderAccountInfo.value.decimals;
        const currentBalance = BigInt(senderAccountInfo.value.amount);
        if (currentBalance < amount) {
            throw new Error(`Insufficient balance. Available: ${currentBalance.toString()}, Required: ${amount.toString()}`);
        }
    } catch (error) {
        if (error instanceof Error && error.message.toLowerCase().includes('could not find account')) {
            throw new Error(`Sender token account not found for token ${tokenAddress}`);
        }
        throw error;
    }
    // Check if recipient's token account exists, create if needed
    const recipientAtaInfo = await connection.getAccountInfo(recipientAta, 'confirmed');
    let createAtaInstruction = null;
    if (!recipientAtaInfo) {
        createAtaInstruction = createAssociatedTokenAccountInstruction(senderAddress, recipientAta, recipientAddress, tokenMint, tokenProgramId);
    }
    // Use TransferChecked which works for both standard Token and Token-2022.
    // Token-2022 mints reject the basic Transfer instruction and require
    // TransferChecked (which includes mint + decimals for verification).
    const transferInstruction = createTransferCheckedInstruction(senderAta, tokenMint, recipientAta, senderAddress, amount, tokenDecimals, tokenProgramId);
    // Prepare the transaction with instructions
    const instructions = createAtaInstruction ? [
        createAtaInstruction,
        transferInstruction
    ] : [
        transferInstruction
    ];
    return await adapter.prepare({
        instructions
    }, context);
};

/**
 * Type guard to check if params is ExecuteSwapSolanaParams.
 *
 * Uses property-based narrowing: Solana swap params have `serializedTransaction`,
 * while EVM swap params have `executeParams` and `tokenInputs`.
 */ const isSolanaSwapParams = (params)=>{
    return 'serializedTransaction' in params;
};
/**
 * Executes a swap transaction on Solana.
 *
 * This action prepares swap transactions that execute on Solana by deserializing
 * a pre-built transaction provided by the stablecoin-service. The service handles
 * DEX aggregator routing, fee collection, slippage protection, and token account
 * management.
 *
 * @remarks
 * **Service Integration**
 *
 * The stablecoin-service returns a fully serialized transaction (base64-encoded)
 * that contains all necessary instructions for the swap operation. This transaction
 * is built using DEX aggregators like Jupiter and includes:
 * - Token account initialization (if needed)
 * - Swap instructions with slippage protection
 * - Fee collection
 * - Token account cleanup
 *
 * **Transaction Format**
 *
 * The service provides VersionedTransaction format which supports address lookup tables
 * and modern Solana features. The transaction includes a recent blockhash from the service,
 * so it can be signed and submitted immediately without rebuilding.
 *
 * **Signing and Execution**
 *
 * The transaction is deserialized, signed with the user's wallet, and submitted directly.
 * This preserves all optimizations from the service including address lookup tables,
 * compute budgets, and priority fees.
 *
 * @param params - Swap execution parameters:
 *   - `serializedTransaction`: Base64-encoded transaction from service
 * @param adapter - Solana adapter for transaction preparation
 * @param context - Resolved operation context with chain information
 * @returns Prepared chain request ready for estimation or execution
 *
 * @throws KitError If chain is not Solana-compatible (INPUT_INVALID_CHAIN)
 * @throws KitError If serializedTransaction is missing or invalid (INPUT_VALIDATION_FAILED)
 * @throws KitError If transaction deserialization fails (INPUT_VALIDATION_FAILED)
 *
 * @example
 * ```typescript
 * import { createSwap } from '@core/service-client'
 * import type { SolanaAdapter } from '@adapters/solana'
 *
 * // 1. Get swap transaction from stablecoin-service
 * const swapResponse = await createSwap({
 *   tokenInAddress: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC
 *   tokenOutAddress: 'HzwqbKZw8HxMN6bF2yFZNrht3c2iXXzpKcFu7uBEDKtr', // USDT
 *   tokenInChain: 'Solana',
 *   fromAddress: await adapter.getAddress(),
 *   toAddress: 'YubQzu18FDqJRyNfG8JqHmsdbxhnoQqcKUHBdUkN6tP',
 *   amount: '1000000', // 1 USDC in base units
 *   apiKey: process.env.API_KEY,
 * })
 *
 * // 2. Execute swap via adapter action
 * const swapRequest = await adapter.prepareAction(
 *   'swap.execute',
 *   {
 *     serializedTransaction: swapResponse.transaction.data
 *   },
 *   context
 * )
 *
 * // 3. Estimate fees
 * const gasEstimate = await swapRequest.estimate()
 * console.log('Transaction fee:', gasEstimate.fee, 'lamports')
 *
 * // 4. Execute transaction
 * const txHash = await swapRequest.execute()
 * console.log('Swap transaction:', txHash)
 * ```
 */ const executeSwap = async (params, adapter, context)=>{
    const { chain } = context;
    // Validate Solana chain
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `Expected Solana chain, but received chain type: ${String(chain.type)}`);
    }
    // Check if EVM params were passed (has executeParams) - throw handler error
    if ('executeParams' in params) {
        throw createValidationFailedError('params', params, 'This action handler only supports Solana swap parameters (must have serializedTransaction)');
    }
    // Narrow type using property-based guard - this function only handles Solana swaps
    // The type guard checks for serializedTransaction and narrows the type for TypeScript
    if (!isSolanaSwapParams(params)) {
        throw createValidationFailedError('serializedTransaction', undefined, 'serializedTransaction is required for Solana swap parameters');
    }
    // After type guard, TypeScript knows params is ExecuteSwapSolanaParams
    const serializedTransaction = params.serializedTransaction;
    // Validate serializedTransaction is a string (we already checked it exists above)
    if (typeof serializedTransaction !== 'string') {
        throw createValidationFailedError('serializedTransaction', serializedTransaction, 'serializedTransaction must be a string');
    }
    // Validate serializedTransaction is not empty
    if (serializedTransaction.trim() === '') {
        throw createValidationFailedError('serializedTransaction', serializedTransaction, 'serializedTransaction must be a non-empty base64-encoded string');
    }
    // Deserialize and prepare the transaction via adapter
    const buffer = Buffer.from(serializedTransaction, 'base64');
    return adapter.prepare({
        serializedTransaction: Uint8Array.from(buffer)
    }, context);
};

/**
 * Prepares a Solana-compatible `balanceOf` read for the canonical USDC token.
 *
 * This function creates a prepared chain request for reading the USDC balance of a given wallet address
 * on a Solana-based chain. It automatically uses the canonical USDC mint address for the current chain,
 * and delegates to the generic SPL token `balanceOf` action. If no wallet address is provided, the adapter's
 * default address is used.
 *
 * @param params - The action payload for the USDC balance lookup:
 *   - `walletAddress` (optional): The wallet address to check the USDC balance for. If not provided, the adapter's address is used.
 * @param adapter - The Solana adapter providing chain context and connection.
 * @returns A promise that resolves to a prepared chain request for the USDC `balanceOf` call.
 *   The returned request's `execute` method yields the balance as a string (in USDC's smallest unit).
 * @throws Error if the current chain is not Solana-compatible, if the USDC address is missing, or if the token account lookup fails.
 *
 * @example
 * ```typescript
 * const prepared = await balanceOf({ walletAddress: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN' }, adapter)
 * const balance = await prepared.execute()
 * console.log(balance) // e.g., "1000000" (for 1 USDC with 6 decimals)
 * ```
 */ const balanceOf = async (params, adapter, context)=>{
    // get the USDC address for the chain
    const chain = context.chain;
    const tokenAddress = chain.usdcAddress;
    if (tokenAddress == null) {
        throw new Error(`USDC is not supported on chain ${chain.name}. Please use a chain that has USDC configured.`);
    }
    // use the generic token balanceOf functionality with the USDC address
    return await balanceOf$1({
        tokenAddress,
        walletAddress: params.walletAddress
    }, adapter, context);
};

/**
 * Prepares a Solana-compatible USDC `transfer` transaction.
 *
 * This function creates a prepared chain request for transferring USDC tokens from the sender's
 * wallet to a recipient address on a Solana-based chain. It automatically resolves the USDC token
 * mint address from the chain configuration and delegates to the generic token transfer function.
 *
 * @param params - The action payload for the USDC transfer:
 *   - `to`: The recipient's wallet address to send USDC to.
 *   - `amount`: The amount of USDC to transfer (in the token's smallest unit, i.e., micro-USDC).
 * @param adapter - The Solana adapter providing chain context and connection.
 * @param context - The resolved operation context containing the chain definition.
 * @returns A promise that resolves to a prepared chain request for the `transfer` call.
 *   The returned request's `execute` method yields the transaction signature.
 * @throws {KitError} If chain is not Solana (INPUT_INVALID_CHAIN) or USDC is not supported (INPUT_UNSUPPORTED_TOKEN).
 * @throws Error if the addresses are invalid or if the token accounts are not found.
 *
 * @example
 * ```typescript
 * const prepared = await transfer({
 *   to: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
 *   amount: 1000000n // 1 USDC (6 decimals)
 * }, adapter, context)
 * const signature = await prepared.execute()
 * console.log('USDC transfer completed:', signature)
 * ```
 */ const transfer$1 = async (params, adapter, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `Expected Solana chain, but received chain type: ${chain.type}`);
    }
    // Get the USDC token address from the chain configuration
    const usdcAddress = chain.usdcAddress;
    if (usdcAddress == null) {
        throw createUnsupportedTokenError('USDC', chain.name);
    }
    // Delegate to the generic token transfer function with the USDC token address
    return transfer$2({
        tokenAddress: usdcAddress,
        to: params.to,
        amount: params.amount
    }, adapter, context);
};

/**
 * Prepares a Solana-compatible USDT `transfer` transaction.
 *
 * This function creates a prepared chain request for transferring USDT tokens from the sender's
 * wallet to a recipient address on a Solana-based chain. It automatically resolves the USDT token
 * mint address from the chain configuration and delegates to the generic token transfer function.
 *
 * @param params - The action payload for the USDT transfer:
 *   - `to`: The recipient's wallet address to send USDT to.
 *   - `amount`: The amount of USDT to transfer (in the token's smallest unit, i.e., micro-USDT).
 * @param adapter - The Solana adapter providing chain context and connection.
 * @param context - The resolved operation context containing the chain definition.
 * @returns A promise that resolves to a prepared chain request for the `transfer` call.
 *   The returned request's `execute` method yields the transaction signature.
 * @throws {KitError} If chain is not Solana (INPUT_INVALID_CHAIN) or USDT is not supported (INPUT_UNSUPPORTED_TOKEN).
 * @throws Error if the addresses are invalid or if the token accounts are not found.
 *
 * @example
 * ```typescript
 * const prepared = await transfer({
 *   to: 'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
 *   amount: 1000000n // 1 USDT (6 decimals)
 * }, adapter, context)
 * const signature = await prepared.execute()
 * console.log('USDT transfer completed:', signature)
 * ```
 */ const transfer = async (params, adapter, context)=>{
    const chain = context.chain;
    if (chain.type !== 'solana') {
        throw createInvalidChainError(chain.name, `Expected Solana chain, but received chain type: ${chain.type}`);
    }
    // Get the USDT token address from the chain configuration
    const usdtAddress = chain.usdtAddress;
    if (usdtAddress == null) {
        throw createUnsupportedTokenError('USDT', chain.name);
    }
    // Delegate to the generic token transfer function with the USDT token address
    return transfer$2({
        tokenAddress: usdtAddress,
        to: params.to,
        amount: params.amount
    }, adapter, context);
};

/**
 * Creates a collection of action handlers for Solana blockchain operations.
 *
 * This factory function generates type-safe action handlers that implement
 * the ActionHandlers interface for Solana-specific blockchain operations.
 * Each handler processes action payloads and returns prepared chain requests
 * that can be executed by the Solana adapter.
 *
 * @remarks
 * All handlers include comprehensive runtime validation and error handling
 * to ensure reliable cross-chain operations. The handlers automatically
 * handle Solana-specific transaction formatting and account management.
 *
 * @param adapter - The configured Solana adapter for blockchain operations.
 * @returns A collection of type-safe action handlers for Solana operations.
 *
 * @throws Error When handler execution fails due to network or validation errors.
 */ const getHandlers = (adapter)=>{
    return {
        /**
     * Handler for token allowance operations on Solana.
     *
     * Returns the maximum uint256 value (2^256 - 1) to represent "infinite" allowance since Solana's token program doesn't support allowances.
     */ 'token.allowance': async (_, context)=>{
            return allowance(adapter, context);
        },
        /**
     * Handler for token balance of operations on Solana.
     *
     * Returns the balance of the token for the given wallet address.
     */ 'token.balanceOf': async (params, context)=>{
            return balanceOf$1(params, adapter, context);
        },
        /**
     * Handler for SPL token transfer operations on Solana.
     *
     * Transfers SPL tokens from the sender's wallet to a recipient address.
     * Automatically creates the recipient's associated token account if needed.
     */ 'token.transfer': async (params, context)=>{
            return await transfer$2(params, adapter, context);
        },
        /**
     * Handler for USDC allowance operations on Solana.
     *
     * Returns the maximum uint256 value (2^256 - 1) to represent "infinite" allowance since Solana's token program doesn't support allowances.
     */ 'usdc.allowance': async (_, context)=>{
            return allowance(adapter, context);
        },
        /**
     * Handler for USDC balance of operations on Solana.
     *
     * Returns the balance of the USDC for the given wallet address.
     */ 'usdc.balanceOf': async (params, context)=>{
            return balanceOf(params, adapter, context);
        },
        /**
     * Handler for USDC transfer operations on Solana.
     *
     * Transfers USDC tokens from the sender's wallet to a recipient address.
     * Automatically creates the recipient's associated token account if needed.
     */ 'usdc.transfer': async (params, context)=>{
            return await transfer$1(params, adapter, context);
        },
        /**
     * Handler for USDC approval operations on Solana.
     *
     * Returns a no-op chain request since Solana's token program doesn't
     * require explicit approval transactions like EVM chains do. On Solana,
     * token transfers are executed directly without prior allowance setup.
     */ 'usdc.approve': async ()=>{
            return createNoopChainRequest();
        },
        /**
     * Handler for USDC increase allowance operations on Solana.
     *
     * Returns a no-op chain request since Solana's token program doesn't
     * require explicit approval transactions like EVM chains do. On Solana,
     * token transfers are executed directly without prior allowance setup.
     */ 'usdc.increaseAllowance': async ()=>{
            return createNoopChainRequest();
        },
        /**
     * Handler for USDT transfer operations on Solana.
     *
     * Transfers USDT tokens from the sender's wallet to a recipient address.
     * Automatically creates the recipient's associated token account if needed.
     */ 'usdt.transfer': async (params, context)=>{
            return await transfer(params, adapter, context);
        },
        /**
     * Handler for native SOL transfer operations on Solana.
     *
     * Transfers native SOL tokens from the sender's wallet to a recipient address.
     */ 'native.transfer': async (params, context)=>{
            return await transfer$3(params, adapter, context);
        },
        /**
     * Handler for CCTP v2 deposit for burn operations on Solana.
     *
     * Burns USDC tokens on the source Solana chain to initiate a cross-chain
     * transfer. This is the first step in the CCTP bridge process.
     */ 'cctp.v2.depositForBurn': async (params, context)=>{
            return depositForBurn(params, adapter, context);
        },
        /**
     * Handler for CCTP v2 deposit for burn with hook operations on Solana.
     *
     * Burns USDC tokens with hook data that signals to Circle's Orbit relayer
     * that forwarding is requested. The relayer will automatically fetch the
     * attestation and submit the destination mint transaction.
     */ 'cctp.v2.depositForBurnWithHook': async (params, context)=>{
            return depositForBurnWithHook(params, adapter, context);
        },
        /**
     * Handler for CCTP v2 receive message operations on Solana.
     *
     * Mints USDC tokens on the destination Solana chain using a valid
     * attestation from Circle. This completes the cross-chain transfer.
     */ 'cctp.v2.receiveMessage': async (params, context)=>{
            return mint(params, adapter, context);
        },
        /**
     * Handler for CCTP v2 deposit for burn operations on Solana via bridge kit.
     *
     * BridgeKit internally handles burning USDC tokens on the source Solana chain
     * to initiate a cross-chain transfer and also handles the fee collection.
     */ 'cctp.v2.customBurn': async (params, context)=>{
            return customBurn(params, adapter, context);
        },
        /**
     * Handler for swap operations on Solana.
     *
     * Executes token swaps using pre-built transactions from the stablecoin-service.
     * The service handles DEX aggregator routing (Jupiter, etc.), fee collection,
     * and slippage protection.
     */ 'swap.execute': async (params, context)=>{
            return executeSwap(params, adapter, context);
        },
        /**
     * Handler for CCTP v2 custom burn with hook operations on Solana.
     *
     * Burns USDC tokens via bridge kit with hook data that signals to Circle's
     * Orbit relayer that forwarding is requested. The relayer will automatically
     * fetch the attestation and submit the destination mint transaction.
     */ 'cctp.v2.customBurnWithHook': async (params, context)=>{
            return customBurnWithHook(params, adapter, context);
        },
        /**
     * Handler for native token balance operations on Solana.
     *
     * Gets the native SOL balance for the given address.
     */ 'native.balanceOf': async (params, context)=>{
            return balanceOf$2(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet deposit on Solana.
     *
     * Deposits tokens into the Gateway Wallet; balance is credited to the signer.
     */ 'gateway.v1.deposit': async (params, context)=>{
            return deposit(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet depositFor on Solana.
     *
     * Deposits tokens on behalf of another address; balance is credited to the
     * specified depositor.
     */ 'gateway.v1.depositFor': async (params, context)=>{
            return depositFor(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet addDelegate on Solana.
     *
     * Prepares the add_delegate instruction on the Gateway Wallet program.
     */ 'gateway.v1.addDelegate': async (params, context)=>{
            return addDelegate(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet removeDelegate on Solana.
     *
     * Prepares the remove_delegate instruction on the Gateway Wallet program.
     */ 'gateway.v1.removeDelegate': async (params, context)=>{
            return removeDelegate(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet isDelegate on Solana (read-only).
     *
     * Checks the gateway_delegate PDA status to determine delegate authorization.
     */ 'gateway.v1.isDelegate': async (params, context)=>{
            return isDelegate(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet initiateWithdrawal on Solana.
     *
     * Starts a delayed fund removal from the caller's Gateway deposit account.
     */ 'gateway.v1.initiateWithdrawal': async (params, context)=>{
            return initiateWithdrawal(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet withdraw on Solana.
     *
     * Completes a previously initiated fund removal after the withdrawal delay.
     */ 'gateway.v1.withdraw': async (params, context)=>{
            return withdraw(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet withdrawingBalance on Solana (read-only).
     *
     * Reads the pending withdrawal balance from the GatewayDeposit PDA.
     */ 'gateway.v1.withdrawingBalance': async (params, context)=>{
            return withdrawingBalance(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet withdrawalBlock on Solana (read-only).
     *
     * Reads the withdrawal block from the GatewayDeposit PDA.
     */ 'gateway.v1.withdrawalBlock': async (params, context)=>{
            return withdrawalBlock(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet burn on Solana.
     *
     * Burns USDC from the Gateway Wallet custody account.
     */ 'gateway.v1.gatewayBurn': async (params, context)=>{
            return gatewayBurn(params, adapter, context);
        },
        /**
     * Handler for Gateway Wallet mint on Solana.
     *
     * Mints USDC to the recipient via the Gateway Minter.
     */ 'gateway.v1.gatewayMint': async (params, context)=>{
            return gatewayMint(params, adapter, context);
        },
        /**
     * Handler for signing burn intents on Solana.
     *
     * Signs typed data for CCTP burn intents using the adapter's
     * signTypedData method.
     */ 'gateway.v1.signBurnIntents': async (params, context)=>{
            return await Promise.resolve(signBurnIntent(params, adapter, context));
        }
    };
};

/**
 * Abstract base class for Solana-compatible blockchain adapters.
 *
 * This class extends the generic `Adapter` to provide Solana-specific functionality
 * for interacting with Solana blockchain networks. It automatically registers
 * Solana-specific action handlers during construction and sets the chain type to 'solana'.
 *
 * Implementations must provide transport-specific methods for connection management,
 * signing, and transaction execution while inheriting shared Solana functionality
 * for address formatting, fee calculation, and chain detection.
 *
 * @typeParam TConnection - The connection type used by the transport layer
 * @typeParam TSigner - The signer type used by the transport layer
 *
 * @remarks
 * The generic parameters provide type safety while maintaining maximum flexibility
 * for different Solana transport implementations like \@solana/web3.js and \@solana/kit.
 * Individual adapters specify their concrete types when extending this base class.
 */ class SolanaBaseAdapter extends Adapter {
    /**
   * The type of chain this adapter is for.
   */ chainType = 'solana';
    /**
   * The constructor for the Solana adapter base.
   *
   * @remarks
   * This constructor registers the action handlers for the Solana adapter.
   */ constructor(){
        super();
        this.actionRegistry.registerHandlers(getHandlers(this));
    }
    /**
   * Get the decimal places for an SPL token on Solana.
   *
   * This method fetches the mint account data and reads the `decimals` field.
   * The connection is obtained via `getConnection()` to support different
   * Solana transport implementations.
   *
   * @param mintAddress - The SPL token mint address
   * @param chain - The Solana chain definition where the token is deployed
   * @returns Promise resolving to the number of decimal places
   * @throws Error when the mint account doesn't exist or decimals cannot be fetched
   *
   * @example
   * ```typescript
   * import { SolanaAdapter } from '@circle-fin/adapter-solana'
   * import { Solana } from '@core/chains'
   *
   * const adapter = new SolanaAdapter({ connection, signer })
   *
   * // Fetch decimals for USDC on Solana
   * const decimals = await adapter.getTokenDecimals(
   *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
   *   Solana
   * )
   * console.log(decimals) // 6
   * ```
   */ async getTokenDecimals(mintAddress, chain) {
        try {
            // Dynamically import Solana dependencies to avoid loading for EVM-only users
            const { PublicKey } = await import('@solana/web3.js');
            const connection = this.getConnection(chain);
            const mintPubkey = new PublicKey(mintAddress);
            const tokenProgramId = await detectTokenProgram(connection, mintPubkey);
            const mintInfo = await getMint(connection, mintPubkey, undefined, tokenProgramId);
            return mintInfo.decimals;
        } catch (error) {
            // If it's already a KitError from our validation, re-throw as-is
            if (error instanceof KitError) {
                throw error;
            }
            throw createValidationFailedError('mintAddress', mintAddress, `Failed to fetch decimals for SPL token on ${chain.name}: ${getErrorMessage(error)}`);
        }
    }
}

/**
 * Resolves a Solana chain identifier to a ChainDefinition.
 * Uses the core resolveChainIdentifier and validates it's specifically a Solana chain.
 *
 * @param identifier - The chain identifier to resolve
 * @returns The resolved ChainDefinition
 * @throws Error if the identifier cannot be resolved or is not a Solana chain
 */ function resolveSolanaChainIdentifier(identifier) {
    // Use the core resolver to handle all the conversion logic
    const chainDefinition = resolveChainIdentifier(identifier);
    // Validate that it's specifically a Solana chain
    if (chainDefinition.type !== 'solana') {
        throw new Error(`Expected a Solana chain, but got ${chainDefinition.type} chain (${chainDefinition.name}). ` + `Please use a valid Solana chain identifier: 'Solana', 'Solana_Devnet', or corresponding Blockchain enum/ChainDefinition.`);
    }
    return chainDefinition;
}

/**
 * Validates that the actual network (determined by genesis hash) matches
 * the expected network (from chain configuration).
 *
 * This prevents common issues where a wallet provider is connected to a different
 * network than what the code is configured for (e.g., wallet on mainnet but code
 * trying to use devnet).
 *
 * @param connection - Generic connection interface supporting getGenesisHash()
 * @param expectedChain - The expected chain definition
 * @throws Error if there's a network mismatch or if the network cannot be determined
 *
 * @remarks
 * This function now supports both @solana/web3.js and @solana/kit connections
 * through the generic interface, making the core package transport-agnostic.
 *
 * @example
 * ```typescript
 * import { validateNetworkConsistency } from './validateNetworkConsistency'
 * import { Solana } from '@core/chains'
 * import { Connection } from '@solana/web3.js'
 *
 * // Works with @solana/web3.js
 * const web3Connection = new Connection('https://api.mainnet-beta.solana.com')
 * await validateNetworkConsistency(web3Connection, Solana)
 *
 * // Also works with @solana/kit RPC
 * const kitRpc = createRpc({ ... })
 * await validateNetworkConsistency(kitRpc, Solana)
 * ```
 */ async function validateNetworkConsistency(connection, expectedChain) {
    try {
        const actualGenesisHash = await connection.getGenesisHash();
        // Determine what network the connection is actually on
        let actualNetworkName;
        if (actualGenesisHash === SOLANA_MAINNET_GENESIS_HASH) {
            actualNetworkName = 'Solana Mainnet';
        } else if (actualGenesisHash === SOLANA_DEVNET_GENESIS_HASH) {
            actualNetworkName = 'Solana Devnet';
        } else {
            throw new Error(`Connected to unsupported Solana network with genesis hash: ${actualGenesisHash}. ` + 'Only Solana Mainnet and Devnet are supported.');
        }
        // Determine what network is expected based on chain configuration
        const expectedNetworkName = expectedChain.isTestnet ? 'Solana Devnet' : 'Solana Mainnet';
        // Check if they match
        if (actualNetworkName !== expectedNetworkName) {
            throw new Error(`Network mismatch detected! ` + `Your wallet/connection is on ${actualNetworkName}, ` + `but the code is configured for ${expectedNetworkName}. ` + `Please either: ` + `1) Switch your wallet to ${expectedNetworkName}, or ` + `2) Update your code configuration to use the correct chain identifier ` + `(${expectedChain.isTestnet ? "'Solana'" : "'Solana_Devnet'"}).`);
        }
    } catch (error) {
        // Re-throw our validation errors as-is
        if (error instanceof Error && error.message.includes('Network mismatch')) {
            throw error;
        }
        // Wrap other errors (connection issues, etc.) with context
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(`Failed to validate network consistency: ${errorMessage}. ` + 'Please ensure your connection is working and you are connected to a supported Solana network.');
    }
}

/**
 * Schema for validating private keys in multiple supported formats.
 *
 * Supports Base58, Base64, and JSON array formats for maximum compatibility
 * with different private key sources and developer preferences.
 *
 * @example
 * ```typescript
 * import { privateKeySchema } from '@core/adapter-solana'
 *
 * // Valid formats:
 * privateKeySchema.parse('5KkQMKuKpKU...') // Base58
 * privateKeySchema.parse('[1,2,3,...]')     // JSON array string
 * privateKeySchema.parse('base64string==')   // Base64
 * ```
 */ const privateKeySchema = zod.z.string({
    required_error: 'Private key is required. Please provide a valid private key (Base58, Base64, or JSON array format).',
    invalid_type_error: 'Private key must be a string. Please provide a valid private key (Base58, Base64, or JSON array format).'
}).min(10, {
    message: 'Private key is too short. Please provide a valid private key.'
}).max(1000, {
    message: 'Private key is too long. Please provide a valid private key.'
});
/**
 * Schema for validating Solana chain identifiers.
 *
 * Accepts multiple formats for developer convenience:
 * - String literals ('Solana', 'Solana_Devnet')
 * - Blockchain enum values (Blockchain.Solana, Blockchain.Solana_Devnet)
 * - ChainDefinition objects with type 'solana'
 *
 * @example
 * ```typescript
 * import { solanaChainIdentifierSchema } from '@core/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 *
 * // Valid formats:
 * solanaChainIdentifierSchema.parse('Solana')              // String literal
 * solanaChainIdentifierSchema.parse(Blockchain.Solana)     // Enum value
 * solanaChainIdentifierSchema.parse(Solana)                // ChainDefinition
 * ```
 */ const solanaChainIdentifierSchema = zod.z.union([
    zod.z.literal('Solana'),
    zod.z.literal('Solana_Devnet'),
    zod.z.nativeEnum(exports.Blockchain).refine((val)=>val === exports.Blockchain.Solana || val === exports.Blockchain.Solana_Devnet, 'Must be a Solana blockchain enum value (Blockchain.Solana or Blockchain.Solana_Devnet)'),
    zod.z.object({
        type: zod.z.literal('solana'),
        chain: zod.z.nativeEnum(exports.Blockchain),
        name: zod.z.string()
    }).passthrough()
]);
/**
 * Schema for validating Solana wallet provider objects.
 *
 * Ensures the provider has all required methods for wallet operations
 * including connection, signing, and optional message signing capabilities.
 *
 * @example
 * ```typescript
 * import { solanaWalletProviderSchema } from '@core/adapter-solana'
 *
 * // Validates wallet providers like Phantom, Solflare, etc.
 * const provider = window.solana
 * solanaWalletProviderSchema.parse(provider)
 * ```
 */ const solanaWalletProviderSchema = zod.z.object({
    connect: zod.z.function().returns(zod.z.promise(zod.z.object({
        publicKey: zod.z.object({
            toString: zod.z.function().returns(zod.z.string())
        })
    }))),
    disconnect: zod.z.function().returns(zod.z.promise(zod.z.void())),
    isConnected: zod.z.boolean(),
    publicKey: zod.z.union([
        zod.z.object({
            toString: zod.z.function().returns(zod.z.string())
        }),
        zod.z.null()
    ]),
    signTransaction: zod.z.function().returns(zod.z.promise(zod.z.unknown())),
    signAllTransactions: zod.z.function().returns(zod.z.promise(zod.z.array(zod.z.unknown()))).optional(),
    signMessage: zod.z.function().returns(zod.z.promise(zod.z.object({
        signature: zod.z.instanceof(Uint8Array)
    }))).optional()
}).passthrough() // Allow additional provider-specific properties
;
/**
 * Schema for validating RPC URL strings.
 *
 * Ensures the URL is properly formatted and can be used for
 * Solana RPC connections.
 *
 * @example
 * ```typescript
 * import { rpcUrlSchema } from '@core/adapter-solana'
 *
 * // Valid URLs:
 * rpcUrlSchema.parse('https://api.mainnet-beta.solana.com')
 * rpcUrlSchema.parse('https://api.devnet.solana.com')
 * rpcUrlSchema.parse('https://rpc.helius.xyz/?api-key=...')
 * ```
 */ zod.z.string({
    invalid_type_error: 'RPC URL must be a string'
}).url({
    message: 'RPC URL must be a valid URL'
});
/**
 * Schema for validating connection configuration options.
 *
 * Provides flexible validation for connection options that work
 * with both @solana/web3.js and @solana/kit adapters.
 *
 * @example
 * ```typescript
 * import { connectionOptionsSchema } from '@core/adapter-solana'
 *
 * const options = {
 *   commitment: 'confirmed',
 *   timeout: 30000,
 *   maxRetries: 3
 * }
 * connectionOptionsSchema.parse(options)
 * ```
 */ zod.z.record(zod.z.unknown()).optional();
/**
 * Base schema for validating adapter creation parameters.
 *
 * Contains common fields used by all Solana adapter factory methods.
 * Extended by transport-specific schemas in individual adapter packages.
 */ zod.z.object({
    privateKey: privateKeySchema.optional(),
    chain: solanaChainIdentifierSchema,
    provider: solanaWalletProviderSchema.optional()
});
/**
 * Schema for validating private key adapter creation parameters.
 *
 * Used by factory methods that create adapters from private keys
 * across both @solana/web3.js and @solana/kit implementations.
 *
 * @example
 * ```typescript
 * import { privateKeyAdapterParamsSchema } from '@core/adapter-solana'
 *
 * const params = {
 *   privateKey: 'your-base58-key',
 *   chain: 'Solana'
 * }
 * privateKeyAdapterParamsSchema.parse(params)
 * ```
 */ const privateKeyAdapterParamsSchema = zod.z.object({
    privateKey: privateKeySchema,
    chain: solanaChainIdentifierSchema
});
/**
 * Schema for validating provider-based adapter creation parameters.
 *
 * Used by factory methods that create adapters from wallet providers
 * across both @solana/web3.js and @solana/kit implementations.
 *
 * @example
 * ```typescript
 * import { providerAdapterParamsSchema } from '@core/adapter-solana'
 *
 * const params = {
 *   provider: window.solana,
 *   chain: 'Solana'
 * }
 * providerAdapterParamsSchema.parse(params)
 * ```
 */ const providerAdapterParamsSchema = zod.z.object({
    provider: solanaWalletProviderSchema,
    chain: solanaChainIdentifierSchema
});

/**
 * Validates parameters for creating a Solana adapter from a private key.
 *
 * This shared validation function can be used by all Solana adapter implementations
 * to ensure consistent parameter validation across transport libraries.
 *
 * @param params - The parameters to validate
 * @param context - Additional context for error reporting (e.g., 'SolanaAdapter', 'SolanaKitAdapter')
 * @throws Error if validation fails with detailed error messages
 *
 * @example
 * ```typescript
 * import { validatePrivateKeyAdapterParams } from '@core/adapter-solana'
 *
 * try {
 *   validatePrivateKeyAdapterParams({
 *     privateKey: 'your-base58-private-key',
 *     chain: 'Solana'
 *   }, 'SolanaAdapter')
 * } catch (error) {
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */ const validatePrivateKeyAdapterParams = (params, context = 'Solana adapter')=>{
    validateOrThrow(params, privateKeyAdapterParamsSchema, `Invalid parameters for ${context} creation from private key`);
};
/**
 * Validates parameters for creating a Solana adapter from a wallet provider.
 *
 * This shared validation function can be used by all Solana adapter implementations
 * to ensure consistent parameter validation across transport libraries.
 *
 * @param params - The parameters to validate
 * @param context - Additional context for error reporting (e.g., 'SolanaAdapter', 'SolanaKitAdapter')
 * @throws Error if validation fails with detailed error messages
 *
 * @example
 * ```typescript
 * import { validateProviderAdapterParams } from '@core/adapter-solana'
 *
 * try {
 *   validateProviderAdapterParams({
 *     provider: window.solana,
 *     chain: 'Solana'
 *   }, 'SolanaKitAdapter')
 * } catch (error) {
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */ const validateProviderAdapterParams = (params, context = 'Solana adapter')=>{
    validateOrThrow(params, providerAdapterParamsSchema, `Invalid parameters for ${context} creation from provider`);
};

/**
 * Validates if the provided value is a valid Solana Signer.
 *
 * @param signer - The value to validate as a Signer
 * @throws Error if the signer is not a valid Solana Signer
 */ function validateSigner(signer) {
    if (!signer) {
        throw new Error('Signer is required');
    }
    if (typeof signer !== 'object') {
        throw new Error(`Signer must be an object but received ${typeof signer}`);
    }
    // Check for essential Signer property
    if (typeof signer['publicKey'] !== 'object' || typeof signer.publicKey.toBase58 !== 'function') {
        throw new Error('Invalid Signer: missing required publicKey.toBase58 method. ' + 'Ensure you are using a Solana Signer instance from @solana/web3.js');
    }
}

/**
 * Gets the cached Signer or initializes it from options if not already cached.
 *
 * @param options - The SolanaAdapterOptions containing the signer (or a function to get it)
 * @param ctx - The operation context to pass to context-aware signer functions
 * @param cachedSigner - The current cached signer instance, if any
 * @returns A Promise resolving to the Solana Signer instance
 */ async function getSigner(options, ctx, cachedSigner) {
    if (typeof options.signer === 'function') {
        // Call with context - functions that don't need it can ignore the parameter
        const signer = await options.signer(ctx);
        validateSigner(signer);
        return signer;
    }
    validateSigner(options.signer);
    return options.signer;
}

/**
 * Creates a Solana Connection using default configuration.
 *
 * This utility handles the common connection creation logic shared between factory methods.
 * It automatically determines the appropriate RPC endpoint based on the chain definition
 * and applies consistent connection configuration.
 *
 * @param resolvedChain - The resolved chain definition
 * @returns A configured Solana Connection instance
 *
 * @example
 * ```typescript
 * import { createConnection } from './createConnection'
 * import { Solana } from '@core/chains'
 * import { resolveSolanaChainIdentifier } from '../../validation'
 *
 * // Using default configuration
 * const resolvedChain = resolveSolanaChainIdentifier('Solana')
 * const connection = createConnection(resolvedChain)
 * ```
 */ function createConnection(resolvedChain) {
    const rpcUrl = getDefaultRpcEndpoint(resolvedChain);
    const connectionConfig = getStandardConnectionConfig();
    return new web3_js.Connection(rpcUrl, connectionConfig);
}

/**
 * Validates if the provided value is a valid Solana Connection.
 *
 * @param connection - The value to validate as a Connection
 * @throws Error if the connection is not a valid Solana Connection
 */ function validateConnection(connection) {
    if (!connection) {
        throw new Error('Connection is required');
    }
    if (typeof connection !== 'object') {
        throw new Error(`Connection must be an object but received ${typeof connection}`);
    }
    // Check for essential Connection methods
    const requiredMethods = [
        'getAccountInfo',
        'getRecentBlockhash',
        'sendTransaction'
    ];
    for (const method of requiredMethods){
        if (typeof connection[method] !== 'function') {
            throw new Error(`Invalid Connection: missing required method "${method}". ` + 'Ensure you are using a Solana Connection instance from @solana/web3.js');
        }
    }
    // Check for required properties
    const requiredProperties = [
        'commitment',
        'rpcEndpoint'
    ];
    for (const prop of requiredProperties){
        if (!(prop in connection)) {
            throw new Error(`Invalid Connection: missing required property "${prop}"`);
        }
    }
}

/**
 * Resolve a Solana {@link Connection} for the adapter.
 *
 * Resolve order (highest precedence first):
 * 1. Reuse `cachedConnection` when provided.
 * 2. Use `options.connection` (validated).
 * 3. Use `options.getConnection({ chain })` when provided alongside `chainDefinition`.
 * 4. Lazily create a default connection from `chainDefinition`.
 *
 * @remarks
 * Provide either a concrete {@link Connection} via `options.connection`, a factory via
 * `options.getConnection`, or a `chainDefinition` to enable lazy initialization. If none
 * are available, the function throws with guidance on how to supply a connection.
 * All returned or constructed connections are validated by {@link validateConnection}.
 *
 * @param options - The Solana adapter options. May include an existing `connection` or a
 *   `getConnection` factory used to construct one.
 * @param cachedConnection - The cached {@link Connection} to reuse when present.
 * @param chainDefinition - The chain hint used by `getConnection` and lazy initialization.
 *   Required when relying on `options.getConnection` or default creation.
 * @returns The validated Solana {@link Connection} instance.
 * @throws Error When no connection can be resolved (no cached connection, no
 *   `options.connection`, no `options.getConnection`, and no `chainDefinition`).
 * @throws Error When the provided or created connection fails validation.
 *
 * @example Using an explicit connection
 * ```typescript
 * import { Connection } from '@solana/web3.js'
 * import type { SolanaAdapterOptions } from '@circle-fin/adapter-solana'
 * import { getConnection } from '@circle-fin/adapter-solana'
 *
 * const options: SolanaAdapterOptions = {
 *   connection: new Connection('https://api.mainnet-beta.solana.com'),
 * }
 * const conn = getConnection(options)
 * console.log(conn.rpcEndpoint)
 * ```
 *
 * @example Using a factory and chain definition
 * ```typescript
 * import { Connection } from '@solana/web3.js'
 * import type { ChainDefinition } from '@core/chains'
 * import { getConnection } from '@circle-fin/adapter-solana'
 *
 * const chain: ChainDefinition = {
 *   type: 'solana',
 *   name: 'Solana',
 *   rpcs: ['https://api.mainnet-beta.solana.com'],
 * }
 *
 * const conn = getConnection(
 *   {
 *     getConnection: ({ chain }) => new Connection(chain.rpcs[0]!),
 *   },
 *   undefined,
 *   chain,
 * )
 * console.log(conn.rpcEndpoint)
 * ```
 *
 * @see validateConnection
 * @see createDefaultConnection
 */ function getConnection(options, cachedConnection, chainDefinition) {
    // Prefer explicitly provided connection
    if (options.connection) {
        validateConnection(options.connection);
        return options.connection;
    }
    // Fallback to lazy factory if provided
    if (options.getConnection && chainDefinition) {
        const conn = options.getConnection({
            chain: chainDefinition
        });
        validateConnection(conn);
        return conn;
    }
    // Final fallback: require a chain hint and create a default connection
    if (chainDefinition) {
        const conn = createConnection(chainDefinition);
        validateConnection(conn);
        return conn;
    }
    throw new Error('No Solana connection available. Provide `options.connection` or `options.getConnection`, or supply a chain to lazily initialize.');
}

/**
 * Polls for transaction confirmation status until required confirmations are met.
 *
 * @param connection - The Solana connection object.
 * @param txHash - The transaction hash to poll for.
 * @param confirmations - The number of confirmations required.
 * @param timeout - The maximum time to wait in milliseconds.
 * @throws Error if timeout is exceeded.
 */ const pollForConfirmation = async (connection, txHash, confirmations, timeout)=>{
    const start = Date.now();
    while(true){
        if (Date.now() - start > timeout) {
            throw new Error(`Timeout after ${timeout.toString()}ms waiting for transaction ${txHash}`);
        }
        const resp = await connection.getSignatureStatuses([
            txHash
        ], {
            searchTransactionHistory: true
        });
        const status = resp.value[0];
        if (status) {
            // status.confirmations === null means 'finalized' internally
            if (status.confirmations === null || status.confirmations >= confirmations) {
                break;
            }
        }
        // Wait 500ms between polls
        await new Promise((r)=>setTimeout(r, 500));
    }
};
/**
 * Fetches the confirmed transaction details from the blockchain.
 *
 * @param connection - The Solana connection object.
 * @param txHash - The transaction hash to fetch.
 * @param maxSupportedTransactionVersion - The maximum transaction version to support.
 * @param timeout - The maximum time to wait in milliseconds.
 * @returns The confirmed transaction details.
 * @throws Error if the transaction is not found within the timeout.
 */ const fetchConfirmedTransaction = async (connection, txHash, maxSupportedTransactionVersion, timeout)=>{
    let confirmedTx = null;
    const fetchStart = Date.now();
    while(Date.now() - fetchStart < timeout){
        confirmedTx = await connection.getTransaction(txHash, {
            maxSupportedTransactionVersion,
            commitment: 'confirmed'
        });
        if (confirmedTx) break;
        await new Promise((r)=>setTimeout(r, 500));
    }
    if (!confirmedTx) {
        throw new Error(`Transaction ${txHash} not found after being confirmed`);
    }
    return confirmedTx;
};
/**
 * Maps the confirmed transaction data to the response format.
 *
 * @param txHash - The transaction hash.
 * @param confirmedTx - The confirmed transaction details.
 * @returns The mapped transaction response.
 */ const mapTransactionResponse = (txHash, confirmedTx)=>{
    const meta = confirmedTx.meta;
    return {
        txHash,
        status: meta?.err ? 'reverted' : 'success',
        blockNumber: BigInt(confirmedTx.slot),
        blockHash: confirmedTx.transaction.message.recentBlockhash,
        transactionIndex: 0,
        gasUsed: meta?.computeUnitsConsumed ? BigInt(meta.computeUnitsConsumed) : 0n,
        cumulativeGasUsed: 0n,
        effectiveGasPrice: meta?.fee ? BigInt(meta.fee) : 0n
    };
};
/**
 * Waits for a transaction to be confirmed on the Solana blockchain.
 *
 * @param connection - The Solana connection object.
 * @param txHash - The hash of the transaction to wait for.
 * @param config - The configuration for the wait operation.
 * @returns The transaction status and details.
 *
 * @example
 * ```typescript
 * import { Connection } from '@solana/web3.js'
 * import { waitForTransaction } from './waitForTransaction'
 *
 * const connection = new Connection('https://api.mainnet-beta.solana.com')
 * const response = await waitForTransaction(connection, 'tx-hash', {
 *   timeout: 30000,
 *   confirmations: 1,
 * })
 * console.log(response.status) // 'success' or 'reverted'
 * ```
 */ const waitForTransaction = async (connection, txHash, config)=>{
    assertSolanaTransactionHash(txHash);
    const { timeout = 30_000, confirmations = 1, maxSupportedTransactionVersion = 0 } = config ?? {};
    await pollForConfirmation(connection, txHash, confirmations, timeout);
    const confirmedTx = await fetchConfirmedTransaction(connection, txHash, maxSupportedTransactionVersion, timeout);
    return mapTransactionResponse(txHash, confirmedTx);
};

/**
 * Schema for validating Connection instances.
 * This validates that the passed object is a valid Solana Connection.
 */ const connectionSchema = zod.z.custom((val)=>val != null && typeof val === 'object' && 'getLatestBlockhash' in val, 'Expected valid Solana Connection object');
/**
 * Zod schema for validating CreateAdapterFromPrivateKeyParams for web3.js.
 * This extends the shared schema with web3.js-specific Connection support.
 *
 * @example
 * ```typescript
 * import { createAdapterFromPrivateKeyParamsSchema } from '@circle-fin/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 * import { Connection } from '@solana/web3.js'
 *
 * const params = {
 *   privateKey: 'your-base58-private-key',
 *   chain: Solana, // or Blockchain.Solana or 'Solana'
 *   connection: new Connection('https://api.mainnet-beta.solana.com') // optional
 * }
 *
 * const result = createAdapterFromPrivateKeyParamsSchema.safeParse(params)
 * if (result.success) {
 *   console.log('Parameters are valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */ const createAdapterFromPrivateKeyParamsSchema = privateKeyAdapterParamsSchema.extend({
    connection: connectionSchema.optional()
});
/**
 * Zod schema for validating CreateAdapterFromProviderParams for web3.js.
 * This extends the shared schema with web3.js-specific Connection support.
 *
 * @example
 * ```typescript
 * import { createAdapterFromProviderParamsSchema } from '@circle-fin/adapter-solana'
 * import { Blockchain, Solana } from '@core/chains'
 * import { Connection } from '@solana/web3.js'
 *
 * const params = {
 *   provider: window.solana,
 *   chain: Solana, // or Blockchain.Solana or 'Solana'
 *   connection: new Connection('https://api.mainnet-beta.solana.com') // optional
 * }
 *
 * const result = createAdapterFromProviderParamsSchema.safeParse(params)
 * if (result.success) {
 *   console.log('Parameters are valid')
 * } else {
 *   console.error('Validation failed:', result.error)
 * }
 * ```
 */ const createAdapterFromProviderParamsSchema = providerAdapterParamsSchema.extend({
    connection: connectionSchema.optional()
});
/**
 * Schema for validating Solana adapter capabilities (OperationContext-based).
 *
 * @remarks
 * - Enforces explicit address context: 'user-controlled' or 'developer-controlled'.
 * - Requires supportedChains to include Solana chain definitions only.
 */ const AdapterCapabilitiesSchema = zod.z.object({
    /**
     * Defines who controls the address used in operations.
     * Must be either 'user-controlled' or 'developer-controlled'.
     */ addressContext: zod.z.enum([
        'user-controlled',
        'developer-controlled'
    ], {
        errorMap: ()=>({
                message: "addressContext must be either 'user-controlled' or 'developer-controlled'. " + "Use 'user-controlled' for browser wallets, private keys, or hardware wallets. " + "Use 'developer-controlled' for enterprise custody solutions or multi-entity adapters."
            })
    }),
    /**
     * Array of supported chains. Must contain Solana chains only.
     * All chains must be Solana type for this adapter.
     */ supportedChains: zod.z.array(zod.z.object({
        type: zod.z.literal('solana', {
            errorMap: ()=>({
                    message: 'Solana adapter only supports Solana chains'
                })
        }),
        name: zod.z.string(),
        // Chain identifier (enum or string); kept flexible for core ChainDefinition compatibility
        chain: zod.z.unknown(),
        // Solana uses non-numeric identifiers (e.g., 'mainnet'); allow either form and optionality
        chainId: zod.z.union([
            zod.z.string(),
            zod.z.number()
        ]).optional()
    }), {
        errorMap: ()=>({
                message: 'supportedChains must be an array of ChainDefinition objects'
            })
    })
}).strict();
/**
 * Zod schema for validating SolanaAdapterOptions used by the Solana adapter constructor.
 *
 * @remarks
 * - `connection` must be a valid `@solana/web3.js` Connection.
 * - `signer` can be either a Signer-like object (has `publicKey`) or a function returning a Promise of a signer.
 */ const solanaAdapterOptionsSchema = zod.z.object({
    connection: connectionSchema.optional(),
    // Optional lazy connection factory; typed as unknown here and validated at use-site
    getConnection: zod.z.function().args(zod.z.object({
        chain: zod.z.unknown()
    })).returns(zod.z.unknown()).optional(),
    signer: zod.z.union([
        // Lazy initialization function returning a signer (Promise)
        zod.z.function().args().returns(zod.z.promise(zod.z.unknown())),
        // Direct Signer-like object (must expose publicKey)
        zod.z.object({
            publicKey: zod.z.unknown()
        }).passthrough()
    ])
}).refine((v)=>v.connection !== undefined || v.getConnection !== undefined, {
    message: 'Either `connection` or `getConnection` must be provided to initialize a Solana connection.'
});

/**
 * Validates the parameters for creating a SolanaAdapter from a private key.
 *
 * This function performs runtime validation of the input parameters using Zod schemas.
 * It extends the shared validation with web3.js-specific Connection validation.
 *
 * @param params - The parameters to validate
 * @throws Error if validation fails with detailed error messages
 *
 * @example
 * ```typescript
 * import { createSolanaAdapterFromPrivateKey } from '@circle-fin/adapter-solana'
 *
 * // This validation function is called internally by createSolanaAdapterFromPrivateKey
 * try {
 *   const adapter = createSolanaAdapterFromPrivateKey({
 *     privateKey: 'your-base58-private-key',
 *     chain: 'Solana'
 *   })
 *   console.log('Adapter created successfully')
 * } catch (error) {
 *   // Validation errors will be thrown here
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */ const validateCreateAdapterFromPrivateKeyParams = (params)=>{
    validatePrivateKeyAdapterParams(params, 'SolanaAdapter (web3.js)');
    // Then validate web3.js-specific parts (connection)
    validateOrThrow(params, createAdapterFromPrivateKeyParamsSchema, 'Invalid parameters for SolanaAdapter creation from private key');
};
/**
 * Validates the parameters for creating a SolanaAdapter from a wallet provider.
 *
 * This function performs runtime validation of the input parameters using Zod schemas.
 * It extends the shared validation with web3.js-specific Connection validation.
 *
 * @param params - The parameters to validate
 * @throws Error if validation fails with detailed error messages
 *
 * @example
 * ```typescript
 * import { createSolanaAdapterFromProvider } from '@circle-fin/adapter-solana'
 *
 * // This validation function is called internally by createSolanaAdapterFromProvider
 * try {
 *   const adapter = await createSolanaAdapterFromProvider({
 *     provider: window.solana,
 *     chain: 'Solana'
 *   })
 *   console.log('Adapter created successfully')
 * } catch (error) {
 *   // Validation errors will be thrown here
 *   console.error('Validation failed:', error.message)
 * }
 * ```
 */ const validateCreateAdapterFromProviderParams = (params)=>{
    validateProviderAdapterParams(params, 'SolanaAdapter (web3.js)');
    // Then validate web3.js-specific parts (connection)
    validateOrThrow(params, createAdapterFromProviderParamsSchema, 'Invalid parameters for SolanaAdapter creation from provider');
};
const validateAdapterCapabilities = (params)=>{
    validateOrThrow(params, AdapterCapabilitiesSchema, 'Invalid parameters for SolanaAdapter capabilities');
};
/**
 * Validates SolanaAdapterOptions passed to the Solana adapter constructor.
 *
 * @param options - The SolanaAdapterOptions to validate
 * @throws Error if validation fails
 */ function validateSolanaAdapterOptions(options) {
    validateOrThrow(options, solanaAdapterOptionsSchema, 'SolanaAdapterOptions');
}

/**
 * Retrieves wallet information including address, balance, and network.
 *
 * @param connection - The Solana {@link Connection} instance to query balance.
 * @param signer - The {@link Signer} whose wallet information to retrieve.
 * @returns A Promise resolving to {@link WalletInfo} containing wallet details.
 * @throws {@link KitError} with RPC_ENDPOINT_ERROR if the RPC request fails or returns invalid data.
 *
 * @remarks
 * This helper function consolidates wallet information retrieval for error
 * handling and diagnostics. It fetches the current SOL balance and determines
 * the network (devnet, testnet, mainnet-beta) from the connection.
 *
 * The function includes explicit RPC error handling to catch issues like:
 * - RPC endpoint being down or unreachable
 * - Rate limiting from the RPC provider
 * - Invalid or null responses
 *
 * The returned object is used primarily for constructing detailed error messages
 * that include wallet context and remediation instructions.
 *
 * @example
 * ```typescript
 * import { Connection, Keypair } from '@solana/web3.js';
 * import { getWalletInfo } from '@circle-fin/adapter-solana';
 *
 * const connection = new Connection('https://api.devnet.solana.com');
 * const signer = Keypair.generate();
 * const info = await getWalletInfo(connection, signer);
 * console.log(`Wallet ${info.walletAddress} has ${info.currentBalanceSol} SOL on ${info.network}`);
 * ```
 */ async function getWalletInfo(connection, signer) {
    const walletAddress = signer.publicKey.toBase58();
    // Fetch wallet balance with explicit error handling
    let currentBalanceLamports;
    try {
        const balance = await connection.getBalance(signer.publicKey);
        // Check for null/undefined response (safety check for malformed RPC responses)
        if (balance === null || balance === undefined) {
            throw new KitError({
                ...RpcError.INVALID_RESPONSE,
                recoverability: 'RETRYABLE',
                message: `RPC returned invalid balance response for wallet ${walletAddress}. The response was null or undefined.`,
                cause: {
                    trace: {
                        walletAddress,
                        response: balance
                    }
                }
            });
        }
        currentBalanceLamports = balance;
    } catch (error) {
        // If it's already a KitError, rethrow it
        if (error instanceof KitError) {
            throw error;
        }
        // Wrap RPC errors with clear context
        throw new KitError({
            ...RpcError.ENDPOINT_ERROR,
            recoverability: 'RETRYABLE',
            message: `Failed to fetch wallet balance from RPC endpoint for ${walletAddress}. The RPC may be unavailable, rate-limited, or experiencing issues.`,
            cause: {
                trace: {
                    walletAddress,
                    originalError: error instanceof Error ? error.message : String(error)
                }
            }
        });
    }
    const currentBalanceSol = lamportsToSol(currentBalanceLamports);
    // Determine network from connection (defaults to mainnet-beta on error)
    let network;
    try {
        network = await getNetworkFromConnection(connection);
    } catch  {
        // Unknown networks or RPC errors default to mainnet-beta
        // We don't fail here since network identification is not critical
        network = 'mainnet-beta';
    }
    return {
        walletAddress,
        currentBalanceLamports,
        currentBalanceSol,
        network
    };
}
/**
 * Calculates the SOL requirements for a transaction based on ATA creation needs.
 *
 * @param params - The {@link SolanaPreparedChainRequestParams} containing transaction instructions.
 * @returns {@link SolRequirements} object with total requirements and detailed breakdown.
 *
 * @remarks
 * This function analyzes transaction instructions to determine how many Associated Token
 * Accounts (ATAs) need to be created, then delegates to the shared core calculation
 * function to compute the total SOL required for:
 * - ATA rent-exempt balance (per ATA)
 * - Transaction fees (including compute units)
 *
 * The breakdown object provides individual cost components for detailed error messages
 * and helps users understand exactly what they're paying for.
 *
 * @example
 * ```typescript
 * import { TransactionInstruction } from '@solana/web3.js'
 * import { calculateRequiredSol } from '@circle-fin/adapter-solana'
 *
 * const params = {
 *   instructions: [
 *     // ... some instructions including ATA creation
 *   ]
 * }
 *
 * const requirements = calculateRequiredSol(params)
 * console.log(`Total required: ${requirements.totalRequiredLamports} lamports`)
 * console.log(`Creating ${requirements.breakdown.ataCount} ATAs`)
 * ```
 */ function calculateRequiredSol(params) {
    const { instructions } = params;
    // Count ATA creation instructions by checking program ID
    const ataCount = instructions?.filter((ix)=>ix.programId.equals(ASSOCIATED_TOKEN_PROGRAM_ID)).length;
    // Delegate to shared core calculation function
    return calculateRequiredSolForAtasWithBreakdown(ataCount ?? 0);
}
/**
 * Handles simulation errors with detailed context and actionable error messages.
 *
 * @param connection - The Solana Connection instance.
 * @param signer - The Signer responsible for the transaction.
 * @param params - The transaction parameters containing instructions.
 * @param logs - The simulation logs from the failed transaction.
 * @param errorObj - The error object from simulation result.
 * @throws Error with user-friendly message and remediation instructions.
 *
 * @remarks
 * This function orchestrates error detection and message building in prioritized order:
 *
 * 1. **Insufficient SOL** (highest priority): Detects when the wallet lacks sufficient
 *    SOL for ATA creation and transaction fees. Includes specific airdrop commands for devnet.
 *
 * 2. **Insufficient Token Balance**: Catches errors where the wallet lacks enough USDC
 *    or other SPL tokens to complete the transfer.
 *
 * 3. **Account Not Found**: Handles missing accounts (typically ATAs) with remediation steps.
 *
 * 4. **Generic Simulation Errors**: Catches all other errors with detailed logs and context.
 *
 * The method fetches wallet information once and reuses it across all error handlers
 * for efficiency. It calculates exact SOL requirements based on the transaction's
 * ATA creation needs.
 *
 * **Important**: This function always throws—it never returns normally.
 *
 * @example
 * ```typescript
 * import { Connection, Keypair } from '@solana/web3.js';
 * import { handleSimulationError } from '@circle-fin/adapter-solana';
 *
 * const connection = new Connection('https://api.devnet.solana.com');
 * const signer = Keypair.generate();
 * const params = { instructions: [...] };
 * const logs = ['Program log: insufficient lamports'];
 * const errorObj = { InsufficientFundsForRent: {} };
 *
 * try {
 *   await handleSimulationError(connection, signer, params, logs, errorObj);
 * } catch (err) {
 *   console.error(err.message); // User-friendly error with remediation steps
 * }
 * ```
 */ async function handleSimulationError(connection, signer, params, logs, errorObj) {
    // Fetch wallet info once for all error handlers
    const walletInfo = await getWalletInfo(connection, signer);
    // Calculate SOL requirements for this transaction
    const solRequirements = calculateRequiredSol(params);
    // Delegate to shared error handling logic
    throwSimulationError(walletInfo, solRequirements, logs, errorObj);
}

/**
 * Validates and deserializes a serialized transaction.
 *
 * Performs runtime validation and deserialization with comprehensive error handling.
 * Validates that the transaction is a valid VersionedTransaction (legacy or v0).
 *
 * @param serializedTransaction - The serialized transaction bytes
 * @returns The deserialized VersionedTransaction
 * @throws Error if validation or deserialization fails
 *
 * @example
 * ```typescript
 * import { validateAndDeserializeTransaction } from './validateSerializedTransaction'
 *
 * const versionedTx = validateAndDeserializeTransaction(serializedBytes)
 * ```
 */ function validateAndDeserializeTransaction(serializedTransaction) {
    // Runtime validation
    if (!serializedTransaction || serializedTransaction.length === 0) {
        throw new Error('serializedTransaction must be a non-empty Uint8Array');
    }
    // Deserialize with error handling
    try {
        const versionedTx = web3_js.VersionedTransaction.deserialize(serializedTransaction);
        // Validate transaction version (should be legacy or v0)
        if (versionedTx.version !== 'legacy' && versionedTx.version !== 0) {
            throw new Error(`Unsupported transaction version: ${String(versionedTx.version)}. Only legacy and v0 transactions are supported.`);
        }
        return versionedTx;
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        throw new Error(`Failed to deserialize serializedTransaction: ${errorMessage}`);
    }
}

/**
 * Resolves blockhash and lastValidBlockHeight for transaction confirmation.
 *
 * Uses the transaction's blockhash if available, otherwise fetches fresh blockhash.
 * Always fetches latest lastValidBlockHeight for accurate confirmation.
 *
 * @remarks
 * The transaction may have a stale blockhash, but we use it for confirmation.
 * If the blockhash is too stale, the transaction will fail on-chain, which is expected behavior.
 * We cannot refresh the blockhash without invalidating existing signatures in partially signed transactions.
 *
 * @param connection - The Solana Connection instance
 * @param versionedTx - The VersionedTransaction (may have stale blockhash)
 * @returns Promise resolving to blockhash and lastValidBlockHeight
 *
 * @example
 * ```typescript
 * import { resolveBlockhashForConfirmation } from './resolveBlockhashForConfirmation'
 *
 * const { blockhash, lastValidBlockHeight } = await resolveBlockhashForConfirmation(
 *   connection,
 *   versionedTx
 * )
 * ```
 */ async function resolveBlockhashForConfirmation(connection, versionedTx) {
    const messageBlockhash = versionedTx.message.recentBlockhash;
    const latestBlockhashInfo = await connection.getLatestBlockhash();
    // Use transaction's blockhash if available, otherwise use fresh one
    // Note: Transaction may have stale blockhash, but we use it for confirmation
    // The transaction will fail if blockhash is too stale, which is expected behavior
    const blockhash = messageBlockhash ? messageBlockhash.toString() : latestBlockhashInfo.blockhash;
    // Always use fresh lastValidBlockHeight for accurate confirmation
    return {
        blockhash,
        lastValidBlockHeight: latestBlockhashInfo.lastValidBlockHeight
    };
}

/**
 * Send and confirm a transaction using a provider-based signer.
 *
 * This function handles signing and sending transactions for provider-based signers
 * (e.g., browser wallet adapters like Phantom or Solflare). Provider-based signers
 * return a new signed transaction rather than modifying in place.
 *
 * @param params - The parameters for sending and confirming the transaction.
 * @returns The transaction signature.
 *
 * @throws Error if the signer is not a provider-based signer.
 * @throws Error if the transaction fails to confirm.
 *
 * @example
 * ```typescript
 * import { sendAndConfirmWithProvider } from './sendAndConfirmWithProvider';
 * import { Connection, VersionedTransaction } from '@solana/web3.js';
 *
 * const signature = await sendAndConfirmWithProvider({
 *   connection,
 *   signer: providerSigner,
 *   versionedTx,
 *   params,
 *   blockhash,
 *   lastValidBlockHeight
 * });
 * ```
 */ async function sendAndConfirmWithProvider(params) {
    const { connection, signer, versionedTx, params: requestParams, blockhash, lastValidBlockHeight, overrides } = params;
    // Type guard to ensure we have a provider signer
    if (!isProviderSigner(signer)) {
        throw new Error('Expected provider-based signer');
    }
    // For provider-based signers, signTransaction returns a NEW signed transaction
    // This preserves any existing signatures in the partially signed transaction
    // Cast is safe because we're passing a VersionedTransaction and get back the same type
    const signedVersionedTx = await signer.signTransaction(versionedTx);
    // Handle additional signers separately if needed
    // Note: sign() preserves existing signatures, so this is safe for partially signed transactions
    if (requestParams.signers && requestParams.signers.length > 0) {
        signedVersionedTx.sign(requestParams.signers);
    }
    // Send the signed transaction
    // Note: Some wallets may auto-submit during signTransaction, so we use skipPreflight
    // to avoid duplicate submission errors and set maxRetries to 0
    const signature = await connection.sendTransaction(signedVersionedTx, {
        preflightCommitment: overrides?.preflightCommitment ?? 'confirmed',
        maxRetries: 0,
        skipPreflight: true
    });
    // Wait for transaction confirmation
    const confirmation = await connection.confirmTransaction({
        signature,
        blockhash,
        lastValidBlockHeight,
        minContextSlot: undefined
    }, overrides?.preflightCommitment ?? 'confirmed');
    if (confirmation.value.err) {
        const errorDetails = JSON.stringify(confirmation.value.err);
        throw parseBlockchainError(new Error(`Transaction failed: ${errorDetails}`), {
            chain: 'Solana',
            operation: 'transaction'
        });
    }
    return signature;
}

/**
 * Send and confirm a transaction using a keypair-based signer.
 *
 * This function handles signing and sending transactions for keypair-based signers
 * (e.g., private key signers). Keypair-based signers modify the transaction in place
 * when signing.
 *
 * @param params - The parameters for sending and confirming the transaction.
 * @returns The transaction signature.
 *
 * @throws Error if the transaction fails to confirm.
 *
 * @example
 * ```typescript
 * import { sendAndConfirmWithKeypair } from './sendAndConfirmWithKeypair';
 * import { Connection, Keypair, VersionedTransaction } from '@solana/web3.js';
 *
 * const keypair = Keypair.generate();
 * const signature = await sendAndConfirmWithKeypair({
 *   connection,
 *   versionedTx,
 *   allSigners: [keypair],
 *   blockhash,
 *   lastValidBlockHeight
 * });
 * ```
 */ async function sendAndConfirmWithKeypair(params) {
    const { connection, versionedTx, allSigners, blockhash, lastValidBlockHeight, overrides } = params;
    // For private key-based signers, sign modifies in place
    // Note: sign() preserves existing signatures, so this works for partially signed transactions
    versionedTx.sign(allSigners);
    // Send the transaction
    const signature = await connection.sendTransaction(versionedTx, {
        preflightCommitment: overrides?.preflightCommitment ?? 'confirmed',
        maxRetries: overrides?.maxRetries ?? 3,
        skipPreflight: overrides?.skipPreflight ?? false
    });
    // Wait for transaction confirmation
    const confirmation = await connection.confirmTransaction({
        signature,
        blockhash,
        lastValidBlockHeight,
        minContextSlot: undefined
    }, overrides?.preflightCommitment ?? 'confirmed');
    if (confirmation.value.err) {
        const errorDetails = JSON.stringify(confirmation.value.err);
        throw parseBlockchainError(new Error(`Transaction failed: ${errorDetails}`), {
            chain: 'Solana',
            operation: 'transaction'
        });
    }
    return signature;
}

/**
 * JSON-RPC error codes.
 *
 * @see https://www.jsonrpc.org/specification#error_object
 */ const JSON_RPC_METHOD_NOT_FOUND = -32601;
/**
 * Default timeout for transaction confirmation in milliseconds.
 */ const DEFAULT_CONFIRMATION_TIMEOUT_MS = 60_000;
/**
 * Timeout for WebSocket capability check in milliseconds.
 */ const WEBSOCKET_CHECK_TIMEOUT_MS = 5000;
/**
 * Number of confirmations required for finalized commitment.
 *
 * Based on Solana's Tower BFT consensus, after ~32 slot confirmations,
 * the transaction achieves economic finality and cannot be rolled back.
 */ const FINALIZED_CONFIRMATION_COUNT = 32;
/**
 * Number of confirmations required for confirmed/processed commitment.
 */ const STANDARD_CONFIRMATION_COUNT = 1;
/**
 * JSON-RPC request ID for WebSocket capability checks.
 */ const JSON_RPC_REQUEST_ID = 1;
/**
 * Dummy signature used for testing WebSocket support.
 *
 * This is a properly formatted base58-encoded Solana signature (88 characters)
 * used to test if the RPC endpoint supports the signatureSubscribe method.
 * While this signature won't match any real transaction, it has the correct
 * format to pass initial validation checks.
 */ const DUMMY_SIGNATURE = '1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111';

/**
 * Cache to store WebSocket support status per RPC endpoint.
 * Key: RPC URL, Value: boolean (true = supports signatureSubscribe)
 */ const wsCapabilityCache = new Map();
/**
 * Check if a Solana RPC endpoint supports the signatureSubscribe WebSocket method.
 *
 * This function tests whether an RPC provider supports real-time transaction
 * confirmation via WebSocket subscriptions. Some providers (like Alchemy on lower
 * tiers) don't support this method, requiring fallback to HTTP polling.
 *
 * The result is cached per RPC URL to avoid repeated checks.
 *
 * @param rpcUrl - The HTTP RPC URL (will be converted to WebSocket URL automatically)
 * @returns Promise resolving to true if signatureSubscribe is supported, false otherwise
 *
 * @example
 * ```typescript
 * import { checkWebSocketSupport } from './checkWebSocketSupport'
 *
 * const rpcUrl = 'https://api.mainnet-beta.solana.com'
 * const supportsWs = await checkWebSocketSupport(rpcUrl)
 *
 * if (supportsWs) {
 *   console.log('Using WebSocket confirmation (faster)')
 * } else {
 *   console.log('Using HTTP polling (more compatible)')
 * }
 * ```
 */ async function checkWebSocketSupport(rpcUrl) {
    // Check cache first
    const cached = wsCapabilityCache.get(rpcUrl);
    if (cached !== undefined) {
        return cached;
    }
    // Convert HTTP(S) URL to WebSocket URL
    const wsUrl = rpcUrl.replace(/^http/, 'ws');
    return new Promise((resolve)=>{
        let ws;
        let settled = false;
        const settle = (supported)=>{
            if (settled) return;
            settled = true;
            clearTimeout(timeoutId);
            wsCapabilityCache.set(rpcUrl, supported);
            resolve(supported);
            try {
                ws.onerror = null;
                ws.onmessage = null;
                ws.onopen = null;
                ws.close();
            } catch  {
            // already closed or never opened
            }
        };
        // Set a timeout to prevent hanging
        const timeoutId = setTimeout(()=>{
            settle(false);
        }, WEBSOCKET_CHECK_TIMEOUT_MS);
        try {
            ws = new WebSocket(wsUrl);
            ws.onopen = ()=>{
                // Send a test signatureSubscribe request with a dummy signature
                ws.send(JSON.stringify({
                    jsonrpc: '2.0',
                    id: JSON_RPC_REQUEST_ID,
                    method: 'signatureSubscribe',
                    params: [
                        DUMMY_SIGNATURE,
                        {
                            commitment: 'confirmed'
                        }
                    ]
                }));
            };
            ws.onmessage = (msg)=>{
                try {
                    const data = JSON.parse(String(msg.data));
                    // Check if method is not found
                    if (data.error?.code === JSON_RPC_METHOD_NOT_FOUND) {
                        settle(false);
                    } else {
                        // Either got a successful result or an error other than "method not found"
                        // (other errors might be due to invalid params, but method exists)
                        settle(true);
                    }
                } catch  {
                    settle(false);
                }
            };
            ws.onerror = ()=>{
                settle(false);
            };
        } catch  {
            clearTimeout(timeoutId);
            wsCapabilityCache.set(rpcUrl, false);
            resolve(false);
        }
    });
}
/**
 * Clear the WebSocket capability cache.
 *
 * This function is useful for testing or when you want to force a re-check
 * of WebSocket support for an RPC endpoint.
 *
 * @param rpcUrl - Optional specific RPC URL to clear. If not provided, clears entire cache.
 * @returns void.
 *
 * @example
 * ```typescript
 * import { clearWebSocketCache } from './checkWebSocketSupport'
 *
 * // Clear specific endpoint
 * clearWebSocketCache('https://api.mainnet-beta.solana.com')
 *
 * // Clear all cached results
 * clearWebSocketCache()
 * ```
 */ function clearWebSocketCache(rpcUrl) {
    if (rpcUrl) {
        wsCapabilityCache.delete(rpcUrl);
    } else {
        wsCapabilityCache.clear();
    }
}

/**
 * Confirm a Solana transaction with automatic fallback from WebSocket to HTTP polling.
 *
 * This function attempts to use WebSocket-based confirmation first (faster) via
 * `connection.confirmTransaction()`. If the RPC provider doesn't support WebSocket
 * subscriptions (detected via error code -32601), it automatically falls back to
 * HTTP polling via `waitForTransaction()`.
 *
 * The WebSocket capability is cached per RPC endpoint to avoid repeated checks.
 *
 * @param params - The parameters for transaction confirmation
 * @returns Promise resolving to the transaction response with status and details
 *
 * @throws Error if the transaction fails to confirm within the timeout period
 *
 * @example
 * ```typescript
 * import { confirmTransactionWithFallback } from './confirmTransactionWithFallback'
 * import { Connection } from '@solana/web3.js'
 *
 * const connection = new Connection('https://api.mainnet-beta.solana.com')
 * const signature = 'transaction-signature-here'
 *
 * const result = await confirmTransactionWithFallback({
 *   connection,
 *   signature,
 *   blockhash: 'recent-blockhash',
 *   lastValidBlockHeight: 12345678,
 *   commitment: 'confirmed',
 *   timeout: 60_000,
 * })
 *
 * console.log('Transaction status:', result.status)
 * ```
 */ async function confirmTransactionWithFallback(params) {
    const { connection, signature, blockhash, lastValidBlockHeight, commitment = 'confirmed', timeout = DEFAULT_CONFIRMATION_TIMEOUT_MS } = params;
    // Get the RPC endpoint URL from the connection
    const rpcEndpoint = connection.rpcEndpoint;
    // Check if this RPC supports WebSocket subscriptions
    const supportsWebSocket = await checkWebSocketSupport(rpcEndpoint);
    if (supportsWebSocket) {
        try {
            // Try WebSocket-based confirmation (faster)
            const confirmation = await connection.confirmTransaction({
                signature,
                blockhash,
                lastValidBlockHeight,
                minContextSlot: undefined
            }, commitment);
            // Convert confirmTransaction response to WaitForTransactionResponse format
            // Gas fields are omitted as they're EVM-specific and not applicable to Solana
            return {
                txHash: signature,
                status: confirmation.value.err ? 'reverted' : 'success',
                blockNumber: BigInt(confirmation.context.slot),
                blockHash: blockhash,
                transactionIndex: 0
            };
        } catch (error) {
            // Check if error is due to WebSocket method not being supported
            const errorMessage = getErrorMessage(error);
            const errorCode = error?.code;
            // Check for JSON-RPC "Method not found" error (-32601) which indicates
            // the RPC doesn't support WebSocket subscriptions like signatureSubscribe.
            // Example error: { code: -32601, message: "Method 'signatureSubscribe' not found" }
            const isSignatureSubscribeUnsupported = errorCode === JSON_RPC_METHOD_NOT_FOUND || errorMessage.includes('signatureSubscribe');
            if (isSignatureSubscribeUnsupported) {
                // WebSocket not supported - fall through to HTTP polling
                // Update cache to reflect this
                clearWebSocketCache(rpcEndpoint);
            } else {
                // Different error - rethrow
                throw error;
            }
        }
    }
    // Use HTTP polling (works with all RPC providers)
    // For 'finalized' commitment, wait for 32 confirmations based on Solana's Tower BFT consensus.
    // After ~32 slot confirmations, the transaction has economic finality and cannot be rolled back.
    // For 'confirmed' or 'processed', 1 confirmation is sufficient.
    return waitForTransaction(connection, signature, {
        timeout,
        confirmations: commitment === 'finalized' ? FINALIZED_CONFIRMATION_COUNT : STANDARD_CONFIRMATION_COUNT
    });
}

/**
 * Simple wallet wrapper that works with AnchorProvider in all environments.
 *
 * This class provides a unified interface for both provider-based signers (e.g., browser wallets)
 * and keypair-based signers, making it compatible with AnchorProvider without requiring
 * the payer: Keypair constraint that would be incompatible with provider-based signers.
 *
 * @remarks
 * This wallet is used for Anchor instruction building, which does not require signing
 * at this stage. Actual signing is deferred to the adapter's `execute` method, which
 * uses the real signer. This design aligns with the `solana-kit` adapter's behavior
 * and avoids unnecessary signing during the instruction building phase.
 *
 * @example
 * ```typescript
 * import { Keypair } from '@solana/web3.js';
 * import { SimpleWallet } from './adapter';
 *
 * const keypair = Keypair.generate();
 * const wallet = new SimpleWallet(keypair);
 * console.log('Wallet address:', wallet.publicKey.toBase58());
 * ```
 */ class SimpleWallet {
    signer;
    /**
   * Create a new SimpleWallet instance.
   *
   * @param signer - The Solana signer (Keypair or provider-based signer).
   */ constructor(signer){
        this.signer = signer;
    }
    /**
   * The public key of the wallet.
   *
   * @returns The PublicKey associated with this wallet's signer.
   */ get publicKey() {
        return this.signer.publicKey;
    }
    /**
   * The fee payer public key for transactions.
   *
   * @returns The PublicKey that will pay for transaction fees.
   */ get payer() {
        return this.signer.publicKey;
    }
    /**
   * Sign a transaction (no-op for Anchor instruction building).
   *
   * @typeParam T - The transaction type (Transaction or VersionedTransaction).
   * @param tx - The transaction to sign.
   * @returns A Promise resolving to the unsigned transaction.
   *
   * @remarks
   * This wallet is used for Anchor instruction building, which does not require signing
   * at this stage. Actual signing is deferred to the adapter's `execute` method, which
   * uses the real signer. This design aligns with the `solana-kit` adapter's behavior
   * and avoids unnecessary signing during the instruction building phase.
   */ async signTransaction(tx) {
        // No-op: Return unsigned transaction
        // Actual signing happens in adapter.execute() using the real signer
        return Promise.resolve(tx);
    }
    /**
   * Sign multiple transactions (no-op for Anchor instruction building).
   *
   * @typeParam T - The transaction type (Transaction or VersionedTransaction).
   * @param txs - An array of transactions to sign.
   * @returns A Promise resolving to an array of unsigned transactions.
   *
   * @remarks
   * This wallet is used for Anchor instruction building, which does not require signing
   * at this stage. See `signTransaction` for details.
   */ async signAllTransactions(txs) {
        // No-op: Return unsigned transactions
        // Actual signing happens in adapter.execute() using the real signer
        return Promise.resolve(txs);
    }
}
/**
 * Parameters for building a Solana VersionedTransaction.
 */ /**
 * A `SolanaAdapter` implementation using `@solana/web3.js` for Solana blockchain interactions.
 *
 * This class encapsulates Solana-specific logic, using a `Connection` for reading data
 * and sending transactions, and a `Signer` for transaction signing. It provides
 * transaction fee estimation, preparation, and execution capabilities with full
 * OperationContext support for multi-chain operations.
 *
 *
 * @remarks
 * The constructor accepts a `@solana/web3.js` `Connection` and `Signer` and
 * provides methods like `prepare`, `getAddress`, etc., that utilize these
 * clients for blockchain interactions. Supports both user-controlled and
 * developer-controlled address contexts via capabilities configuration.
 *
 * @example
 * ```typescript
 * import { Connection, Keypair, PublicKey, SystemProgram } from '@solana/web3.js'
 * import { createSolanaAdapterFromPrivateKey } from '@circle-fin/adapter-solana'
 * import bs58 from 'bs58'
 *
 * async function main() {
 *   const connection = new Connection('https://api.devnet.solana.com')
 *   const signer = Keypair.fromSecretKey(bs58.decode('YOUR_BASE58_PRIVATE_KEY'))
 *
 *   // Prefer factories to construct adapters with correct capabilities
 *   const adapter = createSolanaAdapterFromPrivateKey({
 *     privateKey: bs58.encode(signer.secretKey),
 *     connection,
 *      capabilities optional – defaults to developer-controlled with Solana chains
 *   })
 *
 *   const address = await adapter.getAddress()
 *
 *   const prepared = await adapter.prepare({
 *     instructions: [
 *       SystemProgram.transfer({
 *         fromPubkey: signer.publicKey,
 *         toPubkey: new PublicKey('RECIPIENT_PUBLIC_KEY'), // Replace with a recipient's public key
 *         lamports: 1000000,
 *       }),
 *     ],
 *   });
 *
 *   const fee = await prepared.estimate();
 *   console.log('Estimated transaction fee (lamports):', fee);
 *
 *   const txSignature = await prepared.execute();
 *   console.log('Transaction executed:', txSignature);
 * }
 * ```
 */ class SolanaAdapter extends SolanaBaseAdapter {
    /**
   * Configuration options for this SolanaAdapter instance.
   */ options;
    /**
   * Cached Connection instances per chain for efficient multi-chain operations.
   * @remarks
   * Connections are cached using chain name as the key to enable seamless
   * switching between multiple Solana chains (mainnet, devnet, testnet) within
   * a single adapter instance.
   */ cachedConnections = new Map();
    /**
   * Cached Signer instances per chain.
   * @remarks
   * Signers are cached per chain for consistency with other adapters and to
   * support potential future chain-specific signer configurations, though
   * Solana signers are typically chain-agnostic.
   */ cachedSigners = new Map();
    /**
   * Cached AnchorProvider instances per chain.
   * @remarks
   * AnchorProviders combine connection + wallet and are chain-specific,
   * so we cache them per chain for efficient multi-chain operations.
   */ cachedAnchorProviders = new Map();
    /** Ongoing signer initialization promises to prevent duplicate initialization */ signerInitPromises = new Map();
    /**
   * Create a new SolanaAdapter instance for Solana blockchain interactions.
   *
   * This constructor creates an adapter using the OperationContext pattern, requiring
   * explicit capabilities configuration for type safety. It validates both the options
   * and capabilities at construction time to ensure proper configuration.
   *
   * @param options - Configuration options with connection and signer.
   * @param capabilities - Adapter capabilities defining address control and supported chains.
   * @throws Error when options validation fails.
   * @throws Error when capabilities validation fails.
   * @throws Error when capabilities.addressContext is not explicitly defined.
   * @throws Error when capabilities.supportedChains contains non-Solana chains.
   *
   * @example
   * ```typescript
   * import { createSolanaAdapterFromPrivateKey } from '@circle-fin/adapter-solana'
   * import { SolanaDevnet } from '@core/chains'
   *
   * const adapter = createSolanaAdapterFromPrivateKey({
   *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
   *   capabilities: {
   *     addressContext: 'user-controlled',
   *     supportedChains: [SolanaDevnet],
   *   },
   * })
   * ```
   */ constructor(options, capabilities){
        super();
        validateSolanaAdapterOptions(options);
        validateAdapterCapabilities(capabilities);
        this.capabilities = capabilities;
        this.options = options;
    }
    /**
   * Resets all cached state in the adapter, including Solana-specific caches.
   *
   * This method extends the base class resetState() to also clear Solana-specific
   * caches like connections, signers, and anchor providers. It ensures a clean state when
   * the adapter needs to be reinitialized (e.g., after chain or account changes).
   *
   * @override
   * @remarks
   * When the adapter state needs to be reset (e.g., user changes wallet accounts,
   * switches chains in a dramatic way, or the connection becomes stale), this method
   * clears all cached state to force re-initialization on next access.
   *
   * **What gets cleared:**
   * - Base class caches: `cachedAddress` and `cachedChain`
   * - Solana-specific caches: all connections, signers, and anchor providers
   *
   * @example
   * ```typescript
   * // Called automatically during certain chain switches
   * await adapter.switchToChain(SolanaDevnet)
   *
   * // Or called manually to clear all caches
   * adapter.resetState()
   *
   * // Next call will reinitialize
   * const connection = adapter.getConnection(Solana) // Creates new connection
   * ```
   */ resetState() {
        // Clear Solana-specific per-chain caches
        this.cachedConnections.clear();
        this.cachedSigners.clear();
        this.cachedAnchorProviders.clear();
    }
    /**
   * Generates a cache key from the operation context.
   *
   * @param ctx - The operation context to generate a key for.
   * @returns A string key for caching purposes.
   *
   * @remarks
   * The cache key is based on the chain name and address from the context.
   * This ensures signers are properly cached per unique context combination,
   * which is critical for developer-controlled adapters where the address
   * can vary per operation.
   */ generateSignerCacheKey(ctx) {
        const chainKey = typeof ctx.chain === 'string' ? ctx.chain : ctx.chain?.name ?? 'default';
        const addressKey = 'address' in ctx && ctx.address ? ctx.address : 'no-address';
        return `${chainKey}:${addressKey}`;
    }
    /**
   * Gets the validated Solana Connection instance with per-chain caching.
   *
   * @param chainDefinition - The chain definition for connection initialization (required).
   * @returns The validated {@link Connection} instance used for all blockchain operations.
   *
   * @remarks
   * This method ensures that the connection is always valid and up-to-date. It is used
   * internally by all methods that require network access. Connections are cached per
   * chain to enable efficient multi-chain operations.
   *
   * **Caching Strategy:**
   * - If a cached connection exists for the chain, it is returned immediately
   * - Otherwise, a new connection is created using `options.getConnection` or `options.connection`
   * - The connection is then cached using the chain name as the key
   * - Caches are cleared via `resetState()` when needed
   *
   * @example
   * ```typescript
   * import { Solana, SolanaDevnet } from '@core/chains'
   *
   * // Get connection for specific chain (lazy initialization)
   * const mainnetConn = adapter.getConnection(Solana)
   * const devnetConn = adapter.getConnection(SolanaDevnet)
   * // Each chain gets its own cached connection
   * ```
   */ getConnection(chainDefinition) {
        // Check cache first
        const cacheKey = chainDefinition.name;
        const cachedConnection = this.cachedConnections.get(cacheKey);
        if (cachedConnection) {
            return cachedConnection;
        }
        // Create new connection using helper (which handles options.connection and options.getConnection)
        const newConnection = getConnection(this.options, undefined, chainDefinition);
        // Cache for future use
        this.cachedConnections.set(cacheKey, newConnection);
        return newConnection;
    }
    /**
   * Gets the validated Solana Signer instance with context-aware caching.
   *
   * @param ctx - The operation context for signer initialization.
   * @returns A Promise resolving to the validated {@link Signer} instance.
   *
   * @remarks
   * This method supports both direct signer objects and lazy-initialized signers
   * (e.g., for hardware wallets or browser extensions). Signers are cached per
   * operation context to prevent redundant initialization. Multiple concurrent
   * calls with the same context will share the initialization promise.
   *
   * **Caching Strategy:**
   * - Signers are cached using both chain and address as cache key
   * - For developer-controlled adapters, different addresses get separate signers
   * - For user-controlled adapters, signers are cached per chain
   * - Promise-based deduplication prevents race conditions on concurrent calls
   *
   * @example
   * ```typescript
   * import { Solana } from '@core/chains'
   *
   * // Get signer (cached per context for consistency)
   * const signer = await adapter.getSigner({ chain: Solana })
   * ```
   */ async getSigner(ctx) {
        const cacheKey = this.generateSignerCacheKey(ctx);
        // Check cache first
        const cachedSigner = this.cachedSigners.get(cacheKey);
        if (cachedSigner) {
            return cachedSigner;
        }
        // Check for ongoing initialization
        const ongoingInit = this.signerInitPromises.get(cacheKey);
        if (ongoingInit) {
            return ongoingInit;
        }
        // Initialize with proper cleanup
        const initPromise = (async ()=>{
            try {
                const newSigner = await getSigner(this.options, ctx);
                // Cache success
                this.cachedSigners.set(cacheKey, newSigner);
                this.signerInitPromises.delete(cacheKey);
                return newSigner;
            } catch (error) {
                // Clear promise on error for retry capability
                this.signerInitPromises.delete(cacheKey);
                const errorMessage = error instanceof Error ? error.message : String(error);
                throw new Error(`Failed to initialize signer for context ${cacheKey}: ${errorMessage}`);
            }
        })();
        this.signerInitPromises.set(cacheKey, initPromise);
        return initPromise;
    }
    /**
   * Gets an AnchorProvider instance with per-chain caching.
   *
   * @param chainDefinition - The chain definition for initialization (required).
   * @returns The AnchorProvider instance for the specified chain.
   *
   * @remarks
   * Uses a simple wallet wrapper that works in all environments, avoiding Node.js-specific
   * dependencies. AnchorProviders are cached per chain since they combine a chain-specific
   * connection with a wallet. This enables efficient multi-chain operations where each chain
   * maintains its own provider instance.
   *
   * **Caching Strategy:**
   * - AnchorProviders are cached using chain name as the key
   * - Each chain gets its own provider with dedicated connection
   * - Caches are cleared via `resetState()` when switching or resetting
   *
   * @example
   * ```typescript
   * import { Solana, SolanaDevnet } from '@core/chains'
   *
   * // Get provider for specific chain
   * const mainnetProvider = await adapter.getAnchorProvider(Solana)
   * const devnetProvider = await adapter.getAnchorProvider(SolanaDevnet)
   * // Each chain has its own cached provider
   * ```
   */ async getAnchorProvider(ctx) {
        const chain = resolveChainIdentifier(ctx.chain);
        // Check cache first
        const cacheKey = chain.name;
        const cachedProvider = this.cachedAnchorProviders.get(cacheKey);
        if (cachedProvider) {
            return cachedProvider;
        }
        // Create new provider
        const connection = this.getConnection(chain);
        const signer = await this.getSigner(ctx);
        const wallet = new SimpleWallet(signer);
        // Type assertion is safe - SimpleWallet provides all required methods for AnchorProvider
        const newProvider = new anchor.AnchorProvider(connection, wallet, {
            preflightCommitment: 'confirmed',
            commitment: 'confirmed'
        });
        // Cache for future use
        this.cachedAnchorProviders.set(cacheKey, newProvider);
        return newProvider;
    }
    /**
   * Returns the effective blockhash for a transaction.
   *
   * @param connection - The Solana {@link Connection} instance used to fetch the latest blockhash if needed.
   * @param providedRecentBlockhash - (Optional) A recent blockhash to use for the transaction. If not provided, the latest blockhash will be fetched from the network.
   * @returns The blockhash string to be used in the transaction.
   *
   * @remarks
   * Blockhashes are required for transaction finality and replay protection. This method ensures a valid blockhash is always used.
   */ async getEffectiveBlockhash(connection, providedRecentBlockhash) {
        if (providedRecentBlockhash) return providedRecentBlockhash;
        const { blockhash } = await connection.getLatestBlockhash();
        return blockhash;
    }
    /**
   * Builds a Solana VersionedTransaction from the provided parameters.
   *
   * @param params - The {@link BuildVersionedTransactionParams} object containing all required and optional fields for constructing the transaction.
   *   - instructions: An array of {@link TransactionInstruction} objects representing the actions to be performed.
   *   - signer: The {@link Signer} responsible for authorizing the transaction.
   *   - feePayer: (Optional) The {@link PublicKey} of the account paying the transaction fee. Defaults to the signer's public key if not provided.
   *   - nonceInfo: (Optional) Durable nonce information for advanced transaction replay protection.
   *   - blockhash: The recent blockhash to use for the transaction.
   *   - computeUnitLimit: (Optional) The maximum number of compute units the transaction is allowed to consume.
   *   - addressLookupTableAccounts: (Optional) Address Lookup Table accounts for transaction compression.
   *
   * @returns The constructed {@link VersionedTransaction} ready for simulation or execution.
   *
   * @remarks
   * This method is used internally to ensure all transactions are constructed in a consistent, type-safe manner.
   * When Address Lookup Table accounts are provided, the transaction size is compressed by using
   * shorter indices instead of full 32-byte addresses for frequently-used accounts.
   */ buildVersionedTransaction(params) {
        const { instructions, signer, feePayer, nonceInfo, blockhash, computeUnitLimit, addressLookupTableAccounts } = params;
        const allInstructions = [
            ...instructions
        ];
        if (computeUnitLimit) {
            allInstructions.unshift(web3_js.ComputeBudgetProgram.setComputeUnitLimit({
                units: computeUnitLimit
            }));
        }
        const message = new web3_js.TransactionMessage({
            payerKey: feePayer ?? signer.publicKey,
            recentBlockhash: nonceInfo?.nonce ?? blockhash,
            instructions: allInstructions
        }).compileToV0Message(addressLookupTableAccounts);
        return new web3_js.VersionedTransaction(message);
    }
    /**
   * Estimates the transaction fee for a given set of instructions or serialized transaction.
   *
   * @param connection - The Solana Connection instance to use for estimation.
   * @param signer - The Signer instance to use for transaction signing.
   * @param params - The {@link SolanaPreparedChainRequestParams} object containing either transaction instructions or a serialized transaction.
   * @param overrides - (Optional) {@link SolanaEstimateOverrides} to customize compute unit limits or other estimation parameters.
   * @returns A Promise resolving to an {@link EstimatedGas} object, which includes the estimated gas, gas price, and total fee as a string.
   * @throws \{Error\} When connection.getFeeForMessage() fails.
   * @throws \{Error\} When blockhash retrieval fails.
   * @throws \{Error\} When serializedTransaction validation or deserialization fails.
   *
   * @remarks
   * This method supports two flows:
   * 1. **Instructions flow**: Builds a new transaction from provided instructions
   * 2. **Serialized transaction flow**: Uses a pre-built serialized transaction (which may be partially signed)
   *
   * The connection and signer are passed as parameters to avoid redundant calls to getConnection/getSigner.
   */ async estimate(connection, signer, params, overrides) {
        let versionedTx;
        if (params.serializedTransaction) {
            // Validate and deserialize the serialized transaction
            versionedTx = validateAndDeserializeTransaction(params.serializedTransaction);
        } else {
            // Build transaction from instructions (existing flow)
            // Validate instructions are present when not using serialized transaction
            assertInstructions(params);
            const { instructions, addressLookupTableAccounts } = params;
            const latestBlockhash = await this.getEffectiveBlockhash(connection, undefined);
            versionedTx = this.buildVersionedTransaction({
                instructions,
                signer,
                feePayer: signer.publicKey,
                nonceInfo: undefined,
                blockhash: latestBlockhash,
                // Use overrides computeUnitLimit if provided, otherwise fall back to params
                computeUnitLimit: overrides?.computeUnitLimit ?? params.computeUnitLimit,
                addressLookupTableAccounts
            });
        }
        const message = versionedTx.message;
        const fee = await connection.getFeeForMessage(message);
        const feeValue = fee?.value ? BigInt(fee.value) : 0n;
        return {
            gas: feeValue,
            gasPrice: 1n,
            fee: feeValue.toString()
        };
    }
    /**
   * Simulates the execution of a Solana transaction using the provided instructions and context, without actually broadcasting it to the network.
   *
   * @param connection - The Solana {@link Connection} instance used to communicate with the cluster.
   * @param signer - The {@link Signer} responsible for authorizing the transaction (typically the wallet or keypair).
   * @param params - The {@link SolanaPreparedChainRequestParams} object containing all transaction details (instructions, fee payer, nonce, etc.).
   * @throws KitError if simulation fails.
   *
   * @remarks
   * This method performs a pre-flight simulation of the transaction without submitting
   * it to the network, consuming no SOL and making no state changes. It's automatically
   * called before transaction execution to catch errors early.
   *
   * **Error Handling:**
   * When simulation fails, the method delegates to `handleSimulationError` which provides
   * intelligent error detection and user-friendly messages for common issues:
   * - Insufficient SOL for ATA creation and transaction fees
   * - Insufficient token (USDC) balance
   * - Missing accounts or ATAs
   * - Anchor program errors and constraint violations
   *
   * All error messages include wallet address, network information, and remediation steps.
   *
   * @example
   * ```typescript
   * await adapter.simulateTransaction(
   *   connection,
   *   signer,
   *   { instructions: [SystemProgram.transfer({ fromPubkey, toPubkey, lamports })], feePayer }
   * );
   * // If no error is thrown, the transaction is likely to succeed if sent.
   * ```
   */ async simulateTransaction(connection, signer, params) {
        let versionedTx;
        if (params.serializedTransaction) {
            // Validate and deserialize the serialized transaction
            versionedTx = validateAndDeserializeTransaction(params.serializedTransaction);
        } else {
            // Build transaction from instructions (existing flow)
            // Validate instructions are present when not using serialized transaction
            assertInstructions(params);
            const { instructions, addressLookupTableAccounts, computeUnitLimit } = params;
            const latestBlockhash = await this.getEffectiveBlockhash(connection, undefined);
            versionedTx = this.buildVersionedTransaction({
                instructions,
                signer,
                feePayer: signer.publicKey,
                nonceInfo: undefined,
                blockhash: latestBlockhash,
                computeUnitLimit,
                addressLookupTableAccounts
            });
        }
        const simulationConfig = {
            sigVerify: false,
            replaceRecentBlockhash: true
        };
        let simulationResult;
        try {
            simulationResult = await connection.simulateTransaction(versionedTx, simulationConfig);
        } catch (error) {
            // Wrap errors from simulateTransaction call itself
            throw parseBlockchainError(error, {
                chain: 'Solana',
                operation: 'simulation'
            });
        }
        if (simulationResult.value.err) {
            const logs = simulationResult.value.logs ?? [];
            const errorObj = simulationResult.value.err;
            await handleSimulationError(connection, signer, params, logs, errorObj);
        }
    }
    /**
   * Executes the prepared Solana transaction.
   *
   * @param connection - The Solana {@link Connection} instance used to send the transaction to the network.
   * @param signer - The {@link Signer} responsible for signing the transaction.
   * @param params - The {@link SolanaPreparedChainRequestParams} object containing all transaction details (instructions, fee payer, nonce, etc.).
   * @param overrides - (Optional) {@link SolanaExecuteOverrides} to customize execution parameters (e.g., preflight commitment, retries).
   * @returns A Promise resolving to the transaction signature string, which can be used to track the transaction on the blockchain.
   *
   * @throws Error with detailed message if pre-flight simulation fails (insufficient SOL, invalid state, etc.).
   * @throws Error if the transaction fails to confirm or is rejected by the network.
   *
   * @remarks
   * This method performs the complete transaction execution flow:
   *
   * 1. **Pre-flight Simulation**: Simulates the transaction to catch errors before submission
   * 2. **Transaction Signing**: Signs the transaction with the provided signer(s)
   * 3. **Network Submission**: Sends the signed transaction to the Solana network
   * 4. **Confirmation**: Waits for transaction confirmation based on commitment level
   *
   * The pre-flight simulation provides detailed, actionable error messages for common
   * issues like insufficient SOL for ATA creation or insufficient token balances.
   */ async execute(connection, signer, params, overrides) {
        // Simulate the transaction to catch errors before submission
        await this.simulateTransaction(connection, signer, params);
        try {
            // Handle serialized transaction flow
            if (params.serializedTransaction) {
                return await this.executeSerializedTransaction(connection, signer, params, overrides);
            }
            // Handle instructions flow
            return await this.executeInstructionsTransaction(connection, signer, params, overrides);
        } catch (error) {
            // If already a KitError (from earlier in the flow), don't re-wrap
            if (error instanceof KitError) {
                throw error;
            }
            // Wrap other errors during transaction execution
            throw parseBlockchainError(error, {
                chain: 'Solana',
                operation: 'transaction'
            });
        }
    }
    /**
   * Executes a pre-built serialized transaction.
   */ async executeSerializedTransaction(connection, signer, params, overrides) {
        if (!params.serializedTransaction) {
            throw createValidationFailedError('serializedTransaction', params.serializedTransaction, 'Serialized transaction is required but was not provided.');
        }
        const versionedTx = validateAndDeserializeTransaction(params.serializedTransaction);
        const { blockhash, lastValidBlockHeight } = await resolveBlockhashForConfirmation(connection, versionedTx);
        if (isProviderSigner(signer)) {
            return sendAndConfirmWithProvider({
                connection,
                signer,
                versionedTx,
                params,
                blockhash,
                lastValidBlockHeight,
                overrides
            });
        }
        const allSigners = [
            signer,
            ...params.signers ?? []
        ];
        return sendAndConfirmWithKeypair({
            connection,
            versionedTx,
            allSigners,
            blockhash,
            lastValidBlockHeight,
            overrides
        });
    }
    /**
   * Executes a transaction built from instructions.
   */ async executeInstructionsTransaction(connection, signer, params, overrides) {
        assertInstructions(params);
        const { instructions, addressLookupTableAccounts } = params;
        const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash();
        const versionedTx = this.buildVersionedTransaction({
            instructions,
            signer,
            feePayer: signer.publicKey,
            nonceInfo: undefined,
            blockhash,
            computeUnitLimit: overrides?.computeUnitLimit ?? params.computeUnitLimit,
            addressLookupTableAccounts
        });
        const allSigners = [
            signer,
            ...params.signers ?? []
        ];
        if (isProviderSigner(signer)) {
            return this.sendWithProviderSigner(connection, signer, versionedTx, params.signers, blockhash, lastValidBlockHeight, overrides);
        }
        return this.sendWithKeypairSigner(connection, versionedTx, allSigners, blockhash, lastValidBlockHeight, overrides);
    }
    /**
   * Signs and sends transaction using a provider-based signer (e.g., wallet adapter).
   */ async sendWithProviderSigner(connection, signer, versionedTx, additionalSigners, blockhash, lastValidBlockHeight, overrides) {
        // Provider signers return a NEW signed transaction
        const signedVersionedTx = await signer.signTransaction(versionedTx);
        // Handle additional signers if needed
        if (additionalSigners && additionalSigners.length > 0) {
            signedVersionedTx.sign(additionalSigners);
        }
        // Send with provider-specific settings (wallet may auto-submit)
        const signature = await connection.sendTransaction(signedVersionedTx, {
            preflightCommitment: overrides?.preflightCommitment ?? 'confirmed',
            maxRetries: 0,
            skipPreflight: true
        });
        return this.confirmAndValidate(connection, signature, blockhash, lastValidBlockHeight, overrides);
    }
    /**
   * Signs and sends transaction using a keypair-based signer.
   */ async sendWithKeypairSigner(connection, versionedTx, allSigners, blockhash, lastValidBlockHeight, overrides) {
        // Keypair signers sign in place
        versionedTx.sign(allSigners);
        const signature = await connection.sendTransaction(versionedTx, {
            preflightCommitment: overrides?.preflightCommitment ?? 'confirmed',
            maxRetries: overrides?.maxRetries ?? 3,
            skipPreflight: overrides?.skipPreflight ?? false
        });
        return this.confirmAndValidate(connection, signature, blockhash, lastValidBlockHeight, overrides);
    }
    /**
   * Confirms transaction and throws if reverted.
   */ async confirmAndValidate(connection, signature, blockhash, lastValidBlockHeight, overrides) {
        const txResponse = await confirmTransactionWithFallback({
            connection,
            signature,
            blockhash,
            lastValidBlockHeight,
            commitment: overrides?.preflightCommitment ?? 'confirmed',
            timeout: 60_000
        });
        if (txResponse.status === 'reverted') {
            throw parseBlockchainError(new Error(`Transaction failed: ${signature}`), {
                chain: 'Solana',
                operation: 'transaction'
            });
        }
        return signature;
    }
    /**
   * Prepares a Solana transaction for execution, including pre-flight simulation.
   *
   * @param params - The {@link SolanaPreparedChainRequestParams} object containing either transaction instructions or a serialized transaction.
   * @param ctx - The {@link OperationContext} containing the chain and address context for this operation.
   * @returns A Promise resolving to a {@link PreparedChainRequest} object, which exposes `estimate` and `execute` methods for the prepared transaction.
   *
   * @throws Error When neither instructions nor serializedTransaction is provided.
   * @throws Error When both instructions and serializedTransaction are provided (mutually exclusive).
   * @throws Error When the target chain is not a Solana chain.
   * @throws Error When OperationContext resolution fails or capabilities are not configured.
   * @throws Error When pre-flight simulation fails (transaction would revert on-chain).
   *
   * @remarks
   * This method supports two flows:
   * 1. **Instructions flow**: Builds a new transaction from provided instructions
   * 2. **Serialized transaction flow**: Uses a pre-built serialized transaction (e.g., from Jupiter)
   *
   * The two flows are mutually exclusive - provide either `instructions` or `serializedTransaction`, not both.
   *
   * @example
   * ```typescript
   * // Instructions flow
   * const adapter = new SolanaAdapter({ connection, signer });
   * const prepared = await adapter.prepare(
   *   {
   *     instructions: [instruction],
   *     feePayer: publicKey
   *   },
   *   { chain: SolanaMainnet }
   * );
   *
   * // Serialized transaction flow (e.g., from Jupiter)
   * const prepared = await adapter.prepare(
   *   {
   *     serializedTransaction: jupiterSwapTransaction
   *   },
   *   { chain: SolanaMainnet }
   * );
   * ```
   */ async prepare(params, ctx) {
        // Resolve the target chain from the operation context
        const targetChain = resolveChainIdentifier(ctx.chain);
        // Ensure we're on the correct chain (triggers lazy initialization if needed)
        await this.ensureChain(targetChain);
        // Get connection with chain for lazy initialization
        const connection = this.getConnection(targetChain);
        // Validate that the connection's network matches the target chain
        await validateNetworkConsistency(connection, targetChain);
        // Resolve the full operation context (address resolution happens here)
        const resolvedContext = await resolveOperationContext(this, ctx);
        if (!resolvedContext) {
            throw new Error('OperationContext resolution failed. Ensure the adapter has capabilities configured.');
        }
        // Get the signer for transaction signing
        const signer = await this.getSigner(ctx);
        // Validate mutual exclusivity: either instructions OR serializedTransaction, not both
        const hasInstructions = params.instructions && Array.isArray(params.instructions) && params.instructions.length > 0;
        const hasSerializedTx = params.serializedTransaction instanceof Uint8Array && params.serializedTransaction.length > 0;
        if (hasInstructions && hasSerializedTx) {
            throw new Error('Cannot provide both instructions and serializedTransaction. They are mutually exclusive.');
        }
        if (!hasInstructions && !hasSerializedTx) {
            throw new Error('Either instructions or serializedTransaction must be provided to prepare a Solana transaction.');
        }
        // If serializedTransaction is provided, validate it can be deserialized
        if (hasSerializedTx && params.serializedTransaction) {
            // This will throw if invalid
            validateAndDeserializeTransaction(params.serializedTransaction);
        }
        return {
            type: 'solana',
            estimate: async (overrides)=>{
                // Pass the connection and signer we already have
                return this.estimate(connection, signer, params, overrides);
            },
            execute: async (overrides)=>{
                return this.execute(connection, signer, params, overrides);
            }
        };
    }
    /**
   * Calculate the total transaction fee including compute cost and buffer for Solana.
   *
   * @param baseComputeUnits - The base compute units for the transaction. This represents the computational resources required by the transaction.
   * @param bufferBasisPoints - (Optional) The buffer to add as basis points (e.g., 500 = 5%). Defaults to 500 (5%). This helps account for fee fluctuations and ensures transaction success.
   * @returns A Promise resolving to an EstimatedGas object with:
   * - fee: Total fee in lamports as a string.
   * - gas: Base compute units as a bigint.
   * - gasPrice: Micro-lamports per compute unit as a bigint.
   *
   * @throws Throws an error if the network request fails or the fee calculation fails for any reason.
   *
   * @remarks
   * This method is useful for applications that want to display or pre-fund the expected transaction fee, including a safety margin.
   *
   * @example
   * ```typescript
   * const adapter = new SolanaAdapter({ connection, signer });
   *
   * // Calculate transaction fee with default 5% buffer
   * const fee = await adapter.calculateTransactionFee(200000n);
   * console.log('Transaction fee:', fee.fee, 'lamports');
   *
   * // Calculate transaction fee with custom 10% buffer
   * const feeWithCustomBuffer = await adapter.calculateTransactionFee(200000n, 1000n);
   * console.log('Transaction fee with custom buffer:', feeWithCustomBuffer.fee, 'lamports');
   * ```
   */ async calculateTransactionFee(baseComputeUnits, bufferBasisPoints = DEFAULT_BUFFER_BASIS_POINTS, chain) {
        // Get connection for the specified chain
        const connection = this.getConnection(chain);
        // Create a dummy keypair for fee estimation (no signing needed)
        const dummyKeypair = web3_js.Keypair.generate();
        try {
            // Get latest blockhash for the transaction
            const { blockhash } = await connection.getLatestBlockhash();
            const microLamportsPrice = 2000n // Default priority fee
            ;
            const instructions = [
                web3_js.ComputeBudgetProgram.setComputeUnitLimit({
                    units: Number(baseComputeUnits)
                }),
                web3_js.ComputeBudgetProgram.setComputeUnitPrice({
                    microLamports: Number(microLamportsPrice)
                })
            ];
            const message = new web3_js.TransactionMessage({
                payerKey: dummyKeypair.publicKey,
                recentBlockhash: blockhash,
                instructions
            }).compileToV0Message();
            // Get the fee for the message
            let fee;
            try {
                fee = await connection.getFeeForMessage(message);
            } catch (error) {
                const errorMessage = error instanceof Error ? error.message : String(error);
                throw new Error(`Failed to calculate transaction fee: ${errorMessage}`);
            }
            if (!fee?.value) {
                throw new Error('Failed to get fee for message');
            }
            // Base fee is for signatures, etc.
            const baseFee = BigInt(fee.value);
            // Priority fee is units * price (converted from micro-lamports)
            const priorityFee = baseComputeUnits * microLamportsPrice / 1_000_000n;
            const totalBaseCost = baseFee + priorityFee;
            // Add buffer
            const buffer = totalBaseCost * bufferBasisPoints / 10000n;
            const totalFee = totalBaseCost + buffer;
            return {
                fee: totalFee.toString(),
                gas: baseComputeUnits,
                gasPrice: microLamportsPrice
            };
        } catch (error) {
            if (error instanceof Error) {
                throw error // Re-throw errors we've already formatted
                ;
            }
            throw new Error(`Failed to calculate transaction fee: ${String(error)}`);
        }
    }
    /**
   * Retrieves the connected wallet address.
   *
   * @param chain - The chain to use for address resolution.
   * @returns A promise that resolves to the connected wallet address.
   * @throws When the wallet has no addresses available.
   * @throws When no chain is provided (should not happen with OperationContext pattern).
   * @example
   * ```typescript
   * import { Solana } from '@core/chains'
   *
   * const adapter = new SolanaAdapter({ connection, signer });
   * const address = await adapter.getAddress(Solana);
   * console.log('Adapter Address', address);
   * ```
   */ async getAddress(chain) {
        // Prevent calling getAddress on developer-controlled adapters
        if (this.capabilities?.addressContext === 'developer-controlled') {
            throw new Error('Cannot call getAddress() on developer-controlled adapters. Address must be provided explicitly in the operation context.');
        }
        // Chain parameter should now be provided by resolveOperationContext
        if (!chain) {
            throw new Error('Chain parameter is required for address resolution. This should be provided by the OperationContext pattern.');
        }
        const signer = await this.getSigner({
            chain
        });
        return signer.publicKey.toBase58();
    }
    /**
   * Switches the adapter to operate on the specified Solana chain.
   *
   * For Solana adapters, this is typically a no-op as Solana applications
   * usually don't switch between mainnet/devnet dynamically. All validation
   * is handled by the base class ensureChain method.
   *
   * @returns A promise that resolves immediately (no-op).
   */ async switchToChain() {
        // No-op: Solana applications typically don't switch networks dynamically
        // Different networks (mainnet/devnet) are usually handled by separate deployments
        return Promise.resolve();
    }
    /**
   * Reads the balance of a SPL token for a given wallet address.
   *
   * @param tokenMint - The token mint address to check balance for.
   * @param walletAddress - The wallet address to check the balance for.
   * @param chain - The Solana chain to query (required for connection).
   * @returns Promise resolving to the token balance as a string.
   *
   * @example
   * ```typescript
   * import { Solana } from '@core/chains'
   *
   * const balance = await adapter.readTokenBalance(
   *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC mint
   *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN', // Wallet address
   *   Solana // Chain context required
   * );
   * console.log(`Balance: ${balance}`); // e.g. "1000000" for 1 USDC
   * ```
   */ async readTokenBalance(tokenMint, walletAddress, chain) {
        const connection = this.getConnection(chain);
        // Create PublicKey objects for token mint and wallet address
        const tokenMintKey = new web3_js.PublicKey(tokenMint);
        const walletAddressKey = new web3_js.PublicKey(walletAddress);
        // Detect which token program owns this mint (Token vs Token-2022).
        // Token-2022 mints (e.g. PYUSD) require a different program ID for ATA derivation.
        const tokenProgramId = await detectTokenProgram(connection, tokenMintKey);
        // Derive the associated token account address with the correct program
        const associatedTokenAccount = getAssociatedTokenAddressSync(tokenMintKey, walletAddressKey, false, tokenProgramId);
        try {
            // Query the token account balance with 'confirmed' commitment for fresh data
            const balanceResponse = await connection.getTokenAccountBalance(associatedTokenAccount, 'confirmed');
            // Return the balance or '0' if account doesn't exist
            return balanceResponse.value?.amount ?? '0';
        } catch (error) {
            if (error instanceof Error && /could not find account/i.test(error.message)) {
                // If the account doesn't exist, return 0 (this is a valid state for a new account)
                return '0';
            }
            // Re-throw other errors
            throw error;
        }
    }
    /**
   * Checks if an account exists at the given address.
   *
   * @param address - The account address to check.
   * @param chain - The Solana chain to query (required for connection).
   * @returns Promise resolving to true if account exists, false otherwise.
   *
   * @example
   * ```typescript
   * import { Solana } from '@core/chains'
   *
   * const exists = await adapter.checkAccountExists(
   *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
   *   Solana
   * );
   * ```
   */ async checkAccountExists(address, chain) {
        const connection = this.getConnection(chain);
        try {
            const accountInfo = await connection.getAccountInfo(new web3_js.PublicKey(address));
            return accountInfo !== null;
        } catch  {
            // If there's an error fetching account info, assume it doesn't exist
            return false;
        }
    }
    /**
   * Reads the native SOL balance for a given address.
   *
   * @param address - The wallet address to check the balance for.
   * @param chain - The chain definition to fetch the balance from.
   * @returns Promise resolving to the balance in lamports as a bigint.
   * @throws Error when balance retrieval fails.
   *
   * @example
   * ```typescript
   * const balance = await adapter.readNativeBalance(
   *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN',
   *   Solana
   * )
   * console.log('Balance:', balance.toString(), 'lamports')
   * ```
   */ async readNativeBalance(address, chain) {
        const connection = this.getConnection(chain);
        try {
            const balance = await connection.getBalance(new web3_js.PublicKey(address));
            return BigInt(balance);
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            throw new KitError({
                ...RpcError.ENDPOINT_ERROR,
                recoverability: 'RETRYABLE',
                message: `Failed to get native SOL balance for ${address}: ${errorMessage}`,
                cause: {
                    trace: {
                        operation: 'readNativeBalance',
                        address,
                        chain: chain.name
                    }
                }
            });
        }
    }
    /**
   * Gets the associated token account address for a given mint and owner.
   *
   * @param mint - The token mint address.
   * @param owner - The owner's public key address.
   * @param chain - The Solana chain to query. Used to establish an RPC connection
   *   for detecting whether the mint belongs to the standard Token Program or
   *   Token-2022, which determines the correct ATA derivation.
   * @returns Promise resolving to the associated token account address.
   *
   * @remarks
   * This method makes a network call (`getAccountInfo`) to detect the mint's
   * owning program before deriving the ATA. Token-2022 mints (e.g. PYUSD)
   * require a different program ID for correct ATA derivation.
   *
   * **Performance:** Each invocation incurs one `getAccountInfo` round-trip.
   * Callers that resolve ATAs in bulk should consider caching results.
   *
   * @throws Throws if the RPC call fails (network timeout, rate limit, etc.)
   *   or if the mint/owner addresses are invalid.
   *
   * @example
   * ```typescript
   * import { Solana } from '@core/chains'
   *
   * const ata = await adapter.getAssociatedTokenAccount(
   *   'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC mint
   *   'DhzPkKCLJGHBZbs1AzmK2tRNLZkV8J3yWF3LuWMuKJpN', // Owner
   *   Solana
   * );
   * ```
   */ async getAssociatedTokenAccount(mint, owner, chain) {
        const connection = this.getConnection(chain);
        const mintKey = new web3_js.PublicKey(mint);
        const ownerKey = new web3_js.PublicKey(owner);
        const tokenProgramId = await detectTokenProgram(connection, mintKey);
        const ata = getAssociatedTokenAddressSync(mintKey, ownerKey, false, tokenProgramId);
        return ata.toBase58();
    }
    /**
   * Waits for a Solana transaction to be confirmed and returns the transaction details.
   *
   * @param txHash - The transaction signature (hash) to wait for. This is a base58-encoded string returned by the network when a transaction is submitted.
   * @param config - (Optional) {@link WaitForTransactionConfig} object specifying confirmation requirements, timeout, and transaction version.
   * @returns A Promise resolving to a {@link WaitForTransactionResponse} object containing transaction status, block info, gas usage, and more.
   *
   * @throws Throws an error if the transaction hash is invalid, the config parameters are invalid, the transaction is not found, or if network issues occur.
   *
   * @remarks
   * This method polls the blockchain until the specified transaction is confirmed with the required number of confirmations. It provides comprehensive transaction details once the transaction is finalized.
   *
   * @example
   * ```typescript
   * const adapter = new SolanaAdapter({ connection, signer });
   * const response = await adapter.waitForTransaction('4hpDKV9zXy...', {
   *   confirmations: 1,
   *   timeout: 30000,
   *   maxSupportedTransactionVersion: 0,
   * });
   * console.log('Transaction status:', response.status);
   * console.log('Block number:', response.blockNumber);
   * ```
   */ async waitForTransaction(txHash, config, chain) {
        // Use the chain parameter to get the correct connection
        return waitForTransaction(this.getConnection(chain), txHash, config);
    }
}

/**
 * Creates a Solana Keypair from a given private key string.
 *
 * This function supports multiple private key formats:
 * 1. Base58-encoded string
 * 2. Base64-encoded string
 * 3. JSON array of numbers representing the byte values of the secret key
 *
 * @param privateKey - The private key string in one of the supported formats.
 * @returns A Solana Keypair constructed from the provided secret key.
 * @throws Throws an error if the privateKey cannot be decoded in any supported format.
 */ function keypairFromPrivateKey(privateKey) {
    try {
        const secretKey = parsePrivateKeyToBytes(privateKey);
        // Keypair.fromSecretKey can handle both 32-byte and 64-byte keys correctly.
        return web3_js.Keypair.fromSecretKey(secretKey);
    } catch (error) {
        // Re-throw with a consistent, user-friendly error message.
        const message = error instanceof Error ? error.message : String(error);
        throw new Error(`Invalid private key format. Please provide a valid Base58, base64, or array format private key. Original error: ${message}`);
    }
}

/**
 * Create a SolanaAdapter from a private key.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a private key string. It automatically detects and handles multiple key formats
 * (Base58, Base64, or JSON array) and creates a connection to the appropriate Solana network.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain` (callers may pass `OperationContext.chain` if needed).
 *
 * @param options - Configuration options containing private key, optional connection, and optional capabilities
 * @returns A configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with environment variable (defaults: user-controlled, Solana chains)
 * const adapter = createSolanaAdapterFromPrivateKey({ privateKey: process.env.SOLANA_PRIVATE_KEY! })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = createSolanaAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override capabilities explicitly
 * const adapter = createSolanaAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */ function createSolanaAdapterFromPrivateKey({ privateKey, connection, capabilities }) {
    // Validate inputs and establish capabilities
    const resolvedCapabilities = createAdapterCapabilities('solana', capabilities);
    resolvedCapabilities.supportedChains.forEach((c)=>{
        resolveSolanaChainIdentifier(c.chain);
        validateCreateAdapterFromPrivateKeyParams({
            privateKey,
            chain: c.chain,
            connection
        });
    });
    // Validate that capabilities are appropriate for private key adapters
    // This is essential for JavaScript consumers who don't get TypeScript compilation errors
    if (resolvedCapabilities.addressContext === 'developer-controlled') {
        throw new Error('Private key adapters cannot use "developer-controlled" address context. ' + 'Private key adapters derive addresses from the private key and should use ' + '"user-controlled" address context instead. This prevents address mismatches ' + 'and ensures the adapter operates with the correct account.');
    }
    const bootstrapResolvedChain = resolvedCapabilities.supportedChains?.[0];
    if (!bootstrapResolvedChain) {
        throw new Error('supportedChains must contain at least one chain');
    }
    // Use provided connection or create default
    const keypair = keypairFromPrivateKey(privateKey);
    // Create shared cache for connections to enable per-chain caching
    const connectionCache = new Map();
    const adapterOptions = {
        signer: keypair,
        getConnection: ({ chain })=>{
            // Check cache first
            const cached = connectionCache.get(chain.name);
            if (cached) {
                return cached;
            }
            // Create new connection
            const newConnection = createConnection(chain);
            // Cache for future use
            connectionCache.set(chain.name, newConnection);
            return newConnection;
        },
        ...connection ? {
            connection
        } : {}
    };
    return new SolanaAdapter(adapterOptions, resolvedCapabilities);
}
/**
 * @deprecated Use {@link createSolanaAdapterFromPrivateKey} instead.
 *
 * Create a SolanaAdapter from a private key.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a private key string. It automatically detects and handles multiple key formats
 * (Base58, Base64, or JSON array) and creates a connection to the appropriate Solana network.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain` (callers may pass `OperationContext.chain` if needed).
 *
 * @param options - Configuration options containing private key, optional connection, and optional capabilities
 * @returns A configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with environment variable (defaults: user-controlled, Solana chains)
 * const adapter = createAdapterFromPrivateKey({ privateKey: process.env.SOLANA_PRIVATE_KEY! })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = createAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override capabilities explicitly
 * const adapter = createAdapterFromPrivateKey({
 *   privateKey: process.env.SOLANA_PRIVATE_KEY!,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */ const createAdapterFromPrivateKey = createSolanaAdapterFromPrivateKey;

/**
 * Create a SolanaAdapter from a Solana wallet provider.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a browser wallet provider like Phantom, Solflare, or Backpack. It handles
 * the wallet connection and creates a signer adapter that implements the Solana
 * Signer interface.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain`; OperationContext provides the chain per operation.
 *
 * OperationContext notes:
 * - The returned adapter supports the `OperationContext` pattern across actions.
 * - For user-controlled adapters, `ctx.address` is ignored (resolved from wallet).
 *
 * @param options - Configuration options for creating the adapter. Contains:
 *   - provider: The Solana wallet provider (e.g., window.solana)
 *   - connection: Optional pre-configured Connection instance
 *   - capabilities: Optional capabilities for addressContext and supportedChains
 * @returns A Promise that resolves to a configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with Phantom wallet (defaults: user-controlled, Solana chains; defaultChain is set)
 * const adapter = await createSolanaAdapterFromProvider({ provider: window.solana })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = await createSolanaAdapterFromProvider({
 *   provider: window.solana,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override supportedChains via capabilities (sets adapter.defaultChain to first entry)
 * const adapter = await createSolanaAdapterFromProvider({
 *   provider: window.solana,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */ async function createSolanaAdapterFromProvider({ provider, connection, capabilities }) {
    const resolvedCapabilities = createAdapterCapabilities('solana', capabilities);
    // Resolve and validate for consistency with core resolver; preserve originals
    resolvedCapabilities.supportedChains.forEach((c)=>{
        resolveSolanaChainIdentifier(c.chain);
        validateCreateAdapterFromProviderParams({
            provider,
            chain: c.chain,
            connection
        });
    });
    const bootstrapResolvedChain = resolvedCapabilities.supportedChains[0];
    if (!bootstrapResolvedChain) {
        throw new Error('supportedChains must contain at least one chain');
    }
    validateCreateAdapterFromProviderParams({
        provider,
        chain: bootstrapResolvedChain.chain,
        connection
    });
    // Connect to the wallet if not already connected
    if (!provider.isConnected) {
        await provider.connect();
    }
    // Ensure the wallet provides a public key after connection
    if (!provider.publicKey) {
        throw new Error('Wallet provider does not have a public key available. ' + 'Please ensure the wallet is properly connected and has granted permission to access the public key.');
    }
    // Create a provider signer that properly implements the ProviderSigner interface
    const providerSigner = {
        publicKey: new web3_js.PublicKey(provider.publicKey.toString()),
        // Provider signers don't have secret keys - return empty array for compatibility
        // This property should never be used for actual signing operations
        get secretKey () {
            return new Uint8Array(0) // Empty array indicates no secret key
            ;
        },
        // Mark this as a provider signer for proper detection
        isProviderSigner: true,
        // Delegate signing methods to the provider
        signTransaction: async (transaction)=>{
            const result = await provider.signTransaction(transaction);
            return result;
        },
        signAllTransactions: async (transactions)=>{
            if (provider.signAllTransactions) {
                const result = await provider.signAllTransactions(transactions);
                return result;
            }
            // Fallback to signing one by one
            const signedTransactions = [];
            for (const tx of transactions){
                const signedTx = await provider.signTransaction(tx);
                signedTransactions.push(signedTx);
            }
            return signedTransactions;
        },
        signMessage: async (message)=>{
            if (provider.signMessage) {
                return await provider.signMessage(message);
            }
            throw new Error('Message signing not supported by this wallet provider');
        }
    };
    // Create shared cache for connections to enable per-chain caching
    const connectionCache = new Map();
    const adapterOptions = {
        signer: providerSigner,
        getConnection: ({ chain })=>{
            // Check cache first
            const cached = connectionCache.get(chain.name);
            if (cached) {
                return cached;
            }
            // Create new connection
            const newConnection = createConnection(chain);
            // Cache for future use
            connectionCache.set(chain.name, newConnection);
            return newConnection;
        },
        ...connection ? {
            connection
        } : {}
    };
    return new SolanaAdapter(adapterOptions, resolvedCapabilities);
}
/**
 * @deprecated Use {@link createSolanaAdapterFromProvider} instead.
 *
 * Create a SolanaAdapter from a Solana wallet provider.
 *
 * This factory method provides a convenient way to create a Solana adapter
 * from a browser wallet provider like Phantom, Solflare, or Backpack. It handles
 * the wallet connection and creates a signer adapter that implements the Solana
 * Signer interface.
 *
 * @remarks
 * Capabilities and defaults:
 * - If `capabilities` is provided, it is validated and applied to the adapter.
 * - Otherwise, defaults to `{ addressContext: 'user-controlled', supportedChains: [resolvedChain] }`.
 * - Does not set `adapter.defaultChain`; OperationContext provides the chain per operation.
 *
 * OperationContext notes:
 * - The returned adapter supports the `OperationContext` pattern across actions.
 * - For user-controlled adapters, `ctx.address` is ignored (resolved from wallet).
 *
 * @param options - Configuration options for creating the adapter. Contains:
 *   - provider: The Solana wallet provider (e.g., window.solana)
 *   - connection: Optional pre-configured Connection instance
 *   - capabilities: Optional capabilities for addressContext and supportedChains
 * @returns A Promise that resolves to a configured SolanaAdapter instance
 *
 * @example
 * ```typescript
 * // Basic usage with Phantom wallet (defaults: user-controlled, Solana chains; defaultChain is set)
 * const adapter = await createAdapterFromProvider({ provider: window.solana })
 * ```
 *
 * @example
 * ```typescript
 * // With custom connection for production
 * const customConnection = new Connection('https://your-rpc.com', { commitment: 'confirmed' })
 * const adapter = await createAdapterFromProvider({
 *   provider: window.solana,
 *   connection: customConnection,
 * })
 * ```
 *
 * @example
 * ```typescript
 * // Override supportedChains via capabilities (sets adapter.defaultChain to first entry)
 * const adapter = await createAdapterFromProvider({
 *   provider: window.solana,
 *   capabilities: {
 *     addressContext: 'user-controlled',
 *     supportedChains: [SolanaDevnet]
 *   }
 * })
 * ```
 */ const createAdapterFromProvider = createSolanaAdapterFromProvider;

exports.SolanaAdapter = SolanaAdapter;
exports.createAdapterFromPrivateKey = createAdapterFromPrivateKey;
exports.createAdapterFromProvider = createAdapterFromProvider;
exports.createSolanaAdapterFromPrivateKey = createSolanaAdapterFromPrivateKey;
exports.createSolanaAdapterFromProvider = createSolanaAdapterFromProvider;
//# sourceMappingURL=index.cjs.map
